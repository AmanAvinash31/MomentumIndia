import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Container } from "@/components/site";
import { usePrefs } from "@/lib/prefs";
import {
  type SportingEvent,
  type EventsKPIs,
  type StateSummary,
  SPORT_CATEGORIES,
  ALL_36_STATES_AND_UTS,
} from "@/components/events/events-types";
import { EventsMap } from "@/components/events/events-map";
import { EventsCalendar } from "@/components/events/events-calendar";
import { EventsDirectory } from "@/components/events/events-directory";
import { EventsStateExplorer } from "@/components/events/events-state-explorer";
import { EventModal } from "@/components/events/events-modal";
import {
  MapPin,
  Calendar,
  List,
  BarChart3,
  Search,
  RotateCcw,
  Radio,
  Trophy,
  Flame,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function EventsPage() {
  const { theme } = usePrefs();

  // Active Mobile View: "map" | "calendar" | "list" | "analytics"
  const [mobileView, setMobileView] = useState<"map" | "calendar" | "list" | "analytics">("map");

  // Filters State
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [selectedState, setSelectedState] = useState<string>("All States & UTs");
  const [selectedLevel, setSelectedLevel] = useState<string>("All");
  const [selectedVerification, setSelectedVerification] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedMonth, setSelectedMonth] = useState<number>(1);

  // Selected Event for Modal
  const [activeModalEvent, setActiveModalEvent] = useState<SportingEvent | null>(null);

  // 1. Fetch Dynamic KPIs (100% from SQLite DB)
  const { data: kpisData } = useQuery<EventsKPIs>({
    queryKey: ["/api/events/summary"],
    queryFn: async () => {
      const res = await fetch("/api/events/summary");
      if (!res.ok) throw new Error("Failed to fetch KPIs");
      return res.json();
    },
    staleTime: 1000 * 30,
  });

  // 2. Fetch Events Directory (with unified filter parameters)
  const { data: eventsData, isLoading: eventsLoading } = useQuery<{
    events: SportingEvent[];
    total: number;
    telemetryTimestamp: string;
  }>({
    queryKey: [
      "/api/events",
      selectedCategory,
      selectedState,
      selectedLevel,
      selectedVerification,
      searchQuery,
    ],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedCategory !== "All") params.set("category", selectedCategory);
      if (selectedState !== "All States & UTs") params.set("state", selectedState);
      if (selectedLevel !== "All") params.set("level", selectedLevel);
      if (selectedVerification !== "All") params.set("verification", selectedVerification);
      if (searchQuery.trim()) params.set("search", searchQuery.trim());
      params.set("limit", "1000");

      const res = await fetch(`/api/events?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch events");
      return res.json();
    },
    staleTime: 1000 * 20,
  });

  // 3. Fetch State Summaries
  const { data: statesData } = useQuery<{
    states: StateSummary[];
    totalStatesCovered: number;
  }>({
    queryKey: ["/api/events/states"],
    queryFn: async () => {
      const res = await fetch("/api/events/states");
      if (!res.ok) throw new Error("Failed to fetch state summaries");
      return res.json();
    },
    staleTime: 1000 * 60,
  });

  const events = eventsData?.events || [];
  const states = statesData?.states || [];

  // 2026 at a glance (computed from the currently filtered list): month
  // density, the four flagship Games, and the next event still to come.
  const monthCounts = Array.from({ length: 12 }, (_, i) =>
    events.filter((e) => Number(e.start_date.slice(5, 7)) === i + 1).length
  );
  const maxMonth = Math.max(1, ...monthCounts);
  const MONTH_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const FLAGSHIP_IDS = [
    "icc-mens-t20-world-cup-2026",
    "glasgow-commonwealth-games-2026",
    "asian-games-2026",
    "asian-para-games-2026",
  ];
  const flagships = FLAGSHIP_IDS.map((id) => events.find((e) => e.event_id === id)).filter(
    (e): e is typeof events[number] => !!e
  );
  const todayStr = new Date().toISOString().slice(0, 10);
  const nextUp = [...events]
    .filter((e) => e.end_date >= todayStr)
    .sort((a, b) => a.start_date.localeCompare(b.start_date))[0];
  const scrollToCalendar = (month: number) => {
    setSelectedMonth(month);
    document.getElementById("events-calendar")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleResetFilters = () => {
    setSelectedCategory("All");
    setSelectedState("All States & UTs");
    setSelectedLevel("All");
    setSelectedVerification("All");
    setSearchQuery("");
    setSelectedMonth(1);
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] pb-20 overflow-x-hidden">
      <Container className="pt-6 sm:pt-8 space-y-6 sm:space-y-8">
        {/* ========================================================
            PART 3: UNIFIED SPORTS INTELLIGENCE HEADER
            (Live Dynamic KPI Stat Cards right alongside the title,
             zero faded trophy icon, borderless #131926 cards)
            ======================================================== */}
        <div className="relative isolate overflow-hidden rounded-3xl bg-[var(--surface)] p-6 sm:p-8 md:p-10 border-none shadow-2xl">
          {/* Ambient Lighting */}
          <div className="absolute top-0 right-0 -z-10 h-72 w-72 rounded-full bg-orange-500/10 blur-[90px] pointer-events-none" />
          <div className="absolute bottom-0 left-0 -z-10 h-72 w-72 rounded-full bg-blue-500/10 blur-[90px] pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Title & Dek (Left Column) */}
            <div className="lg:col-span-6 space-y-3.5">
              <div className="inline-flex items-center gap-2 rounded-full bg-orange-500/10 px-3.5 py-1 text-xs font-bold text-orange-400 border-none">
                <Radio className="h-3.5 w-3.5 animate-pulse text-orange-500" />
                <span>National Sports Intelligence</span>
              </div>

              <h1 className="font-display text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-[var(--text)] leading-[1.05]">
                India Sports Events 2026
              </h1>

              <p className="text-sm sm:text-base text-[var(--text-muted)] leading-relaxed max-w-xl">
                Comprehensive directory, interactive national map, and multi-source telemetry calendar covering all 28 States and 8 Union Territories.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-1 text-xs font-semibold text-[var(--text-muted)]">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 border-none">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Live Multi-Source Telemetry Active
                </span>
                <span>Auto-refreshed every 6 hrs · SAI, IOA & News Wires</span>
              </div>
            </div>

            {/* 4 Dynamic KPI Stat Cards Right Alongside the Title (Right Column) */}
            <div className="lg:col-span-6 grid grid-cols-2 gap-3.5">
              {/* 1. Total 2026 Events */}
              <div className="rounded-xl bg-[var(--surface-2)] p-4 flex flex-col justify-between border-none shadow-sm transition-all hover:bg-[var(--surface-hover)]">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                    Total 2026 Events
                  </span>
                  <span className="p-1.5 rounded-lg bg-orange-500/15 text-orange-400">
                    <Calendar className="h-4 w-4" />
                  </span>
                </div>
                <div className="mt-3">
                  <p className="font-display text-2xl sm:text-3xl font-extrabold text-[var(--text)] tracking-tight">
                    {kpisData?.totalUnique ?? events.length}
                  </p>
                  <p className="text-[11px] text-[var(--text-muted)] mt-0.5 truncate">Across 2026 Calendar</p>
                </div>
              </div>

              {/* 2. States & UTs Covered */}
              <div className="rounded-xl bg-[var(--surface-2)] p-4 flex flex-col justify-between border-none shadow-sm transition-all hover:bg-[var(--surface-hover)]">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                    States & UTs Covered
                  </span>
                  <span className="p-1.5 rounded-lg bg-purple-500/15 text-purple-400">
                    <MapPin className="h-4 w-4" />
                  </span>
                </div>
                <div className="mt-3">
                  <p className="font-display text-2xl sm:text-3xl font-extrabold text-[var(--text)] tracking-tight">
                    {kpisData?.statesRepresented ?? 36} / 36
                  </p>
                  <p className="text-[11px] text-[var(--text-muted)] mt-0.5 truncate">100% Pan-India Reach</p>
                </div>
              </div>

              {/* 3. National Championships */}
              <div className="rounded-xl bg-[var(--surface-2)] p-4 flex flex-col justify-between border-none shadow-sm transition-all hover:bg-[var(--surface-hover)]">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                    National Championships
                  </span>
                  <span className="p-1.5 rounded-lg bg-blue-500/15 text-blue-400">
                    <Trophy className="h-4 w-4" />
                  </span>
                </div>
                <div className="mt-3">
                  <p className="font-display text-2xl sm:text-3xl font-extrabold text-[var(--text)] tracking-tight">
                    {kpisData?.national ?? events.filter(e => e.competition_level === "National").length}
                  </p>
                  <p className="text-[11px] text-[var(--text-muted)] mt-0.5 truncate">
                    {kpisData?.international ?? events.filter(e => e.competition_level === "International").length} International
                  </p>
                </div>
              </div>

              {/* 4. Upcoming Events */}
              <div className="rounded-xl bg-[var(--surface-2)] p-4 flex flex-col justify-between border-none shadow-sm transition-all hover:bg-[var(--surface-hover)]">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                    Upcoming Events
                  </span>
                  <span className="p-1.5 rounded-lg bg-emerald-500/15 text-emerald-400">
                    <Flame className="h-4 w-4" />
                  </span>
                </div>
                <div className="mt-3">
                  <p className="font-display text-2xl sm:text-3xl font-extrabold text-[var(--text)] tracking-tight">
                    {kpisData?.upcoming ?? events.length}
                  </p>
                  <p className="text-[11px] text-[var(--text-muted)] mt-0.5 truncate">
                    {kpisData?.ongoing ?? 0} Currently Live
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================
            2026 AT A GLANCE: flagship Games + year density strip
            Bars are clickable: they jump to that month in the calendar.
            ======================================================== */}
        <div className="rounded-2xl bg-[var(--surface)] p-4 sm:p-6 shadow-sm border-none space-y-5">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-orange-400">
                The Year In One View
              </span>
              <h2 className="font-display text-xl sm:text-2xl font-extrabold text-[var(--text)] mt-0.5">
                2026 at a glance
              </h2>
            </div>
            {nextUp && (
              <p className="text-xs font-semibold text-[var(--text-muted)]">
                Next up:{" "}
                <button
                  onClick={() => setActiveModalEvent(nextUp)}
                  className="text-orange-400 font-bold hover:underline cursor-pointer border-none bg-transparent p-0"
                >
                  {nextUp.event_name}
                </button>{" "}
                · {nextUp.start_date}
              </p>
            )}
          </div>

          {/* Flagship Games cards */}
          {flagships.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {flagships.map((ev) => (
                <button
                  key={ev.event_id}
                  onClick={() => setActiveModalEvent(ev)}
                  className="text-left rounded-xl bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] p-4 transition-colors border-none cursor-pointer group"
                >
                  <span className="text-[11px] font-bold uppercase tracking-wider text-orange-400">
                    {ev.sport}
                  </span>
                  <span className="font-display text-base font-extrabold text-[var(--text)] group-hover:text-orange-400 transition-colors block mt-1 leading-snug">
                    {ev.event_name}
                  </span>
                  <span className="text-xs text-[var(--text-muted)] block mt-1">
                    {ev.city}, {ev.country} · {ev.start_date} to {ev.end_date}
                  </span>
                  <span className="text-xs text-[var(--text-muted)] block mt-2 leading-relaxed line-clamp-3">
                    {ev.event_description}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Month density strip */}
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)] mb-2">
              Events by month — tap a month to open it in the calendar
            </p>
            <div className="flex items-end gap-1.5 sm:gap-2" role="group" aria-label="Events per month">
              {monthCounts.map((count, i) => (
                <button
                  key={MONTH_SHORT[i]}
                  onClick={() => scrollToCalendar(i + 1)}
                  title={`${MONTH_SHORT[i]} 2026: ${count} events`}
                  className="flex-1 flex flex-col items-center gap-1.5 group cursor-pointer border-none bg-transparent p-0"
                >
                  <span className="text-[11px] font-bold text-[var(--text)]">{count}</span>
                  <span
                    className="w-full rounded-t-md bg-orange-500/80 group-hover:bg-orange-500 transition-colors"
                    style={{ height: `${Math.max(6, Math.round((count / maxMonth) * 64))}px` }}
                  />
                  <span className="text-[10px] font-bold text-[var(--text-muted)]">{MONTH_SHORT[i]}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* ========================================================
            PART 3: BORDERLESS FILTER & SEARCH BAR
            (All outlines removed, bg-[var(--surface-2)], text-[var(--text)], rounded-xl)
            ======================================================== */}
        <div className="rounded-2xl bg-[var(--surface)] p-4 sm:p-5 shadow-sm border-none space-y-4">
          {/* Category Chips Bar (Horizontally scrollable with soft borderless fills) */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
            {SPORT_CATEGORIES.map((cat) => {
              const active = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={cn(
                    "tap-target px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all shrink-0 border-none cursor-pointer",
                    active
                      ? "bg-orange-500 text-[var(--text)] shadow-md font-extrabold"
                      : "bg-white/[0.05] hover:bg-white/[0.09] text-[var(--text-muted)]"
                  )}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {/* Secondary Controls: Search, State, Level, Verification Dropdowns */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--text-muted)] pointer-events-none" />
              <input
                type="text"
                placeholder="Search stadium, city, athlete, sport..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="tap-target w-full pl-9 pr-4 py-2.5 rounded-xl bg-[var(--surface-2)] text-xs font-medium text-[var(--text)] border-none outline-none focus:ring-0 placeholder:text-[var(--text-muted)]"
              />
            </div>

            {/* State/UT Dropdown (36 units) */}
            <div className="relative">
              <select
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                className="tap-target w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] text-xs font-bold text-[var(--text)] border-none outline-none focus:ring-0 cursor-pointer"
              >
                {ALL_36_STATES_AND_UTS.map((st) => (
                  <option key={st} value={st} className="bg-[var(--surface)] text-[var(--text)]">
                    {st}
                  </option>
                ))}
              </select>
            </div>

            {/* Competition Level Dropdown */}
            <div className="relative">
              <select
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="tap-target w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] text-xs font-bold text-[var(--text)] border-none outline-none focus:ring-0 cursor-pointer"
              >
                <option value="All" className="bg-[var(--surface)] text-[var(--text)]">All Competition Levels</option>
                <option value="International" className="bg-[var(--surface)] text-[var(--text)]">International</option>
                <option value="National" className="bg-[var(--surface)] text-[var(--text)]">National</option>
                <option value="State" className="bg-[var(--surface)] text-[var(--text)]">State</option>
                <option value="Mass-Participation" className="bg-[var(--surface)] text-[var(--text)]">Mass-Participation</option>
              </select>
            </div>

            {/* Verification Status & Reset Button */}
            <div className="flex items-center gap-2">
              <select
                value={selectedVerification}
                onChange={(e) => setSelectedVerification(e.target.value)}
                className="tap-target flex-1 px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] text-xs font-bold text-[var(--text)] border-none outline-none focus:ring-0 cursor-pointer"
              >
                <option value="All" className="bg-[var(--surface)] text-[var(--text)]">All Verification Badges</option>
                <option value="CONFIRMED" className="bg-[var(--surface)] text-[var(--text)]">CONFIRMED</option>
                <option value="CROSS-VERIFIED" className="bg-[var(--surface)] text-[var(--text)]">CROSS-VERIFIED</option>
                <option value="PARTIALLY VERIFIED" className="bg-[var(--surface)] text-[var(--text)]">PARTIALLY VERIFIED</option>
              </select>

              <button
                onClick={handleResetFilters}
                className="tap-target px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] text-[var(--text-muted)] hover:text-[var(--text)] text-xs font-bold shrink-0 transition-colors border-none cursor-pointer"
                title="Reset all filters"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* ========================================================
            PART 5: MOBILE STICKY SEGMENTED SWITCHER (< 768px)
            (Map | Calendar | Directory | Analytics)
            ======================================================== */}
        <div className="md:hidden sticky top-14 z-30 -mx-4 px-4 py-2 bg-[var(--bg)]/95 backdrop-blur-md">
          <div className="grid grid-cols-4 gap-1 rounded-xl bg-[var(--surface)] p-1 shadow-sm border-none">
            <button
              onClick={() => setMobileView("map")}
              className={cn(
                "tap-target rounded-lg text-xs font-bold flex flex-col items-center justify-center gap-0.5 transition-colors border-none py-1.5 cursor-pointer",
                mobileView === "map"
                  ? "bg-orange-500 text-[var(--text)] font-extrabold shadow-sm"
                  : "text-[var(--text-muted)] hover:text-[var(--text)]"
              )}
            >
              <MapPin className="h-3.5 w-3.5" />
              <span>Map</span>
            </button>
            <button
              onClick={() => setMobileView("calendar")}
              className={cn(
                "tap-target rounded-lg text-xs font-bold flex flex-col items-center justify-center gap-0.5 transition-colors border-none py-1.5 cursor-pointer",
                mobileView === "calendar"
                  ? "bg-orange-500 text-[var(--text)] font-extrabold shadow-sm"
                  : "text-[var(--text-muted)] hover:text-[var(--text)]"
              )}
            >
              <Calendar className="h-3.5 w-3.5" />
              <span>Calendar</span>
            </button>
            <button
              onClick={() => setMobileView("list")}
              className={cn(
                "tap-target rounded-lg text-xs font-bold flex flex-col items-center justify-center gap-0.5 transition-colors border-none py-1.5 cursor-pointer",
                mobileView === "list"
                  ? "bg-orange-500 text-[var(--text)] font-extrabold shadow-sm"
                  : "text-[var(--text-muted)] hover:text-[var(--text)]"
              )}
            >
              <List className="h-3.5 w-3.5" />
              <span>Directory</span>
            </button>
            <button
              onClick={() => setMobileView("analytics")}
              className={cn(
                "tap-target rounded-lg text-xs font-bold flex flex-col items-center justify-center gap-0.5 transition-colors border-none py-1.5 cursor-pointer",
                mobileView === "analytics"
                  ? "bg-orange-500 text-[var(--text)] font-extrabold shadow-sm"
                  : "text-[var(--text-muted)] hover:text-[var(--text)]"
              )}
            >
              <BarChart3 className="h-3.5 w-3.5" />
              <span>Analytics</span>
            </button>
          </div>
        </div>

        {/* VIEW CONTAINER */}
        <div className="space-y-10">
          {/* Section 1: National Interactive Map (PART 2) */}
          <div className={mobileView === "map" ? "block" : "hidden md:block"}>
            <div className="mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-400">
                Geographic Telemetry
              </span>
              <h3 className="font-display text-xl sm:text-2xl font-extrabold text-[var(--text)]">
                National Interactive Map
              </h3>
            </div>
            <EventsMap
              events={events}
              theme={theme}
              onSelectEvent={(ev) => setActiveModalEvent(ev)}
            />
          </div>

          {/* Section 2: Interactive 2026 Event Calendar (PART 3) */}
          <div id="events-calendar" className={mobileView === "calendar" ? "block" : "hidden md:block"}>
            <div className="mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-400">
                Championship Timeline
              </span>
              <h3 className="font-display text-xl sm:text-2xl font-extrabold text-[var(--text)]">
                2026 Interactive Calendar & Schedules
              </h3>
            </div>
            <EventsCalendar
              events={events}
              onSelectEvent={(ev) => setActiveModalEvent(ev)}
              selectedMonth={selectedMonth}
              onMonthChange={(m) => setSelectedMonth(m)}
            />
          </div>

          {/* Section 3: Paginated National Event Directory (PART 4) */}
          <div className={mobileView === "list" ? "block" : "hidden md:block"}>
            <EventsDirectory
              events={events}
              onSelectEvent={(ev) => setActiveModalEvent(ev)}
              loading={eventsLoading}
            />
          </div>

          {/* Section 4: State-by-State Explorer & Visual Analytics */}
          <div className={mobileView === "analytics" ? "block" : "hidden md:block"}>
            <EventsStateExplorer
              states={states}
              onSelectState={(stateName) => setSelectedState(stateName)}
              onSelectEvent={(ev) => setActiveModalEvent(ev)}
            />
          </div>
        </div>
      </Container>

      {/* Event Intelligence Modal */}
      <EventModal
        event={activeModalEvent}
        open={!!activeModalEvent}
        onClose={() => setActiveModalEvent(null)}
      />
    </div>
  );
}

export default EventsPage;
