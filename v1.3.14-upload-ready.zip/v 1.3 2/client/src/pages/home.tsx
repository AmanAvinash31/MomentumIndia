import { useState, useMemo, lazy, Suspense } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, CalendarDays, Clock, MapPin, Zap, Trophy, Newspaper, Award, BarChart3, Sparkles, RefreshCw } from "lucide-react";
import { ARTICLES, LEAD, IMG, OLY, CWG, ASIAN, sumEditions, total, TALLY_ALL_ASIAN, PEOPLE, mergeAthletes, personMedals, HALL, fmtDate, readTime, GAMES, type Edition, type Article } from "@/data";
import { Container, Img, Kicker, SectionHead, MoreLink, MedalTriplet, CountUp, useCountdown, Tabs } from "@/components/site";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import { FollowButton } from "@/components/action-buttons";
import { getEventStatus, formatDateRangeIST } from "@shared/lifecycle";

const EditionChart = lazy(() => import("@/components/charts").then(m => ({ default: m.EditionChart })));
const EditionSheet = lazy(() => import("@/components/charts").then(m => ({ default: m.EditionSheet })));
const RiseBand = lazy(() => import("@/pages/rise").then(m => ({ default: m.RiseBand })));
const PlusBand = lazy(() => import("@/pages/plus").then(m => ({ default: m.PlusBand })));
const NationBand = lazy(() => import("@/pages/nation").then(m => ({ default: m.NationBand })));
const LiveStrip = lazy(() => import("@/pages/live").then(m => ({ default: m.LiveStrip })));

function timeAgo(dateStr?: string | null): string {
  if (!dateStr) return "";
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return "";
  const diff = Math.max(0, Date.now() - d.getTime());
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Just now";
  if (mins === 1) return "1 min ago";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs === 1) return "1 hr ago";
  if (hrs < 24) return `${hrs} hrs ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export const localized = (a: Article, lang: string) => (lang !== "en" && (a as any)[lang] ? { ...a, ...(a as any)[lang] } : a);

export function StoryCard({ a, size = "md", className }: { a: Article; size?: "lg" | "md" | "sm"; className?: string }) {
  const l = a;
  if (size === "sm") return (
    <Link href={`/news/${a.slug}`} data-testid={`card-story-${a.slug}`} className={cn("group flex gap-4", className)}>
      <span className="relative h-20 w-28 shrink-0 overflow-hidden rounded-md"><Img src={a.img} alt="" className="transition-transform duration-700 group-hover:scale-105" /></span>
      <span className="min-w-0">
        <span className="text-xs font-bold uppercase tracking-[0.1em]" style={{ color: GAMES[a.g]?.color }}>{GAMES[a.g]?.short}</span>
        <span className="mt-1 line-clamp-3 block font-bold leading-snug group-hover:text-primary">{l.title}</span>
      </span>
    </Link>
  );
  return (
    <Link href={`/news/${a.slug}`} data-testid={`card-story-${a.slug}`} className={cn("group block", className)}>
      <span className={cn("relative block overflow-hidden rounded-lg", size === "lg" ? "aspect-[16/10]" : "aspect-[16/10]")}>
        <Img src={a.img} alt="" className="transition-transform duration-700 group-hover:scale-105" />
        <span className="absolute left-3 top-3 rounded-full bg-ink/80 px-2.5 py-1 text-[0.7rem] font-bold uppercase tracking-[0.1em] text-paper backdrop-blur">{GAMES[a.g]?.short}</span>
      </span>
      <span className={cn("mt-4 block text-balance font-display font-semibold leading-[1.08] group-hover:text-primary", size === "lg" ? "text-[clamp(1.6rem,1rem+1.6vw,2.4rem)]" : "text-xl")}>{l.title}</span>
      {size === "lg" && <span className="mt-3 line-clamp-2 block text-pretty text-muted-foreground">{l.body}</span>}
      <span className="mt-3 flex items-center gap-3 text-xs text-muted-foreground"><span>{fmtDate(a.date)}</span><span className="flex items-center gap-1"><Clock className="h-3 w-3" />{readTime(a)} min read</span></span>
    </Link>
  );
}

function TodayTicker() {
  const { data: newsData } = useQuery<{ news: any[]; lastUpdated?: string | null }>({
    queryKey: ["/api/agent/news"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/agent/news?limit=10");
      return res.json();
    },
    staleTime: 30000,
  });

  const latestItem = useMemo(() => {
    const newsList = newsData?.news ?? [];

    const indiaNews = newsList.find(n =>
      n.title?.toLowerCase().includes("india") ||
      n.title?.toLowerCase().includes("ind") ||
      n.sport?.toLowerCase().includes("athletics") ||
      n.sport?.toLowerCase().includes("badminton") ||
      n.sport?.toLowerCase().includes("cricket") ||
      n.sport?.toLowerCase().includes("hockey")
    );

    if (indiaNews) {
      return {
        title: indiaNews.title,
        sport: indiaNews.sport,
        published_at: indiaNews.published_at,
        url: indiaNews.url || "/news",
        isExternal: !!indiaNews.url,
      };
    }

    if (newsList[0]) {
      return {
        title: newsList[0].title,
        sport: newsList[0].sport,
        published_at: newsList[0].published_at,
        url: newsList[0].url || "/news",
        isExternal: !!newsList[0].url,
      };
    }

    return {
      title: LEAD.title,
      sport: "Cover Story",
      published_at: LEAD.date,
      url: `/news/${LEAD.slug}`,
      isExternal: false,
    };
  }, [newsData]);

  const timeAgoStr = timeAgo(latestItem.published_at);

  return (
    <div className="flex items-center gap-2.5 rounded-xl border-none bg-[var(--surface-2)] px-3.5 py-2.5 text-xs shadow-sm sm:gap-3">
      <span className="flex shrink-0 items-center gap-1.5 font-bold uppercase tracking-wider text-[var(--accent)]">
        <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
        <span className="hidden sm:inline">Today in Sport</span>
        <span className="sm:hidden">Live</span>
      </span>
      {latestItem.sport && (
        <span className="hidden shrink-0 rounded-full border-none bg-[var(--surface)] px-2 py-0.5 text-[10px] font-bold text-[var(--text-muted)] md:inline-flex">
          {latestItem.sport}
        </span>
      )}
      <div className="min-w-0 flex-1 truncate">
        {latestItem.isExternal ? (
          <a
            href={latestItem.url}
            target="_blank"
            rel="noopener noreferrer"
            className="block truncate font-medium text-[var(--text)] transition-colors hover:text-[var(--accent)] hover:underline"
          >
            {latestItem.title}
          </a>
        ) : (
          <Link
            href={latestItem.url}
            className="block truncate font-medium text-[var(--text)] transition-colors hover:text-[var(--accent)] hover:underline"
          >
            {latestItem.title}
          </Link>
        )}
      </div>
      {timeAgoStr && (
        <span className="shrink-0 rounded border-none bg-white/[0.05] px-1.5 py-0.5 font-mono text-[11px] text-slate-400">
          {timeAgoStr}
        </span>
      )}
      <Link
        href="/match-centre"
        className="ml-1 inline-flex shrink-0 items-center gap-1 text-[11px] font-bold text-[var(--accent)] hover:underline sm:ml-auto sm:text-xs"
      >
        <span>Match Centre</span>
        <ArrowRight className="h-3 w-3" />
      </Link>
    </div>
  );
}

interface HeroGamesData {
  gamesId: string;
  gamesName: string;
  kicker: string;
  headline: string;
  dek: string;
  status: "Live" | "Ended" | "Upcoming";
  indiaRank: number;
  totalMedals: number;
  goldMedals: number;
  medalSports: number;
  source: string;
  sourceUrl: string;
  updatedAt: string;
  benchmarkNote?: string;
}

function Hero() {
  const { data: heroData, isError, refetch } = useQuery<HeroGamesData>({
    queryKey: ["/api/hero/games"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/hero/games");
      return res.json();
    },
    staleTime: 60000,
  });

  const hero: HeroGamesData = heroData ?? {
    gamesId: "asian-games-2026",
    gamesName: "20th Asian Games (Aichi-Nagoya 2026)",
    kicker: "Aichi-Nagoya 2026 · Final Results",
    headline: "The Golden Haul at Aichi-Nagoya 2026",
    dek: "85 medals for India — 21 gold, 27 silver, and 37 bronze. India finished ranked 4th across 18 podium sports.",
    status: "Ended",
    indiaRank: 4,
    totalMedals: 85,
    goldMedals: 21,
    medalSports: 18,
    source: "Wikipedia (CC BY-SA)",
    sourceUrl: "https://en.wikipedia.org/wiki/2026_Asian_Games_medal_table",
    updatedAt: new Date().toISOString(),
  };

  const updatedAgo = timeAgo(hero.updatedAt);

  const heroGamesHref =
    hero.gamesId === "asian-para-games-2026"
      ? "/games/asian-para-games-2026"
      : hero.gamesId === "asian-games-2026"
      ? "/games/asian-games-2026"
      : hero.gamesId === "glasgow-2026"
      ? "/games/glasgow-2026"
      : hero.gamesId === "ahmedabad-2030"
      ? "/games/ahmedabad-2030"
      : hero.gamesId === "la-2028" || hero.gamesId === "road-to-la-2028"
      ? "/road-to-la-2028"
      : `/games/${hero.gamesId}`;

  const rankOrd = (n: number) => { const s = ["th", "st", "nd", "rd"]; const v = n % 100; return `${n}${s[(v - 20) % 10] || s[v] || s[0]}`; };
  const stats: [string, string, string][] = [
    ["Continental rank", rankOrd(hero.indiaRank), "on the continental table"],
    ["Total medals", `${hero.totalMedals}`, "Official continental tally"],
    ["Gold medals", `${hero.goldMedals}`, "Podium gold haul"],
    ["Medal sports", `${hero.medalSports}`, `Podium in ${hero.medalSports} disciplines`],
  ];

  return (
    <section className="grain relative isolate overflow-hidden bg-ink text-paper">
      {/* Full-bleed stadium photography with editorial scrims */}
      <div className="absolute inset-0 -z-10">
        <img
          src="/img/hero-javelin.webp"
          srcSet="/img/hero-javelin-800.webp 800w, /img/hero-javelin-1200.webp 1200w, /img/hero-javelin.webp 1600w"
          sizes="100vw"
          alt="Indian athlete releasing a javelin under stadium floodlights"
          width={1600}
          height={900}
          loading="eager"
          className="h-full w-full object-cover object-[70%_center]"
        />
        <div className="scrim-l absolute inset-0" />
        <div className="scrim-b absolute inset-0 opacity-70" />
        <div className="mi-hero-glow absolute inset-0" aria-hidden="true" />
      </div>

      <Container className="pb-10 pt-14 md:pb-14 md:pt-24 lg:pt-28">
        <div className="max-w-3xl">
          <div className="flex flex-wrap items-center gap-2.5">
            <span data-testid="hero-tagline" className="mi-glass inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-xs font-semibold tracking-[0.04em] text-gold-bright">
              <Sparkles className="h-3.5 w-3.5" />
              {hero.kicker}
            </span>
            {hero.status === "Live" && (
              <span className="inline-flex items-center gap-1.5 rounded-full border-none bg-emerald-500/15 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-emerald-300 backdrop-blur">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                Live competition
              </span>
            )}
          </div>

          <h1 className="mt-6 text-balance font-display text-[clamp(2.3rem,1.1rem+4vw,4.8rem)] font-bold leading-[0.98]">
            {hero.headline}
          </h1>

          <div className="mi-swoosh mt-5 h-[3px] w-28 rounded-full" aria-hidden="true" />

          <p className="mt-5 max-w-xl text-pretty text-base leading-relaxed text-paper/80 md:text-lg">
            {hero.dek}
          </p>

          <div className="mt-7 flex flex-wrap items-center gap-3">
            <Link
              href={heroGamesHref}
              data-testid="button-hero-story"
              className="btn-primary inline-flex h-12 items-center gap-2 rounded-full px-6 text-sm font-bold shadow-lg border-none"
            >
              <span>Read the cover story</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="/medals"
              className="inline-flex h-12 items-center gap-2 rounded-full border-none bg-white/10 px-5 text-sm font-bold text-paper/85 transition-colors hover:bg-white/20 hover:text-paper"
            >
              All-time medal tables
            </Link>
          </div>
        </div>

        {/* Results band — glass panel with the Games tally */}
        <div className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border-none bg-white/10 backdrop-blur-md md:mt-14 md:grid-cols-4">
          {stats.map(([k, v, s]) => (
            <div key={k} className="bg-ink/60 p-4 backdrop-blur-md md:p-5">
              <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-paper/60">{k}</p>
              <p className="mt-1.5 font-display text-3xl font-bold tnum md:text-4xl">{v}</p>
              <p className="mt-0.5 text-[11px] leading-tight text-paper/60">{s}</p>
            </div>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-xs text-paper/60">
          <p data-testid="hero-data-source">
            Source:{" "}
            <a
              href={hero.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-paper/80 underline-offset-2 hover:text-paper hover:underline"
            >
              {hero.source}
            </a>
            {updatedAgo && ` · updated ${updatedAgo}`}
            {hero.status === "Ended" && " · Final results"}
          </p>
          {isError && (
            <button
              onClick={() => refetch()}
              className="inline-flex items-center gap-1 font-semibold text-gold-bright hover:underline"
            >
              <RefreshCw className="h-3 w-3" />
              <span>Retry</span>
            </button>
          )}
        </div>
      </Container>
    </section>
  );
}

function PostHeroStrip() {
  return (
    <section className="bg-[var(--surface)]">
      <Container className="py-4 md:py-5">
        <TodayTicker />
        <div className="no-scrollbar -mx-4 mt-3 flex snap-x items-center gap-2 overflow-x-auto px-4 pb-0.5 sm:-mx-0 sm:px-0">
          {[
            { label: "All 26 Disciplines", href: "/match-centre", icon: Zap },
            { label: "Asian Games Hub", href: "/games/asian-games-2026", icon: Trophy },
            { label: "Special Reports", href: "/news", icon: Newspaper },
            { label: "Hall of Fame", href: "/hall-of-fame", icon: Award },
            { label: "All-Time Records", href: "/medals", icon: BarChart3 },
          ].map(tab => {
            const Ic = tab.icon;
            return (
              <Link
                key={tab.label}
                href={tab.href}
                className="flex shrink-0 snap-start items-center gap-2 rounded-full border-none bg-[#131926] hover:bg-[#182030] px-4 py-2 text-xs font-semibold text-slate-200 shadow-sm transition-colors"
              >
                <Ic className="h-3.5 w-3.5 shrink-0 text-[var(--accent)]" strokeWidth={1.75} />
                <span className="whitespace-nowrap">{tab.label}</span>
              </Link>
            );
          })}
        </div>
      </Container>
    </section>
  );
}

function Numbers() {
  const { data: overviewData } = useQuery<{
    total_medals: number;
    telemetry_source: string;
    updated_at: string;
    overview: {
      key: "oly" | "cwg" | "asian";
      name: string;
      slug: string;
      gold: number;
      silver: number;
      bronze: number;
      total: number;
      sub: string;
    }[];
  }>({
    queryKey: ["/api/medals/overview"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/medals/overview");
      return res.json();
    },
    staleTime: 60000,
  });

  const oly = overviewData?.overview?.find(x => x.key === "oly");
  const asian = overviewData?.overview?.find(x => x.key === "asian");
  const cwg = overviewData?.overview?.find(x => x.key === "cwg");

  const o = oly ? { g: oly.gold, s: oly.silver, b: oly.bronze } : sumEditions(OLY);
  const a = asian ? { g: asian.gold, s: asian.silver, b: asian.bronze } : { g: TALLY_ALL_ASIAN[2], s: TALLY_ALL_ASIAN[3], b: TALLY_ALL_ASIAN[4] };
  const c = cwg ? { g: cwg.gold, s: cwg.silver, b: cwg.bronze } : sumEditions(CWG);

  const items = [
    { k: "Olympic Games", n: oly?.total ?? total(o), m: o, sub: oly?.sub ?? "since Paris 1900", href: "/medals/olympics", testid: "stat-oly" },
    { k: "Asian Games", n: asian?.total ?? total(a), m: a, sub: asian?.sub ?? `all-time, rank ${TALLY_ALL_ASIAN[0]}`, href: "/medals/asian-games", testid: "stat-asian" },
    { k: "Commonwealth Games", n: cwg?.total ?? total(c), m: c, sub: cwg?.sub ?? "fourth all-time", href: "/medals/commonwealth", testid: "stat-cwg" },
  ];

  return (
    <section className="relative overflow-hidden bg-ink text-paper">
      <div className="mi-hero-glow absolute inset-0" aria-hidden="true" />
      <Container className="relative py-14 md:py-20">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-2xl">
            <Kicker className="text-gold-bright">Celebrate the past · India's medal count</Kicker>
            <h2 className="mt-3 font-display text-[clamp(1.9rem,1.2rem+2.2vw,3.2rem)] font-bold leading-[1.04]">
              Every medal, every Games, since 1900.
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-paper/60">
            The full record at the three multi-sport Games that matter most — edition by edition, sport by sport.
          </p>
        </div>

        {/* Ledger rows instead of cards — reads like a national tally board */}
        <div className="mt-10 rounded-2xl bg-[#0d111a] p-2 md:p-4 border-none">
          {items.map(i => (
            <Link
              key={i.k}
              href={i.href}
              data-testid={i.testid}
              className="group flex flex-col gap-3 py-6 transition-colors hover:bg-white/[0.03] md:grid md:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)_auto] md:items-center md:gap-8 md:py-7 rounded-xl px-3 border-none"
            >
              <div>
                <p className="font-display text-xl font-semibold md:text-2xl">{i.k}</p>
                <p className="mt-0.5 text-xs capitalize text-paper/55">{i.sub}</p>
              </div>
              <p className="font-display text-5xl font-bold tnum md:text-6xl">
                <CountUp to={i.n} />
              </p>
              <MedalTriplet g={i.m.g} s={i.m.s} b={i.m.b} size="sm" className="text-paper/90" />
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-gold-bright transition-transform group-hover:translate-x-1">
                Explore <ArrowRight className="h-3.5 w-3.5" />
              </span>
            </Link>
          ))}
        </div>

        <div className="mt-4 flex items-center gap-2 text-xs text-paper/55">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-indgreen" />
          <span>Source: {overviewData?.telemetry_source ?? "IOC & OCA Official Telemetry"}</span>
        </div>
      </Container>
    </section>
  );
}

function Hubs() {
  const { data: activeGamesData } = useQuery<{
    live: any[];
    upcoming: any[];
    telemetry_source: string;
  }>({
    queryKey: ["/api/games/active"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/games/active");
      return res.json();
    },
    staleTime: 60000,
  });

  const hubsRaw = [
    { k: "Asian Para Games 2026", where: "Aichi-Nagoya, Japan", start: "2026-10-18", end: "2026-10-24", img: "/img/real-sheetal-devi.jpg", href: "/games/asian-para-games-2026", tag: "Major Games" },
    { k: "Asian Games 2026", where: "Aichi-Nagoya, Japan", start: "2026-09-19", end: "2026-10-04", img: "/img/hockey.webp", href: "/games/asian-games-2026", tag: "Major Games" },
    { k: "Glasgow 2026", where: "Scotland", start: "2026-07-23", end: "2026-08-02", img: "/img/weightlifting.webp", href: "/games/glasgow-2026", tag: "CWG Record" },
    { k: "Road to LA 2028", where: "Los Angeles, USA", start: "2028-07-14", end: "2028-07-30", img: "/img/hero-javelin.webp", href: "/road-to-la-2028", tag: "Olympics" },
  ];

  const PRIORITY: Record<string, number> = { Live: 0, Upcoming: 1, Ended: 2 };

  const hubs = hubsRaw
    .map(h => {
      const lc = getEventStatus(h.start, h.end);
      const line = lc.status === "Live"
        ? "Competition Live Now in Japan"
        : lc.status === "Upcoming"
        ? `${formatDateRangeIST(h.start, h.end)} · ${lc.label}`
        : `${formatDateRangeIST(h.start, h.end)} · Final Results`;
      return { ...h, lc, line };
    })
    .sort((a, b) => {
      const pA = PRIORITY[a.lc.status] ?? 3;
      const pB = PRIORITY[b.lc.status] ?? 3;
      if (pA !== pB) return pA - pB;
      return a.start.localeCompare(b.start);
    });

  return (
    <section className="py-14 md:py-20">
      <Container>
        <SectionHead
          kicker="Participate in the present · Major hubs"
          title="Follow India, Games by Games"
          dek={`Official Games hubs tracking Indian contingents with dynamic IST phases (${activeGamesData?.telemetry_source ?? "OCA & IOC"}).`}
        />
        <div className="overflow-hidden rounded-2xl border-none bg-[var(--surface-2)] shadow-sm p-2">
          <ul className="space-y-1">
            {hubs.map(h => (
              <li key={h.k}>
                <div className="flex items-center gap-2">
                <Link
                  href={h.href}
                  data-testid={`hub-${h.href.split("/").pop()}`}
                  className="group flex flex-1 items-center gap-4 p-4 transition-colors hover:bg-[var(--surface-hover)] rounded-xl md:gap-6 md:p-5 border-none"
                >
                  <span className="relative h-16 w-24 shrink-0 overflow-hidden rounded-lg bg-[var(--surface-2)] md:h-20 md:w-32">
                    <Img src={h.img} alt={h.k} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                      <span className="font-display text-lg font-semibold leading-tight group-hover:text-primary md:text-xl">{h.k}</span>
                      <span
                        className={cn(
                          "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider",
                          h.lc.status === "Live" && "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
                          h.lc.status === "Upcoming" && "bg-amber-500/15 text-amber-700 dark:text-amber-300",
                          h.lc.status === "Ended" && "bg-muted text-muted-foreground"
                        )}
                      >
                        {h.lc.status === "Live" && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" />}
                        {h.lc.status}
                      </span>
                    </span>
                    <span className="mt-1 block text-sm text-[var(--text-muted)]">
                      <MapPin className="mr-1 inline h-3 w-3" />{h.where} · {h.line}
                    </span>
                  </span>
                  <ArrowRight className="h-5 w-5 shrink-0 text-[var(--text-muted)] transition-transform group-hover:translate-x-1 group-hover:text-primary" />
                </Link>
                <FollowButton kind="games" k={h.href.split("/").pop() || h.k} label={h.k} />
                </div>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </section>
  );
}

function HistoryTeaser() {
  const [tab, setTab] = useState<"oly" | "cwg" | "asian">("oly");
  const [pick, setPick] = useState<Edition | null>(null);
  const data = tab === "oly" ? OLY : tab === "cwg" ? CWG : ASIAN;
  const s = sumEditions(data);
  const best = data.filter(e => !e.dnp && !e.upcoming).reduce((a, b) => (total(b) > total(a) ? b : a));
  return (
    <section className="bg-[var(--surface)] text-[var(--text)]">
      <Container className="py-16 md:py-24">
        <SectionHead kicker="Celebrate the past · Medal history" title="A century of Indian medals" dek="Hover a column for the haul, or click it to open that Games." action={<MoreLink href="/medals" testid="link-medal-history">Full medal history</MoreLink>} />
        <Tabs tabs={[["oly", "Olympics"], ["cwg", "Commonwealth Games"], ["asian", "Asian Games (since 1951)"]]} value={tab} onChange={setTab} />
        <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_3fr]">
          <div className="space-y-6">
            <div><p className="text-sm text-[var(--text-muted)]">Total medals</p><p className="font-display text-6xl font-semibold leading-none tnum text-[var(--text)]">{total(s)}</p><MedalTriplet g={s.g} s={s.s} b={s.b} size="sm" className="mt-3" /></div>
            <div className="pt-5"><p className="text-sm text-[var(--text-muted)]">Best Games</p><p className="mt-1 font-display text-2xl font-semibold text-[var(--text)]">{best.host} {best.y}</p><p className="text-sm text-[var(--text-muted)]">{total(best)} medals · {best.g} gold</p></div>
            <Link href={tab === "oly" ? "/medals/olympics" : tab === "cwg" ? "/medals/commonwealth" : "/medals/asian-games"} className="inline-flex h-10 items-center gap-2 rounded-full border-none bg-[#131926] hover:bg-[#182030] px-4 text-sm font-bold text-slate-200">Open the {tab === "oly" ? "Olympic" : tab === "cwg" ? "Commonwealth" : "Asian Games"} record<ArrowRight className="h-4 w-4" /></Link>
          </div>
          <div className="rounded-2xl border-none bg-[var(--surface-2)] p-4 shadow-sm md:p-6">
            <Suspense fallback={<div className="h-[320px] animate-pulse rounded-lg bg-[var(--surface-2)]" />}>
              <EditionChart data={data} games={tab} onPick={setPick} height={320} />
            </Suspense>
          </div>
        </div>
      </Container>
      <Suspense fallback={null}>
        {pick && <EditionSheet edition={pick} games={tab} onClose={() => setPick(null)} />}
      </Suspense>
    </section>
  );
}

function Athletes() {
  const featured = mergeAthletes([]).filter(p => p.featured).slice(0, 10);
  return (
    <section className="bg-[var(--surface-2)]/25 py-16 md:py-24">
      <Container>
        <SectionHead kicker="Celebrate the past · Athletes" title="The faces of Indian sport" dek="The medallists whose stories motivate the next generation." action={<MoreLink href="/athletes" testid="link-all-athletes">Browse athletes</MoreLink>} />
        <div className="no-scrollbar -mx-4 flex snap-x gap-4 overflow-x-auto px-4 pb-4 sm:-mx-6 sm:px-6 lg:-mx-10 lg:px-10">
          {featured.map(p => { const m = personMedals(p); return (
            <Link key={p.slug} href={`/athletes/${p.slug}`} data-testid={`card-athlete-${p.slug}`} className="group relative aspect-[3/4] w-60 shrink-0 snap-start overflow-hidden rounded-[14px] bg-ink text-paper sm:w-64">
              <Img src={p.img} alt="" className="transition-transform duration-[1.2s] group-hover:scale-105" />
              <div className="scrim-b absolute inset-0" />
              <div className="absolute inset-x-0 bottom-0 p-5">
                <p className="text-xs font-bold uppercase tracking-[0.12em] text-saffron">{p.sport}</p>
                <h3 className="mt-1 font-display text-2xl font-semibold leading-none">{p.name}</h3>
                <MedalTriplet g={m.G} s={m.S} b={m.B} size="sm" className="mt-3" />
              </div>
            </Link>); })}
        </div>
        <p className="mt-2 text-xs text-[var(--text-muted)]">Sport photography is illustrative and does not depict the named athlete. Medal counts are career medals shown in each athlete's timeline, not Olympic-only totals.</p>
      </Container>
    </section>
  );
}

interface CalendarEventItem {
  id: string;
  name: string;
  shortName: string;
  location: string;
  startDate: string;
  endDate: string;
  status: "Live" | "Ended" | "Upcoming";
  label: string;
  daysToStart: number;
  source: string;
  sourceUrl: string;
  fetchedAt: string;
}

function ComingUpEventCard({ ev }: { ev: CalendarEventItem }) {
  const cd = useCountdown(`${ev.startDate}T00:00:00+05:30`);
  const dateRange = formatDateRangeIST(ev.startDate, ev.endDate);
  const imgPath = ev.id.includes("para")
    ? "/img/relay.webp"
    : ev.id.includes("asian")
    ? "/img/hockey.webp"
    : ev.id.includes("glasgow") || ev.id.includes("cwg")
    ? "/img/boxing.webp"
    : "/img/hero-javelin.webp";

  return (
    <div className="relative flex flex-col justify-between overflow-hidden rounded-2xl border-none bg-[var(--surface-2)] shadow-sm">
      <div className="relative h-36 overflow-hidden">
        <Img src={imgPath} alt={ev.name} className="h-full w-full object-cover" />
        <div className="scrim-b absolute inset-0 opacity-60" />
        <div className="absolute top-2.5 left-2.5">
          <span className="rounded-full border-none bg-black/60 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[var(--accent)] backdrop-blur-md">
            {ev.status === "Live" ? "Live Now" : ev.label}
          </span>
        </div>
      </div>
      <div className="flex flex-1 flex-col justify-between p-4">
        <div>
          <h3 className="font-display text-xl font-bold leading-tight text-[var(--text)]">{ev.shortName}</h3>
          <p className="mt-1 flex items-center gap-1 text-xs text-[var(--text-muted)]">
            <MapPin className="h-3 w-3 shrink-0" />
            {ev.location} · {dateRange}
          </p>
        </div>
        <div className="mt-4">
          {ev.status === "Live" ? (
            <div className="flex items-center gap-2 rounded-md border-none bg-emerald-500/15 px-3 py-2 text-xs font-bold text-emerald-400">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
              <span>Competition Live in IST</span>
            </div>
          ) : cd && !cd.done ? (
            <div className="grid grid-cols-4 gap-1.5 text-center" aria-live="off">
              {[["days", cd.d], ["hrs", cd.h], ["min", cd.m], ["sec", cd.s]].map(([l, v]) => (
                <div key={l as string} className="rounded-md bg-[var(--surface-2)] py-1.5">
                  <p className="font-display text-lg font-bold tnum text-[var(--text)]">{String(v).padStart(2, "0")}</p>
                  <p className="text-[9px] uppercase tracking-wider text-[var(--text-muted)]">{l as string}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="rounded-md bg-[var(--surface-2)] px-3 py-2 text-xs text-[var(--text-muted)]">
              {ev.label}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function Upcoming() {
  const { data: calData } = useQuery<{ events: CalendarEventItem[]; source: string }>({
    queryKey: ["/api/calendar/coming-up"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/calendar/coming-up?limit=6");
      return res.json();
    },
    staleTime: 60000,
  });

  const events = calData?.events?.length ? calData.events : [
    {
      id: "road-to-la-2028",
      name: "34th Summer Olympic Games (Los Angeles 2028)",
      shortName: "LA 2028 Olympics",
      location: "Los Angeles, USA",
      startDate: "2028-07-14",
      endDate: "2028-07-30",
      status: "Upcoming" as const,
      label: "Starts in 628 days",
      daysToStart: 628,
      source: "Wikidata (CC0)",
      sourceUrl: "https://www.wikidata.org/wiki/Q1454044",
      fetchedAt: new Date().toISOString(),
    },
    {
      id: "cwg-2030",
      name: "Centenary Commonwealth Games (Ahmedabad 2030)",
      shortName: "Ahmedabad 2030 CWG",
      location: "Ahmedabad, India",
      startDate: "2030-10-01",
      endDate: "2030-10-14",
      status: "Upcoming" as const,
      label: "Centenary edition",
      daysToStart: 1437,
      source: "Wikidata (CC0)",
      sourceUrl: "https://www.wikidata.org",
      fetchedAt: new Date().toISOString(),
    },
    {
      id: "asian-games-2030",
      name: "21st Asian Games (Doha 2030)",
      shortName: "Doha 2030 Asian Games",
      location: "Doha, Qatar",
      startDate: "2030-11-01",
      endDate: "2030-11-16",
      status: "Upcoming" as const,
      label: "Upcoming continental Games",
      daysToStart: 1468,
      source: "Wikidata (CC0)",
      sourceUrl: "https://www.wikidata.org",
      fetchedAt: new Date().toISOString(),
    },
    {
      id: "glasgow-2026",
      name: "23rd Commonwealth Games (Glasgow 2026)",
      shortName: "Glasgow 2026 CWG",
      location: "Glasgow, Scotland",
      startDate: "2026-07-23",
      endDate: "2026-08-02",
      status: "Upcoming" as const,
      label: "10 core disciplines",
      daysToStart: 271,
      source: "Wikidata (CC0)",
      sourceUrl: "https://www.wikidata.org",
      fetchedAt: new Date().toISOString(),
    },
    {
      id: "asian-games-2026",
      name: "20th Asian Games (Aichi-Nagoya 2026)",
      shortName: "Aichi-Nagoya 2026",
      location: "Aichi-Nagoya, Japan",
      startDate: "2026-09-19",
      endDate: "2026-10-04",
      status: "Upcoming" as const,
      label: "Major continental Games",
      daysToStart: 329,
      source: "Wikidata (CC0)",
      sourceUrl: "https://www.wikidata.org",
      fetchedAt: new Date().toISOString(),
    },
    {
      id: "asian-para-games-2026",
      name: "5th Asian Para Games (Aichi-Nagoya 2026)",
      shortName: "Asian Para Games 2026",
      location: "Aichi-Nagoya, Japan",
      startDate: "2026-10-18",
      endDate: "2026-10-24",
      status: "Upcoming" as const,
      label: "Para continental Games",
      daysToStart: 358,
      source: "Wikidata (CC0)",
      sourceUrl: "https://www.wikidata.org",
      fetchedAt: new Date().toISOString(),
    },
  ];

  return (
    <section className="py-16 md:py-24">
      <Container>
        <SectionHead
          kicker="Prepare for the future · Coming up"
          title="What's next for India"
          dek="The next 6 major multi-sport Games sourced live from Wikidata & Wikipedia public APIs."
          action={<MoreLink href="/schedule" testid="link-schedule">Full schedule</MoreLink>}
        />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {events.slice(0, 6).map(ev => (
            <ComingUpEventCard key={ev.id} ev={ev} />
          ))}
        </div>
        <p className="mt-3 text-right text-xs text-[var(--text-muted)]">
          Source: Wikidata (P580, P582) & Wikipedia APIs · Updated daily at 04:00 IST
        </p>
      </Container>
    </section>
  );
}

function ReadRow({ a }: { a: Article }) {
  return (
    <Link href={`/news/${a.slug}`} data-testid={`card-story-${a.slug}`} className="group flex items-start gap-5 py-5">
      <span className="mt-1 w-20 shrink-0 text-[0.68rem] font-bold uppercase leading-snug tracking-[0.12em]" style={{ color: GAMES[a.g]?.color }}>
        {GAMES[a.g]?.short}
      </span>
      <span className="min-w-0">
        <span className="block font-display text-lg font-semibold leading-snug group-hover:text-primary">{a.title}</span>
        <span className="mt-1.5 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
          <span>{fmtDate(a.date)}</span>
          <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{readTime(a)} min read</span>
        </span>
      </span>
    </Link>
  );
}

function AnalysisAndHall() {
  const analysis = ARTICLES.filter(a => a.kind === "analysis");
  return (
    <section className="bg-[var(--surface-2)]/30 py-16 md:py-24">
      <Container>
        <div className="grid gap-12 lg:gap-16 lg:grid-cols-[1.4fr_1fr]">
          <div className="lg:pr-12">
            <SectionHead kicker="Archive analysis" title="Deeper reads" />
            <div className="space-y-1">{analysis.map(a => <ReadRow key={a.slug} a={a} />)}</div>
          </div>
          <div className="lg:pl-4">
            <SectionHead kicker="Archive legends" title="Hall of fame" action={<MoreLink href="/hall-of-fame" testid="link-hall">See all</MoreLink>} />
            <ol className="space-y-1">
              {HALL.slice(0, 5).map((h, i) => (
                <li key={h.n} className="flex items-baseline gap-4 py-4">
                  <span className="font-display text-2xl font-bold tnum text-primary/70">{String(i + 1).padStart(2, "0")}</span>
                  <div><p className="font-bold">{h.n} <span className="font-normal text-muted-foreground">· {h.sp}</span></p><p className="mt-0.5 text-sm text-muted-foreground">{h.t}</p></div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </Container>
    </section>
  );
}

/* Theme journey: the homepage is read past -> present -> future. The three
 * timeline below the hero is the map; each theme heading below is an
 * anchor (#past / #present / #future) so a reader can jump straight to the
 * part they came for instead of scrolling a long, unordered page. */
// In-page jumps must scroll, not navigate: in dev the router is
// hash-based (useHashLocation in App.tsx), so a plain <a href="#past">
// is read as the route "/past" and renders the 404 page. Buttons
// below call this instead, and it works in both hash and path mode.
function jumpTo(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function JourneyTimeline() {
  // Calendar-day countdown to the LA 2028 opening ceremony (14 July
  // 2028), so the number matches the demo: 622 days on 31 Oct 2026.
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const daysToLA = Math.max(0, Math.round((new Date(2028, 6, 14).getTime() - today.getTime()) / 864e5));
  return (
    <section className="bg-[var(--surface)]" aria-label="The journey: past, present, future">
      <Container className="py-8 md:py-10">
        <div className="relative pl-9 md:pl-11">
          <div aria-hidden="true" className="absolute left-3 md:left-4 top-2 bottom-2 w-[3px] rounded-full bg-gradient-to-b from-[#d4af37] via-[#ff9933] to-[#22c55e]" />
          {/* Then — Celebrate */}
          <div className="relative mb-12">
            <span aria-hidden="true" className="absolute -left-9 md:-left-11 top-1 grid h-6 w-6 place-items-center rounded-full border-4 border-[var(--surface)] bg-[#d4af37]" />
            <p className="font-display text-sm font-bold italic text-[#d4af37]">Then</p>
            <button type="button" onClick={() => jumpTo("past")} className="group inline-block cursor-pointer text-left"><h2 className="mt-1 font-display text-4xl font-extrabold uppercase tracking-tight text-[var(--text)] group-hover:text-primary sm:text-5xl">Celebrate</h2></button>
            <p className="mt-2 font-display text-lg italic text-[var(--text-muted)]">Honour the ones who proved it could be done.</p>
            <div className="mt-4 flex items-center gap-5 rounded-2xl bg-[var(--surface-2)] p-5">
              <span aria-hidden="true" className="flex shrink-0 flex-col items-center">
                <span className="flex w-14 overflow-hidden rounded-t-sm"><span className="h-7 flex-1 bg-[#ff9933]" /><span className="h-7 flex-1 bg-[#f5f0e6]" /><span className="h-7 flex-1 bg-[#138808]" /></span>
                <span className="grid h-16 w-16 place-items-center rounded-full bg-[#d4af37] text-[#0b2e17] shadow-md"><Award className="h-8 w-8" /></span>
              </span>
              <span className="text-base leading-relaxed text-[var(--text)] sm:text-lg">Medal tables that agree with each other, and the names behind every podium.</span>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Link href="/medals" className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-bold text-[var(--text)] hover:border-primary">Medal tables</Link>
              <Link href="/athletes" className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-bold text-[var(--text)] hover:border-primary">Athletes</Link>
              <Link href="/hall-of-fame" className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-bold text-[var(--text)] hover:border-primary">The Hall</Link>
            </div>
          </div>
          {/* Now — Participate */}
          <div className="relative mb-12">
            <span aria-hidden="true" className="absolute -left-9 md:-left-11 top-1 grid h-6 w-6 place-items-center rounded-full border-4 border-[var(--surface)] bg-[#ff9933]" />
            <p className="font-display text-sm font-bold italic text-[#ff9933]">Now</p>
            <button type="button" onClick={() => jumpTo("present")} className="group inline-block cursor-pointer text-left"><h2 className="mt-1 font-display text-4xl font-extrabold uppercase tracking-tight text-[var(--text)] group-hover:text-primary sm:text-5xl">Participate</h2></button>
            <p className="mt-2 font-display text-lg italic text-[var(--text-muted)]">History is being written this week — be there for it.</p>
            <div className="mt-4 flex items-center gap-5 rounded-2xl bg-[var(--surface-2)] p-5">
              <span aria-hidden="true" className="relative flex shrink-0 h-16 w-16 items-center justify-center">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#ff9933] opacity-30" />
                <span className="absolute inline-flex h-10 w-10 rounded-full border-2 border-[#ff9933]/60" />
                <span className="relative inline-flex h-4 w-4 rounded-full bg-[#ff9933]" />
              </span>
              <span>
                <span className="flex items-center gap-2 font-display text-lg font-bold text-[#ff9933]"><span className="h-2.5 w-2.5 rounded-full bg-[#ff9933]" />Live now</span>
                <span className="mt-1 block text-base leading-relaxed text-[var(--text)] sm:text-lg">Results as they happen, and where to watch every moment.</span>
              </span>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <button type="button" onClick={() => jumpTo("present")} className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-bold text-[var(--text)] hover:border-primary cursor-pointer">Command Centre</button>
              <Link href="/match-centre" className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-bold text-[var(--text)] hover:border-primary">Live results</Link>
              <Link href="/games/asian-games-2026" className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-bold text-[var(--text)] hover:border-primary">Games hubs</Link>
            </div>
          </div>
          {/* Next — Prepare */}
          <div className="relative">
            <span aria-hidden="true" className="absolute -left-9 md:-left-11 top-1 grid h-6 w-6 place-items-center rounded-full border-4 border-[var(--surface)] bg-[#22c55e]" />
            <p className="font-display text-sm font-bold italic text-[#22c55e]">Next</p>
            <button type="button" onClick={() => jumpTo("future")} className="group inline-block cursor-pointer text-left"><h2 className="mt-1 font-display text-4xl font-extrabold uppercase tracking-tight text-[var(--text)] group-hover:text-primary sm:text-5xl">Prepare</h2></button>
            <p className="mt-2 font-display text-lg italic text-[var(--text-muted)]">The next podium is built in today&apos;s training halls.</p>
            <div className="mt-4 rounded-2xl bg-[var(--surface-2)] p-5">
              <p className="font-display text-6xl font-extrabold leading-none text-[#22c55e] tnum sm:text-7xl">{daysToLA}</p>
              <p className="mt-2 text-base leading-relaxed text-[var(--text)] sm:text-lg">days to the LA 2028 opening ceremony</p>
              <p className="mt-3 text-sm leading-relaxed text-[var(--text-muted)]">The road to LA 2028 and the 2026 events calendar — what&apos;s next, and how India gets ready for it.</p>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Link href="/road-to-la-2028" className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-bold text-[var(--text)] hover:border-primary">Road to LA 2028</Link>
              <Link href="/events" className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-bold text-[var(--text)] hover:border-primary">2026 calendar</Link>
              <Link href="/pathway" className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-bold text-[var(--text)] hover:border-primary">How India gets ready</Link>
            </div>
          </div>
        </div>
        <p className="mt-12 border-t border-[var(--border)] pt-8 font-display text-2xl italic leading-snug text-[var(--text)] sm:text-3xl">&ldquo;Behind every medal is a morning nobody filmed.&rdquo;</p>
      </Container>
    </section>
  );
}

function ThemeHeading({ id, kicker, title, dek }: { id: string; kicker: string; title: string; dek: string }) {
  return (
    <section id={id} className="scroll-mt-24 bg-[var(--surface)]">
      <Container className="pb-2 pt-10 md:pt-14">
        <Kicker className="text-gold-ink">{kicker}</Kicker>
        <h2 className="mt-3 font-display text-[clamp(1.9rem,1.2rem+2.2vw,3.2rem)] font-bold leading-[1.04]">{title}</h2>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-[var(--text-muted)] md:text-base">{dek}</p>
      </Container>
    </section>
  );
}


// ---- Modern homepage (v1.3.11) ----
// The old homepage stacked 11 sections with three repeated theme
// headings, a ticker strip and a timeline. A world-class sports
// homepage does the opposite: one hero, one proof strip, a few
// big visual cards that lead to the full sections, then live
// results and athletes. Everything removed from the homepage
// below still exists as a full page behind the menu.
function HomeStats() {
  const o = sumEditions(OLY);
  const c = sumEditions(CWG);
  const asianTotal = TALLY_ALL_ASIAN ? TALLY_ALL_ASIAN[2] + TALLY_ALL_ASIAN[3] + TALLY_ALL_ASIAN[4] : 864;
  // Asian Para Games 2026 final result, verified (see PATCH_NOTES):
  // India 4th with 114 medals, 30 gold, 35 silver, 49 bronze.
  const stats = [
    { label: "Olympic medals", value: o.g + o.s + o.b, sub: `${o.g} gold · ${o.s} silver · ${o.b} bronze` },
    { label: "Asian Games medals", value: asianTotal, sub: "All-time tally" },
    { label: "Commonwealth medals", value: c.g + c.s + c.b, sub: `${c.g} gold · ${c.s} silver · ${c.b} bronze` },
    { label: "Asian Para Games 2026", value: 114, sub: "India 4th · 30 gold · 35 silver · 49 bronze" },
  ];
  return (
    <section className="bg-[var(--surface)]" aria-label="India's medal totals">
      <Container className="py-10 md:py-14">
        <div className="grid grid-cols-2 gap-6 lg:grid-cols-4">
          {stats.map(st => (
            <div key={st.label}>
              <p className="font-display text-4xl font-extrabold leading-none text-[var(--text)] tnum md:text-5xl">{st.value}</p>
              <p className="mt-2 text-sm font-bold text-[var(--text)]">{st.label}</p>
              <p className="mt-0.5 text-xs leading-relaxed text-[var(--text-muted)]">{st.sub}</p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}

function FeatureCards() {
  const cards = [
    { href: "/medals", img: "/img/real-neeraj-action.jpg", Icon: Trophy, kicker: "Medal History", title: "Every Indian medal, in one place", text: "Olympic, Asian Games and Commonwealth tallies with edition breakdowns and the Hall of Fame.", meta: "41 Olympic · 864 Asian · 563 Commonwealth" },
    { href: "/events", img: "/img/real-nagoya-stadium.jpg", srcSet: "/img/real-nagoya-stadium-800.webp 800w, /img/real-nagoya-stadium-1200.webp 1200w", Icon: CalendarDays, kicker: "Events 2026", title: "The year, mapped", text: "68 events across 36 States & UTs — the T20 World Cup, Glasgow, the Asian Games and the Asian Para Games.", meta: "National map · 2026 calendar" },
    { href: "/facilities", img: "/img/academy.webp", Icon: MapPin, kicker: "Facilities", title: "Find somewhere to train", text: "SAI centres and Khelo academies, searchable by state — from a first trial to a national camp.", meta: "Search by state" },
  ];
  return (
    <section className="bg-[var(--surface)]" aria-label="Start here">
      <Container className="pb-10 md:pb-14">
        <Kicker className="text-gold-ink">Start here</Kicker>
        <h2 className="mt-3 font-display text-[clamp(1.9rem,1.2rem+2.2vw,3.2rem)] font-bold leading-[1.04]">India&apos;s sporting story, in three places</h2>
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {cards.map(card => (
            <Link key={card.href} href={card.href} className="group overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--surface-2)] transition-shadow hover:shadow-xl">
              <span className="block overflow-hidden">
                <img src={card.img} srcSet={(card as { srcSet?: string }).srcSet} sizes="(max-width: 768px) 800px, 1200px" alt="" loading="lazy" className="aspect-[16/10] w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              </span>
              <span className="block p-5 md:p-6">
                <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.12em] text-[var(--accent)]"><card.Icon className="h-4 w-4" />{card.kicker}</span>
                <span className="mt-2 block font-display text-xl font-bold leading-tight text-[var(--text)] md:text-2xl">{card.title}</span>
                <span className="mt-2 block text-sm leading-relaxed text-[var(--text-muted)]">{card.text}</span>
                <span className="mt-4 flex items-center justify-between gap-2 border-t border-[var(--border)] pt-4">
                  <span className="text-xs font-bold text-[var(--text-muted)]">{card.meta}</span>
                  <span className="inline-flex items-center gap-1 text-sm font-bold text-primary transition-transform group-hover:translate-x-1">Explore <ArrowRight className="h-4 w-4" /></span>
                </span>
              </span>
            </Link>
          ))}
        </div>
      </Container>
    </section>
  );
}

export default function Home() {
  return (
    <>
      <Hero />
      <HomeStats />
      <FeatureCards />
      <Suspense fallback={<div className="h-14" />}>
        <LiveStrip />
      </Suspense>
      <Athletes />
    </>
  );
}
