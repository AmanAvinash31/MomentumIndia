import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Container, Kicker } from "@/components/site";
import { Sparkles, RefreshCw, Send, Radio, Trophy, Newspaper, Bot, Clock, ExternalLink } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { usePollInterval } from "@/lib/live-stream";
import { cn } from "@/lib/utils";
import { sportImage } from "@/data";
import { PaginationControl } from "@/components/pagination-control";

const ALL_26_SPORTS = [
  "all",
  "Cricket",
  "Football",
  "Kabaddi",
  "Hockey",
  "Athletics",
  "Badminton",
  "Shooting",
  "Archery",
  "Wrestling",
  "Boxing",
  "Weightlifting",
  "Para Sports",
  "Table Tennis",
  "Squash",
  "Tennis",
  "Golf",
  "Swimming",
  "Sailing",
  "Rowing",
  "Judo",
  "Mixed Martial Arts",
  "Kurash",
  "Wushu",
  "Sepaktakraw",
  "Soft Tennis",
  "Cycling"
] as const;

function timeAgo(dateStr?: string | null): string {
  if (!dateStr) return "recently";
  const diffMs = Date.now() - new Date(dateStr).getTime();
  if (diffMs < 0 || isNaN(diffMs)) return "just now";
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins === 1) return "1 min ago";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs === 1) return "1 hr ago";
  if (hrs < 24) return `${hrs} hrs ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export default function SportsAgentPage() {
  const queryClient = useQueryClient();
  const [selectedSport, setSelectedSport] = useState<string>("all");
  const [selectedDate, setSelectedDate] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<"scores" | "news" | "chat">("scores");
  // Numbered pagination for both Match Centre lists (previously every
  // fetched item rendered on one long page, with no page 2, 3…).
  const [resultsPage, setResultsPage] = useState(1);
  const [agentNewsPage, setAgentNewsPage] = useState(1);
  const RESULTS_PAGE_SIZE = 20;
  const AGENT_NEWS_PAGE_SIZE = 12;
  const [extraResults, setExtraResults] = useState<any[]>([]);
  const [extraAgentNews, setExtraAgentNews] = useState<any[]>([]);
  const [extraResultsCursor, setExtraResultsCursor] = useState<number | null>(null);
  const [extraAgentNewsCursor, setExtraAgentNewsCursor] = useState<number | null>(null);
  const [loadingOlder, setLoadingOlder] = useState<"results" | "news" | null>(null);
  const [userQuery, setUserQuery] = useState("");
  const [chatLog, setChatLog] = useState<{ role: "user" | "agent"; text: string; results?: any[]; news?: any[] }[]>([
    {
      role: "agent",
      text: "Welcome to the **Momentum Daily Results Feed & Sports Wire Desk**. All results and news dispatches are sourced directly via RSS news wires across India's 26 sports.\n\nAsk about today's outcomes: *'Did India win in shooting?'*, *'Latest cricket score'*, or *'Any badminton results?'*."
    }
  ]);

  // Query real available dates from stored results
  const { data: datesData } = useQuery<{ dates: string[] }>({
    queryKey: ["/api/agent/results/dates"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/agent/results/dates");
      return res.json();
    },
    refetchInterval: usePollInterval(30000),
  });

  const availableDates = datesData?.dates ?? [];

  // Query real daily sports results
  const { data: resultsData, isLoading: resultsLoading } = useQuery<{
    sport: string;
    date_ist: string;
    count: number;
    results: any[];
    nextCursor?: number | null;
    lastUpdated?: string | null;
  }>({
    queryKey: ["/api/agent/results", selectedSport, selectedDate],
    queryFn: async () => {
      const params = new URLSearchParams();
      params.set("limit", "200");
      if (selectedSport !== "all") params.set("sport", selectedSport);
      if (selectedDate !== "all") params.set("date_ist", selectedDate);
      const res = await apiRequest("GET", `/api/agent/results?${params.toString()}`);
      return res.json();
    },
    refetchInterval: usePollInterval(15000),
  });

  // Query real news
  const { data: newsData, isLoading: newsLoading } = useQuery<{
    sport: string;
    count: number;
    news: any[];
    nextCursor?: number | null;
    lastUpdated?: string | null;
  }>({
    queryKey: ["/api/agent/news", selectedSport],
    queryFn: async () => {
      const url = selectedSport === "all" ? "/api/agent/news?limit=100" : `/api/agent/news?sport=${encodeURIComponent(selectedSport)}&limit=100`;
      const res = await apiRequest("GET", url);
      return res.json();
    },
    refetchInterval: usePollInterval(25000),
  });

  // Mutations
  const refreshResultsMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/agent/results/fetch");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/agent/results"] });
      queryClient.invalidateQueries({ queryKey: ["/api/agent/results/dates"] });
    }
  });

  const fetchNewsMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/agent/news/fetch", { sport: selectedSport });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/agent/news"] });
    }
  });

  const queryMutation = useMutation({
    mutationFn: async (query: string) => {
      const res = await apiRequest("POST", "/api/agent/query", { query });
      return res.json();
    },
    onSuccess: (data, variables) => {
      setChatLog(prev => [
        ...prev,
        { role: "user", text: variables },
        { role: "agent", text: data.answer, results: data.relatedResults, news: data.relatedNews }
      ]);
      setUserQuery("");
    }
  });

  const handleSendQuery = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!userQuery.trim() || queryMutation.isPending) return;
    queryMutation.mutate(userQuery.trim());
  };

  const resultsList = useMemo(() => {
    const base = resultsData?.results ?? [];
    const baseIds = new Set(base.map((x: any) => x.id));
    return [...base, ...extraResults.filter((x: any) => !baseIds.has(x.id))];
  }, [resultsData, extraResults]);
  const newsList = useMemo(() => {
    const base = newsData?.news ?? [];
    const baseIds = new Set(base.map((x: any) => x.id));
    return [...base, ...extraAgentNews.filter((x: any) => !baseIds.has(x.id))];
  }, [newsData, extraAgentNews]);
  const resultsCursor = extraResultsCursor ?? resultsData?.nextCursor ?? null;
  const agentNewsCursor = extraAgentNewsCursor ?? newsData?.nextCursor ?? null;
  useEffect(() => { setResultsPage(1); setAgentNewsPage(1); setExtraResults([]); setExtraAgentNews([]); setExtraResultsCursor(null); setExtraAgentNewsCursor(null); }, [selectedSport, selectedDate]);
  const paginatedResults = useMemo(() => {
    const start = (resultsPage - 1) * RESULTS_PAGE_SIZE;
    return resultsList.slice(start, start + RESULTS_PAGE_SIZE);
  }, [resultsList, resultsPage]);
  const paginatedAgentNews = useMemo(() => {
    const start = (agentNewsPage - 1) * AGENT_NEWS_PAGE_SIZE;
    return newsList.slice(start, start + AGENT_NEWS_PAGE_SIZE);
  }, [newsList, agentNewsPage]);
  const loadOlder = async (kind: "results" | "news") => {
    const cursor = kind === "results" ? resultsCursor : agentNewsCursor;
    if (!cursor || loadingOlder) return;
    setLoadingOlder(kind);
    try {
      const params = new URLSearchParams({ cursor: String(cursor) });
      if (kind === "results") {
        params.set("limit", "200");
        if (selectedSport !== "all") params.set("sport", selectedSport);
        if (selectedDate !== "all") params.set("date_ist", selectedDate);
      } else {
        params.set("limit", "100");
        if (selectedSport !== "all") params.set("sport", selectedSport);
      }
      const endpoint = kind === "results" ? "/api/agent/results" : "/api/agent/news";
      const res = await apiRequest("GET", `${endpoint}?${params.toString()}`);
      const data = await res.json();
      if (kind === "results") { setExtraResults(prev => [...prev, ...(data.results ?? [])]); setExtraResultsCursor(data.nextCursor ?? null); }
      else { setExtraAgentNews(prev => [...prev, ...(data.news ?? [])]); setExtraAgentNewsCursor(data.nextCursor ?? null); }
    } catch { /* keep loaded pages; button stays available */ } finally {
      setLoadingOlder(null);
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Modern Hero Header */}
      <section className="relative border-b border-border bg-gradient-to-b from-[#0b1329] via-[#0d1733] to-background pt-12 pb-10 text-paper">
        <Container>
          <div className="flex flex-wrap items-center justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-saffron/30 bg-saffron/10 px-3 py-1 text-xs font-semibold text-saffron">
                <span className="relative flex h-2 w-2">
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-saffron"></span>
                </span>
                Results from the past day, via news wires
              </div>
              <h1 className="mt-3 font-display text-[clamp(2.2rem,1.2rem+3.5vw,4.2rem)] font-bold tracking-tight">
                All 26 Sports <span className="tri-text">Daily Results</span>
              </h1>
              <p className="mt-2 max-w-2xl text-base text-paper/75 sm:text-lg">
                Real daily match outcomes, scorelines, and competition milestones across Indian sports, updated automatically via news agency RSS feeds.
              </p>
              <p className="mt-2 min-h-[1.25rem] text-xs font-mono text-primary">
                {resultsData?.lastUpdated ? `Last updated ${timeAgo(resultsData.lastUpdated)}` : ""}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => refreshResultsMutation.mutate()}
                disabled={refreshResultsMutation.isPending}
                data-testid="button-refresh-scores"
                className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-semibold backdrop-blur transition hover:bg-white/20 disabled:opacity-60"
              >
                <RefreshCw className={cn("h-4 w-4", refreshResultsMutation.isPending && "animate-spin text-saffron")} />
                {refreshResultsMutation.isPending ? "Scanning Results..." : "Check Daily Results"}
              </button>

              <button
                onClick={() => fetchNewsMutation.mutate()}
                disabled={fetchNewsMutation.isPending}
                data-testid="button-fetch-news"
                className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-lg shadow-orange-500/20 hover:brightness-105 disabled:opacity-60"
              >
                <Sparkles className={cn("h-4 w-4", fetchNewsMutation.isPending && "animate-spin")} />
                {fetchNewsMutation.isPending ? "Updating Wire..." : "Update Wire Dispatches"}
              </button>
            </div>
          </div>
        </Container>
      </section>

      {/* Navigation & Controls Strip */}
      <section className="sticky top-0 z-30 border-b border-border bg-background/95 shadow-sm backdrop-blur">
        <Container className="py-3">
          <div className="flex flex-col gap-3">
            {/* View Switcher Tabs */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-1 rounded-full border border-border bg-card/80 p-1">
                <button
                  onClick={() => setActiveTab("scores")}
                  className={cn(
                    "flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-bold transition",
                    activeTab === "scores"
                      ? "bg-primary text-primary-foreground shadow"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  <Trophy className="h-3.5 w-3.5" />
                  26 Sports Daily Results
                </button>
                <button
                  onClick={() => setActiveTab("news")}
                  className={cn(
                    "flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-bold transition",
                    activeTab === "news"
                      ? "bg-primary text-primary-foreground shadow"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  <Newspaper className="h-3.5 w-3.5" />
                  News wire
                </button>
                <button
                  onClick={() => setActiveTab("chat")}
                  className={cn(
                    "flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-bold transition",
                    activeTab === "chat"
                      ? "bg-primary text-primary-foreground shadow"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  <Bot className="h-3.5 w-3.5" />
                  Search the wire desk
                </button>
              </div>

              {/* Date Filter Tabs - only for dates that have data */}
              {activeTab === "scores" && (
                <div className="no-scrollbar flex items-center gap-1.5 overflow-x-auto py-1">
                  <button
                    onClick={() => setSelectedDate("all")}
                    className={cn(
                      "whitespace-nowrap rounded-full px-3 py-1 text-xs font-semibold transition flex items-center gap-1.5 border-none",
                      selectedDate === "all"
                        ? "bg-orange-500 text-white font-bold shadow"
                        : "bg-white/[0.05] hover:bg-white/[0.09] text-slate-300"
                    )}
                  >
                    <span>All Dates</span>
                  </button>
                  {availableDates.map(dateStr => (
                    <button
                      key={dateStr}
                      onClick={() => setSelectedDate(dateStr)}
                      className={cn(
                        "whitespace-nowrap rounded-full px-3 py-1 text-xs font-semibold transition flex items-center gap-1.5 border-none",
                        selectedDate === dateStr
                          ? "bg-orange-500 text-white font-bold shadow"
                          : "bg-white/[0.05] hover:bg-white/[0.09] text-slate-300"
                      )}
                    >
                      <span>{dateStr}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Sport Category Filter Pills - swipeable chip row */}
            <div className="swipe-chips items-center">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 shrink-0 mr-1 self-center">
                Sport ({ALL_26_SPORTS.length - 1}):
              </span>
              {ALL_26_SPORTS.map(sp => (
                <button
                  key={sp}
                  onClick={() => setSelectedSport(sp)}
                  data-testid={`agent-filter-${sp.toLowerCase().replace(/\s+/g, "-")}`}
                  className={cn(
                    "swipe-chip transition shadow-sm border-none",
                    selectedSport === sp
                      ? "bg-orange-500 text-white font-bold shadow-md shadow-orange-500/20"
                      : "bg-white/[0.05] hover:bg-white/[0.09] text-slate-300"
                  )}
                >
                  {sp === "all" ? "All 26 Sports" : sp}
                </button>
              ))}
            </div>
          </div>
        </Container>
      </section>

      {/* Main Content Area */}
      <Container className="pt-8">
        {/* ==================== TAB 1: 26 SPORTS DAILY RESULTS ==================== */}
        {activeTab === "scores" && (
          <div>
            <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-bold text-primary">
                    {selectedDate === "all" ? "All Stored Dates" : selectedDate}
                  </span>
                  <span className="text-xs text-muted-foreground">·</span>
                  <span className="text-xs font-semibold text-muted-foreground">
                    {selectedSport === "all" ? "All 26 Sports" : selectedSport}
                  </span>
                </div>
                <h2 className="mt-1 font-display text-2xl font-bold">
                  Results from the past day, via news wires
                </h2>
                <p className="text-sm text-muted-foreground">
                  India competition match results, wins, and medal outcomes tracked across authoritative sports feeds.
                </p>
              </div>

              <div className="flex items-center gap-3 text-xs font-mono text-muted-foreground">
                <span className="border-l border-border pl-3">
                  {resultsList.length} Results Found
                </span>
              </div>
            </div>

            {resultsLoading ? (
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3, 4, 5, 6].map(i => (
                  <div key={i} className="h-44 animate-pulse rounded-2xl border border-border bg-card/50 p-5" />
                ))}
              </div>
            ) : resultsList.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-border p-12 text-center text-muted-foreground">
                <Trophy className="mx-auto h-8 w-8 opacity-40 text-saffron" />
                <p className="mt-3 font-semibold text-foreground">
                  No India results reported yet for this sport today.
                </p>
                <p className="mt-1 text-xs">Switch to "All Dates" or select "All 26 Sports".</p>
              </div>
            ) : (
              <>
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {paginatedResults.map((item: any) => (
                  <div
                    key={item.id}
                    className="group relative flex flex-col justify-between rounded-2xl border-none bg-[#131926] p-5 shadow-sm transition-all hover:bg-[#182030] hover:shadow-xl"
                    style={{ minWidth: 0, overflowWrap: "anywhere" }}
                  >
                    <div style={{ minWidth: 0 }}>
                      {/* Top Ribbon: Sport on left, Date and Source on right */}
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <span className="font-mono font-bold uppercase tracking-wider text-saffron shrink-0">
                          {item.sport}
                        </span>
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="text-[11px] text-slate-400 shrink-0 font-mono">
                            {item.date_ist}
                          </span>
                          <span className="rounded-full border-none bg-white/[0.05] px-2 py-0.5 text-[10px] text-slate-300 truncate">
                            {item.source}
                          </span>
                        </div>
                      </div>

                      {/* Headline */}
                      <h3
                        className="mt-3 font-display text-base font-bold leading-snug text-slate-100 group-hover:text-primary transition-colors"
                        style={{ overflowWrap: "anywhere", minWidth: 0 }}
                      >
                        {item.headline}
                      </h3>

                      {/* Extracted score if literally present */}
                      {item.score_text && (
                        <div className="mt-3 inline-flex items-center gap-1.5 rounded-lg border-none bg-emerald-950/40 px-2.5 py-1 text-xs font-mono font-bold text-emerald-400">
                          Score: {item.score_text}
                        </div>
                      )}
                    </div>

                    {/* Footer */}
                    <div className="mt-4 flex items-center justify-between border-none pt-2 text-xs text-slate-400">
                      <span className="text-[11px] truncate mr-2 font-medium">Source: {item.source}</span>
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 font-semibold text-primary hover:underline shrink-0"
                      >
                        <span>Read source</span>
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
              <PaginationControl
                page={resultsPage}
                setPage={setResultsPage}
                pageSize={RESULTS_PAGE_SIZE}
                totalItems={resultsList.length}
                label="results"
              />
              {resultsCursor && (
                <div className="mt-4 flex justify-center">
                  <button
                    onClick={() => loadOlder("results")}
                    disabled={loadingOlder === "results"}
                    className="rounded-full border border-border px-5 py-2 text-xs font-bold hover:border-primary disabled:opacity-50"
                  >
                    {loadingOlder === "results" ? "Loading older results…" : "Load older results"}
                  </button>
                </div>
              )}
            </>
          )}
          </div>
        )}

        {/* ==================== TAB 2: NEWSROOM STREAM ==================== */}
        {activeTab === "news" && (
          <div>
            <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-display text-2xl font-bold">
                  {selectedSport === "all" ? "In-Depth Sports Journalism & Wire Feed" : `${selectedSport} News & Wire Feed`}
                </h2>
                <p className="text-sm text-muted-foreground">
                  Reporting from verified publisher RSS wires across Indian and international sporting circuits.
                </p>
                {newsData?.lastUpdated && (
                  <p className="mt-1 text-xs font-mono text-primary">
                    Last updated {timeAgo(newsData.lastUpdated)}
                  </p>
                )}
              </div>

              <button
                onClick={() => fetchNewsMutation.mutate()}
                disabled={fetchNewsMutation.isPending}
                className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-xs font-semibold hover:bg-muted"
              >
                <RefreshCw className={cn("h-3.5 w-3.5", fetchNewsMutation.isPending && "animate-spin text-primary")} />
                Scan For Breaking News
              </button>
            </div>

            {newsLoading ? (
              <div className="grid gap-6 md:grid-cols-2">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="h-64 animate-pulse rounded-2xl border border-border bg-card/50" />
                ))}
              </div>
            ) : newsList.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-border p-12 text-center text-muted-foreground">
                <Newspaper className="mx-auto h-8 w-8 opacity-40 text-saffron" />
                <p className="mt-3 font-semibold text-foreground">No news reports found for this sport</p>
                <p className="mt-1 text-xs">Switch to "All 26 Sports" or click "Scan For Breaking News".</p>
              </div>
            ) : (
              <>
                <div className="grid gap-6 md:grid-cols-2">
                {paginatedAgentNews.map((item: any) => {
                  const thumb = item.image_url || sportImage(item.sport);
                  return (
                    <article
                      key={item.id}
                      className="flex flex-col justify-between rounded-2xl border-none bg-[#131926] p-5 shadow-sm transition hover:bg-[#182030] hover:shadow-lg"
                      style={{ minWidth: 0, overflowWrap: "anywhere" }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div className="relative mb-4 aspect-[16/9] w-full overflow-hidden rounded-xl bg-muted">
                          <img
                            src={thumb}
                            alt=""
                            className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
                            onError={(e) => {
                              (e.currentTarget as HTMLImageElement).src = sportImage(item.sport);
                            }}
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                          <div className="absolute left-3 bottom-3 flex items-center gap-1.5">
                            <span className="rounded-full bg-black/75 backdrop-blur px-2 py-0.5 text-[10px] font-bold text-amber-300">
                              {item.sport}
                            </span>
                          </div>
                          <span className="absolute right-3 bottom-3 text-[11px] text-white/90 font-medium">
                            {new Date(item.published_at).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })} IST
                          </span>
                        </div>

                        <div className="flex items-center justify-between gap-2 text-xs">
                          <span className="font-bold text-saffron truncate">{item.source}</span>
                          <span className="text-muted-foreground shrink-0">
                            {new Date(item.published_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                          </span>
                        </div>

                        <h3
                          className="mt-2 font-display text-lg font-bold leading-snug text-foreground"
                          style={{ overflowWrap: "anywhere", minWidth: 0 }}
                        >
                          {item.title}
                        </h3>

                        {/* Real summary only if present */}
                        {item.summary && (
                          <p
                            className="mt-2.5 text-xs leading-relaxed text-muted-foreground line-clamp-3"
                            style={{ overflowWrap: "anywhere", minWidth: 0 }}
                          >
                            {item.summary}
                          </p>
                        )}
                      </div>

                      <div className="mt-5 flex items-center justify-between border-none pt-2 text-xs text-slate-400">
                        <span className="truncate mr-2">Agency: <strong className="text-foreground">{item.source}</strong></span>
                        {item.url && (
                          <a
                            href={item.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 font-semibold text-primary hover:underline shrink-0"
                          >
                            <span>Read Full Article</span>
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        )}
                      </div>
                    </article>
                  );
                })}
              </div>
              <PaginationControl
                page={agentNewsPage}
                setPage={setAgentNewsPage}
                pageSize={AGENT_NEWS_PAGE_SIZE}
                totalItems={newsList.length}
                label="news stories"
              />
              {agentNewsCursor && (
                <div className="mt-4 flex justify-center">
                  <button
                    onClick={() => loadOlder("news")}
                    disabled={loadingOlder === "news"}
                    className="rounded-full border border-border px-5 py-2 text-xs font-bold hover:border-primary disabled:opacity-50"
                  >
                    {loadingOlder === "news" ? "Loading older stories…" : "Load older news stories"}
                  </button>
                </div>
              )}
            </>
          )}
          </div>
        )}

        {/* ==================== TAB 3: CONVERSATIONAL SPORTS AI ==================== */}
        {activeTab === "chat" && (
          <div className="mx-auto max-w-4xl">
            <div className="mb-6">
              <h2 className="font-display text-2xl font-bold">Search the Wire Desk (Factual Grounded Records)</h2>
              <p className="text-sm text-muted-foreground">
                Query daily match results, medal outcomes, and current news across all 26 sports sourced directly from verified news wires.
              </p>
              <div className="mt-2.5 inline-flex items-center gap-2 rounded-lg border border-primary/20 bg-primary/10 px-3 py-1.5 text-xs text-primary">
                <Sparkles className="h-3.5 w-3.5" />
                <span>Deterministic query engine: answers are sourced strictly from stored SQLite news and results with real publisher links. Zero generative hallucination; no LLM API key required.</span>
              </div>
            </div>

            <div className="mb-4 flex flex-wrap gap-2">
              <span className="text-xs font-semibold text-muted-foreground self-center">Try asking:</span>
              {[
                "Who won in cricket today?",
                "Latest badminton results",
                "Did India win medals in shooting?",
                "Recent athletics updates",
                "What results were reported today?"
              ].map(q => (
                <button
                  key={q}
                  onClick={() => {
                    setUserQuery(q);
                    queryMutation.mutate(q);
                  }}
                  className="rounded-full border border-border bg-card px-3 py-1 text-xs text-muted-foreground hover:border-primary/50 hover:text-foreground transition"
                >
                  {q}
                </button>
              ))}
            </div>

            <div className="flex h-[520px] flex-col rounded-2xl border border-border bg-card shadow-sm">
              <div className="flex-1 space-y-4 overflow-y-auto p-4 sm:p-6">
                {chatLog.map((msg, i) => (
                  <div
                    key={i}
                    className={cn("flex gap-3", msg.role === "user" ? "justify-end" : "justify-start")}
                  >
                    {msg.role === "agent" && (
                      <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary font-bold text-primary-foreground text-xs">
                        MI
                      </div>
                    )}
                    <div
                      className={cn(
                        "max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed",
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground font-medium rounded-br-xs"
                          : "border border-border/80 bg-background/80 text-foreground rounded-bl-xs"
                      )}
                      style={{ overflowWrap: "anywhere", minWidth: 0 }}
                    >
                      <div className="whitespace-pre-wrap">{msg.text}</div>
                    </div>
                  </div>
                ))}
                {queryMutation.isPending && (
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <div className="grid h-8 w-8 place-items-center rounded-full bg-primary/20 text-primary">
                      <Sparkles className="h-4 w-4 animate-spin" />
                    </div>
                    <span>Scanning daily results and wire dispatches...</span>
                  </div>
                )}
              </div>

              <form onSubmit={handleSendQuery} className="border-t border-border p-3 sm:p-4">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={userQuery}
                    onChange={e => setUserQuery(e.target.value)}
                    placeholder="Search the wire desk (e.g. 'badminton results today', 'who won in cricket?')..."
                    className="flex-1 rounded-full border border-border bg-background px-4 py-2.5 text-sm outline-none transition focus:border-primary focus:ring-1 focus:ring-primary"
                  />
                  <button
                    type="submit"
                    disabled={!userQuery.trim() || queryMutation.isPending}
                    data-testid="button-send-query"
                    className="grid h-10 w-10 place-items-center rounded-full bg-primary text-primary-foreground shadow transition hover:brightness-105 disabled:opacity-50"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </Container>
    </div>
  );
}
