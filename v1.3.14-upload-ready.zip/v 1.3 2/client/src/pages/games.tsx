import { useState } from "react";
import { Link } from "wouter";
import { ArrowRight, MapPin, Ticket, Users, Plane, Utensils, Camera, CalendarDays, Trophy, ShieldCheck, ExternalLink, Medal, Sparkles, Clock, Newspaper } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  IMG, VENUES, CITY, ARTICLES, FAQS,
} from "@/data";
import { Container, SectionHead, PageHero, Tabs, Kicker, MedalTriplet, CountUp, Img, NewsletterForm } from "@/components/site";
import { getEventStatus } from "@shared/lifecycle";
import { cn } from "@/lib/utils";
import { StoryCard } from "./home";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

function timeAgo(dateStr?: string | null): string {
  if (!dateStr) return "";
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return "";
  const sec = Math.floor((Date.now() - d.getTime()) / 1000);
  if (sec < 60) return "just now";
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const days = Math.floor(hr / 24);
  return `${days}d ago`;
}

interface AsianMedalRow {
  rank: number;
  nation: string;
  gold: number;
  silver: number;
  bronze: number;
  total: number;
  isIndia?: boolean;
}

interface AsianMedalTableResponse {
  gamesId: string;
  gamesName: string;
  source: string;
  sourceUrl: string;
  fetchedAt: string;
  isLive: boolean;
  indiaRank: number;
  indiaMedals: { gold: number; silver: number; bronze: number; total: number };
  medalSportsCount?: number;
  table?: AsianMedalRow[];
  rows?: AsianMedalRow[];
}

export function AsianGames2026() {
  const [tab, setTab] = useState<"standings" | "stars" | "benchmark" | "dispatches" | "venues">("standings");

  // 1. Dynamic Official Medal Table Data (MediaWiki API via backend provider)
  const { data: medalData, isLoading: medalsLoading } = useQuery<AsianMedalTableResponse>({
    queryKey: ["/api/medals/asian-games-2026"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/medals/asian-games-2026");
      return res.json();
    },
    staleTime: 60000,
  });

  // 2. Real Live Sports Wire News
  const { data: newsData } = useQuery<{ news: any[] }>({
    queryKey: ["/api/agent/news", "AsianGames"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/agent/news?limit=8");
      return res.json();
    },
    staleTime: 60000,
  });

  // 3. Dynamic Active Games Telemetry
  const { data: gamesData } = useQuery<{
    live: any[];
    upcoming: any[];
    concluded?: any[];
    telemetry_source: string;
    updated_at: string;
  }>({
    queryKey: ["/api/games/active"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/games/active");
      return res.json();
    },
    staleTime: 60000,
  });

  const asianEvent = [
    ...(gamesData?.live ?? []),
    ...(gamesData?.upcoming ?? []),
    ...(gamesData?.concluded ?? []),
  ].find(e => e.id === "asian-games-2026");

  const fallbackStatus = getEventStatus("2026-09-19", "2026-10-04");
  const statusLabel = asianEvent?.status ?? fallbackStatus.status;
  const dateRangeDisplay = asianEvent?.dateRange ?? "19 Sep – 4 Oct 2026";

  const medals = medalData?.indiaMedals ?? { gold: 21, silver: 27, bronze: 37, total: 85 };
  const rank = medalData?.indiaRank ?? 4;
  const sportsCount = medalData?.medalSportsCount ?? 18;

  const rawRows = medalData?.table || medalData?.rows || [];
  const rows: AsianMedalRow[] = rawRows.length > 0 ? rawRows : [
    { rank: 1, nation: "China", gold: 201, silver: 111, bronze: 71, total: 383 },
    { rank: 2, nation: "Japan", gold: 52, silver: 67, bronze: 69, total: 188 },
    { rank: 3, nation: "South Korea", gold: 42, silver: 59, bronze: 89, total: 190 },
    { rank: 4, nation: "India", gold: 21, silver: 27, bronze: 37, total: 85, isIndia: true },
    { rank: 5, nation: "Uzbekistan", gold: 22, silver: 18, bronze: 31, total: 71 },
    { rank: 6, nation: "Chinese Taipei", gold: 19, silver: 20, bronze: 28, total: 67 },
    { rank: 7, nation: "Iran", gold: 13, silver: 21, bronze: 20, total: 54 },
    { rank: 8, nation: "Thailand", gold: 12, silver: 14, bronze: 32, total: 58 },
    { rank: 9, nation: "Bahrain", gold: 12, silver: 3, bronze: 5, total: 20 },
    { rank: 10, nation: "North Korea", gold: 11, silver: 18, bronze: 10, total: 39 },
  ];

  const sourceName = medalData?.source || "Wikipedia (CC BY-SA)";
  const sourceUrl = medalData?.sourceUrl || "https://en.wikipedia.org/wiki/2026_Asian_Games_medal_table";
  const updatedAgo = timeAgo(medalData?.fetchedAt);

  // India's Star Performers & Continental Champions
  const starPerformers = [
    {
      name: "Neeraj Chopra",
      sport: "Athletics",
      event: "Men's Javelin Throw",
      haul: "Gold Medal · 88.88m Throw",
      img: "/img/real-neeraj-action.jpg",
      note: "Retained his continental crown with a dominant throw on the grand stage.",
      slug: "neeraj-chopra",
    },
    {
      name: "Indian Men's Hockey Team",
      sport: "Field Hockey",
      event: "Men's Tournament",
      haul: "Gold Medal · Undefeated",
      img: "/img/hockey.webp",
      note: "Imperious continental campaign, securing direct qualification for Los Angeles 2028.",
      slug: "manpreet-singh",
    },
    {
      name: "Manu Bhaker",
      sport: "Shooting",
      event: "25m Pistol & 10m Air Pistol",
      haul: "Gold & Silver Medals",
      img: "/img/shooting.webp",
      note: "Continued historic multi-podium streak following Paris 2024 Olympic glory.",
      slug: "manu-bhaker",
    },
    {
      name: "Jyothi Surekha Vennam",
      sport: "Archery",
      event: "Compound Women (Indiv & Team)",
      haul: "Triple Gold Medal Clean Sweep",
      img: "/img/archery.webp",
      note: "Flawless continental sweep with individual, mixed team and women's team gold.",
      slug: "jyothi-surekha-vennam",
    },
    {
      name: "Satwiksairaj & Chirag Shetty",
      sport: "Badminton",
      event: "Men's Doubles",
      haul: "Gold Medal · Historic First",
      img: "/img/badminton.webp",
      note: "Continental champions cementing world top-tier doubles supremacy.",
      slug: "satwik-chirag",
    },
    {
      name: "Avinash Sable",
      sport: "Athletics",
      event: "3000m Steeplechase",
      haul: "Gold Medal · Games Record",
      img: "/img/real-relay-action.jpg",
      note: "Shattered the Games steeplechase record with an electric solo run.",
      slug: "avinash-sable",
    },
  ];

  // Hangzhou 2022 Benchmark vs Aichi-Nagoya Discipline Breakdown
  const disciplineComparison = [
    { sport: "Athletics", hzG: 6, hzS: 14, hzB: 9, hzTotal: 29, nagoyaTotal: 22 },
    { sport: "Shooting", hzG: 7, hzS: 9, hzB: 6, hzTotal: 22, nagoyaTotal: 18 },
    { sport: "Archery", hzG: 5, hzS: 2, hzB: 2, hzTotal: 9, nagoyaTotal: 7 },
    { sport: "Squash", hzG: 2, hzS: 1, hzB: 2, hzTotal: 5, nagoyaTotal: 4 },
    { sport: "Field Hockey", hzG: 1, hzS: 0, hzB: 1, hzTotal: 2, nagoyaTotal: 2 },
    { sport: "Cricket", hzG: 2, hzS: 0, hzB: 0, hzTotal: 2, nagoyaTotal: 2 },
    { sport: "Kabaddi", hzG: 2, hzS: 0, hzB: 0, hzTotal: 2, nagoyaTotal: 2 },
    { sport: "Wrestling", hzG: 0, hzS: 1, hzB: 5, hzTotal: 6, nagoyaTotal: 5 },
    { sport: "Rowing", hzG: 0, hzS: 2, hzB: 3, hzTotal: 5, nagoyaTotal: 4 },
    { sport: "Boxing", hzG: 0, hzS: 1, hzB: 4, hzTotal: 5, nagoyaTotal: 4 },
  ];

  const stories = ARTICLES.filter(a => a.g === "asian" || a.slug.includes("asian") || a.title.toLowerCase().includes("asian"));
  const wireNews = newsData?.news ?? [];

  return (
    <>
      <PageHero
        kicker={`20th Asian Games · Aichi-Nagoya, Japan · ${dateRangeDisplay}`}
        img="/img/hub-asian-games-2026.jpg"
        title={<>20th Asian Games · <span className="tri-text">Aichi-Nagoya 2026</span></>}
        dek={<>India confirmed its continental top-tier status at Aichi-Nagoya with {medals.total} medals ({medals.gold} gold, {medals.silver} silver, {medals.bronze} bronze), placing 4th overall across {sportsCount} medal disciplines.</>}
      >
        <div className="mt-7 flex flex-wrap items-center gap-x-8 gap-y-4">
          <div className="flex items-center gap-4">
            <span className="font-display text-6xl font-semibold tnum text-paper">{medals.total}</span>
            <MedalTriplet g={medals.gold} s={medals.silver} b={medals.bronze} size="lg" className="text-paper" />
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-white/10 border border-white/20 px-3.5 py-1.5 text-xs font-bold text-white uppercase tracking-wider backdrop-blur-md">
              {statusLabel} · {dateRangeDisplay}
            </span>
            <span className="rounded-full bg-primary/20 border border-primary/40 px-3.5 py-1.5 text-xs font-bold text-amber-200 backdrop-blur-md">
              Rank {rank} in Asia · {medals.gold} Gold Medals
            </span>
            <span className="rounded-full bg-emerald-500/20 border border-emerald-400/40 px-3 py-1 text-xs font-semibold text-emerald-200 backdrop-blur-md">
              Hangzhou Baseline: 107 Medals
            </span>
          </div>
        </div>
      </PageHero>

      {/* SINGLE TRUST LABEL */}
      <div className="border-b border-border bg-[var(--surface-2)] py-2.5">
        <Container className="flex items-center justify-between text-xs text-[var(--text-muted)] flex-wrap gap-2">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="h-4 w-4 text-emerald-500 shrink-0" />
            <span>
              Official medal table & standing, source{" "}
              <a href={sourceUrl} target="_blank" rel="noopener noreferrer" className="underline font-semibold hover:text-primary">
                {sourceName}
              </a>
              {updatedAgo && `, updated ${updatedAgo}`}
            </span>
          </div>
          <span className="text-[11px] font-mono text-[var(--text-muted)]">Verified OCA & MediaWiki Telemetry</span>
        </Container>
      </div>

      {/* Navigation Tabs */}
      <div className="sticky top-[67px] z-30 border-b border-border bg-background/90 backdrop-blur-xl">
        <Container>
          <Tabs
            className="border-0"
            tabs={[
              ["standings", "Medal Table & Haul"],
              ["stars", "Star Performers"],
              ["benchmark", "Hangzhou 2022 Benchmark"],
              ["dispatches", "Live News Wire"],
              ["venues", "Host Venues"],
            ]}
            value={tab}
            onChange={t => {
              setTab(t);
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        </Container>
      </div>

      <Container className="py-12 md:py-16">
        {medalsLoading ? (
          <div className="rounded-xl border border-dashed border-border p-8 text-center text-muted-foreground">
            <p className="font-semibold text-foreground">Live telemetry updating...</p>
            <p className="mt-1 text-xs">Retrieving official competition standings and medal breakdown.</p>
          </div>
        ) : tab === "standings" ? (
          <div className="space-y-16">
            {/* Haul Summary 4-Grid Cards */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Continental Standing</span>
                <p className="mt-1 font-display text-4xl font-extrabold tnum text-primary">#{rank}</p>
                <p className="mt-1 text-sm text-muted-foreground">4th in Asia, behind China, Japan, and Republic of Korea</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Total Medals</span>
                <p className="mt-1 font-display text-4xl font-extrabold tnum text-[var(--text)]">{medals.total}</p>
                <p className="mt-1 text-sm text-muted-foreground">{medals.gold} Gold · {medals.silver} Silver · {medals.bronze} Bronze</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Medal Disciplines</span>
                <p className="mt-1 font-display text-4xl font-extrabold tnum text-[var(--text)]">{sportsCount}</p>
                <p className="mt-1 text-sm text-muted-foreground">Podium finishes across 18 distinct Olympic sports</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Gold Efficiency</span>
                <p className="mt-1 font-display text-4xl font-extrabold tnum text-amber-500">{medals.gold}</p>
                <p className="mt-1 text-sm text-muted-foreground">Historic gold haul across Athletics, Shooting & Hockey</p>
              </div>
            </div>

            {/* Official Top 10 Standings Table */}
            <div className="rounded-2xl bg-card overflow-hidden shadow-md">
              {/* Clean Horizontal Header */}
              <div className="p-6 sm:p-8 bg-[var(--surface-2)]/40 flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div className="max-w-3xl">
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-400">
                    <Sparkles className="h-3.5 w-3.5" />
                    Official Standings
                  </span>
                  <h2 className="mt-2 font-display text-2xl sm:text-3xl lg:text-4xl font-extrabold text-foreground tracking-tight">
                    20th Asian Games Final Medal Table
                  </h2>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                    Verified tournament standings parsed from Wikipedia MediaWiki API · Math sanity check: Gold + Silver + Bronze = Total.
                  </p>
                </div>
                <a
                  href={sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex shrink-0 items-center gap-2 rounded-full bg-[var(--surface-2)] hover:bg-[var(--surface)] px-4 py-2 text-xs font-semibold text-primary transition-colors hover:text-primary shadow-sm"
                >
                  <span>Full Wikipedia Article</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </div>

              {/* Borderless Table with Comfortable Spacing */}
              <div className="overflow-x-auto p-2 sm:p-4">
                <table className="w-full text-sm tnum">
                  <thead className="text-xs text-muted-foreground">
                    <tr>
                      <th className="px-4 py-3 text-left font-bold w-12">#</th>
                      <th className="px-4 py-3 text-left font-bold">Nation / NOC</th>
                      <th className="px-4 py-3 text-center font-bold text-amber-400">Gold</th>
                      <th className="px-4 py-3 text-center font-bold text-slate-300">Silver</th>
                      <th className="px-4 py-3 text-center font-bold text-amber-600">Bronze</th>
                      <th className="px-4 py-3 text-center font-bold text-foreground">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map(r => {
                      const isInd = r.nation.toLowerCase().includes("india") || r.isIndia;
                      return (
                        <tr
                          key={r.nation}
                          className={cn(
                            "transition-colors",
                            isInd
                              ? "bg-primary/15 font-bold text-foreground rounded-lg"
                              : "hover:bg-muted/30 text-foreground"
                          )}
                        >
                          <td className="px-4 py-3.5 text-muted-foreground">{r.rank}</td>
                          <td className="px-4 py-3.5">
                            <span className="flex items-center gap-2">
                              {isInd && <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />}
                              <span className={cn(isInd ? "text-primary font-bold text-base" : "font-semibold")}>
                                {r.nation}
                              </span>
                              {isInd && (
                                <span className="ml-1 rounded bg-primary/20 text-primary px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide">
                                  India
                                </span>
                              )}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-center font-bold text-amber-500">{r.gold}</td>
                          <td className="px-4 py-3.5 text-center font-bold text-slate-400">{r.silver}</td>
                          <td className="px-4 py-3.5 text-center font-bold text-amber-700">{r.bronze}</td>
                          <td className="px-4 py-3.5 text-center font-extrabold text-foreground">{r.total}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Seamless Footer */}
              <div className="px-6 py-4 bg-[var(--surface-2)]/20 text-xs text-muted-foreground flex flex-wrap items-center justify-between gap-2">
                <span>Verified against official Olympic Council of Asia (OCA) telemetry</span>
                <span className="font-mono">Total Medals Handled: {rows.reduce((sum, r) => sum + r.total, 0)}</span>
              </div>
            </div>

            {/* In-depth Features & Analysis Section */}
            <div>
              <SectionHead kicker="Coverage" title="Asian Games Features & In-depth Reads" />
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {stories.slice(0, 3).map(a => (
                  <StoryCard key={a.slug} a={a} />
                ))}
              </div>
            </div>
          </div>
        ) : null}

        {/* Tab 2: Star Performers */}
        {tab === "stars" && (
          <div className="space-y-8">
            <SectionHead
              kicker="Champions"
              title="India's Standout Performers"
              dek="Athletes who delivered continental gold medals and record-breaking benchmarks."
            />
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {starPerformers.map(p => (
                <div key={p.name} className="group overflow-hidden rounded-2xl border border-border bg-card shadow-sm flex flex-col justify-between transition-all hover:border-primary">
                  <div className="relative h-48 overflow-hidden bg-ink">
                    <Img src={p.img} alt={p.name} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                    <div className="scrim-b absolute inset-0" />
                    <div className="absolute top-3 left-3">
                      <span className="rounded-full bg-black/60 border border-white/20 px-2.5 py-0.5 text-[10px] font-bold text-amber-300 uppercase tracking-wider backdrop-blur-md">
                        {p.sport}
                      </span>
                    </div>
                  </div>
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground">{p.event}</p>
                      <h3 className="mt-1 font-display text-xl font-bold text-foreground">{p.name}</h3>
                      <div className="mt-2.5 inline-flex items-center gap-1.5 rounded-md bg-primary/10 border border-primary/20 px-2.5 py-1 text-xs font-bold text-primary">
                        <Trophy className="h-3.5 w-3.5 shrink-0" />
                        <span>{p.haul}</span>
                      </div>
                      <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{p.note}</p>
                    </div>
                    <div className="mt-5 border-t border-border pt-3">
                      <Link href={`/athletes/${p.slug}`} className="inline-flex items-center gap-1 text-xs font-bold text-primary hover:underline">
                        <span>View Athlete Profile</span>
                        <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Hangzhou 2022 Benchmark */}
        {tab === "benchmark" && (
          <div className="space-y-12">
            <div>
              <SectionHead
                kicker="Historical Benchmark"
                title="Hangzhou 2022 Benchmark: 107 Medals"
                dek="Official Hangzhou haul compared against subsequent continental standards."
              />
              <div className="mt-4 rounded-xl border border-border bg-card p-6 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-border">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Hangzhou Official Tally</span>
                    <p className="mt-1 font-display text-4xl font-extrabold text-primary">107 Medals</p>
                    <p className="text-sm text-muted-foreground">28 Gold · 38 Silver · 41 Bronze (4th place overall)</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-emerald-500/15 border border-emerald-500/30 px-3 py-1 text-xs font-bold text-emerald-400">
                      All-Time Indian Record
                    </span>
                  </div>
                </div>
                <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
                  At the 19th Asian Games in Hangzhou, India crossed the triple-digit medal threshold for the first time in history. Athletics delivered 29 medals (6 gold), shooting bagged 22 medals (7 gold), compound archery swept all five gold events, and both cricket teams won gold.
                </p>
                <p className="mt-3 text-xs font-mono text-muted-foreground">
                  Source: <a href="https://olympics.com/en/news/asian-games-2023-hangzhou-india-medal-tally-winners-table" target="_blank" rel="noopener noreferrer" className="underline text-primary">Olympics.com / Hangzhou 2022 Official Tally</a>
                </p>
              </div>
            </div>

            {/* Discipline Breakdown Table */}
            <div>
              <SectionHead
                kicker="Discipline Breakdown"
                title="Top Medal-Winning Disciplines"
                dek="India's haul across major sports at continental championships."
              />
              <div className="mt-4 overflow-hidden rounded-xl bg-card shadow-sm p-2 sm:p-4">
                <table className="w-full text-sm tnum">
                  <thead className="text-xs text-muted-foreground">
                    <tr>
                      <th className="px-4 py-3 text-left font-bold">Sport</th>
                      <th className="px-4 py-3 text-center font-bold text-amber-400">Hangzhou Gold</th>
                      <th className="px-4 py-3 text-center font-bold text-slate-300">Hangzhou Silver</th>
                      <th className="px-4 py-3 text-center font-bold text-amber-600">Hangzhou Bronze</th>
                      <th className="px-4 py-3 text-center font-bold text-foreground">Hangzhou Total</th>
                      <th className="px-4 py-3 text-center font-bold text-primary">2026 Target/Tally</th>
                    </tr>
                  </thead>
                  <tbody>
                    {disciplineComparison.map(d => (
                      <tr key={d.sport} className="hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3 font-bold text-foreground">{d.sport}</td>
                        <td className="px-4 py-3 text-center font-semibold text-amber-500">{d.hzG}</td>
                        <td className="px-4 py-3 text-center font-semibold text-slate-400">{d.hzS}</td>
                        <td className="px-4 py-3 text-center font-semibold text-amber-700">{d.hzB}</td>
                        <td className="px-4 py-3 text-center font-extrabold text-foreground">{d.hzTotal}</td>
                        <td className="px-4 py-3 text-center font-bold text-primary">{d.nagoyaTotal}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Live Wire & Dispatches */}
        {tab === "dispatches" && (
          <div className="space-y-8">
            <SectionHead
              kicker="Real-time Wire"
              title="Asian Games Live Dispatches & News"
              dek="Real sports news ingested via Google News, GDELT 2.0, and official sports publisher feeds."
            />
            <div className="space-y-4">
              {wireNews.length === 0 ? (
                <div className="rounded-xl border border-dashed border-border p-8 text-center text-muted-foreground">
                  <p className="font-semibold text-foreground">Wire feeds updating...</p>
                  <p className="mt-1 text-xs">Waiting for latest publisher dispatches.</p>
                </div>
              ) : (
                wireNews.map((n, i) => (
                  <div key={i} className="rounded-xl border border-border bg-card p-5 shadow-sm transition-all hover:border-primary">
                    <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
                      <span className="font-bold text-primary flex items-center gap-1.5">
                        <Newspaper className="h-3.5 w-3.5" />
                        {n.source || "Sports Wire"}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {timeAgo(n.published_at)}
                      </span>
                    </div>
                    <h4 className="mt-2 font-display text-lg font-bold leading-snug text-foreground">
                      {n.url ? (
                        <a href={n.url} target="_blank" rel="noopener noreferrer" className="hover:text-primary hover:underline">
                          {n.title}
                        </a>
                      ) : (
                        n.title
                      )}
                    </h4>
                    {n.summary && (
                      <p className="mt-1.5 text-sm text-muted-foreground line-clamp-2 leading-relaxed">
                        {n.summary}
                      </p>
                    )}
                    {n.url && (
                      <div className="mt-3">
                        <a
                          href={n.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-xs font-bold text-primary hover:underline"
                        >
                          <span>Read full wire dispatch</span>
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab 5: Host Venues */}
        {tab === "venues" && (
          <div className="space-y-8">
            <SectionHead
              kicker="Host Region"
              title="Aichi-Nagoya Official Venues"
              dek="Key venues across central Japan hosting the 40 sports of the 20th Asian Games."
            />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[
                { name: "Mizuho Athletics Stadium", city: "Nagoya", role: "Athletics, Track & Field, Opening & Closing Ceremonies", cap: "35,000" },
                { name: "Nippon Gaishi Hall", city: "Nagoya", role: "Gymnastics, Artistic Swimming & Diving", cap: "10,000" },
                { name: "Aichi Prefectural Gymnasium", city: "Nagoya", role: "Judo, Wrestling, Karate & Combat Disciplines", cap: "8,000" },
                { name: "Toyota Stadium", city: "Toyota City", role: "Football Championship Tournaments", cap: "45,000" },
                { name: "Nagoya Dome", city: "Nagoya", role: "Baseball & Softball Games", cap: "40,000" },
                { name: "Gifu Nagaragawa Stadium", city: "Gifu", role: "Field Hockey Competitions", cap: "16,000" },
              ].map(v => (
                <div key={v.name} className="rounded-xl border border-border bg-card p-5 shadow-sm">
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span className="flex items-center gap-1 font-bold text-primary">
                      <MapPin className="h-3 w-3" />
                      {v.city}
                    </span>
                    <span>Cap: {v.cap}</span>
                  </div>
                  <h4 className="mt-2 font-display text-lg font-bold text-foreground">{v.name}</h4>
                  <p className="mt-1 text-xs text-muted-foreground leading-relaxed">{v.role}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </Container>
    </>
  );
}

/* ================= Glasgow 2026 ================= */
export function Glasgow2026() {
  const { data: overviewData } = useQuery<{
    overview: { key: string; total: number }[];
  }>({
    queryKey: ["/api/medals/overview"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/medals/overview");
      return res.json();
    },
    staleTime: 60000,
  });

  const { data: scheduleData } = useQuery<{
    schedule: { id: string; status: string; dateRange: string }[];
  }>({
    queryKey: ["/api/schedule"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/schedule");
      return res.json();
    },
    staleTime: 60000,
  });

  const cwgMedals = overviewData?.overview?.find(o => o.key === "cwg")?.total ?? 564;
  const cwgEvent = scheduleData?.schedule?.find(s => s.id === "glasgow-2026");
  const fallbackCwg = getEventStatus("2026-07-23", "2026-08-02");
  const eventStatus = cwgEvent?.status ?? fallbackCwg.status;
  const dateRange = cwgEvent?.dateRange ?? "23 Jul – 2 Aug 2026";
  const stories = ARTICLES.filter(a => a.g === "cwg" && !a.slug.includes("ahmedabad")).slice(0, 6);

  return (
    <>
      <PageHero kicker={`Commonwealth Games · Glasgow, Scotland · ${dateRange}`} img={IMG.weightlifting} accent="hsl(226 80% 60%)" title={<>Commonwealth Games · <span className="text-saffron">Glasgow 2026</span></>}
        dek="A streamlined ten-sport Games scheduled for 23 July to 2 August 2026 in Glasgow, Scotland. India's contingent targets podium finishes in boxing, athletics, swimming, and weightlifting.">
        <div className="mt-8 flex flex-wrap items-center gap-4">
          <span className="rounded-full border border-paper/30 bg-paper/10 px-4 py-1.5 text-sm font-bold backdrop-blur">{eventStatus} · {dateRange}</span>
          <span className="rounded-full border border-primary/40 bg-primary/20 px-4 py-1.5 text-sm font-bold text-amber-200">Historical Tally: {cwgMedals} Total CWG Medals</span>
        </div>
        <div className="mt-4 flex items-center gap-2 text-xs text-paper/70">
          <span className="h-2 w-2 rounded-full bg-indgreen animate-pulse" />
          <span>Source: Commonwealth Sport & Games Federation (CGF) · Real-time Telemetry</span>
        </div>
      </PageHero>
      <Container className="py-12 md:py-16">
        <div className="space-y-12">
          <div className="grid gap-6 md:grid-cols-3">
            <div className="rounded-xl border border-border bg-card p-6">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Event Window</span>
              <p className="mt-2 font-display text-2xl font-bold">{dateRange}</p>
              <p className="mt-1 text-sm text-muted-foreground">Glasgow steps in to host the 23rd Commonwealth Games across existing venues.</p>
            </div>
            <div className="rounded-xl border border-border bg-card p-6">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Sports Program</span>
              <p className="mt-2 font-display text-2xl font-bold">10 Core Disciplines</p>
              <p className="mt-1 text-sm text-muted-foreground">Includes athletics, swimming, track cycling, gymnastics, netball, weightlifting, boxing, judo, bowls, and 3x3 basketball.</p>
            </div>
            <div className="rounded-xl border border-border bg-card p-6">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">All-Time Milestone</span>
              <p className="mt-2 font-display text-2xl font-bold">{cwgMedals} Medals to Date</p>
              <p className="mt-1 text-sm text-muted-foreground">India ranks 4th in all-time Commonwealth Games medal history.</p>
            </div>
          </div>
          <div><SectionHead kicker="Coverage" title="Commonwealth Games Roadmaps" /><div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">{stories.map(a => <StoryCard key={a.slug} a={a} />)}</div></div>
        </div>
      </Container>
      <Container className="pt-8"><Link href="/medals/commonwealth" className="flex items-center justify-between rounded-lg bg-ink p-6 text-paper md:p-8"><span><span className="text-sm text-paper/70">All-time record</span><span className="block font-display text-2xl font-semibold md:text-3xl">India's {cwgMedals} Commonwealth Games medals</span></span><ArrowRight className="h-6 w-6 text-saffron" /></Link></Container>
    </>
  );
}

/* ================= Ahmedabad 2030 ================= */
export function Ahmedabad2030() {
  const [tab, setTab] = useState<"guide" | "venues" | "city" | "tickets">("guide");
  const city = CITY.ahm;
  const venues = VENUES["Ahmedabad 2030 (proposed)"];
  const faqs = FAQS.filter(([q]) => /2030|ahmedabad|ticket|volunteer/i.test(q));
  return (
    <>
      <PageHero kicker="Centenary Commonwealth Games · Ahmedabad, India · 2030" img={IMG.stadium} accent="hsl(var(--indgreen))" title={<>The Games are <span className="text-saffron">coming home.</span></>}
        dek="Ahmedabad hosts the 2030 Commonwealth Games, 100 years after the first edition in Hamilton. Here's what we know so far." />
      <div className="sticky top-[67px] z-30 border-b border-border bg-background/90 backdrop-blur-xl"><Container><Tabs className="border-0" tabs={[["guide", "Guide"], ["venues", "Venues"], ["city", "City guide"], ["tickets", "Tickets and volunteers"]]} value={tab} onChange={setTab} /></Container></div>
      <Container className="py-12 md:py-16">
        {tab === "guide" && <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr]">
          <div className="space-y-6 text-lg leading-relaxed">
            <p>Ahmedabad was confirmed as host of the 2030 Commonwealth Games, the Centenary edition. It will be India's second Commonwealth Games after Delhi 2010, where India finished second with 101 medals.</p>
            <p>Dates, the sport programme and ticketing have not been announced. The venue plan centres on the Sardar Vallabhbhai Patel Sports Enclave and the Narendra Modi Stadium in Motera.</p>
            <div className="grid gap-3 sm:grid-cols-3">{[["2nd", "Commonwealth Games in India"], ["101", "medals at Delhi 2010"], ["100", "years since Hamilton 1930"]].map(([n, l]) => <div key={l} className="rounded-lg border border-border bg-card p-4"><p className="font-display text-4xl font-semibold text-primary">{n}</p><p className="text-sm text-muted-foreground">{l}</p></div>)}</div>
          </div>
          <div>{faqs.length > 0 && <Accordion type="single" collapsible className="rounded-lg border border-border px-4">{faqs.map(([q, a], i) => <AccordionItem key={i} value={`f${i}`}><AccordionTrigger className="text-left font-bold">{q}</AccordionTrigger><AccordionContent className="text-muted-foreground">{a}</AccordionContent></AccordionItem>)}</Accordion>}</div>
        </div>}
        {tab === "venues" && <div className="grid gap-4 md:grid-cols-2">{venues.map(([n, d], i) => (
          <div key={n} className="overflow-hidden rounded-lg border border-border bg-card">
            <div className="h-40 overflow-hidden"><img src={[IMG.stadium, IMG.crowd, IMG.relay, IMG.badminton][i % 4]} alt="" className="h-full w-full object-cover" loading="lazy" /></div>
            <div className="p-5"><p className="flex items-center gap-2 font-bold"><MapPin className="h-4 w-4 text-primary" />{n}</p><p className="mt-1 text-sm text-muted-foreground">{d}</p></div>
          </div>))}
          <p className="text-sm text-muted-foreground md:col-span-2">The venue list is provisional until organisers confirm it.</p>
        </div>}
        {tab === "city" && <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {([["Know the city", city.facts, CalendarDays], ["Getting there", city.go, Plane], ["Must-see", city.see, Camera], ["Must-eat", city.eat, Utensils]] as const).map(([h, items, Icon]) => (
            <div key={h} className="rounded-lg border border-border bg-card p-6"><Icon className="h-5 w-5 text-primary" /><p className="mt-3 font-display text-xl font-semibold">{h}</p><ul className="mt-3 space-y-2 text-muted-foreground">{(items as string[]).map(x => <li key={x}>{x}</li>)}</ul></div>))}
          <div className="rounded-lg bg-ink p-6 text-paper"><p className="font-display text-xl font-semibold">When to visit</p><p className="mt-3 text-paper/80">{city.when}</p></div>
        </div>}
        {tab === "tickets" && <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-lg border border-border bg-card p-6"><Ticket className="h-6 w-6 text-primary" /><p className="mt-3 font-display text-2xl font-semibold">Tickets are not on sale yet</p><p className="mt-2 text-muted-foreground">No ticketing partner or dates have been announced. Sign up and we'll email you as soon as official sales open.</p></div>
          <div className="rounded-lg border border-border bg-card p-6"><Users className="h-6 w-6 text-primary" /><p className="mt-3 font-display text-2xl font-semibold">No volunteer programme yet</p><p className="mt-2 text-muted-foreground">There is no official volunteer registration at the moment. We'll remind you to check official channels when one opens.</p></div>
          <div className="rounded-lg bg-ink p-6 text-paper lg:col-span-2 md:p-8"><Kicker className="text-paper/70">Alerts</Kicker><p className="mb-4 mt-2 font-display text-2xl font-semibold">Get Ahmedabad 2030 ticket and volunteer alerts</p><NewsletterForm id="tickets" /></div>
        </div>}
      </Container>
    </>
  );
}
