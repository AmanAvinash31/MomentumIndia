import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Clock, ExternalLink, Sparkles, Radio } from "lucide-react";
import { ARTICLES, GAMES, fmtDate, readTime, sportImage } from "@/data";
import { Container, Img, Kicker, SectionHead, Tabs, NewsletterForm } from "@/components/site";
import { StoryCard } from "./home";
import { usePollInterval } from "@/lib/live-stream";
import NotFound from "./not-found";
import { cn } from "@/lib/utils";
import { ReportButton } from "@/components/action-buttons";
import { ShareButtons } from "@/components/share-buttons";
import { PaginationControl } from "@/components/pagination-control";

const FILTER_TAGS = [
  "All",
  "General",
  "Cricket",
  "Hockey",
  "Football",
  "Badminton",
  "Athletics",
  "Shooting",
  "Boxing",
  "Wrestling",
  "Para Sports",
  "International",
] as const;

function timeAgo(dateStr?: string | null): string {
  if (!dateStr) return "recently";
  const diffMs = Date.now() - new Date(dateStr).getTime();
  if (diffMs < 0 || isNaN(diffMs)) return "just now";
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins === 1) return "1 min ago";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs === 1) return "1 hr ago";
  if (hrs < 24) return `${hrs} hrs ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export function NewsIndex() {
  const [mode, setMode] = useState<"wire" | "articles">("wire");
  const [wireSport, setWireSport] = useState<string>("All");
  const [f, setF] = useState<"all" | "asian" | "cwg" | "oly" | "analysis">("all");
  // Numbered pagination (12 per page) for both wire and archive lists.
  // The wire previously rendered one fetched batch with no pages at all.
  const [wirePage, setWirePage] = useState(1);
  const [archivePage, setArchivePage] = useState(1);
  const WIRE_PAGE_SIZE = 12;
  const ARCHIVE_PAGE_SIZE = 12;
  // Older wire batches pulled through the API cursor, appended so the
  // page count grows instead of stopping at the first batch.
  const [extraWire, setExtraWire] = useState<any[]>([]);
  const [extraWireCursor, setExtraWireCursor] = useState<number | null>(null);
  const [loadingOlderWire, setLoadingOlderWire] = useState(false);

  const list = useMemo(() => ARTICLES.filter(a => f === "all" || (f === "analysis" ? a.kind === "analysis" : a.g === f && a.kind === "news")), [f]);
  const [first, ...rest] = list;

  // Query live wire news from verified sports wires
  const { data: wireData, isLoading: wireLoading } = useQuery<{
    sport: string;
    count: number;
    news: any[];
    nextCursor?: number | null;
    lastUpdated?: string | null;
  }>({
    queryKey: ["/api/agent/news", wireSport],
    queryFn: async () => {
      const url = wireSport === "All" ? "/api/agent/news?limit=100" : `/api/agent/news?sport=${encodeURIComponent(wireSport)}&limit=100`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch live wire news");
      return res.json();
    },
    refetchInterval: usePollInterval(25000),
  });

  const wireNews = useMemo(() => {
    const base = wireData?.news ?? [];
    const baseIds = new Set(base.map((x: any) => x.id));
    return [...base, ...extraWire.filter((x: any) => !baseIds.has(x.id))];
  }, [wireData, extraWire]);
  const wireCursor = extraWireCursor ?? wireData?.nextCursor ?? null;
  useEffect(() => { setWirePage(1); setExtraWire([]); setExtraWireCursor(null); }, [wireSport]);
  useEffect(() => { setArchivePage(1); }, [f]);
  const paginatedWire = useMemo(() => {
    const start = (wirePage - 1) * WIRE_PAGE_SIZE;
    return wireNews.slice(start, start + WIRE_PAGE_SIZE);
  }, [wireNews, wirePage]);
  const paginatedArchive = useMemo(() => {
    const start = (archivePage - 1) * ARCHIVE_PAGE_SIZE;
    return rest.slice(start, start + ARCHIVE_PAGE_SIZE);
  }, [rest, archivePage]);
  const loadOlderWire = async () => {
    if (!wireCursor || loadingOlderWire) return;
    setLoadingOlderWire(true);
    try {
      const params = new URLSearchParams({ limit: "100", cursor: String(wireCursor) });
      if (wireSport !== "All") params.set("sport", wireSport);
      const res = await fetch(`/api/agent/news?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to load older wire items");
      const data = await res.json();
      setExtraWire(prev => [...prev, ...(data.news ?? [])]);
      setExtraWireCursor(data.nextCursor ?? null);
    } catch { /* keep the loaded pages; the button stays available */ } finally {
      setLoadingOlderWire(false);
    }
  };

  return (
    <>
      <Container className="pt-12 md:pt-16">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <Kicker className="text-gold-ink">Momentum Sports Journalism</Kicker>
            <h1 className="mt-3 font-display text-[clamp(2.4rem,1.2rem+4vw,4.5rem)] font-semibold leading-[0.95]">
              {mode === "wire" ? "Live Sports Wire" : "News & Long-Form Analysis"}
            </h1>
            <p className="mt-3 max-w-2xl text-lg text-muted-foreground">
              {mode === "wire"
                ? "Real-time sports dispatches pulled continuously from news agency wires (Sportstar, The Hindu, NDTV Sports, ESPNcricinfo)."
                : "Archive investigative reports from Aichi-Nagoya, Glasgow and the road to Los Angeles 2028."}
            </p>
            {wireData?.lastUpdated && (
              <p className="mt-2 text-xs font-mono text-primary">
                Last updated {timeAgo(wireData.lastUpdated)}
              </p>
            )}
          </div>

          {/* Master View Switcher */}
          <div className="flex items-center gap-1.5 rounded-full border border-border bg-card p-1 shadow-sm">
            <button
              onClick={() => setMode("wire")}
              className={cn(
                "flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold transition",
                mode === "wire" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"
              )}
            >
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              Live Sports Wire
            </button>
            <button
              onClick={() => setMode("articles")}
              className={cn(
                "rounded-full px-4 py-2 text-xs font-bold transition",
                mode === "articles" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"
              )}
            >
              Archive Reports
            </button>
          </div>
        </div>

        {mode === "wire" ? (
          /* Wire Sport Category Filters - single swipeable chip row with 44px tap targets */
          <div className="mt-8 swipe-chips">
            {FILTER_TAGS.map(sp => (
              <button
                key={sp}
                onClick={() => setWireSport(sp)}
                data-testid={`filter-sport-${sp.toLowerCase()}`}
                className={cn(
                  "swipe-chip transition shadow-sm",
                  wireSport === sp
                    ? "bg-primary text-primary-foreground font-bold shadow-md shadow-primary/20"
                    : "border border-border/80 bg-card text-muted-foreground hover:text-foreground hover:border-primary/40"
                )}
              >
                {sp}
              </button>
            ))}
          </div>
        ) : (
          <Tabs className="mt-8" tabs={[["all", "All"], ["asian", "Asian Games"], ["cwg", "Commonwealth"], ["oly", "Olympics"], ["analysis", "Analysis"]]} value={f} onChange={setF} />
        )}
      </Container>

      <Container className="py-10">
        {mode === "wire" ? (
          wireLoading ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="h-72 animate-pulse rounded-2xl border border-border bg-card/60" />
              ))}
            </div>
          ) : wireNews.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border p-12 text-center text-muted-foreground">
              <p className="font-semibold text-foreground">No recent wire dispatches for {wireSport}</p>
              <p className="mt-1 text-xs">Switch to "All" to browse live sports headlines.</p>
            </div>
          ) : (
            <>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {paginatedWire.map((item: any) => {
                const imgSrc = item.image_url || sportImage(item.sport);
                return (
                  <article
                    key={item.id}
                    className="flex flex-col justify-between rounded-2xl border border-border/80 bg-card overflow-hidden shadow-sm transition hover:border-primary/50 hover:shadow-lg"
                    style={{ minWidth: 0, overflowWrap: "anywhere" }}
                  >
                    <div style={{ minWidth: 0 }}>
                      {/* Photo Header */}
                      <div className="relative aspect-[16/9] w-full overflow-hidden bg-muted">
                        <img
                          src={imgSrc}
                          alt=""
                          className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
                          onError={(e) => {
                            (e.currentTarget as HTMLImageElement).src = sportImage(item.sport);
                          }}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                        <div className="absolute left-3 bottom-3 flex items-center gap-1.5">
                          <span className="rounded-full bg-black/75 backdrop-blur px-2 py-0.5 text-[10px] font-bold text-amber-300">
                            {item.sport}
                          </span>
                        </div>
                        <span className="absolute right-3 bottom-3 text-[11px] text-white/90 font-medium">
                          {new Date(item.published_at).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })} IST
                        </span>
                      </div>

                      <div className="p-5" style={{ minWidth: 0 }}>
                        <div className="flex items-center justify-between text-xs text-muted-foreground gap-2">
                          <span className="font-bold text-saffron truncate">{item.source}</span>
                          <span className="shrink-0">{new Date(item.published_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</span>
                        </div>

                        <h3
                          className="mt-2.5 font-display text-base font-bold leading-snug text-foreground line-clamp-2"
                          style={{ overflowWrap: "anywhere", minWidth: 0 }}
                        >
                          {item.title}
                        </h3>

                        {/* Real summary if any, otherwise no snippet rendered */}
                        {item.summary && (
                          <p
                            className="mt-2 text-xs leading-relaxed text-muted-foreground line-clamp-3"
                            style={{ overflowWrap: "anywhere", minWidth: 0 }}
                          >
                            {item.summary}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="p-5 pt-0">
                      <div className="flex items-center justify-between border-t border-border/60 pt-3 text-xs text-muted-foreground">
                        <span className="text-[11px] truncate mr-2">Agency: <strong className="text-foreground">{item.source}</strong></span>
                        <ReportButton page={item.title} />
                        {item.url && (
                          <a
                            href={item.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 font-semibold text-primary hover:underline shrink-0"
                          >
                            <span>Read Full Article</span>
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        )}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
            <PaginationControl
              page={wirePage}
              setPage={setWirePage}
              pageSize={WIRE_PAGE_SIZE}
              totalItems={wireNews.length}
              label="wire stories"
            />
            {wireCursor && (
              <div className="mt-4 flex justify-center">
                <button
                  onClick={loadOlderWire}
                  disabled={loadingOlderWire}
                  className="rounded-full border border-border px-5 py-2 text-xs font-bold hover:border-primary disabled:opacity-50"
                >
                  {loadingOlderWire ? "Loading older stories…" : "Load older wire stories"}
                </button>
              </div>
            )}
            </>
          )
        ) : (
          !first ? (
            <p className="rounded-lg border border-dashed border-border p-10 text-center text-muted-foreground">
              No stories in this section yet. Try another filter.
            </p>
          ) : (
            <>
              <StoryCard a={first} size="lg" className="mb-12 lg:max-w-4xl" />
              <div className="grid gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
                {paginatedArchive.map(a => <StoryCard key={a.slug} a={a} />)}
              </div>
              <PaginationControl
                page={archivePage}
                setPage={setArchivePage}
                pageSize={ARCHIVE_PAGE_SIZE}
                totalItems={rest.length}
                label="archive stories"
              />
            </>
          )
        )}
      </Container>
    </>
  );
}

export function ArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const a = ARTICLES.find(x => x.slug === slug);
  if (!a) return <NotFound />;

  const l = a;
  const related = ARTICLES.filter(x => x.slug !== a.slug && x.g === a.g).slice(0, 3);

  return (
    <article>
      <Container className="pt-10 md:pt-14">
        <Link href="/news" data-testid="link-back-news" className="inline-flex items-center gap-1.5 text-sm font-bold text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />News
        </Link>
        <div className="mx-auto mt-8 max-w-3xl" style={{ overflowWrap: "anywhere", minWidth: 0 }}>
          <Kicker color={GAMES[a.g]?.color} className="text-muted-foreground">
            {GAMES[a.g]?.label}{a.kind === "analysis" ? " · Archive Analysis" : " · Archive"}
          </Kicker>
          <h1 className="mt-4 text-balance font-display text-[clamp(2.2rem,1.2rem+3.4vw,4rem)] font-semibold leading-[0.98]" style={{ overflowWrap: "anywhere", minWidth: 0 }}>
            {l.title}
          </h1>
          <p className="mt-5 text-pretty text-xl leading-relaxed text-muted-foreground" style={{ overflowWrap: "anywhere", minWidth: 0 }}>
            {l.body}
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-y border-border py-4">
            <div className="flex items-center gap-3 text-sm">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-foreground font-display font-semibold text-background">MI</span>
              <div>
                <p className="font-bold">Momentum India desk</p>
                <p className="flex items-center gap-2 text-muted-foreground">
                  {fmtDate(a.date)}<span>·</span><Clock className="h-3 w-3" />{readTime(a)} min read
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <ShareButtons title={a.title} />
              <ReportButton page={a.title} />
            </div>
          </div>
        </div>
      </Container>
      <Container className="mt-10">
        <figure className="mx-auto max-w-5xl">
          <div className="aspect-[16/9] overflow-hidden rounded-lg">
            <Img src={a.img} alt="" eager />
          </div>
          <figcaption className="mt-2 text-xs text-muted-foreground">Archive Photography.</figcaption>
        </figure>
      </Container>
      <Container>
        <div className="mx-auto mt-10 max-w-[68ch] space-y-6 text-[1.125rem] leading-[1.75]" style={{ overflowWrap: "anywhere", minWidth: 0 }}>
          {l.paras.map((p: string, i: number) => (
            <p
              key={i}
              className={cn("text-pretty", i === 0 && "first-letter:float-left first-letter:mr-2 first-letter:mt-1 first-letter:font-display first-letter:text-6xl first-letter:font-semibold first-letter:leading-[0.8] first-letter:text-primary")}
              style={{ overflowWrap: "anywhere", minWidth: 0 }}
            >
              {p}
            </p>
          ))}
        </div>
        <div className="mx-auto mt-14 max-w-3xl rounded-lg bg-ink p-6 text-paper md:p-8">
          <p className="font-display text-2xl font-semibold">Get stories like this after every big day</p>
          <div className="mt-4"><NewsletterForm id="article" /></div>
        </div>
      </Container>
      {related.length > 0 && (
        <Container className="mt-20">
          <SectionHead kicker="Keep reading" title="More from this Games" />
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {related.map(r => (
              <StoryCard key={r.slug} a={r} />
            ))}
          </div>
        </Container>
      )}
    </article>
  );
}
