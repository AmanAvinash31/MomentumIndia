import { useMemo, useState } from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowRight, Brain, CalendarHeart, Check, Crown, Lock, RotateCcw, Share2, Target, X } from "lucide-react";
import { Container, Kicker, SectionHead, PageHero, Tabs } from "@/components/site";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { usePrefs } from "@/lib/prefs";
import { OLY_MEDALS, OLY, ASIAN, CWG, isPlayed, total, MEDAL_LABEL, type OlyMedal } from "@/data";
import { field, Err } from "@/pages/nation";
import { cn } from "@/lib/utils";
import { DynamicQuiz } from "@/components/dynamic-quiz";

const wa = (text: string) => `https://wa.me/?text=${encodeURIComponent(text)}`;
const siteUrl = () => (typeof window !== "undefined" ? window.location.origin : "");
const ShareWA = ({ text, label = "Share on WhatsApp", testid }: { text: string; label?: string; testid?: string }) => (
  <a href={wa(text)} target="_blank" rel="noreferrer" data-testid={testid} className="inline-flex items-center gap-1.5 rounded-full bg-[#25D366] px-4 py-2 text-sm font-bold text-[#0b2e17] hover:brightness-105"><Share2 className="h-4 w-4" />{label}</a>
);

export default function FanZone() {
  const [tab, setTab] = useState<"predict" | "quiz" | "polls" | "today">("predict");
  return (
    <>
      <PageHero kicker="Fan zone · Play along" img="/img/celebration.webp" accent="#FF9933" title={<>Call it before it <span className="tri-text">happens</span></>}
        dek="Predict results, climb the leaderboard, test your memory of India's great days and vote in live community sports polls." />
      <Container className="py-10 md:py-14">
        <Tabs tabs={[["predict", "Predictions"], ["quiz", "Quiz"], ["polls", "Live Polls"], ["today", "On this day"]]} value={tab} onChange={setTab} />
        <div className="mt-8">{tab === "predict" ? <Predictions /> : tab === "quiz" ? <Quiz /> : tab === "polls" ? <CommunityPolls /> : <OnThisDay />}</div>
      </Container>
    </>
  );
}

/* ===================================================== predictions */
type Q = { id: number; question: string; options: string[]; closes_at: string; answer: string | null; points: number; topic: string | null; status: string; votes: Record<string, number> };
type Board = { nickname: string; points: number; correct: number; picks: number };
function Predictions() {
  const { followEmail, setFollowEmail } = usePrefs();
  const [email, setEmail] = useState(followEmail ?? "");
  const [nick, setNick] = useState("");
  const [ready, setReady] = useState(false);
  const { data } = useQuery<{ questions: Q[]; leaderboard: Board[]; players: number }>({ queryKey: ["/api/fan"] });
  const mine = useQuery<{ picks: { qid: number; choice: string }[] }>({ queryKey: [`/api/fan/mine/${email}`], enabled: ready && !!email });
  const myPick = new Map((mine.data?.picks ?? []).map(p => [p.qid, p.choice]));
  const pick = useMutation({
    mutationFn: async (b: { qid: number; choice: string }) => (await apiRequest("POST", "/api/fan/pick", { ...b, nickname: nick, email })).json(),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/fan"] }); mine.refetch(); },
  });
  const errMsg = pick.error ? (() => { const m = String((pick.error as Error).message); try { return JSON.parse(m.slice(m.indexOf("{"))).message as string; } catch { return "We couldn't save that pick. Try again."; } })() : null;
  const qs = data?.questions ?? [];
  const open = qs.filter(q => q.status === "open" && +new Date(q.closes_at) > Date.now());
  const closed = qs.filter(q => !open.includes(q));
  return (
    <div className="grid gap-10 lg:grid-cols-[1.5fr_1fr]">
      <div>
        {!ready ? (
          <form className="mb-8 grid gap-3 rounded-xl border border-border bg-card p-5 sm:grid-cols-[1fr_1fr_auto] sm:items-end" onSubmit={e => { e.preventDefault(); if (nick.trim().length >= 2 && /\S+@\S+\.\S+/.test(email)) { setReady(true); setFollowEmail(email.trim().toLowerCase()); } }}>
            <p className="sm:col-span-3"><b className="font-display text-xl">Join the game</b><span className="block text-sm text-muted-foreground">Your nickname appears on the leaderboard. Your email is only used to keep your picks; it is never shown.</span></p>
            <label className="text-sm"><span className="mb-1 block font-bold">Nickname</span><input className={field} value={nick} onChange={e => setNick(e.target.value)} maxLength={24} placeholder="Javelin_Junkie" data-testid="fan-nick" /></label>
            <label className="text-sm"><span className="mb-1 block font-bold">Email</span><input type="email" className={field} value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" data-testid="fan-email" /></label>
            <button className="h-11 rounded-full bg-primary px-6 font-bold text-primary-foreground" data-testid="fan-join">Start picking</button>
          </form>
        ) : <p className="mb-6 rounded-md bg-indgreen/10 p-3 text-sm" role="status">Playing as <b>{nick}</b>. You can change a pick until the question closes.</p>}
        <Err msg={errMsg} />
        <SectionHead kicker={`${open.length} open`} title="Make your picks" />
        {open.length === 0 && <p className="rounded-lg border border-dashed border-border p-8 text-center text-muted-foreground">No open questions right now. New ones go up before every big event.</p>}
        <ul className="space-y-4">{open.map(q => <QCard key={q.id} q={q} mine={myPick.get(q.id)} can={ready} busy={pick.isPending} onPick={c => pick.mutate({ qid: q.id, choice: c })} />)}</ul>
        {closed.length > 0 && <><SectionHead className="mt-12" kicker="Closed" title="Results and locked questions" />
          <ul className="space-y-4">{closed.map(q => <QCard key={q.id} q={q} mine={myPick.get(q.id)} can={false} busy={false} onPick={() => {}} />)}</ul></>}
      </div>
      <aside>
        <div className="sticky top-24 rounded-xl border border-border bg-card p-5">
          <p className="flex items-center gap-2 font-display text-xl font-semibold"><Crown className="h-5 w-5 text-gold" />Leaderboard</p>
          <p className="text-sm text-muted-foreground">{(data?.players ?? 0).toLocaleString("en-IN")} player{data?.players === 1 ? "" : "s"}. Points are added when a question is settled.</p>
          {(data?.leaderboard ?? []).length === 0 ? <p className="mt-4 rounded-md bg-muted p-4 text-sm">Be the first on the board.</p> : (
            <ol className="mt-4 divide-y divide-border">{data!.leaderboard.map((b, i) => (
              <li key={i} className="flex items-center justify-between gap-3 py-2.5 text-sm"><span className="flex items-center gap-3"><b className={cn("grid h-7 w-7 place-items-center rounded-full text-xs tnum", i === 0 ? "bg-gold text-ink" : i === 1 ? "bg-silver text-ink" : i === 2 ? "bg-bronze text-ink" : "bg-muted")}>{i + 1}</b><span className="font-bold">{b.nickname}</span></span><span className="tnum"><b>{b.points}</b> pts <span className="text-muted-foreground">· {b.correct}/{b.picks}</span></span></li>))}</ol>
          )}
          <div className="mt-5"><ShareWA text={`I'm predicting India's results on Momentum India. Think you can beat me? ${siteUrl()}/fan-zone`} label="Challenge friends" testid="fan-share" /></div>
        </div>
      </aside>
    </div>
  );
}
function QCard({ q, mine, can, busy, onPick }: { q: Q; mine?: string; can: boolean; busy: boolean; onPick: (c: string) => void }) {
  const votes = Object.values(q.votes).reduce((a, b) => a + b, 0);
  const closesIn = +new Date(q.closes_at) - Date.now();
  const isOpen = q.status === "open" && closesIn > 0;
  return (
    <li className="rounded-xl border border-border bg-card p-5" data-testid={`q-${q.id}`}>
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold uppercase tracking-[0.1em] text-muted-foreground"><span className="text-saffron">{q.topic ?? "Prediction"} · {q.points} pts</span>
        <span className="flex items-center gap-1">{isOpen ? <>Closes {new Date(q.closes_at).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })} IST</> : q.answer ? "Settled" : <><Lock className="h-3 w-3" />Closed, awaiting result</>}</span></div>
      <p className="mt-2 font-display text-xl font-semibold leading-snug">{q.question}</p>
      <div className="mt-4 grid gap-2 sm:grid-cols-2">{q.options.map(o => {
        const pct = votes ? Math.round(((q.votes[o] ?? 0) / votes) * 100) : 0;
        const right = q.answer === o, chosen = mine === o;
        return (
          <button key={o} disabled={!can || !isOpen || busy} onClick={() => onPick(o)} data-testid={`q-${q.id}-opt-${o.replace(/\W+/g, "-")}`}
            className={cn("relative overflow-hidden rounded-lg border p-3 text-left text-sm font-bold transition disabled:cursor-default", chosen ? "border-primary ring-2 ring-primary" : "border-border", right && "border-indgreen ring-2 ring-indgreen", can && isOpen && "hover:border-foreground/50")}>
            {votes > 0 && <span className="absolute inset-y-0 left-0 -z-0 bg-primary/10" style={{ width: `${pct}%` }} />}
            <span className="relative flex items-center justify-between gap-2"><span className="flex items-center gap-1.5">{right && <Check className="h-4 w-4 text-indgreen" />}{q.answer && chosen && !right && <X className="h-4 w-4 text-[hsl(2_75%_55%)]" />}{o}</span>{votes > 0 && <span className="tnum text-xs text-muted-foreground">{pct}%</span>}</span>
          </button>);
      })}</div>
      <p className="mt-3 text-xs text-muted-foreground">{votes.toLocaleString("en-IN")} pick{votes === 1 ? "" : "s"}{mine ? ` · Your pick: ${mine}` : can || !isOpen ? "" : " · Join above to pick"}</p>
    </li>
  );
}

/* ===================================================== quiz */
function Quiz() {
  return <DynamicQuiz />;
}

/* ===================================================== on this day */
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const parseD = (d: string) => { const [day, mon] = d.split(" "); return { day: +day, mon: MONTHS.indexOf(mon) }; };
const sentence = (m: OlyMedal) => `${m.n} won Olympic ${MEDAL_LABEL[m.m].toLowerCase()} in the ${m.ev.toLowerCase()} (${m.sp.toLowerCase()}) in ${m.y}.`;
function OnThisDay() {
  const now = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
  const today = OLY_MEDALS.filter(m => { const p = parseD(m.d); return p.day === now.getDate() && p.mon === now.getMonth(); });
  const ahead = OLY_MEDALS.map(m => { const p = parseD(m.d); let at = new Date(now.getFullYear(), p.mon, p.day); if (at < new Date(now.getFullYear(), now.getMonth(), now.getDate())) at = new Date(now.getFullYear() + 1, p.mon, p.day); return { m, at, days: Math.round((+at - +new Date(now.getFullYear(), now.getMonth(), now.getDate())) / 864e5) }; })
    .filter(x => x.days > 0).sort((a, b) => a.days - b.days).slice(0, 6);
  const label = now.toLocaleDateString("en-IN", { day: "numeric", month: "long" });
  return (
    <div className="grid gap-10 lg:grid-cols-[1.3fr_1fr]">
      <div>
        <Kicker className="text-saffron">{label}</Kicker>
        <h2 className="mt-2 font-display text-4xl font-semibold">On this day</h2>
        {today.length ? (
          <ul className="mt-6 space-y-4">{today.map(m => (
            <li key={m.n + m.y + m.ev} className="rounded-xl border border-border bg-card p-6"><p className="font-display text-6xl font-semibold tnum text-muted-foreground/60">{m.y}</p><p className="mt-2 text-xl font-semibold">{sentence(m)}</p>
              <div className="mt-4"><ShareWA text={`On this day in ${m.y}: ${sentence(m)} Via Momentum India ${siteUrl()}/fan-zone`} label="Share this moment" testid="otd-share" /></div></li>))}</ul>
        ) : (
          <div className="mt-6 rounded-xl border border-dashed border-border p-8"><CalendarHeart className="h-8 w-8 text-saffron" /><p className="mt-3 text-lg">No Indian Olympic medal was won on {label}. The next anniversary is {ahead[0] ? <b>in {ahead[0].days} day{ahead[0].days === 1 ? "" : "s"}</b> : "coming up"}.</p></div>
        )}
      </div>
      <aside>
        <p className="mb-3 flex items-center gap-2 font-bold"><Target className="h-4 w-4 text-primary" />Coming up</p>
        <ul className="divide-y divide-border rounded-xl border border-border bg-card">{ahead.map(({ m, at, days }) => (
          <li key={m.n + m.y + m.ev} className="p-4"><p className="text-xs font-bold uppercase tracking-[0.1em] text-muted-foreground">{at.toLocaleDateString("en-IN", { day: "numeric", month: "short" })} · in {days} day{days === 1 ? "" : "s"}</p><p className="mt-1 text-sm">{sentence(m)}</p></li>))}</ul>
        <p className="mt-3 text-xs text-muted-foreground">Dates from the Olympic medal records on this site. <Link href="/medals/olympics" className="font-bold text-primary hover:underline">See all 41 medals</Link>.</p>
      </aside>
    </div>
  );
}

/* ===================================================== live polls */
interface DynamicPoll {
  id: number;
  topic: string;
  question: string;
  options: string[];
  votes: Record<string, number>;
  total_votes: number;
  status: string;
}

function CommunityPolls() {
  const [myVotes, setMyVotes] = useState<Record<number, number>>({});

  const { data: pollsData, isLoading: pollsLoading, refetch } = useQuery<{
    count: number;
    polls: DynamicPoll[];
    telemetry_source: string;
    updated_at: string;
  }>({
    queryKey: ["/api/fan/polls"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/fan/polls");
      return res.json();
    },
    staleTime: 15000,
  });

  const voteMutation = useMutation({
    mutationFn: async ({ pollId, optionIndex }: { pollId: number; optionIndex: number }) => {
      const res = await apiRequest("POST", `/api/fan/polls/${pollId}/vote`, { optionIndex });
      return res.json();
    },
    onSuccess: (_, vars) => {
      setMyVotes(prev => ({ ...prev, [vars.pollId]: vars.optionIndex }));
      refetch();
    },
  });

  const polls = pollsData?.polls ?? [];

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5 font-medium">
          <span className="h-2 w-2 rounded-full bg-indgreen animate-pulse" />
          Source: {pollsData?.telemetry_source ?? "Momentum India Community Pulse"}
        </span>
        <span className="rounded bg-muted px-2 py-0.5 font-mono text-[11px]">Live Telemetry Active</span>
      </div>

      {pollsLoading ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground">
          <p className="font-semibold text-foreground">Live telemetry updating...</p>
          <p className="mt-1 text-xs">Retrieving active community polls.</p>
        </div>
      ) : polls.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground">
          <p className="font-semibold text-foreground">Live telemetry updating...</p>
          <p className="mt-1 text-xs">New community polls will be posted before upcoming events.</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2">
          {polls.map(p => {
            const hasVoted = myVotes[p.id] !== undefined;
            const chosen = myVotes[p.id];
            return (
              <div key={p.id} className="rounded-xl border border-border bg-card p-6 shadow-sm flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-saffron">{p.topic}</span>
                  <h3 className="mt-2 font-display text-xl font-bold leading-snug">{p.question}</h3>
                  <div className="mt-5 space-y-2.5">
                    {p.options.map((opt, idx) => {
                      const count = p.votes?.[String(idx)] ?? 0;
                      const pct = p.total_votes > 0 ? Math.round((count / p.total_votes) * 100) : 0;
                      const isChosen = chosen === idx;
                      return (
                        <button
                          key={opt}
                          disabled={voteMutation.isPending}
                          onClick={() => voteMutation.mutate({ pollId: p.id, optionIndex: idx })}
                          className={cn(
                            "group relative flex w-full items-center justify-between overflow-hidden rounded-lg border p-3.5 text-left text-sm font-semibold transition-all",
                            isChosen ? "border-primary bg-primary/10 ring-1 ring-primary" : "border-border bg-background/50 hover:border-primary/50"
                          )}
                        >
                          <span
                            className="absolute inset-y-0 left-0 -z-0 bg-primary/15 transition-all duration-500"
                            style={{ width: hasVoted ? `${pct}%` : "0%" }}
                          />
                          <span className="relative z-10 flex items-center gap-2">
                            {isChosen && <Check className="h-4 w-4 text-primary" />}
                            <span>{opt}</span>
                          </span>
                          {hasVoted && (
                            <span className="relative z-10 font-mono text-xs font-bold text-muted-foreground tnum">
                              {pct}% ({count})
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div className="mt-5 flex items-center justify-between border-t border-border pt-3 text-xs text-muted-foreground">
                  <span>{p.total_votes.toLocaleString("en-IN")} total votes</span>
                  <span>{hasVoted ? "Vote recorded" : "Click any option to vote"}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
