import { useQuery } from "@tanstack/react-query";
import { Container, PageHero, Kicker, SectionHead } from "@/components/site";
import { ExternalLink, Database, RefreshCw, ShieldCheck, CheckCircle2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface ProviderStatus {
  name: string;
  feeds: string;
  schedule: string;
  licence: string;
  status: string;
  source_url: string;
}

export function DataSourcesPage() {
  const { data, isLoading } = useQuery<{ providers: ProviderStatus[]; timestamp: string }>({
    queryKey: ["/api/providers/status"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/providers/status");
      return res.json();
    },
    staleTime: 60000,
  });

  const providers = data?.providers ?? [
    {
      name: "Wikidata Entity API",
      feeds: "Multi-sport Games calendar (dates, host cities, start P580, end P582)",
      schedule: "Daily at 04:00 IST",
      licence: "CC0 (Public Domain)",
      status: "Active",
      source_url: "https://www.wikidata.org",
    },
    {
      name: "Wikipedia MediaWiki API",
      feeds: "Medal tallies (India plus Top 10) for Asian Games, Para Games, CWG & Olympics",
      schedule: "Every 15 min (Live Games) · Every 6 hours (Ended)",
      licence: "Creative Commons Attribution-ShareAlike 4.0 (CC BY-SA)",
      status: "Active",
      source_url: "https://en.wikipedia.org",
    },
    {
      name: "TheSportsDB Free API",
      feeds: "Indian Super League (ISL league 4791) fixtures, scores, and standings",
      schedule: "Every 30 min on match days · 6 hours off-season",
      licence: "TheSportsDB Open Free API Terms",
      status: "Active",
      source_url: "https://www.thesportsdb.com",
    },
    {
      name: "GDELT DOC 2.0 API",
      feeds: "Real-time global news monitoring & headline indexing for Indian sporting events",
      schedule: "Every 10 min",
      licence: "Open Data (GDELT Project)",
      status: "Active",
      source_url: "https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/",
    },
    {
      name: "Official Federation Portals (PKL, HIL, BCCI)",
      feeds: "Direct official match centre portals and verified communications",
      schedule: "Direct verified links (no unauthorized scraping)",
      licence: "Official Fair Attribution",
      status: "Active",
      source_url: "https://www.prokabaddi.com",
    },
    {
      name: "Syndicated Publisher Feeds",
      feeds: "Sportstar, The Hindu, NDTV Sports, ESPNcricinfo, Google News Sports",
      schedule: "Every 10 min with circuit breaker safeguards",
      licence: "Publisher Fair Use & Direct Attribution Links",
      status: "Active",
      source_url: "https://sportstar.thehindu.com",
    },
  ];

  return (
    <>
      <PageHero
        kicker="Transparency & Data Standards"
        img="/img/relay.webp"
        title="Data Sources & Attribution"
        dek="Every number shown on Momentum India is fetched from verified, public, and free sources with open licences. We never invent scores or medal tallies."
      />

      <Container className="py-12 md:py-16">
        <div className="space-y-12">
          {/* Integrity Pledge */}
          <div className="rounded-[14px] border border-[var(--border)] bg-[var(--surface-2)] p-6 md:p-8 shadow-sm">
            <div className="flex items-start gap-4">
              <ShieldCheck className="h-7 w-7 text-emerald-500 shrink-0 mt-1" />
              <div>
                <h2 className="font-display text-xl md:text-2xl font-bold text-[var(--text)]">
                  The Zero-Invented-Numbers Standard
                </h2>
                <p className="mt-2 text-sm md:text-base text-[var(--text-muted)] leading-relaxed">
                  Momentum India operates under a strict data integrity policy:
                </p>
                <ul className="mt-3 space-y-2 text-sm text-[var(--text-muted)] list-disc pl-5">
                  <li><strong>Clear Attribution:</strong> Every live score, fixture, and medal tally explicitly displays its origin and relative timestamp (&ldquo;Source: Wikipedia (CC BY-SA), updated 5 min ago&rdquo;).</li>
                  <li><strong>Zero Invented Numbers:</strong> We never synthesize or extrapolate results. If a source endpoint fails, we show the last good cached value clearly labelled <em>stale</em>, or show a friendly notice. We never show fake zeros or placeholder blanks for missing data.</li>
                  <li><strong>Terms & Robot Rules:</strong> We respect all source terms and robot exclusion rules. We do not scrape Olympics.com, and we do not call undocumented ESPN endpoints.</li>
                  <li><strong>Automated Ingestion:</strong> Zero admin-panel data entry is required. Feeds update automatically via background cron guards with concurrency locks.</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Connected Providers */}
          <div>
            <SectionHead
              kicker="Connected Providers"
              title="Public Feeds & Ingestion Schedule"
              dek="All endpoints are normalized into our SQLite store with circuit breakers and fallback caching."
            />

            <div className="mt-6 grid gap-4 md:grid-cols-2">
              {providers.map((p) => (
                <div
                  key={p.name}
                  className="rounded-[14px] border border-[var(--border)] bg-[var(--surface)] p-5 shadow-sm transition hover:border-[var(--accent)]"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="flex items-center gap-2 font-display text-lg font-bold text-[var(--text)]">
                      <Database className="h-4 w-4 text-[var(--accent)]" />
                      {p.name}
                    </span>
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-0.5 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                      <CheckCircle2 className="h-3 w-3" />
                      {p.status}
                    </span>
                  </div>

                  <p className="mt-2 text-sm text-[var(--text)] font-medium">
                    {p.feeds}
                  </p>

                  <div className="mt-4 pt-3 space-y-1.5 text-xs text-[var(--text-muted)]">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1 font-semibold">
                        <RefreshCw className="h-3 w-3" />
                        Refresh Interval:
                      </span>
                      <span>{p.schedule}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">Licence / Attribution:</span>
                      <span className="text-right">{p.licence}</span>
                    </div>
                  </div>

                  <div className="mt-3 text-right">
                    <a
                      href={p.source_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs font-bold text-[var(--accent)] hover:underline"
                    >
                      <span>Visit Provider Portal</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Container>
    </>
  );
}

export default DataSourcesPage;
