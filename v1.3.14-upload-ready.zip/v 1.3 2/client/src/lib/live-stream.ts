import { useEffect, useState } from "react";
import { queryClient } from "./queryClient";

let eventSource: EventSource | null = null;
let reconnectTimer: any = null;
let isConnected = false;

export function initLiveStream() {
  if (typeof window === "undefined" || !("EventSource" in window)) return;
  if (eventSource) return;

  function connect() {
    try {
      eventSource = new EventSource("/api/v1/stream");

      eventSource.onopen = () => {
        isConnected = true;
      };

      eventSource.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          const type = payload?.type;

          if (type === "news") {
            queryClient.invalidateQueries({ queryKey: ["/api/agent/news"] });
          } else if (type === "result") {
            queryClient.invalidateQueries({ queryKey: ["/api/agent/results"] });
            queryClient.invalidateQueries({ queryKey: ["/api/agent/results/dates"] });
          } else if (type === "medals") {
            queryClient.invalidateQueries({ queryKey: ["/api/live/apg2026"] });
            queryClient.invalidateQueries({ queryKey: ["/api/live/medals"] });
          } else if (type === "fixtures") {
            queryClient.invalidateQueries({ queryKey: ["/api/fixtures"] });
          }
        } catch {
          // Ignore parse errors from heartbeat/ping
        }
      };

      eventSource.onerror = () => {
        isConnected = false;
        if (eventSource) {
          eventSource.close();
          eventSource = null;
        }
        // Exponential-ish backoff reconnect
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(connect, 5000);
      };
    } catch {
      isConnected = false;
    }
  }

  connect();
}

/**
 * Hook to pause polling intervals when the tab is hidden (document.hidden)
 * and provide sensible fallback intervals.
 */
export function usePollInterval(defaultMs: number): number | false {
  const [hidden, setHidden] = useState<boolean>(() =>
    typeof document !== "undefined" ? document.hidden : false
  );

  useEffect(() => {
    initLiveStream();

    const handleVisibility = () => {
      setHidden(document.hidden);
    };

    document.addEventListener("visibilitychange", handleVisibility);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, []);

  if (hidden) return false;
  return defaultMs;
}
