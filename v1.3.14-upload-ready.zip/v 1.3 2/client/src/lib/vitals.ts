import { hasConsent } from "@/components/cmp-banner";

function sendVital(name: string, value: number, rating: "good" | "needs-improvement" | "poor") {
  if (typeof window === "undefined" || !navigator.sendBeacon) return;
  // If user explicitly chose essential only, respect it
  if (localStorage.getItem("momentum_cookie_consent") === "essential") return;

  const payload = JSON.stringify({
    name,
    value: Math.round(value * 100) / 100,
    rating,
    path: window.location.pathname || "/",
  });

  const blob = new Blob([payload], { type: "application/json" });
  navigator.sendBeacon("/api/vitals", blob);
}

export function initWebVitals() {
  if (typeof window === "undefined" || !("PerformanceObserver" in window)) return;

  try {
    // 1. Largest Contentful Paint (LCP)
    const lcpObserver = new PerformanceObserver(entryList => {
      const entries = entryList.getEntries();
      const lastEntry = entries[entries.length - 1] as PerformanceEntry & { startTime: number };
      if (lastEntry) {
        const val = lastEntry.startTime;
        const rating = val <= 2500 ? "good" : val <= 4000 ? "needs-improvement" : "poor";
        sendVital("LCP", val, rating);
      }
    });
    lcpObserver.observe({ type: "largest-contentful-paint", buffered: true });

    // 2. Cumulative Layout Shift (CLS)
    let clsValue = 0;
    const clsObserver = new PerformanceObserver(entryList => {
      for (const entry of entryList.getEntries() as any[]) {
        if (!entry.hadRecentInput) {
          clsValue += entry.value;
        }
      }
    });
    clsObserver.observe({ type: "layout-shift", buffered: true });

    // Report CLS when page unloads or visibility changes to hidden
    const reportCls = () => {
      if (clsValue > 0) {
        const rating = clsValue <= 0.1 ? "good" : clsValue <= 0.25 ? "needs-improvement" : "poor";
        sendVital("CLS", clsValue, rating);
      }
    };
    window.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") reportCls();
    });

    // 3. Interaction to Next Paint (INP)
    const inpObserver = new PerformanceObserver(entryList => {
      for (const entry of entryList.getEntries() as any[]) {
        const duration = entry.duration;
        const rating = duration <= 200 ? "good" : duration <= 500 ? "needs-improvement" : "poor";
        sendVital("INP", duration, rating);
      }
    });
    inpObserver.observe({ type: "event", buffered: true, durationThreshold: 16 } as any);
  } catch {}
}
