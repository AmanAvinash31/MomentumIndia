import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { I18N } from "@/data";

export type Theme = "light" | "dark";
export type ThemePref = "light" | "dark" | "system";

type Prefs = {
  theme: Theme;
  themePref: ThemePref;
  resolvedTheme: Theme;
  setTheme: (t: ThemePref) => void;
  toggleTheme: () => void;
  t: (k: string, fallback?: string) => string;
  lite: boolean;
  setLite: (v: boolean) => void;
  followEmail: string;
  setFollowEmail: (e: string) => void;
  isMobile: boolean;
};

const Ctx = createContext<Prefs | null>(null);

const EXTRA_EN: Record<string, string> = {
  games: "Games",
  athletes: "Athletes",
  news: "News",
  explore: "Explore",
  search: "Search",
  latest: "Latest",
  allNews: "All news",
  readStory: "Read the story",
  medalHistory: "Medal history",
  rise: "Next gen",
};

function getInitialThemePref(): ThemePref {
  if (typeof window === "undefined") return "system";
  try {
    const saved = localStorage.getItem("momentum_theme");
    if (saved === "light" || saved === "dark" || saved === "system") return saved;
    // Legacy stored values were already resolved themes; treat a stored
    // value as an explicit choice, never as "system".
    return "system";
  } catch { return "system"; }
}

export function PrefsProvider({ children }: { children: ReactNode }) {
  const [themePref, setThemePrefState] = useState<ThemePref>(getInitialThemePref);
  const [systemDark, setSystemDark] = useState<boolean>(() =>
    typeof window !== "undefined" && !!window.matchMedia?.("(prefers-color-scheme: dark)").matches);
  // Follow OS changes while "system" is selected.
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  const theme: Theme = themePref === "system" ? (systemDark ? "dark" : "light") : themePref;
  const [lite, setLite] = useState<boolean>(() => typeof navigator !== "undefined" && !!(navigator as any).connection?.saveData);
  const [followEmail, setFollowEmail] = useState("");
  const [isMobile, setIsMobile] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return window.innerWidth < 768;
    }
    return false;
  });

  useEffect(() => {
    if (typeof window === "undefined") return;
    const resizeListener = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener("resize", resizeListener);
    return () => window.removeEventListener("resize", resizeListener);
  }, []);

  const setTheme = (next: ThemePref) => {
    setThemePrefState(next);
    try {
      localStorage.setItem("momentum_theme", next);
    } catch {}
  };

  // Cycle: Light -> Dark -> System -> Light, so one button reaches all three.
  const toggleTheme = () => {
    const next: ThemePref = themePref === "light" ? "dark" : themePref === "dark" ? "system" : "light";
    setTheme(next);
  };

  useEffect(() => {
    document.documentElement.classList.toggle("lite", lite);
  }, [lite]);

  useEffect(() => {
    const isDark = theme === "dark";
    document.documentElement.classList.toggle("dark", isDark);
    document.documentElement.dataset.theme = theme;
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = "en";
  }, []);

  const value = useMemo<Prefs>(() => ({
    theme,
    themePref,
    resolvedTheme: theme,
    setTheme,
    toggleTheme,
    lite,
    setLite,
    followEmail,
    setFollowEmail,
    isMobile,
    t: (k, fb) => EXTRA_EN[k] ?? I18N.en?.[k] ?? fb ?? k,
  }), [theme, themePref, lite, followEmail, isMobile]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const usePrefs = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("PrefsProvider missing");
  return c;
};
