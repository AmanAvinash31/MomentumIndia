import { useEffect } from "react";
import { useLocation } from "wouter";
import { getConsent } from "@/components/cmp-banner";

/**
 * Google Analytics 4, consent-gated.
 *
 * Activation requires the visitor accepting analytics in the cookie
 * consent banner ("Accept All"). "Essential Only" or no choice yet = no
 * tracking script is loaded and no page view is sent.
 *
 * The Measurement ID below is the site's own GA4 ID, set at the owner's
 * request on 1 Nov 2026 (stream "Momentum India Website"). A Measurement
 * ID is a public identifier — it is visible in the page source of any
 * site using GA4, so embedding it here is not a secret leak. A build-time
 * VITE_GA_MEASUREMENT_ID, if set, still overrides it, so the ID can be
 * rotated without another code change.
 *
 * SPA page views are sent manually on route change (send_page_view: false
 * on the initial config), so hash-routing in dev and path-routing in
 * production both report the in-app route, not just the first load.
 */

const GA_ID =
  (import.meta.env.VITE_GA_MEASUREMENT_ID as string | undefined)?.trim() ||
  "G-SZCX58T0Z4";

declare global {
  interface Window {
    dataLayer?: unknown[];
    gtag?: (...args: unknown[]) => void;
  }
}

let loaded = false;

function loadGtag(): void {
  if (loaded || !GA_ID || typeof document === "undefined") return;
  loaded = true;
  window.dataLayer = window.dataLayer || [];
  window.gtag = window.gtag || function (...args: unknown[]) {
    window.dataLayer!.push(args);
  };
  window.gtag("js", new Date());
  window.gtag("config", GA_ID, { anonymize_ip: true, send_page_view: false });
  const script = document.createElement("script");
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(GA_ID)}`;
  document.head.appendChild(script);
}

function trackPageView(path: string): void {
  if (!loaded || !GA_ID || typeof window.gtag !== "function") return;
  window.gtag("config", GA_ID, { page_path: path, anonymize_ip: true });
}

export function Analytics() {
  const [loc] = useLocation();

  // Load only after consent is accepted, including when the visitor
  // accepts after this component first mounted.
  useEffect(() => {
    if (getConsent() === "accepted") loadGtag();
    const onConsent = (e: Event) => {
      if ((e as CustomEvent).detail === "accepted") loadGtag();
    };
    window.addEventListener("momentum_consent_change", onConsent);
    return () => window.removeEventListener("momentum_consent_change", onConsent);
  }, []);

  useEffect(() => {
    trackPageView(loc);
  }, [loc]);

  return null;
}
