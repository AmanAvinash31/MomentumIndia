import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

interface PaginationControlProps {
  page: number;
  setPage: (page: number) => void;
  pageSize?: number;
  totalItems: number;
  visibleCount?: number;
  onLoadMore?: () => void;
  label?: string;
  className?: string;
}

export function PaginationControl({
  page,
  setPage,
  pageSize = 20,
  totalItems,
  visibleCount,
  onLoadMore,
  label = "items",
  className,
}: PaginationControlProps) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  if (totalItems <= pageSize && (!visibleCount || visibleCount >= totalItems)) {
    return null;
  }

  const start = Math.min((page - 1) * pageSize + 1, totalItems);
  const end = Math.min(page * pageSize, totalItems);

  // Generate page numbers with ellipsis
  const getPageNumbers = () => {
    const pages: (number | "...")[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      pages.push(1);
      if (page > 3) pages.push("...");
      const startP = Math.max(2, page - 1);
      const endP = Math.min(totalPages - 1, page + 1);
      for (let i = startP; i <= endP; i++) {
        if (!pages.includes(i)) pages.push(i);
      }
      if (page < totalPages - 2) pages.push("...");
      pages.push(totalPages);
    }
    return pages;
  };

  const hasMore = visibleCount !== undefined ? visibleCount < totalItems : end < totalItems;

  return (
    <div className={cn("mt-8 flex flex-col items-center justify-between gap-4 border-t border-border pt-6 sm:flex-row", className)}>
      {/* Information text */}
      <p className="text-xs font-medium text-muted-foreground">
        Showing <span className="font-bold text-foreground">{start}–{end}</span> of{" "}
        <span className="font-bold text-foreground">{totalItems}</span> {label}
      </p>

      {/* Buttons */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        {/* Load More Button */}
        {onLoadMore && hasMore && (
          <button
            type="button"
            onClick={onLoadMore}
            className="inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-xs font-bold text-primary transition hover:bg-primary/20"
          >
            <Plus className="h-3.5 w-3.5" />
            Load 20 More
          </button>
        )}

        {/* Previous Button */}
        <button
          type="button"
          onClick={() => setPage(Math.max(1, page - 1))}
          disabled={page <= 1}
          className="inline-flex items-center gap-1 rounded-full border border-border px-3 py-1.5 text-xs font-bold transition hover:bg-muted disabled:opacity-40"
        >
          <ChevronLeft className="h-3.5 w-3.5" />
          Prev
        </button>

        {/* Page Number Buttons */}
        <div className="flex items-center gap-1">
          {getPageNumbers().map((p, idx) =>
            p === "..." ? (
              <span key={`dots-${idx}`} className="px-1 text-xs text-muted-foreground">
                …
              </span>
            ) : (
              <button
                key={p}
                type="button"
                onClick={() => setPage(p as number)}
                className={cn(
                  "grid h-7 w-7 place-items-center rounded-full text-xs font-bold transition",
                  page === p
                    ? "bg-foreground text-background"
                    : "border border-border text-muted-foreground hover:border-foreground hover:text-foreground"
                )}
              >
                {p}
              </button>
            )
          )}
        </div>

        {/* Next Button */}
        <button
          type="button"
          onClick={() => setPage(Math.min(totalPages, page + 1))}
          disabled={page >= totalPages}
          className="inline-flex items-center gap-1 rounded-full border border-border px-3 py-1.5 text-xs font-bold transition hover:bg-muted disabled:opacity-40"
        >
          Next
          <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}
