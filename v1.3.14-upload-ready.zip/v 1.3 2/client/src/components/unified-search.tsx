import { useState, useEffect, useRef, useMemo } from "react";
import { Link, useLocation } from "wouter";
import { Search, X, Sparkles, Trophy, User, Newspaper, MapPin, ArrowRight, Clock, HelpCircle, Dumbbell } from "lucide-react";
import { PEOPLE, ARTICLES, FAQS } from "@/data";
import { cn } from "@/lib/utils";

const TRENDING_CHIPS = ["Cricket", "Badminton", "Hockey", "Shooting", "Wrestling", "Athletics", "Kabaddi", "Asian Para Games"];

const ALL_SPORTS = [
  "Cricket", "Badminton", "Hockey", "Shooting", "Wrestling", "Athletics",
  "Boxing", "Archery", "Weightlifting", "Table Tennis", "Squash", "Tennis",
  "Football", "Kabaddi", "Para Sports", "Swimming", "Judo", "Equestrian",
  "Rowing", "Sailing", "Cycling", "Gymnastics", "Fencing", "Golf"
];

function getRecentSearches(): string[] {
  try {
    const raw = localStorage.getItem("momentum_recent_searches");
    return raw ? JSON.parse(raw).slice(0, 6) : [];
  } catch {
    return [];
  }
}

function saveRecentSearch(q: string) {
  try {
    const trimmed = q.trim();
    if (!trimmed || trimmed.length < 2) return;
    const current = getRecentSearches().filter(s => s.toLowerCase() !== trimmed.toLowerCase());
    current.unshift(trimmed);
    localStorage.setItem("momentum_recent_searches", JSON.stringify(current.slice(0, 8)));
  } catch {}
}

export function UnifiedSearch({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [query, setQuery] = useState("");
  const [recents, setRecents] = useState<string[]>([]);
  const [, setLocation] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setRecents(getRecentSearches());
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery("");
    }
  }, [open]);

  // Keyboard shortcut Cmd+K or Ctrl+K & Escape
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        if (open) onClose();
      }
      if (e.key === "Escape" && open) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [open, onClose]);

  const q = query.trim().toLowerCase();

  const results = useMemo(() => {
    if (!q) return null;

    const matchedAthletes = PEOPLE.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.sport.toLowerCase().includes(q) ||
      p.tagline?.toLowerCase().includes(q)
    ).slice(0, 4);

    const matchedNews = ARTICLES.filter(a =>
      a.title.toLowerCase().includes(q) ||
      a.body.toLowerCase().includes(q) ||
      a.paras.some(p => p.toLowerCase().includes(q))
    ).slice(0, 4);

    const matchedSports = ALL_SPORTS.filter(s =>
      s.toLowerCase().includes(q)
    ).slice(0, 3);

    const matchedFaqs = FAQS.filter(([question, answer]) =>
      question.toLowerCase().includes(q) || answer.toLowerCase().includes(q)
    ).slice(0, 2);

    const totalCount = matchedAthletes.length + matchedNews.length + matchedSports.length + matchedFaqs.length;

    return {
      athletes: matchedAthletes,
      news: matchedNews,
      sports: matchedSports,
      faqs: matchedFaqs,
      totalCount,
    };
  }, [q]);

  const handleSelect = (href: string, term?: string) => {
    if (term) saveRecentSearch(term);
    else if (query) saveRecentSearch(query);
    onClose();
    setLocation(href);
  };

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Search Momentum India"
      className="fixed inset-0 z-50 flex flex-col bg-background/95 backdrop-blur-xl animate-in fade-in duration-200"
    >
      {/* Top Search Bar */}
      <div className="border-b border-border/80 px-4 py-3 sm:px-6">
        <div className="mx-auto flex max-w-3xl items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <input
              ref={inputRef}
              type="search"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search athletes, sports, news, medals, venues..."
              data-testid="input-unified-search"
              className="tap-target h-12 w-full rounded-full border border-border bg-card pl-11 pr-10 text-base font-medium text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 shadow-sm"
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                aria-label="Clear search input"
                className="tap-target absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <button
            onClick={onClose}
            aria-label="Close search"
            className="tap-target rounded-full px-4 text-sm font-semibold text-muted-foreground hover:text-foreground"
          >
            Cancel
          </button>
        </div>
      </div>

      {/* Search Content Body */}
      <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-6">
        <div className="mx-auto max-w-3xl space-y-6">
          {/* No search term yet: Show Recent Searches & Trending Sports */}
          {!q && (
            <div className="space-y-6">
              {recents.length > 0 && (
                <div>
                  <div className="mb-2.5 flex items-center justify-between">
                    <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                      <Clock className="h-3.5 w-3.5" />
                      Recent Searches
                    </p>
                    <button
                      onClick={() => {
                        localStorage.removeItem("momentum_recent_searches");
                        setRecents([]);
                      }}
                      className="text-xs text-muted-foreground hover:text-primary"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="swipe-chips">
                    {recents.map(term => (
                      <button
                        key={term}
                        onClick={() => setQuery(term)}
                        className="swipe-chip border border-border bg-card text-foreground hover:border-primary hover:text-primary shadow-sm"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <p className="mb-2.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  <Sparkles className="h-3.5 w-3.5 text-primary" />
                  Trending Sports & Topics
                </p>
                <div className="swipe-chips">
                  {TRENDING_CHIPS.map(chip => (
                    <button
                      key={chip}
                      onClick={() => setQuery(chip)}
                      className="swipe-chip border border-border/80 bg-card/80 text-foreground hover:border-primary hover:text-primary shadow-sm"
                    >
                      {chip}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quick links */}
              <div className="rounded-2xl border border-border bg-card p-4 shadow-sm">
                <p className="mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Popular Destinations</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    onClick={() => handleSelect("/match-centre")}
                    className="tap-target flex items-center justify-between rounded-xl p-3 text-left hover:bg-muted/60 transition"
                  >
                    <span className="font-semibold text-sm">26 Sports Match Centre & Results</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </button>
                  <button
                    onClick={() => handleSelect("/medals")}
                    className="tap-target flex items-center justify-between rounded-xl p-3 text-left hover:bg-muted/60 transition"
                  >
                    <span className="font-semibold text-sm">All-time Indian Medal History</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </button>
                  <button
                    onClick={() => handleSelect("/games/asian-para-games-2026")}
                    className="tap-target flex items-center justify-between rounded-xl p-3 text-left hover:bg-muted/60 transition"
                  >
                    <span className="font-semibold text-sm">Asian Para Games 2026 Live Hub</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </button>
                  <button
                    onClick={() => handleSelect("/fan-zone")}
                    className="tap-target flex items-center justify-between rounded-xl p-3 text-left hover:bg-muted/60 transition"
                  >
                    <span className="font-semibold text-sm">Fan Zone & Daily Sports Quiz</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Results matching query */}
          {q && results && results.totalCount > 0 && (
            <div className="space-y-6">
              {/* Athletes */}
              {results.athletes.length > 0 && (
                <div>
                  <p className="mb-2.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-saffron">
                    <User className="h-3.5 w-3.5" />
                    Athletes ({results.athletes.length})
                  </p>
                  <div className="grid gap-2">
                    {results.athletes.map(p => (
                      <button
                        key={p.slug}
                        data-testid={`search-result-athlete-${p.slug}`}
                        onClick={() => handleSelect(`/athletes/${p.slug}`, p.name)}
                        className="tap-target flex w-full items-center justify-between rounded-xl border border-border bg-card p-3 text-left hover:border-primary/50 transition shadow-sm"
                      >
                        <div className="min-w-0 pr-3">
                          <p className="font-bold text-sm text-foreground truncate">{p.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{p.sport} {p.tagline ? `· ${p.tagline}` : ""}</p>
                        </div>
                        <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* News */}
              {results.news.length > 0 && (
                <div>
                  <p className="mb-2.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-500">
                    <Newspaper className="h-3.5 w-3.5" />
                    Stories & Dispatches ({results.news.length})
                  </p>
                  <div className="grid gap-2">
                    {results.news.map(n => (
                      <button
                        key={n.slug}
                        data-testid={`search-result-news-${n.slug}`}
                        onClick={() => handleSelect(`/news/${n.slug}`, n.title)}
                        className="tap-target flex w-full items-center justify-between rounded-xl border border-border bg-card p-3 text-left hover:border-primary/50 transition shadow-sm"
                      >
                        <div className="min-w-0 pr-3">
                          <p className="font-bold text-sm text-foreground line-clamp-1">{n.title}</p>
                          <p className="text-xs text-muted-foreground line-clamp-1">{n.body}</p>
                        </div>
                        <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Sports */}
              {results.sports.length > 0 && (
                <div>
                  <p className="mb-2.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-500">
                    <Dumbbell className="h-3.5 w-3.5" />
                    Sports Hubs
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {results.sports.map(s => (
                      <button
                        key={s}
                        data-testid={`search-result-sport-${s.toLowerCase()}`}
                        onClick={() => handleSelect(`/sports`, s)}
                        className="swipe-chip border border-border bg-card text-foreground hover:border-primary hover:text-primary shadow-sm"
                      >
                        {s} Discipline Guide
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* FAQs & Knowledge */}
              {results.faqs.length > 0 && (
                <div>
                  <p className="mb-2.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-sky-500">
                    <HelpCircle className="h-3.5 w-3.5" />
                    Direct Answers
                  </p>
                  <div className="grid gap-2">
                    {results.faqs.map(([ques, ans], i) => (
                      <div key={i} className="rounded-xl border border-border bg-card p-3.5 text-left shadow-sm">
                        <p className="font-bold text-sm text-foreground">{ques}</p>
                        <p className="mt-1 text-xs text-muted-foreground leading-relaxed">{ans}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Empty State: No results found */}
          {q && results && results.totalCount === 0 && (
            <div className="rounded-2xl border border-border bg-card p-8 text-center shadow-sm">
              <Search className="mx-auto h-10 w-10 text-muted-foreground/60" />
              <h3 className="mt-3 font-display text-lg font-bold">No results found for "{query}"</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">
                Try searching for athlete names (Neeraj, Manu, Sindhu), major sports (Cricket, Badminton, Hockey), or live events.
              </p>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {TRENDING_CHIPS.slice(0, 4).map(chip => (
                  <button
                    key={chip}
                    onClick={() => setQuery(chip)}
                    className="swipe-chip border border-border bg-muted/60 text-xs font-semibold hover:border-primary hover:text-primary"
                  >
                    Try "{chip}"
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
