import { useState, useEffect } from "react";
import { ShieldCheck, X } from "lucide-react";
import { cn } from "@/lib/utils";

const CONSENT_KEY = "momentum_cookie_consent";

export type ConsentStatus = "accepted" | "essential" | null;

export function getConsent(): ConsentStatus {
  try {
    return (localStorage.getItem(CONSENT_KEY) as ConsentStatus) || null;
  } catch {
    return null;
  }
}

export function hasConsent(): boolean {
  return getConsent() === "accepted";
}

export function CmpBanner() {
  const [consent, setConsent] = useState<ConsentStatus>(() => {
    // Initial read
    try {
      return (localStorage.getItem(CONSENT_KEY) as ConsentStatus) || null;
    } catch {
      return "essential";
    }
  });

  const save = (status: "accepted" | "essential") => {
    try {
      localStorage.setItem(CONSENT_KEY, status);
    } catch {}
    setConsent(status);
    window.dispatchEvent(new CustomEvent("momentum_consent_change", { detail: status }));
  };

  if (consent !== null) return null;

  return (
    <aside
      role="region"
      aria-label="Cookie and Privacy Consent"
      data-testid="cmp-banner"
      className="fixed bottom-16 sm:bottom-6 left-4 right-4 z-50 mx-auto max-w-xl rounded-2xl border border-primary/30 bg-card/95 p-4 sm:p-5 shadow-2xl backdrop-blur-md"
    >
      <div className="flex items-start gap-3">
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
          <ShieldCheck className="h-5 w-5" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-bold text-foreground">Your privacy matters to us</h3>
          <p className="mt-1 text-xs text-muted-foreground leading-relaxed">
            Momentum India uses anonymous performance vitals to ensure our multi-sport coverage loads blazing fast. We never sell your personal data.
          </p>
          <div className="mt-3.5 flex flex-wrap items-center gap-2">
            <button
              onClick={() => save("accepted")}
              data-testid="cmp-accept"
              className="inline-flex min-h-[44px] items-center justify-center rounded-full bg-primary px-5 text-xs font-bold text-primary-foreground shadow-sm hover:brightness-105 active:scale-95 transition"
            >
              Accept All
            </button>
            <button
              onClick={() => save("essential")}
              data-testid="cmp-essential"
              className="inline-flex min-h-[44px] items-center justify-center rounded-full border border-border bg-background px-4 text-xs font-bold text-muted-foreground hover:bg-muted hover:text-foreground active:scale-95 transition"
            >
              Essential Only
            </button>
          </div>
        </div>
        <button
          onClick={() => save("essential")}
          aria-label="Close consent banner"
          className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </aside>
  );
}
