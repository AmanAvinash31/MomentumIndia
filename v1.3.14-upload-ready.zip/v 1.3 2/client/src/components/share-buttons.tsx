import { useState } from "react";
import { Link2, Check, MessageCircle, Send } from "lucide-react";

/**
 * One-tap sharing for stories (and any future page that reuses it).
 * WhatsApp first: it is the channel Indian sports news actually travels
 * through. Links are plain external share intents with the headline and
 * the page URL prefilled — no tracking parameters, no data sent to the
 * site, and the share happens in the visitor's own app. Copy link is
 * kept exactly as before, including its data-testid.
 */
export function ShareButtons({ title, url }: { title: string; url?: string }) {
  const [copied, setCopied] = useState(false);
  const pageUrl = url ?? (typeof window !== "undefined" ? window.location.href : "");
  const text = `${title} — The Momentum India`;
  const encodedText = encodeURIComponent(text);
  const encodedUrl = encodeURIComponent(pageUrl);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(pageUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* clipboard blocked */
    }
  };

  const btn =
    "tap-target inline-flex items-center gap-1.5 rounded-full border border-border px-3.5 py-1.5 text-xs font-bold text-muted-foreground hover:text-foreground hover:border-primary transition";

  return (
    <span className="flex flex-wrap items-center gap-2">
      <a
        href={`https://wa.me/?text=${encodedText}%20${encodedUrl}`}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Share on WhatsApp"
        data-testid="button-share-whatsapp"
        className={btn}
      >
        <MessageCircle className="h-3.5 w-3.5" />WhatsApp
      </a>
      <a
        href={`https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Share on X"
        data-testid="button-share-x"
        className={btn}
      >
        X
      </a>
      <a
        href={`https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Share on Telegram"
        data-testid="button-share-telegram"
        className={btn}
      >
        <Send className="h-3.5 w-3.5" />Telegram
      </a>
      <button
        onClick={copy}
        data-testid="button-copy-link"
        aria-label="Copy link"
        className={btn}
      >
        {copied ? (
          <>
            <Check className="h-3.5 w-3.5 text-emerald-500" />Copied link
          </>
        ) : (
          <>
            <Link2 className="h-3.5 w-3.5" />Copy link
          </>
        )}
      </button>
    </span>
  );
}
