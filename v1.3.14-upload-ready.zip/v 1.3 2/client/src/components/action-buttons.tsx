import { useState, useEffect } from "react";
import { Bell, CalendarPlus, Check, Loader2, ShieldCheck } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { usePrefs } from "@/lib/prefs";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";

const field = "w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/30";
const btn = "inline-flex items-center justify-center gap-1.5 rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-60";
const errMsg = (e: unknown) => { const m = String((e as Error)?.message ?? e); try { return JSON.parse(m.slice(m.indexOf("{"))).message; } catch { return "Something went wrong. Check your connection and try again."; } };

/* ================================================= calendar (.ics) */
export type CalEvent = { id: string; title: string; start: string; end: string; where: string; note?: string };
export const KEY_EVENTS: CalEvent[] = [
  { id: "apg2026", title: "Asian Para Games 2026", start: "2026-10-18", end: "2026-10-25", where: "Aichi-Nagoya, Japan", note: "India's flag bearers: Pramod Bhagat and Bhavina Patel" },
  { id: "la28", title: "Olympic Games, Los Angeles 2028", start: "2028-07-14", end: "2028-07-31", where: "Los Angeles, USA" },
  { id: "la28p", title: "Paralympic Games, Los Angeles 2028", start: "2028-08-15", end: "2028-08-28", where: "Los Angeles, USA" },
];
const icsDate = (d: string) => d.replace(/-/g, "");
const icsTime = (d: string) => new Date(d).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
export function downloadIcs(evs: CalEvent[], name = "momentum-india") {
  const stamp = new Date().toISOString().replace(/[-:]/g, "").slice(0, 15) + "Z";
  const body = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Momentum India//EN", "CALSCALE:GREGORIAN",
    ...evs.flatMap(e => ["BEGIN:VEVENT", `UID:${e.id}@momentum-india`, `DTSTAMP:${stamp}`, ...(e.start.includes("T") ? [`DTSTART:${icsTime(e.start)}`, `DTEND:${icsTime(e.end)}`] : [`DTSTART;VALUE=DATE:${icsDate(e.start)}`, `DTEND;VALUE=DATE:${icsDate(e.end)}`]),
      `SUMMARY:${e.title}`, `LOCATION:${e.where}`, `DESCRIPTION:${(e.note ?? "Follow India on Momentum India").replace(/[,;]/g, "\\$&")}`, "END:VEVENT"]),
    "END:VCALENDAR"].join("\r\n");
  const url = URL.createObjectURL(new Blob([body], { type: "text/calendar;charset=utf-8" }));
  const a = document.createElement("a"); a.href = url; a.download = `${name}.ics`; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function CalButton({ evs, name, label = "Add to calendar", className }: { evs: CalEvent[]; name?: string; label?: string; className?: string }) {
  return <button onClick={() => downloadIcs(evs, name)} data-testid={`button-cal-${name ?? "all"}`} className={cn("inline-flex items-center gap-1.5 rounded-full border border-current/30 px-4 py-2 text-sm font-bold hover:border-current", className)}><CalendarPlus className="h-4 w-4" />{label}</button>;
}

/* ================================================= follow */
export type FollowKind = "athlete" | "sport" | "games" | "trials";
export type FollowItem = { kind: FollowKind; key: string; label: string };
export const followedCache = new Map<string, Set<string>>();

export function FollowButton({ kind, k, label, className, tone = "light" }: { kind: FollowKind; k: string; label: string; className?: string; tone?: "light" | "dark" }) {
  const { followEmail, setFollowEmail } = usePrefs();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [on, setOn] = useState(() => !!followEmail && !!followedCache.get(followEmail)?.has(`${kind}:${k}`));
  const save = async (email: string) => {
    setBusy(true);
    try {
      const r = await (await apiRequest("POST", "/api/follow", { email, items: [{ kind, key: k, label }] })).json();
      if (r.manage_token) {
        try {
          localStorage.setItem("mi_manage_token", r.manage_token);
          localStorage.setItem(`mi_manage_token_${email.toLowerCase()}`, r.manage_token);
        } catch {}
      }
      // For an address that already had follows, the server no longer
      // returns the full list (see server/routes.ts) — keep the local cache
      // and just mark this item followed.
      if (r.follows) followedCache.set(email, new Set(r.follows.map((f: FollowItem) => `${f.kind}:${f.key}`)));
      else { const s = followedCache.get(email) ?? new Set<string>(); s.add(`${kind}:${k}`); followedCache.set(email, s); }
      setFollowEmail(email); setOn(true); setOpen(false);
      toast({ title: `Following ${label}`, description: "See everything you follow on My Momentum." });
    } catch (e) { toast({ title: "Could not follow", description: errMsg(e), variant: "destructive" }); }
    setBusy(false);
  };
  return (
    <>
      <button data-testid={`button-follow-${kind}-${k}`} aria-pressed={on} disabled={busy} onClick={() => on ? undefined : followEmail ? save(followEmail) : setOpen(true)}
        className={cn("inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-bold transition-colors",
          on ? "bg-indgreen text-white" : tone === "dark" ? "border border-paper/40 text-paper hover:border-paper" : "border border-border hover:border-foreground", className)}>
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : on ? <Check className="h-4 w-4" /> : <Bell className="h-4 w-4" />}{on ? "Following" : "Follow"}
      </button>
      <EmailDialog open={open} setOpen={setOpen} title={`Follow ${label}`} busy={busy} onSubmit={save}
        desc="Enter your email to save what you follow. We'll use it for alerts and your For you page, nothing else." />
    </>
  );
}

export function EmailDialog({ open, setOpen, title, desc, busy, onSubmit }: { open: boolean; setOpen: (v: boolean) => void; title: string; desc: string; busy: boolean; onSubmit: (email: string) => void }) {
  const [email, setEmail] = useState("");
  const [err, setErr] = useState("");
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle className="font-display text-2xl">{title}</DialogTitle><DialogDescription>{desc}</DialogDescription></DialogHeader>
        <form noValidate onSubmit={e => { e.preventDefault(); const v = email.trim().toLowerCase(); if (!/^\S+@\S+\.\S+$/.test(v)) return setErr("Enter a valid email address, like name@example.com."); setErr(""); onSubmit(v); }} className="space-y-3">
          <label className="block text-sm font-bold" htmlFor="follow-email">Email</label>
          <input id="follow-email" type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} className={field} placeholder="name@example.com" data-testid="input-follow-email" aria-invalid={!!err} aria-describedby={err ? "follow-err" : undefined} />
          {err && <p id="follow-err" className="text-sm text-destructive">{err}</p>}
          <button type="submit" disabled={busy} className={cn(btn, "w-full")} data-testid="button-follow-submit">{busy && <Loader2 className="h-4 w-4 animate-spin" />}Follow</button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/* ================================================= claim a listing */
export function ClaimDialog({ listing, kind, open, setOpen }: { listing: string; kind: "sai" | "academy"; open: boolean; setOpen: (v: boolean) => void }) {
  const [f, setF] = useState({ name: "", role: "", email: "", phone: "", fees: "", coaches: "", website: "", notes: "" });
  const [st, setSt] = useState<{ s: "idle" | "busy" | "ok" | "err"; msg?: string }>({ s: "idle" });
  useEffect(() => { if (open) setSt({ s: "idle" }); }, [open]);
  const up = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setSt({ s: "busy" });
    try { const r = await (await apiRequest("POST", "/api/claims", { listing, kind, ...f })).json(); setSt({ s: "ok", msg: r.ref }); }
    catch (x) { setSt({ s: "err", msg: errMsg(x) }); }
  };
  const In = (k: keyof typeof f, l: string, p = "", req = false, type = "text") => (
    <div><label htmlFor={`cl-${k}`} className="text-sm font-bold">{l}{req && <span className="text-primary"> *</span>}</label><input id={`cl-${k}`} type={type} required={req} value={f[k]} onChange={up(k)} placeholder={p} className={cn(field, "mt-1")} data-testid={`input-claim-${k}`} /></div>
  );
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader><DialogTitle className="font-display text-2xl">Update this listing</DialogTitle><DialogDescription>{listing}</DialogDescription></DialogHeader>
        {st.s === "ok" ? (
          <div className="space-y-3" data-testid="claim-ok">
            <p className="flex items-center gap-2 font-bold text-indgreen"><ShieldCheck className="h-5 w-5" />Received. Your reference is {st.msg}.</p>
            <p className="text-sm text-muted-foreground">We check every update before it goes live: we call the number you gave and confirm it against the centre's official listing. Verified listings get a green badge. This usually takes about a week.</p>
            <button onClick={() => setOpen(false)} className={btn}>Done</button>
          </div>
        ) : (
          <form noValidate onSubmit={submit} className="space-y-3">
            <p className="text-sm text-muted-foreground">For coaches, administrators and owners. Add the contact details parents need. Nothing is published until we verify it.</p>
            <div className="grid gap-3 sm:grid-cols-2">{In("name", "Your name", "", true)}{In("role", "Your role", "Head coach", true)}</div>
            <div className="grid gap-3 sm:grid-cols-2">{In("phone", "Centre phone", "0124 123 4567", true, "tel")}{In("email", "Centre email", "admissions@…", true, "email")}</div>
            {In("fees", "Fees and boarding", "Free residential, or ₹ per month")}
            {In("website", "Website or social page", "https://")}
            <div><label htmlFor="cl-coaches" className="text-sm font-bold">Coaches and qualifications</label><textarea id="cl-coaches" rows={2} value={f.coaches} onChange={up("coaches")} className={cn(field, "mt-1")} placeholder="Names, NIS diploma, certifications" /></div>
            <div><label htmlFor="cl-notes" className="text-sm font-bold">Anything else</label><textarea id="cl-notes" rows={2} value={f.notes} onChange={up("notes")} className={cn(field, "mt-1")} placeholder="Trial dates, age groups, girls' hostel" /></div>
            {st.s === "err" && <p className="text-sm text-destructive" role="alert">{st.msg}</p>}
            <button className={cn(btn, "w-full")} disabled={st.s === "busy"} data-testid="button-claim-submit">{st.s === "busy" && <Loader2 className="h-4 w-4 animate-spin" />}Send for verification</button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* ================================================= editorial standards */
export function StandardsBody() {
  return (
    <div className="space-y-8 text-base leading-relaxed">
      <section><h2 className="font-display text-2xl font-semibold">How we work</h2>
        <ul className="mt-3 space-y-2">{[
          "Every number links to its source. We prefer official records: SAI, the Ministry of Youth Affairs and Sports, PIB, Parliament answers, and the IOC, OCA and Commonwealth Sport.",
          "Where official data is missing, we use two independent reports and say so.",
          "We say what we don't know. For example, SAI does not publish a phone number for each centre, so we show the regional office instead.",
          "Photographs are illustrative and AI-generated. They never stand in for a named athlete.",
          "Watchlists show current form. They are not predictions or betting advice.",
        ].map(x => <li key={x} className="flex gap-2"><Check className="mt-1 h-4 w-4 shrink-0 text-indgreen" />{x}</li>)}</ul></section>
      <section><h2 className="font-display text-2xl font-semibold">Verified listings</h2>
        <p className="mt-2">Coaches and administrators can update a centre or academy listing. We call the number provided, confirm it against official records, and only then publish it with a green Verified badge. Unverified details are never shown.</p></section>
      <section><h2 className="font-display text-2xl font-semibold">Corrections</h2>
        <p className="mt-2">Found an error? Tell us the page and your source. We fix errors fast and log every change below.</p>
        <CorrectionForm />
        <ul className="mt-3 divide-y divide-border rounded-lg border border-border text-sm" data-testid="corrections">{[
          ["8 Oct 2026", "Facilities", "Clarified that SAI does not publish per-centre contacts. Added regional offices, helplines and sanctioned places."],
        ].map(([d, p, t]) => <li key={t} className="grid gap-1 p-3 sm:grid-cols-[7rem_8rem_1fr]"><span className="font-bold tnum">{d}</span><span className="text-muted-foreground">{p}</span><span>{t}</span></li>)}</ul></section>
      <section><h2 className="font-display text-2xl font-semibold">Data and methods</h2>
        <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
          <li><b className="text-foreground">Facilities.</b> SAI's 2025–26 centre list, matched to its centre-finder data for regions, coordinates and sanctioned places. Khelo India academies come from the ministry's state-wise list.</li>
          <li><b className="text-foreground">Girls' share.</b> Girls' sanctioned places divided by all places at open SAI centres. Places are approved capacity, not current enrolment.</li>
          <li><b className="text-foreground">Medal tables.</b> Medals are counted per event, so a team gold counts once.</li>
          <li><b className="text-foreground">Open data.</b> Download our medal datasets as CSV from the medal history pages.</li>
        </ul></section>
    </div>
  );
}

function CorrectionForm() {
  const [f, setF] = useState({ page: "", detail: "", source: "", email: "" });
  const [st, setSt] = useState<{ s: "idle" | "busy" | "ok" | "err"; msg?: string }>({ s: "idle" });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setSt({ s: "busy" });
    try { const r = await (await apiRequest("POST", "/api/corrections", f)).json(); setSt({ s: "ok", msg: r.ref }); setF({ page: "", detail: "", source: "", email: "" }); }
    catch (x) { setSt({ s: "err", msg: errMsg(x) }); }
  };
  if (st.s === "ok") return <p className="mt-4 flex items-center gap-2 rounded-lg border border-border p-4 font-bold text-indgreen" data-testid="correction-ok"><Check className="h-5 w-5" />Thanks. Your reference is {st.msg}. We reply within three working days.</p>;
  return (
    <form noValidate onSubmit={submit} className="mt-4 grid gap-3 rounded-lg border border-border p-4 sm:grid-cols-2" data-testid="correction-form">
      <div><label htmlFor="co-page" className="text-sm font-bold">Page<span className="text-primary"> *</span></label><input id="co-page" value={f.page} onChange={e => setF({ ...f, page: e.target.value })} className={cn(field, "mt-1")} placeholder="Facilities, Haryana" /></div>
      <div><label htmlFor="co-email" className="text-sm font-bold">Your email<span className="text-primary"> *</span></label><input id="co-email" type="email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} className={cn(field, "mt-1")} placeholder="name@example.com" /></div>
      <div className="sm:col-span-2"><label htmlFor="co-detail" className="text-sm font-bold">What's wrong<span className="text-primary"> *</span></label><textarea id="co-detail" rows={3} value={f.detail} onChange={e => setF({ ...f, detail: e.target.value })} className={cn(field, "mt-1")} /></div>
      <div className="sm:col-span-2"><label htmlFor="co-source" className="text-sm font-bold">Source link</label><input id="co-source" value={f.source} onChange={e => setF({ ...f, source: e.target.value })} className={cn(field, "mt-1")} placeholder="https://" /></div>
      {st.s === "err" && <p className="text-sm text-destructive sm:col-span-2" role="alert">{st.msg}</p>}
      <button className={cn(btn, "w-fit")} disabled={st.s === "busy"} data-testid="button-correction">{st.s === "busy" && <Loader2 className="h-4 w-4 animate-spin" />}Send correction</button>
    </form>
  );
}

/* ================================================= report an error (feed / article cards) */
export function ReportButton({ page, className }: { page: string; className?: string }) {
  const [open, setOpen] = useState(false);
  const [detail, setDetail] = useState("");
  const [email, setEmail] = useState("");
  const [st, setSt] = useState<{ s: "idle" | "busy" | "ok" | "err"; msg?: string }>({ s: "idle" });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setSt({ s: "busy" });
    try {
      const r = await (await apiRequest("POST", "/api/corrections", { page, detail, source: "", email })).json();
      setSt({ s: "ok", msg: r.ref });
    } catch (x) { setSt({ s: "err", msg: errMsg(x) }); }
  };
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} data-testid="button-report" className={cn("inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-primary hover:underline", className)}>
        Report an error
      </button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="font-display text-2xl">Report an error</DialogTitle><DialogDescription>{page}</DialogDescription></DialogHeader>
          {st.s === "ok" ? (
            <p className="flex items-center gap-2 rounded-lg border border-border p-4 font-bold text-indgreen"><Check className="h-5 w-5" />Thanks. Your reference is {st.msg}.</p>
          ) : (
            <form noValidate onSubmit={submit} className="space-y-3">
              <div><label className="text-sm font-bold" htmlFor="report-detail">What&apos;s wrong</label><textarea id="report-detail" rows={3} value={detail} onChange={e => setDetail(e.target.value)} className={cn(field, "mt-1")} placeholder="Wrong sport, wrong score, wrong medal count…" /></div>
              <div><label className="text-sm font-bold" htmlFor="report-email">Your email</label><input id="report-email" type="email" value={email} onChange={e => setEmail(e.target.value)} className={cn(field, "mt-1")} placeholder="name@example.com" /></div>
              {st.s === "err" && <p className="text-sm text-destructive" role="alert">{st.msg}</p>}
              <button type="submit" disabled={st.s === "busy" || !detail.trim() || !/^\S+@\S+\.\S+$/.test(email)} className={cn(btn, "w-full")}>{st.s === "busy" && <Loader2 className="h-4 w-4 animate-spin" />}Send report</button>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
