import { useState, useMemo } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  Trophy,
  Zap,
  Newspaper,
  Tv,
  Brain,
  Calendar,
  Clock,
  MapPin,
  ArrowRight,
  Filter,
  CheckCircle2,
  Activity,
  Award,
  Radio,
  Sparkles,
  ExternalLink
} from "lucide-react";
import { Container, Kicker, SectionHead } from "@/components/site";
import { DynamicQuiz } from "@/components/dynamic-quiz";
import { ARTICLES, LEAD, fmtDate, readTime, GAMES, sportImage } from "@/data";
import { apiRequest } from "@/lib/queryClient";
import { usePollInterval } from "@/lib/live-stream";
import { cn } from "@/lib/utils";

const FILTER_SPORTS = [
  "All",
  "Cricket",
  "Hockey",
  "Badminton",
  "Athletics",
  "Shooting",
  "Boxing",
  "Wrestling",
  "Kabaddi",
  "Squash",
  "Tennis",
  "Para Sports"
] as const;

function timeAgo(dateStr?: string | null): string {
  if (!dateStr) return "recently";
  const diffMs = Date.now() - new Date(dateStr).getTime();
  if (diffMs < 0 || isNaN(diffMs)) return "just now";
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins === 1) return "1 min ago";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs === 1) return "1 hr ago";
  if (hrs < 24) return `${hrs} hrs ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

function formatDateChip(dateStr: string): string {
  if (dateStr === "all") return "All";
  const now = new Date();
  const todayStr = now.toISOString().split("T")[0];
  if (dateStr === todayStr) return "Today";
  const yesterday = new Date(Date.now() - 86400000);
  const yestStr = yesterday.toISOString().split("T")[0];
  if (dateStr === yestStr) return "Yesterday";
  try {
    const parts = dateStr.split("-");
    if (parts.length === 3) {
      const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      return d.toLocaleDateString("en-US", { weekday: "short", day: "numeric" });
    }
    return dateStr;
  } catch {
    return dateStr;
  }
}

export function FrontPageCommandCenter() {
  const [selectedSport, setSelectedSport] = useState<string>("All");
  const [selectedDate, setSelectedDate] = useState<string>("all");
  const [newsDeskMode, setNewsDeskMode] = useState<"india" | "international" | "archive">("india");

  // Fetch real available dates from stored results
  const { data: datesData } = useQuery<{ dates: string[] }>({
    queryKey: ["/api/agent/results/dates"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/agent/results/dates");
      return res.json();
    },
    refetchInterval: usePollInterval(30000),
  });

  const availableDates = datesData?.dates ?? [];

  // Fetch real daily sports results from news wires
  const { data: resultsData, isLoading: resultsLoading } = useQuery<{
    sport: string;
    date_ist: string;
    count: number;
    results: any[];
    lastUpdated?: string | null;
  }>({
    queryKey: ["/api/agent/results", selectedSport, selectedDate],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedSport !== "All") params.set("sport", selectedSport);
      if (selectedDate !== "all") params.set("date_ist", selectedDate);
      const res = await apiRequest("GET", `/api/agent/results?${params.toString()}`);
      return res.json();
    },
    refetchInterval: usePollInterval(20000),
  });

  // Fetch real-time live sports wire news
  const { data: wireNewsData, isLoading: wireLoading } = useQuery<{
    sport: string;
    count: number;
    news: any[];
    lastUpdated?: string | null;
  }>({
    queryKey: ["/api/agent/news"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/agent/news?limit=6");
      return res.json();
    },
    refetchInterval: usePollInterval(20000),
  });

  const allResults = resultsData?.results ?? [];
  const previewResults = allResults.slice(0, 4);
  const liveNews = wireNewsData?.news ?? [];

  // Filter wire news based on tab: India first
  const filteredWireNews = useMemo(() => {
    if (newsDeskMode === "international") {
      return liveNews.filter(n => !n.title.toLowerCase().includes("india") && !n.title.toLowerCase().includes("ind"));
    }
    // Default "india" wire: prioritized
    return liveNews;
  }, [liveNews, newsDeskMode]);

  // Compute Broadcast status dynamically from dates
  const broadcastGuides = useMemo(() => {
    const list = [
      {
        event: "Indian Super League (ISL)",
        dates: "Daily · 19:30 IST",
        channels: "Sports18 1 HD · JioHotstar & Free on YouTube",
        href: "/leagues",
        status: "Live" as const
      },
      {
        event: "Asian Para Games 2026",
        dates: "18 to 24 October 2026",
        channels: "Sony Sports 1, 3, 5 · SonyLIV · DD Sports",
        href: "/games/asian-para-games-2026",
        status: "Upcoming" as const
      },
      {
        event: "Pro Kabaddi League (PKL)",
        dates: "Daily · 20:00 & 21:00 IST",
        channels: "Star Sports 1, Star Sports 2 · Disney+ Hotstar",
        href: "/leagues",
        status: "Upcoming" as const
      },
      {
        event: "Hockey India League (HIL)",
        dates: "Weekly Fixtures in IST",
        channels: "Sony Sports Ten 1 · SonyLIV · DD Sports",
        href: "/leagues",
        status: "Upcoming" as const
      }
    ];

    // Sort order: Live first, then Upcoming, then Ended
    const order = { Live: 0, Upcoming: 1, Ended: 2 };
    return [...list].sort((a, b) => order[a.status] - order[b.status]);
  }, []);

  return (
    <section className="relative py-12 md:py-16 bg-[var(--bg)]">
      <Container>
        {/* Section Header: At most one small label in body font */}
        <div className="mb-8 md:mb-10 text-center max-w-2xl mx-auto">
          <span className="inline-flex items-center gap-1.5 rounded-full border-none bg-orange-500/10 px-3 py-1 text-xs font-semibold text-orange-400 tracking-[0.04em]">
            <span className="h-2 w-2 rounded-full bg-[var(--accent)] animate-pulse" />
            Daily News Wires & Match Results
          </span>
          <h2 className="mt-3 font-display text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-[var(--text)]">
            The Daily Ledger & Match Centre
          </h2>
          <p className="mt-2 text-sm md:text-base text-[var(--text-muted)] leading-relaxed">
            Real daily competition results across Indian sports, dispatches directly from verified publisher wires, and broadcast guides.
          </p>
        </div>

        {/* 2-by-2 Grid Layout for Command Center Pillars */}
        <div className="grid gap-6 lg:grid-cols-2 min-w-0 items-stretch">
          {/* ================= PILLAR A: REAL DAILY RESULTS FEED ================= */}
          <div className="rounded-2xl border-none bg-[var(--surface-2)] p-4 sm:p-5 md:p-6 flex flex-col justify-between min-w-0 shadow-sm">
            <div>
              <div className="flex items-center justify-between pb-3.5">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-[var(--surface-hover)] text-[var(--accent)] border-none">
                    <Zap className="h-4 w-4 fill-current" />
                  </span>
                  <div>
                    <h3 className="font-display text-lg font-bold text-[var(--text)]">
                      Daily Results Feed
                    </h3>
                    <p className="text-xs text-[var(--text-muted)]">
                      Past day verified results
                      {resultsData?.lastUpdated && (
                        <span className="ml-1 text-[var(--accent)]">· Updated {timeAgo(resultsData.lastUpdated)}</span>
                      )}
                    </p>
                  </div>
                </div>
                <Link
                  href="/match-centre"
                  className="inline-flex items-center gap-1 text-xs font-bold text-[var(--accent)] hover:underline"
                >
                  <span>All 26 Sports</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>

              {/* Date chips: Today, Yesterday, Fri 23, All */}
              <div className="mt-3.5 space-y-2">
                <div className="no-scrollbar flex items-center gap-1.5 overflow-x-auto pb-1">
                  <button
                    onClick={() => setSelectedDate("all")}
                    className={cn(
                      "rounded-full px-3 py-1 text-xs whitespace-nowrap transition-colors border-none",
                      selectedDate === "all"
                        ? "bg-orange-500 text-white font-bold shadow-sm"
                        : "bg-[var(--surface)] hover:bg-[var(--surface-hover)] text-[var(--text-muted)]"
                    )}
                  >
                    All
                  </button>
                  {availableDates.map(dateStr => (
                    <button
                      key={dateStr}
                      onClick={() => setSelectedDate(dateStr)}
                      className={cn(
                        "rounded-full px-3 py-1 text-xs whitespace-nowrap transition-colors border-none",
                        selectedDate === dateStr
                          ? "bg-orange-500 text-white font-bold shadow-sm"
                          : "bg-[var(--surface)] hover:bg-[var(--surface-hover)] text-[var(--text-muted)]"
                      )}
                    >
                      {formatDateChip(dateStr)}
                    </button>
                  ))}
                </div>

                {/* Sports Filter Chips */}
                <div className="swipe-chips">
                  {FILTER_SPORTS.map(sp => (
                    <button
                      key={sp}
                      onClick={() => setSelectedSport(sp)}
                      data-testid={`cc-filter-${sp.toLowerCase()}`}
                      className={cn(
                        "swipe-chip transition-colors shadow-sm border-none",
                        selectedSport === sp
                          ? "bg-orange-500 text-white font-bold shadow-sm"
                          : "bg-[var(--surface)] hover:bg-[var(--surface-hover)] text-[var(--text-muted)]"
                      )}
                    >
                      {sp}
                    </button>
                  ))}
                </div>
              </div>

              {/* Results preview list: Entire card is link, real scores shown large */}
              <div className="mt-4 space-y-2.5">
                {resultsLoading ? (
                  <div className="space-y-2.5">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="h-20 animate-pulse rounded-xl border-none bg-[var(--surface-hover)]" />
                    ))}
                  </div>
                ) : previewResults.length === 0 ? (
                  <div className="rounded-xl border-none bg-[var(--surface-hover)] p-8 text-center text-xs text-[var(--text-muted)]">
                    No India results reported yet for this sport today.
                  </div>
                ) : (
                  previewResults.map(resItem => (
                    <a
                      key={resItem.id}
                      href={resItem.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group rounded-xl border-none bg-[var(--surface-hover)] p-3.5 block transition-all hover:bg-[var(--surface-hover)] shadow-sm"
                    >
                      <div className="flex items-center justify-between text-xs gap-2">
                        <span className="text-xs font-bold uppercase tracking-wider text-[var(--accent)]">
                          {resItem.sport}
                        </span>
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="text-[11px] text-[var(--text-muted)]">
                            {formatDateChip(resItem.date_ist)}
                          </span>
                          <span className="rounded-full border-none bg-[var(--surface)] px-2 py-0.5 text-[10px] text-[var(--text-muted)]">
                            {resItem.source}
                          </span>
                        </div>
                      </div>

                      <p className="mt-1.5 text-sm font-semibold text-slate-100 group-hover:text-[var(--accent)] transition-colors leading-snug">
                        {resItem.headline}
                      </p>

                      <div className="mt-2.5 flex items-center justify-between pt-1 border-none">
                        {resItem.score_text ? (
                          <span className="font-mono text-base font-bold text-emerald-400 bg-emerald-500/15 border-none px-2.5 py-0.5 rounded-[8px]">
                            Score: {resItem.score_text}
                          </span>
                        ) : (
                          <span className="text-xs text-[var(--text-muted)] font-medium">Result wire</span>
                        )}
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-[var(--accent)] group-hover:underline">
                          <span>Read source</span>
                          <ExternalLink className="h-3 w-3" />
                        </span>
                      </div>
                    </a>
                  ))
                )}
              </div>
            </div>

            <div className="mt-5 pt-3.5 flex items-center justify-between text-xs border-none">
              <span className="text-[var(--text-muted)]">
                Continuous verified updates
              </span>
              <Link
                href="/match-centre"
                className="btn-primary rounded-[10px] px-4 py-1.5 text-xs font-bold shadow border-none"
              >
                All 26 Sports Feed
              </Link>
            </div>
          </div>

          {/* ================= PILLAR B: BREAKING NEWS & ANATOMY STORIES ================= */}
          <div className="rounded-2xl border-none bg-[var(--surface-2)] p-4 sm:p-5 md:p-6 flex flex-col justify-between min-w-0 shadow-sm">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3.5">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-[var(--surface-hover)] text-[var(--accent)] border-none">
                    <Newspaper className="h-4 w-4" />
                  </span>
                  <div>
                    <h3 className="font-display text-lg font-bold text-[var(--text)]">
                      Dispatches & Wire Desk
                    </h3>
                    <p className="text-xs text-[var(--text-muted)]">
                      Live sports journalism from news agency wires
                      {wireNewsData?.lastUpdated && (
                        <span className="ml-1 text-[var(--accent)]">· Updated {timeAgo(wireNewsData.lastUpdated)}</span>
                      )}
                    </p>
                  </div>
                </div>

                {/* Sub-tab Switcher: India | International | Archive */}
                <div className="flex items-center gap-1 rounded-full border-none bg-[var(--surface-hover)] p-0.5">
                  <button
                    onClick={() => setNewsDeskMode("india")}
                    className={cn(
                      "flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold transition-colors border-none",
                      newsDeskMode === "india"
                        ? "bg-orange-500 text-white font-bold shadow-sm"
                        : "text-[var(--text-muted)] hover:text-white"
                    )}
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    India
                  </button>
                  <button
                    onClick={() => setNewsDeskMode("international")}
                    className={cn(
                      "rounded-full px-2.5 py-1 text-xs font-semibold transition-colors border-none",
                      newsDeskMode === "international"
                        ? "bg-orange-500 text-white font-bold shadow-sm"
                        : "text-[var(--text-muted)] hover:text-white"
                    )}
                  >
                    World
                  </button>
                  <button
                    onClick={() => setNewsDeskMode("archive")}
                    className={cn(
                      "rounded-full px-2.5 py-1 text-xs font-semibold transition-colors border-none",
                      newsDeskMode === "archive"
                        ? "bg-orange-500 text-white font-bold shadow-sm"
                        : "text-[var(--text-muted)] hover:text-white"
                    )}
                  >
                    Archive
                  </button>
                </div>
              </div>

              {newsDeskMode !== "archive" ? (
                /* LIVE WIRE DISPATCHES */
                wireLoading ? (
                  <div className="mt-4 space-y-3">
                    <div className="h-40 animate-pulse rounded-xl bg-[var(--surface-hover)] border-none" />
                    <div className="h-16 animate-pulse rounded-xl bg-[var(--surface-hover)] border-none" />
                  </div>
                ) : filteredWireNews.length === 0 ? (
                  <div className="mt-6 rounded-xl border-none bg-[var(--surface-hover)] p-6 text-center text-xs text-[var(--text-muted)]">
                    Connecting to live sports wire...
                  </div>
                ) : (
                  <>
                    {/* Top Story */}
                    {(() => {
                      const top = filteredWireNews[0];
                      const imgSrc = top.image_url || sportImage(top.sport);
                      return (
                        <a
                          href={top.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-4 block group rounded-xl border-none overflow-hidden bg-[var(--surface-hover)] transition-all hover:bg-[var(--surface-hover)] shadow-sm"
                        >
                          <div className="relative aspect-[16/9] w-full overflow-hidden bg-[var(--surface-2)]">
                            <img
                              src={imgSrc}
                              alt=""
                              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                              onError={(e) => {
                                (e.currentTarget as HTMLImageElement).src = sportImage(top.sport);
                              }}
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                            <div className="absolute left-3 top-3">
                              <span className="rounded-full bg-black/75 backdrop-blur px-2.5 py-0.5 text-[0.68rem] font-bold text-amber-300">
                                {top.sport}
                              </span>
                            </div>
                            <span className="absolute right-3 bottom-3 text-[11px] text-white/90 font-medium">
                              {new Date(top.published_at).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })} IST
                            </span>
                          </div>
                          <div className="p-3.5">
                            <span className="text-[11px] font-bold text-[var(--accent)]">
                              {top.source}
                            </span>
                            <h4 className="mt-1 font-sans text-base font-bold leading-snug text-slate-100 group-hover:text-[var(--accent)] transition-colors line-clamp-2">
                              {top.title}
                            </h4>
                            {top.summary && (
                              <p className="mt-1.5 text-xs text-[var(--text-muted)] line-clamp-2 leading-relaxed">
                                {top.summary}
                              </p>
                            )}
                          </div>
                        </a>
                      );
                    })()}

                    {/* Secondary Headlines with 4:3 thumbnails */}
                    <div className="mt-3 space-y-2">
                      {filteredWireNews.slice(1, 3).map((item: any) => {
                        const thumb = item.image_url || sportImage(item.sport);
                        return (
                          <a
                            key={item.id}
                            href={item.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex gap-3 group rounded-xl border-none bg-[var(--surface-hover)] p-2.5 transition-all hover:bg-[var(--surface-hover)] shadow-sm"
                          >
                            <div className="relative aspect-[4/3] w-20 shrink-0 overflow-hidden rounded-[8px] bg-[var(--surface-2)]">
                              <img
                                src={thumb}
                                alt=""
                                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                                onError={(e) => {
                                  (e.currentTarget as HTMLImageElement).src = sportImage(item.sport);
                                }}
                              />
                            </div>
                            <div className="min-w-0 flex-1 flex flex-col justify-between">
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <span className="text-[10px] font-bold uppercase text-[var(--accent)]">
                                    {item.sport}
                                  </span>
                                  <span className="text-[10px] text-slate-500">·</span>
                                  <span className="text-[10px] text-[var(--text-muted)] truncate">
                                    {item.source}
                                  </span>
                                </div>
                                <p className="mt-0.5 text-xs font-semibold leading-tight line-clamp-2 text-slate-100 group-hover:text-[var(--accent)] transition-colors">
                                  {item.title}
                                </p>
                              </div>
                              <span className="text-[11px] text-[var(--text-muted)] mt-1">
                                {new Date(item.published_at).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                              </span>
                            </div>
                          </a>
                        );
                      })}
                    </div>
                  </>
                )
              ) : (
                /* EDITORIAL INVESTIGATIVE ARCHIVES */
                <>
                  <Link
                    href={`/news/${LEAD.slug}`}
                    className="mt-4 block group rounded-xl border-none overflow-hidden bg-[var(--surface-hover)] transition-all hover:bg-[var(--surface-hover)] shadow-sm"
                  >
                    <div className="relative aspect-[16/9] w-full overflow-hidden bg-[var(--surface-2)]">
                      <img
                        src={LEAD.img}
                        alt=""
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <span className="absolute left-3 top-3 rounded-full bg-black/75 backdrop-blur px-2.5 py-0.5 text-[0.68rem] font-bold uppercase tracking-wider text-amber-300">
                        Feature
                      </span>
                    </div>
                    <div className="p-3.5">
                      <h4 className="font-sans text-base font-bold leading-snug text-slate-100 group-hover:text-[var(--accent)] transition-colors">
                        {LEAD.title}
                      </h4>
                      <p className="mt-1.5 text-xs text-[var(--text-muted)] line-clamp-2 leading-relaxed">
                        {LEAD.paras?.[0] || LEAD.title}
                      </p>
                    </div>
                  </Link>

                  <div className="mt-3 space-y-2">
                    {ARTICLES.slice(0, 2).map((item) => (
                      <Link
                        key={item.slug}
                        href={`/news/${item.slug}`}
                        className="flex gap-3 group rounded-xl border-none bg-[var(--surface-hover)] p-2.5 transition-all hover:bg-[var(--surface-hover)] shadow-sm"
                      >
                        <div className="relative aspect-[4/3] w-20 shrink-0 overflow-hidden rounded-[8px] bg-[var(--surface-2)]">
                          <img
                            src={item.img}
                            alt=""
                            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                        </div>
                        <div className="min-w-0 flex-1 flex flex-col justify-between">
                          <p className="text-xs font-semibold leading-tight line-clamp-2 text-slate-100 group-hover:text-[var(--accent)] transition-colors">
                            {item.title}
                          </p>
                          <span className="text-[11px] text-[var(--text-muted)]">{readTime(item)} min read</span>
                        </div>
                      </Link>
                    ))}
                  </div>
                </>
              )}
            </div>

            <div className="mt-5 pt-3.5 flex items-center justify-between text-xs border-none">
              <span className="text-[var(--text-muted)]">
                Live newsroom dispatches
              </span>
              <Link
                href="/news"
                className="btn-primary rounded-[10px] px-4 py-1.5 text-xs font-bold shadow border-none"
              >
                Open Newsroom Wire
              </Link>
            </div>
          </div>

          {/* ================= PILLAR C: SPORTS QUIZ ================= */}
          <div className="rounded-2xl border-none bg-[var(--surface-2)] p-4 sm:p-5 md:p-6 flex flex-col justify-between min-w-0 shadow-sm">
            <div>
              {/* Title on ONE line, Fan Zone Hub link on right */}
              <div className="flex items-center justify-between pb-3.5 mb-4">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-[var(--surface-hover)] text-[var(--accent)] border-none">
                    <Brain className="h-4 w-4" />
                  </span>
                  <div>
                    <h3 className="font-display text-lg font-bold text-[var(--text)] leading-tight">
                      The Indian Sports Quiz
                    </h3>
                    <p className="text-xs text-[var(--text-muted)]">Olympic & Asian Games trivia round</p>
                  </div>
                </div>
                <Link
                  href="/fan-zone"
                  className="inline-flex items-center gap-1 text-xs font-bold text-[var(--accent)] hover:underline shrink-0"
                >
                  <span>Fan Zone Hub</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>

              <DynamicQuiz embedded={true} />
            </div>

            <div className="mt-5 pt-3.5 flex items-center justify-between text-xs border-none">
              <span className="text-[var(--text-muted)]">New questions generated dynamically</span>
              <Link href="/fan-zone" className="text-xs font-bold text-[var(--accent)] hover:underline inline-flex items-center gap-1">
                Predict Para Games Haul <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          </div>

          {/* ================= PILLAR D: WHERE TO WATCH IN INDIA ================= */}
          <div className="rounded-2xl border-none bg-[var(--surface-2)] p-4 sm:p-5 md:p-6 flex flex-col justify-between min-w-0 shadow-sm">
            <div>
              <div className="flex items-center justify-between pb-3.5">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-[var(--surface-hover)] text-[var(--accent)] border-none">
                    <Tv className="h-4 w-4" />
                  </span>
                  <div>
                    <h3 className="font-display text-lg font-bold text-[var(--text)] leading-tight">
                      Where to Watch in India
                    </h3>
                    <p className="text-xs text-[var(--text-muted)]">Official broadcasters & streaming channels in IST</p>
                  </div>
                </div>
                <Link
                  href="/watch"
                  className="inline-flex items-center gap-1 text-xs font-bold text-[var(--accent)] hover:underline shrink-0"
                >
                  <span>Full TV guide</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>

              {/* Broadcast Cards Grid: Live, Upcoming, Ended status chips computed from dates, NO ARCHIVE */}
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {broadcastGuides.map(item => (
                  <Link
                    key={item.event}
                    href={item.href}
                    className="rounded-xl border-none bg-[var(--surface-hover)] p-3.5 block transition-all hover:bg-[var(--surface-hover)] shadow-sm"
                  >
                    <div className="flex items-center justify-between">
                      {item.status === "Live" ? (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/15 border-none px-2 py-0.5 text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          LIVE
                        </span>
                      ) : item.status === "Upcoming" ? (
                        <span className="inline-flex items-center rounded-full bg-amber-500/15 border-none px-2 py-0.5 text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                          UPCOMING
                        </span>
                      ) : (
                        <span className="inline-flex items-center rounded-full bg-[var(--surface)] border-none px-2 py-0.5 text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-wider">
                          ENDED
                        </span>
                      )}
                    </div>
                    <h5 className="mt-2 font-sans text-sm font-bold text-slate-100">
                      {item.event}
                    </h5>
                    <p className="mt-0.5 text-[11px] font-mono text-[var(--accent)]">
                      {item.dates}
                    </p>
                    <p className="mt-2 text-xs text-[var(--text-muted)] leading-snug">
                      <b className="text-[var(--text)] font-semibold">Broadcast:</b> {item.channels}
                    </p>
                  </Link>
                ))}
              </div>
            </div>

            <div className="mt-5 pt-3.5 flex items-center justify-between text-xs border-none">
              <span className="text-[var(--text-muted)]">All broadcast schedules in IST</span>
              <Link
                href="/watch"
                className="text-xs font-bold text-[var(--accent)] hover:underline inline-flex items-center gap-1"
              >
                Open Broadcast Guide <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
