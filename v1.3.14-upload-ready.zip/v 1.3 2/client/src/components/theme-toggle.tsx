import { Sun, Moon } from "lucide-react";
import { usePrefs } from "@/lib/prefs";
import { cn } from "@/lib/utils";

export function ThemeToggle({ className }: { className?: string }) {
  const { theme, themePref, toggleTheme } = usePrefs();
  const isDark = theme === "dark";
  const label = themePref === "system" ? `System (${isDark ? "dark" : "light"})` : themePref;

  return (
    <button
      type="button"
      onClick={toggleTheme}
      data-testid="button-theme-toggle"
      aria-label={`Theme: ${label}. Tap to change theme.`}
      title={`Theme: ${label}. Tap to change.`}
      className={cn(
        "tap-target inline-flex h-9 w-9 items-center justify-center rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text)] transition-colors hover:border-[var(--accent)] hover:text-[var(--accent)] shadow-sm shrink-0",
        className
      )}
    >
      {isDark ? (
        <Sun className="h-4 w-4 transition-transform hover:rotate-45" strokeWidth={1.75} />
      ) : (
        <Moon className="h-4 w-4 transition-transform hover:-rotate-12" strokeWidth={1.75} />
      )}
    </button>
  );
}

// Backwards compatibility alias
export const ThemeToggle3Way = ({ className }: { className?: string; compact?: boolean }) => (
  <ThemeToggle className={className} />
);
