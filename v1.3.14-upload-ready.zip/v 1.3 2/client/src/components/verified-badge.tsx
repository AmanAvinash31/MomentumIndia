import { AlertCircle, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export function VerifiedBadge({ date = "2026-10-08", className }: { date?: string; className?: string }) {
  const checked = new Date(date).getTime();
  const now = Date.now();
  const diffDays = Math.floor((now - checked) / (1000 * 60 * 60 * 24));
  const isOutdated = diffDays > 14;

  const fmt = (d: string) => {
    try {
      return new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
    } catch {
      return d;
    }
  };

  return (
    <div className={cn("inline-flex flex-wrap items-center gap-1.5 text-xs", className)} data-testid="verified-badge">
      <span className="inline-flex items-center gap-1 rounded-full bg-muted/80 px-2.5 py-0.5 font-medium text-muted-foreground border border-border/50">
        <CheckCircle2 className="h-3 w-3 text-indgreen" />
        Verified {fmt(date)}
      </span>
      {isOutdated && (
        <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 font-medium text-amber-600 dark:text-amber-400 border border-amber-500/20" title={`Last verified ${diffDays} days ago`}>
          <AlertCircle className="h-3 w-3" />
          May be outdated (&gt;14d)
        </span>
      )}
    </div>
  );
}
