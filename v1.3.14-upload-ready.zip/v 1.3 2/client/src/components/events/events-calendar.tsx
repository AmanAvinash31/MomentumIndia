import React, { useState } from "react";
import { type SportingEvent, CATEGORY_COLORS } from "./events-types";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Download, Clock, MapPin, ShieldCheck, ExternalLink, ArrowRight } from "lucide-react";
import { formatEventDateBadge } from "./events-directory";
import { cn } from "@/lib/utils";

interface EventsCalendarProps {
  events: SportingEvent[];
  onSelectEvent: (event: SportingEvent) => void;
  selectedMonth?: number; // 1-12
  onMonthChange?: (m: number) => void;
}

export function EventsCalendar({ events, onSelectEvent, selectedMonth = 1, onMonthChange }: EventsCalendarProps) {
  const [viewMode, setViewMode] = useState<"month" | "week" | "agenda">("month");
  const [currentMonth, setCurrentMonth] = useState<number>(selectedMonth);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);

  const MONTH_NAMES = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const handlePrevMonth = () => {
    const nextM = currentMonth > 1 ? currentMonth - 1 : 12;
    setCurrentMonth(nextM);
    setSelectedDay(null);
    onMonthChange?.(nextM);
  };

  const handleNextMonth = () => {
    const nextM = currentMonth < 12 ? currentMonth + 1 : 1;
    setCurrentMonth(nextM);
    setSelectedDay(null);
    onMonthChange?.(nextM);
  };

  const daysInMonth = new Date(2026, currentMonth, 0).getDate();
  const firstDayOfWeek = new Date(2026, currentMonth - 1, 1).getDay(); // 0 = Sun

  // Filter events active during current month
  const mStr = String(currentMonth).padStart(2, "0");
  const monthEvents = events.filter((e) => {
    return (
      e.start_date.startsWith(`2026-${mStr}`) ||
      e.end_date.startsWith(`2026-${mStr}`) ||
      (e.start_date <= `2026-${mStr}-${daysInMonth}` && e.end_date >= `2026-${mStr}-01`)
    );
  });

  // Calculate day mapping for month view
  const eventsByDay: Record<number, SportingEvent[]> = {};
  for (let day = 1; day <= daysInMonth; day++) {
    const dayStr = `2026-${mStr}-${String(day).padStart(2, "0")}`;
    eventsByDay[day] = monthEvents.filter((e) => e.start_date <= dayStr && e.end_date >= dayStr);
  }

  // Active list of events for the right column feed
  const timelineEvents = selectedDay ? (eventsByDay[selectedDay] || []) : monthEvents;

  return (
    <div className="rounded-2xl bg-[var(--surface)] p-4 sm:p-6 shadow-sm border-none">
      {/* Calendar Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-none">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-[var(--surface-2)] rounded-xl p-1 border-none">
            <button
              onClick={handlePrevMonth}
              className="tap-target h-8 w-8 grid place-items-center rounded-lg hover:bg-white/[0.08] text-[var(--text-muted)] hover:text-[var(--text)] transition-colors border-none cursor-pointer"
              aria-label="Previous Month"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="font-display font-bold text-base sm:text-lg px-2 min-w-36 text-center text-[var(--text)]">
              {MONTH_NAMES[currentMonth - 1]} 2026
            </span>
            <button
              onClick={handleNextMonth}
              className="tap-target h-8 w-8 grid place-items-center rounded-lg hover:bg-white/[0.08] text-[var(--text-muted)] hover:text-[var(--text)] transition-colors border-none cursor-pointer"
              aria-label="Next Month"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>

          <span className="text-xs font-bold px-3 py-1 rounded-full bg-orange-500/10 text-orange-400 border-none">
            {monthEvents.length} tournaments
          </span>
        </div>

        {/* View Switcher & Exports (Week, Agenda, .ics, CSV styled cleanly without borders) */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center rounded-xl bg-[var(--surface-2)] p-1 text-xs font-bold border-none">
            <button
              onClick={() => setViewMode("month")}
              className={cn(
                "tap-target px-3 py-1 rounded-lg transition-colors border-none cursor-pointer",
                viewMode === "month"
                  ? "bg-orange-500 text-[var(--text)] font-bold shadow-sm"
                  : "text-[var(--text-muted)] hover:text-[var(--text)]"
              )}
            >
              Month
            </button>
            <button
              onClick={() => setViewMode("week")}
              className={cn(
                "tap-target px-3 py-1 rounded-lg transition-colors border-none cursor-pointer",
                viewMode === "week"
                  ? "bg-orange-500 text-[var(--text)] font-bold shadow-sm"
                  : "text-[var(--text-muted)] hover:text-[var(--text)]"
              )}
            >
              Week
            </button>
            <button
              onClick={() => setViewMode("agenda")}
              className={cn(
                "tap-target px-3 py-1 rounded-lg transition-colors border-none cursor-pointer",
                viewMode === "agenda"
                  ? "bg-orange-500 text-[var(--text)] font-bold shadow-sm"
                  : "text-[var(--text-muted)] hover:text-[var(--text)]"
              )}
            >
              Agenda
            </button>
          </div>

          <a
            href="/api/events/export/ics"
            download="India_Sports_Events_2026.ics"
            className="tap-target px-3.5 py-1.5 rounded-xl bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] text-xs font-bold inline-flex items-center gap-1.5 text-[var(--text)] border-none transition-colors shadow-sm"
            title="Download .ics Calendar for Apple / Google Calendar"
          >
            <Download className="h-3.5 w-3.5 text-orange-400" />
            <span>.ics</span>
          </a>
          <a
            href="/api/events/export/csv"
            download="India_Sports_Events_2026.csv"
            className="tap-target px-3.5 py-1.5 rounded-xl bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] text-xs font-bold inline-flex items-center gap-1.5 text-[var(--text)] border-none transition-colors shadow-sm"
            title="Download Full 2026 Database in CSV"
          >
            <Download className="h-3.5 w-3.5 text-orange-400" />
            <span>CSV</span>
          </a>
        </div>
      </div>

      {/* MONTH VIEW: Clean Split Interactive Schedule View */}
      {viewMode === "month" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* LEFT COLUMN: Sleek Month Grid */}
          <div className="lg:col-span-7 space-y-2">
            {/* Day Header Row */}
            <div className="grid grid-cols-7 gap-1 text-center font-bold text-xs text-[var(--text-muted)] uppercase py-1 select-none">
              <span>Sun</span>
              <span>Mon</span>
              <span>Tue</span>
              <span>Wed</span>
              <span>Thu</span>
              <span>Fri</span>
              <span>Sat</span>
            </div>

            {/* Days Grid */}
            <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
              {/* Blank leading days */}
              {Array.from({ length: firstDayOfWeek }).map((_, idx) => (
                <div
                  key={`blank-${idx}`}
                  className="h-16 sm:h-20 rounded-xl bg-[var(--surface-2)] opacity-20 border-none"
                />
              ))}

              {/* Day Tiles: Borderless dark day tiles showing date and clean sport indicator dots */}
              {Array.from({ length: daysInMonth }).map((_, idx) => {
                const day = idx + 1;
                const dayEvents = eventsByDay[day] || [];
                const isSelected = selectedDay === day;
                const hasEvents = dayEvents.length > 0;

                return (
                  <div
                    key={`day-${day}`}
                    onClick={() => {
                      if (selectedDay === day) {
                        setSelectedDay(null); // toggle off
                      } else {
                        setSelectedDay(day);
                      }
                    }}
                    className={cn(
                      "h-16 sm:h-20 rounded-xl p-2 flex flex-col justify-between transition-all cursor-pointer border-none select-none relative group",
                      isSelected
                        ? "bg-[#182030] ring-1 ring-orange-500/60 shadow-[0_0_16px_rgba(249,115,22,0.3)] text-[var(--text)]"
                        : "bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] text-[var(--text-muted)]"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={cn(
                          "font-display text-xs sm:text-sm font-extrabold",
                          isSelected ? "text-orange-400" : hasEvents ? "text-[var(--text)]" : "text-[var(--text-muted)]"
                        )}
                      >
                        {day}
                      </span>
                      {dayEvents.length > 1 && (
                        <span className="text-[9px] font-bold text-[var(--text-muted)] group-hover:text-orange-400">
                          {dayEvents.length}
                        </span>
                      )}
                    </div>

                    {/* Clean color-coded sport indicator dots (• • •) instead of repeating full orange text bricks */}
                    <div className="flex items-center gap-1 flex-wrap pt-1 min-h-[14px]">
                      {dayEvents.slice(0, 4).map((ev) => {
                        const catColor = CATEGORY_COLORS[ev.sport_category] || CATEGORY_COLORS.Default;
                        return (
                          <span
                            key={ev.event_id}
                            className="h-2 w-2 rounded-full shrink-0"
                            style={{
                              backgroundColor: catColor,
                              boxShadow: `0 0 6px ${catColor}`,
                            }}
                            title={`${ev.event_name} (${ev.sport})`}
                          />
                        );
                      })}
                      {dayEvents.length > 4 && (
                        <span className="text-[9px] font-extrabold text-orange-400 leading-none">
                          +{dayEvents.length - 4}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Instruction footnote */}
            <div className="pt-2 text-[11px] text-[var(--text-muted)] flex items-center justify-between">
              <span>Click any date tile to isolate competitions for that day.</span>
              {selectedDay !== null && (
                <button
                  onClick={() => setSelectedDay(null)}
                  className="text-orange-400 hover:text-orange-300 font-bold underline cursor-pointer border-none bg-transparent"
                >
                  View All {MONTH_NAMES[currentMonth - 1]} Events
                </button>
              )}
            </div>
          </div>

          {/* RIGHT COLUMN: Active Month / Selected Date Timeline Feed */}
          <div className="lg:col-span-5 bg-[var(--bg)] rounded-2xl p-4 sm:p-5 border-none shadow-xs">
            <div className="flex items-center justify-between pb-3 border-none">
              <div>
                <h4 className="font-display text-sm sm:text-base font-extrabold text-[var(--text)]">
                  {selectedDay !== null
                    ? `${selectedDay} ${MONTH_NAMES[currentMonth - 1]} 2026 Schedule`
                    : `${MONTH_NAMES[currentMonth - 1]} 2026 Active Feed`}
                </h4>
                <p className="text-xs text-[var(--text-muted)]">
                  {timelineEvents.length} {timelineEvents.length === 1 ? "competition" : "competitions"} active
                </p>
              </div>

              {selectedDay !== null && (
                <button
                  onClick={() => setSelectedDay(null)}
                  className="tap-target px-2.5 py-1 rounded-lg bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] text-xs font-bold text-orange-400 transition-colors border-none cursor-pointer"
                >
                  Full Month
                </button>
              )}
            </div>

            {/* Scrollable list of sleek borderless event cards */}
            <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1 no-scrollbar">
              {timelineEvents.length === 0 ? (
                <div className="rounded-xl bg-[var(--surface-2)] p-8 text-center text-xs text-[var(--text-muted)] border-none">
                  No competitions scheduled for this specific date.
                  <button
                    onClick={() => setSelectedDay(null)}
                    className="block mx-auto mt-2 text-orange-400 font-bold hover:underline border-none bg-transparent cursor-pointer"
                  >
                    Browse entire month
                  </button>
                </div>
              ) : (
                timelineEvents.map((ev) => {
                  const catColor = CATEGORY_COLORS[ev.sport_category] || CATEGORY_COLORS.Default;
                  const readableDates = formatEventDateBadge(ev.start_date, ev.end_date);

                  return (
                    <div
                      key={ev.event_id}
                      onClick={() => onSelectEvent(ev)}
                      className="bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] rounded-xl p-3.5 sm:p-4 transition-all border-none group cursor-pointer shadow-xs space-y-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        {/* Sport Category Badge */}
                        <span
                          className="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full text-[var(--text)] border-none"
                          style={{ backgroundColor: catColor }}
                        >
                          {ev.sport}
                        </span>

                        {/* Date Range Pill */}
                        <span className="font-mono text-[11px] font-bold text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded-md border-none">
                          {readableDates}
                        </span>
                      </div>

                      {/* Event Name */}
                      <div>
                        <h5 className="font-display font-bold text-sm sm:text-base text-[var(--text)] group-hover:text-orange-400 transition-colors leading-snug">
                          {ev.event_name}
                        </h5>
                        <p className="text-xs text-[var(--text-muted)] mt-0.5">
                          {ev.discipline ? `${ev.discipline} · ` : ""}{ev.competition_level}
                        </p>
                      </div>

                      {/* City, Venue & Verification Status */}
                      <div className="pt-1 flex items-center justify-between text-xs text-[var(--text-muted)] border-none">
                        <div className="flex items-center gap-1.5 truncate max-w-[200px]">
                          <MapPin className="h-3 w-3 text-orange-400 shrink-0" />
                          <span className="truncate">{ev.city}, {ev.state_or_union_territory}</span>
                        </div>

                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 shrink-0">
                          <ShieldCheck className="h-3.5 w-3.5" />
                          <span>{ev.verification_status}</span>
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* WEEK VIEW: Sleek Borderless Cards */}
      {viewMode === "week" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {monthEvents.slice(0, 8).map((ev) => {
            const catColor = CATEGORY_COLORS[ev.sport_category] || CATEGORY_COLORS.Default;
            const readableDates = formatEventDateBadge(ev.start_date, ev.end_date);
            return (
              <div
                key={ev.event_id}
                onClick={() => onSelectEvent(ev)}
                className="rounded-xl bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] p-4 cursor-pointer transition-all flex flex-col justify-between border-none shadow-xs"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span
                      className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full text-[var(--text)] border-none"
                      style={{ backgroundColor: catColor }}
                    >
                      {ev.sport}
                    </span>
                    <span className="text-[10px] font-bold text-[var(--text-muted)]">
                      {ev.competition_level}
                    </span>
                  </div>
                  <h4 className="font-display font-bold text-sm text-[var(--text)] line-clamp-2">
                    {ev.event_name}
                  </h4>
                </div>

                <div className="mt-4 pt-2 text-xs text-[var(--text-muted)] space-y-1.5 border-none">
                  <div className="flex items-center gap-1.5 font-mono text-orange-400 font-bold">
                    <Clock className="h-3 w-3 shrink-0" />
                    <span>{readableDates}</span>
                  </div>
                  <div className="flex items-center gap-1.5 truncate">
                    <MapPin className="h-3 w-3 text-[var(--text-muted)] shrink-0" />
                    <span className="truncate">{ev.city}, {ev.state_or_union_territory}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* AGENDA VIEW: Sleek Timeline Rows */}
      {viewMode === "agenda" && (
        <div className="space-y-2.5">
          {monthEvents.map((ev) => {
            const catColor = CATEGORY_COLORS[ev.sport_category] || CATEGORY_COLORS.Default;
            const readableDates = formatEventDateBadge(ev.start_date, ev.end_date);
            const startDayNum = ev.start_date.split("-")[2] || "01";
            const monthIdx = parseInt(ev.start_date.split("-")[1] || "1", 10) - 1;

            return (
              <div
                key={ev.event_id}
                onClick={() => onSelectEvent(ev)}
                className="rounded-xl bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer transition-all border-none shadow-xs"
              >
                <div className="flex items-start sm:items-center gap-3">
                  <div className="text-center min-w-16 rounded-xl bg-orange-500/10 px-2.5 py-1.5 shrink-0 border-none">
                    <p className="font-display font-extrabold text-base text-orange-400">
                      {startDayNum}
                    </p>
                    <p className="text-[10px] font-bold uppercase text-orange-400/80">
                      {MONTH_NAMES[monthIdx].slice(0, 3)}
                    </p>
                  </div>

                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span
                        className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full text-[var(--text)] border-none"
                        style={{ backgroundColor: catColor }}
                      >
                        {ev.sport}
                      </span>
                      <span className="text-[11px] font-semibold text-emerald-400">
                        {ev.verification_status}
                      </span>
                      <span className="font-mono text-xs text-orange-400 font-semibold">
                        {readableDates}
                      </span>
                    </div>
                    <h4 className="font-display font-bold text-sm sm:text-base text-[var(--text)]">
                      {ev.event_name}
                    </h4>
                    <p className="text-xs text-[var(--text-muted)] mt-0.5">
                      📍 {ev.venue ? `${ev.venue}, ` : ""}{ev.city}, {ev.state_or_union_territory}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-white/[0.05] text-[var(--text-muted)] border-none">
                    {ev.competition_level}
                  </span>
                  <button className="tap-target px-3.5 py-1.5 rounded-lg bg-orange-500 text-[var(--text)] text-xs font-bold hover:brightness-105 border-none cursor-pointer shadow-sm">
                    Inspect
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
