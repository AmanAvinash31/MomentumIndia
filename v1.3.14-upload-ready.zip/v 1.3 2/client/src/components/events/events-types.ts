export interface SportingEvent {
  event_id: string;
  event_name: string;
  official_event_name: string | null;
  sport: string;
  discipline: string | null;
  sport_category: string;
  event_type: string | null;
  competition_level: "International" | "National" | "State" | "Zonal" | "Mass-Participation";
  gender_category: "Open" | "Men" | "Women" | "Mixed" | null;
  age_category: "Senior" | "Junior" | "Youth" | "Sub-Junior" | "Masters" | "Open" | null;
  para_sport: number;
  international_or_domestic: "International" | "Domestic";
  start_date: string;
  end_date: string;
  date_precision: "EXACT" | "APPROXIMATE" | "MONTH" | "TBA";
  date_status: "CONFIRMED" | "TENTATIVE" | "TBA";
  country: string;
  state_or_union_territory: string;
  city: string;
  district: string | null;
  venue: string | null;
  venue_address: string | null;
  latitude: number;
  longitude: number;
  organizer: string | null;
  governing_federation: string | null;
  event_description: string | null;
  competition_format: string | null;
  registration_url: string | null;
  official_event_url: string | null;
  source_urls: string;
  verification_status: "CONFIRMED" | "CROSS-VERIFIED" | "PARTIALLY VERIFIED" | "UNCONFIRMED";
  last_verified_at: string;
  event_status: "UPCOMING" | "ONGOING" | "COMPLETED" | "POSTPONED" | "CANCELLED";
  price_or_registration_fee: string | null;
  registration_deadline: string | null;
  recurring_event: number;
  expected_participants: number | null;
  national_or_international_significance: string | null;
  data_completeness: number;
  last_updated_at: string;
}

export interface EventsKPIs {
  totalUnique: number;
  confirmed: number;
  crossVerified: number;
  partiallyVerified: number;
  unconfirmed: number;
  upcoming: number;
  ongoing: number;
  completed: number;
  postponed: number;
  cancelled: number;
  international: number;
  national: number;
  stateLevel: number;
  massParticipation: number;
  marathonEndurance: number;
  ultraTrail: number;
  ironmanTriathlon: number;
  hyroxFitness: number;
  chessMindSports: number;
  olympicSports: number;
  commonwealthSports: number;
  asianGamesSports: number;
  paraSports: number;
  indigenousSports: number;
  awaitingVerification: number;
  statesRepresented: number;
  citiesRepresented: number;
  lastUpdatedAt: string;
}

export interface StateSummary {
  state: string;
  count: number;
  sports: Record<string, number>;
  monthly: number[];
  majorEvents: string[];
  completeness: number;
  upcomingCount: number;
  cities: string[];
}

export const SPORT_CATEGORIES = [
  "All",
  "Olympic Sports",
  "Commonwealth Games",
  "Asian Games",
  "Marathon & Endurance",
  "HYROX & Fitness",
  "Chess & Mind Sports",
  "Indigenous Sports",
  "Para-sports",
  "Cricket & Leagues",
  "Motorsports",
] as const;

export const ALL_36_STATES_AND_UTS = [
  "All States & UTs",
  // 28 States
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
  // 8 Union Territories
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi",
  "Jammu and Kashmir",
  "Ladakh",
  "Lakshadweep",
  "Puducherry"
] as const;

export const CATEGORY_COLORS: Record<string, string> = {
  "Olympic Sports": "#F59E0B", // Amber
  "Commonwealth Games": "#3B82F6", // Blue
  "Asian Games": "#EC4899", // Pink
  "Marathon & Endurance": "#06B6D4", // Cyan
  "HYROX & Fitness": "#EF4444", // Red
  "Chess & Mind Sports": "#8B5CF6", // Purple
  "Indigenous Sports": "#F97316", // Orange
  "Para-sports": "#10B981", // Emerald
  "Cricket & Leagues": "#22C55E", // Green
  "Motorsports": "#6366F1", // Indigo
  "Default": "#A855F7"
};

