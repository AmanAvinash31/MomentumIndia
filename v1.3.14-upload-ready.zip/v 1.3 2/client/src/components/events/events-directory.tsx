import React, { useState, useEffect, useMemo } from "react";
import { type SportingEvent, CATEGORY_COLORS } from "./events-types";
import { Calendar, MapPin, ShieldCheck, ChevronRight, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";

export function formatEventDateBadge(startStr: string, endStr?: string | null): string {
  if (!startStr) return "";
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  const parseDate = (s: string) => {
    const parts = s.split("-");
    if (parts.length < 3) return null;
    return {
      year: parts[0],
      month: parseInt(parts[1], 10),
      day: parseInt(parts[2], 10),
    };
  };

  const start = parseDate(startStr);
  const end = endStr ? parseDate(endStr) : null;

  if (!start) return startStr;

  if (!end || startStr === endStr) {
    return `${start.day} ${months[start.month - 1]} ${start.year}`;
  }

  if (start.year === end.year) {
    if (start.month === end.month) {
      return `${start.day} – ${end.day} ${months[start.month - 1]} ${start.year}`;
    }
    return `${start.day} ${months[start.month - 1]} – ${end.day} ${months[end.month - 1]} ${start.year}`;
  }

  return `${start.day} ${months[start.month - 1]} ${start.year} – ${end.day} ${months[end.month - 1]} ${end.year}`;
}

interface EventsDirectoryProps {
  events: SportingEvent[];
  onSelectEvent: (event: SportingEvent) => void;
  loading?: boolean;
}

export function EventsDirectory({ events, onSelectEvent, loading }: EventsDirectoryProps) {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(8);

  // Auto-reset to Page 1 whenever filters or search results change
  useEffect(() => {
    setCurrentPage(1);
  }, [events]);

  const totalEvents = events.length;
  const totalPages = Math.max(1, Math.ceil(totalEvents / pageSize));
  const validCurrentPage = Math.min(currentPage, totalPages);

  const startIdx = totalEvents === 0 ? 0 : (validCurrentPage - 1) * pageSize + 1;
  const endIdx = Math.min(validCurrentPage * pageSize, totalEvents);

  const paginatedEvents = useMemo(() => {
    const start = (validCurrentPage - 1) * pageSize;
    return events.slice(start, start + pageSize);
  }, [events, validCurrentPage, pageSize]);

  const handleShowMore = () => {
    setPageSize((prev) => prev + 8);
  };

  if (loading) {
    return (
      <div className="space-y-3 animate-pulse">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <div key={i} className="h-16 rounded-xl bg-[var(--surface-2)] border-none" />
        ))}
      </div>
    );
  }

  if (events.length === 0) {
    return (
      <div className="rounded-2xl bg-[var(--surface)] p-12 text-center text-[var(--text-muted)] border-none">
        <Calendar className="h-10 w-10 mx-auto text-slate-500 mb-3" />
        <p className="font-display text-lg font-bold text-[var(--text)]">No events match your selected filters</p>
        <p className="text-xs text-[var(--text-muted)] mt-1">Try resetting the sport category, state, or search keyword.</p>
      </div>
    );
  }

  // Generate pagination page numbers
  const pageNumbers: (number | string)[] = [];
  if (totalPages <= 5) {
    for (let i = 1; i <= totalPages; i++) pageNumbers.push(i);
  } else {
    pageNumbers.push(1);
    if (validCurrentPage > 3) pageNumbers.push("...");
    const start = Math.max(2, validCurrentPage - 1);
    const end = Math.min(totalPages - 1, validCurrentPage + 1);
    for (let i = start; i <= end; i++) pageNumbers.push(i);
    if (validCurrentPage < totalPages - 2) pageNumbers.push("...");
    pageNumbers.push(totalPages);
  }

  return (
    <div className="rounded-2xl bg-[var(--surface)] p-4 sm:p-6 shadow-sm border-none">
      {/* Header: Title, Live Dynamic Counter & Page Size Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-none">
        <div>
          <h3 className="font-display text-xl sm:text-2xl font-extrabold text-[var(--text)]">
            National Event Directory
          </h3>
          <p className="text-xs text-[var(--text-muted)] mt-0.5">
            {totalEvents === 0
              ? "0 competitions found"
              : `Showing ${startIdx}–${endIdx} of ${totalEvents} verified competitions across India`}
          </p>
        </div>

        {/* Per-Page Selector (8 / 16 / 25 per page) */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="text-xs font-semibold text-[var(--text-muted)]">View:</span>
          <div className="flex items-center rounded-xl bg-[var(--surface-2)] p-0.5 text-xs font-bold border-none">
            {[8, 16, 25].map((size) => (
              <button
                key={size}
                onClick={() => {
                  setPageSize(size);
                  setCurrentPage(1);
                }}
                className={cn(
                  "tap-target px-2.5 py-1 rounded-lg transition-colors border-none",
                  pageSize === size
                    ? "bg-orange-500 text-[var(--text)] font-bold shadow-sm"
                    : "text-[var(--text-muted)] hover:text-[var(--text)]"
                )}
              >
                {size}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Desktop & Tablet Floating Row Cards (Zero White Lines, Zero Border, Surface Elevation) */}
      <div className="hidden md:block">
        {/* Table Column Labels */}
        <div className="grid grid-cols-12 gap-4 px-4 py-2 text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)] select-none">
          <div className="col-span-4">Event & Sport</div>
          <div className="col-span-2">Dates</div>
          <div className="col-span-3">Location & Venue</div>
          <div className="col-span-1">Level</div>
          <div className="col-span-2 text-right">Intel Details</div>
        </div>

        {/* Floating Borderless Cards */}
        <div className="space-y-2 mt-1">
          {paginatedEvents.map((ev) => {
            const catColor = CATEGORY_COLORS[ev.sport_category] || CATEGORY_COLORS.Default;
            const readableDates = formatEventDateBadge(ev.start_date, ev.end_date);

            return (
              <div
                key={ev.event_id}
                onClick={() => onSelectEvent(ev)}
                className="grid grid-cols-12 gap-4 items-center bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] rounded-xl px-4 py-3.5 transition-all border-none group cursor-pointer shadow-xs"
              >
                {/* Event Name & Sport */}
                <div className="col-span-4 flex items-center gap-3 min-w-0">
                  <span
                    className="h-2.5 w-2.5 rounded-full shrink-0"
                    style={{
                      backgroundColor: catColor,
                      boxShadow: `0 0 8px ${catColor}`,
                    }}
                  />
                  <div className="min-w-0">
                    <span className="font-bold text-[var(--text)] group-hover:text-orange-400 transition-colors block truncate">
                      {ev.event_name}
                    </span>
                    <span className="text-xs text-[var(--text-muted)] block truncate">
                      {ev.sport} {ev.discipline ? `· ${ev.discipline}` : ""}
                    </span>
                  </div>
                </div>

                {/* Human-Readable Date Badge */}
                <div className="col-span-2 font-mono text-xs whitespace-nowrap">
                  <span className="inline-block bg-orange-500/10 text-orange-400 font-bold px-2 py-0.5 rounded-md border-none">
                    {readableDates}
                  </span>
                </div>

                {/* City & Venue */}
                <div className="col-span-3 text-xs min-w-0">
                  <span className="font-semibold text-[var(--text)] block truncate">
                    {ev.city}, {ev.state_or_union_territory}
                  </span>
                  <span className="text-[var(--text-muted)] block truncate">
                    {ev.venue || "Venue TBA"}
                  </span>
                </div>

                {/* Level Badge */}
                <div className="col-span-1 whitespace-nowrap">
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-white/[0.05] text-[var(--text-muted)] border-none">
                    {ev.competition_level}
                  </span>
                </div>

                {/* Verification Status & Inspect Button */}
                <div className="col-span-2 flex items-center justify-end gap-2.5">
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                    <ShieldCheck className="h-3.5 w-3.5 shrink-0" />
                    <span className="hidden lg:inline">{ev.verification_status}</span>
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectEvent(ev);
                    }}
                    className="tap-target px-3 py-1.5 rounded-lg bg-orange-500/10 text-orange-400 group-hover:bg-orange-500 group-hover:text-[var(--text)] text-xs font-bold transition-all inline-flex items-center gap-1 border-none"
                  >
                    <span>Inspect</span>
                    <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Mobile Stackable Cards (< 768px) with Touch Targets */}
      <div className="md:hidden space-y-2.5">
        {paginatedEvents.map((ev) => {
          const catColor = CATEGORY_COLORS[ev.sport_category] || CATEGORY_COLORS.Default;
          const readableDates = formatEventDateBadge(ev.start_date, ev.end_date);

          return (
            <div
              key={ev.event_id}
              onClick={() => onSelectEvent(ev)}
              className="bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] rounded-xl px-4 py-3.5 transition-all border-none cursor-pointer space-y-2.5 shadow-xs"
            >
              <div className="flex items-center justify-between gap-2">
                <span
                  className="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full text-[var(--text)] border-none"
                  style={{ backgroundColor: catColor }}
                >
                  {ev.sport}
                </span>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                  <ShieldCheck className="h-3.5 w-3.5" />
                  {ev.verification_status}
                </span>
              </div>

              <div>
                <h4 className="font-display font-bold text-base text-[var(--text)] leading-snug">
                  {ev.event_name}
                </h4>
                <p className="text-xs text-[var(--text-muted)] mt-0.5">
                  {ev.discipline ? `${ev.discipline} · ` : ""}{ev.competition_level} Level
                </p>
              </div>

              <div className="pt-2 flex items-center justify-between text-xs text-[var(--text-muted)] border-none">
                <div className="space-y-1">
                  <div className="font-mono text-xs text-orange-400 font-bold bg-orange-500/10 px-2 py-0.5 rounded-md inline-block">
                    {readableDates}
                  </div>
                  <div className="flex items-center gap-1.5 truncate max-w-[200px] text-[var(--text-muted)]">
                    <MapPin className="h-3 w-3 text-orange-400 shrink-0" />
                    <span className="truncate">{ev.city}, {ev.state_or_union_territory}</span>
                  </div>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectEvent(ev);
                  }}
                  className="tap-target px-3.5 py-1.5 rounded-lg bg-orange-500 text-[var(--text)] text-xs font-bold shrink-0 shadow-sm border-none"
                >
                  Inspect
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sleek Borderless Pagination Bar at Bottom */}
      <div className="mt-6 pt-3 flex flex-col sm:flex-row items-center justify-between gap-4 border-none">
        {/* Quick Expand Button ("Show 8 More") */}
        <div>
          {endIdx < totalEvents ? (
            <button
              onClick={handleShowMore}
              className="tap-target px-4 py-2 rounded-xl bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] text-xs font-bold text-orange-400 border-none transition-colors shadow-sm inline-flex items-center gap-2"
            >
              <span>Show 8 More Competitions</span>
              <span className="text-[10px] text-[var(--text-muted)]">({totalEvents - endIdx} left)</span>
            </button>
          ) : (
            <span className="text-xs text-slate-500 font-medium">All {totalEvents} competitions loaded</span>
          )}
        </div>

        {/* Page navigation pills (< Prev, 1, 2, 3 ... Next >) */}
        {totalPages > 1 && (
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={validCurrentPage === 1}
              className="tap-target px-3 py-1.5 rounded-xl bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] disabled:opacity-30 disabled:hover:bg-[var(--surface-2)] text-xs font-bold text-[var(--text-muted)] border-none transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              ‹ Prev
            </button>

            {pageNumbers.map((p, idx) => {
              if (typeof p === "string") {
                return (
                  <span key={`ellipsis-${idx}`} className="px-1 text-xs text-slate-500">
                    …
                  </span>
                );
              }
              return (
                <button
                  key={`page-${p}`}
                  onClick={() => setCurrentPage(p)}
                  className={cn(
                    "tap-target h-8 min-w-8 px-2 rounded-xl text-xs font-bold transition-colors border-none cursor-pointer",
                    validCurrentPage === p
                      ? "bg-orange-500 text-[var(--text)] font-extrabold shadow-sm"
                      : "bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] text-[var(--text-muted)]"
                  )}
                >
                  {p}
                </button>
              );
            })}

            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={validCurrentPage === totalPages}
              className="tap-target px-3 py-1.5 rounded-xl bg-[var(--surface-2)] hover:bg-[var(--surface-hover)] disabled:opacity-30 disabled:hover:bg-[var(--surface-2)] text-xs font-bold text-[var(--text-muted)] border-none transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              Next ›
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
