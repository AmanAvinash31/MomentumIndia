import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { type SportingEvent, CATEGORY_COLORS } from "./events-types";
import { Calendar, MapPin, ExternalLink, ShieldCheck, Trophy, Users, Award, Building, DollarSign } from "lucide-react";
import { formatEventDateBadge } from "./events-directory";

interface EventModalProps {
  event: SportingEvent | null;
  open: boolean;
  onClose: () => void;
}

export function EventModal({ event, open, onClose }: EventModalProps) {
  if (!event) return null;

  let sources: string[] = [];
  try {
    sources = JSON.parse(event.source_urls || "[]");
  } catch {}

  const catColor = CATEGORY_COLORS[event.sport_category] || CATEGORY_COLORS.Default;
  const readableDates = formatEventDateBadge(event.start_date, event.end_date);

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-[var(--surface)] text-[var(--text)] border-none shadow-2xl p-6 sm:p-8 rounded-2xl">
        <DialogHeader className="space-y-2 border-none">
          <div className="flex flex-wrap items-center gap-2">
            <span
              className="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full text-[var(--text)] border-none"
              style={{ backgroundColor: catColor }}
            >
              {event.sport}
            </span>
            <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-white/[0.05] text-[var(--text-muted)] border-none">
              {event.competition_level}
            </span>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-400 flex items-center gap-1 border-none">
              <ShieldCheck className="h-3.5 w-3.5" />
              {event.verification_status}
            </span>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-orange-500/15 text-orange-400 border-none">
              {event.event_status}
            </span>
          </div>

          <DialogTitle className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight mt-2 text-[var(--text)]">
            {event.event_name}
          </DialogTitle>

          {event.official_event_name && event.official_event_name !== event.event_name && (
            <DialogDescription className="text-sm font-medium text-[var(--text-muted)]">
              Official: {event.official_event_name}
            </DialogDescription>
          )}
        </DialogHeader>

        <div className="space-y-6 mt-4 border-none">
          {/* Key Facts Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[var(--surface-2)] rounded-xl p-4 border-none">
            <div className="flex items-start gap-3">
              <Calendar className="h-5 w-5 text-orange-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-[var(--text-muted)] uppercase font-bold tracking-wider">Date & Schedule</p>
                <p className="font-semibold text-sm text-[var(--text)]">{readableDates}</p>
                <p className="text-xs text-[var(--text-muted)]">{event.date_status} · {event.date_precision}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-orange-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-[var(--text-muted)] uppercase font-bold tracking-wider">Host City & State</p>
                <p className="font-semibold text-sm text-[var(--text)]">{event.city}, {event.state_or_union_territory}</p>
                <p className="text-xs text-[var(--text-muted)]">{event.venue || "Venue TBA"}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Building className="h-5 w-5 text-orange-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-[var(--text-muted)] uppercase font-bold tracking-wider">Organizer & Federation</p>
                <p className="font-semibold text-sm text-[var(--text)]">{event.organizer || "National Organizing Committee"}</p>
                <p className="text-xs text-[var(--text-muted)]">{event.governing_federation || "Sanctioned Body"}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Award className="h-5 w-5 text-orange-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-[var(--text-muted)] uppercase font-bold tracking-wider">Format & Category</p>
                <p className="font-semibold text-sm text-[var(--text)]">{event.discipline || event.sport}</p>
                <p className="text-xs text-[var(--text-muted)]">{event.sport_category} {event.para_sport === 1 ? "· Para-Sport" : ""}</p>
              </div>
            </div>
          </div>

          {/* Description */}
          {event.event_description && (
            <div className="bg-[var(--surface-2)] rounded-xl p-4 border-none">
              <h4 className="text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-2">Championship Overview</h4>
              <p className="text-sm text-[var(--text)] leading-relaxed">{event.event_description}</p>
            </div>
          )}

          {/* Logistics strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-xl bg-[var(--surface-2)] p-3 text-center border-none">
              <p className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-wider">Participants</p>
              <p className="text-sm font-bold text-[var(--text)] mt-0.5">
                {event.expected_participants ? `${event.expected_participants.toLocaleString()}+` : "TBA"}
              </p>
            </div>
            <div className="rounded-xl bg-[var(--surface-2)] p-3 text-center border-none">
              <p className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-wider">Eligibility</p>
              <p className="text-sm font-bold text-[var(--text)] mt-0.5">{event.age_category || "Open"}</p>
            </div>
            <div className="rounded-xl bg-[var(--surface-2)] p-3 text-center border-none">
              <p className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-wider">Gender</p>
              <p className="text-sm font-bold text-[var(--text)] mt-0.5">{event.gender_category || "Men & Women"}</p>
            </div>
            <div className="rounded-xl bg-[var(--surface-2)] p-3 text-center border-none">
              <p className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-wider">Entry Fee</p>
              <p className="text-sm font-bold text-[var(--text)] mt-0.5">{event.price_or_registration_fee || "Sanctioned Honors"}</p>
            </div>
          </div>

          {/* Telemetry & Source URLs */}
          <div className="bg-[var(--surface-2)] rounded-xl p-4 border-none space-y-3">
            <div className="flex items-center justify-between text-xs text-[var(--text-muted)]">
              <span className="font-semibold text-[var(--text-muted)]">Verified Research Sources</span>
              <span>Refreshed: {event.last_verified_at || "Recent Telemetry"}</span>
            </div>

            {sources.length > 0 ? (
              <div className="space-y-2">
                {sources.map((url, i) => (
                  <a
                    key={i}
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between gap-2 p-2.5 rounded-lg bg-[var(--surface)] hover:bg-[var(--surface-hover)] text-xs font-semibold text-orange-400 hover:text-orange-300 transition-colors border-none"
                  >
                    <span className="truncate">{url}</span>
                    <ExternalLink className="h-3.5 w-3.5 shrink-0" />
                  </a>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[var(--text-muted)]">
                Data collected via official federation circulars and verified government press releases.
              </p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
