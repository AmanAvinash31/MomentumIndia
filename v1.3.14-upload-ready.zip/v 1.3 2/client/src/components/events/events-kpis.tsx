import React from "react";
import { type EventsKPIs } from "./events-types";
import { Trophy, Calendar, MapPin, Activity, Flame, ShieldCheck } from "lucide-react";

interface KPIProps {
  kpis: EventsKPIs | null;
  loading?: boolean;
}

export function EventsKPIsSection({ kpis, loading }: KPIProps) {
  if (loading || !kpis) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 animate-pulse">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="h-24 rounded-xl bg-[var(--surface-2)] border-none" />
        ))}
      </div>
    );
  }

  const cards = [
    {
      label: "Total Events",
      value: kpis.totalUnique,
      sub: "Across 2026",
      icon: Calendar,
      color: "text-amber-400",
      bg: "bg-amber-500/10",
    },
    {
      label: "Confirmed & Verified",
      value: kpis.confirmed + kpis.crossVerified,
      sub: `${Math.round(((kpis.confirmed + kpis.crossVerified) / Math.max(1, kpis.totalUnique)) * 100)}% verified`,
      icon: ShieldCheck,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10",
    },
    {
      label: "Upcoming Fixtures",
      value: kpis.upcoming,
      sub: `${kpis.ongoing} currently live`,
      icon: Flame,
      color: "text-orange-400",
      bg: "bg-orange-500/10",
    },
    {
      label: "National & Intl",
      value: kpis.national + kpis.international,
      sub: `${kpis.international} international`,
      icon: Trophy,
      color: "text-blue-400",
      bg: "bg-blue-500/10",
    },
    {
      label: "Marathon & Endurance",
      value: kpis.marathonEndurance,
      sub: `${kpis.ultraTrail} ultra & trails`,
      icon: Activity,
      color: "text-cyan-400",
      bg: "bg-cyan-500/10",
    },
    {
      label: "Coverage Reach",
      value: `${kpis.statesRepresented} / 36`,
      sub: "All States & UTs",
      icon: MapPin,
      color: "text-purple-400",
      bg: "bg-purple-500/10",
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
      {cards.map((c) => {
        const Icon = c.icon;
        return (
          <div
            key={c.label}
            className="rounded-xl bg-[var(--surface-2)] p-3.5 sm:p-4 flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 shadow-sm border-none"
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)] truncate">
                {c.label}
              </span>
              <span className={`p-1.5 rounded-lg ${c.bg} ${c.color} shrink-0 border-none`}>
                <Icon className="h-4 w-4" />
              </span>
            </div>
            <div className="mt-2">
              <p className="font-display text-2xl sm:text-3xl font-extrabold text-[var(--text)] tracking-tight">
                {typeof c.value === "number" ? c.value.toLocaleString() : c.value}
              </p>
              <p className="text-[11px] text-[var(--text-muted)] mt-0.5 truncate">{c.sub}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
