import React, { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { type SportingEvent, CATEGORY_COLORS } from "./events-types";
import { Layers, RotateCcw } from "lucide-react";
import { formatEventDateBadge } from "./events-directory";

interface EventsMapProps {
  events: SportingEvent[];
  theme: string;
  onSelectEvent: (event: SportingEvent) => void;
  selectedEventId?: string;
}

export function EventsMap({ events, theme, onSelectEvent, selectedEventId }: EventsMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const tilesRef = useRef<L.TileLayer | null>(null);
  const [densityMode, setDensityMode] = useState<boolean>(false);

  // Initialize Map locked cleanly to India
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [22.5, 79.0],
      zoom: 4.8,
      minZoom: 4,
      maxZoom: 16,
      scrollWheelZoom: false,
      zoomControl: false,
      attributionControl: true,
    });

    L.control.zoom({ position: "topright" }).addTo(map);
    markersLayerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Update TileLayer: Use keyless Esri World Dark Gray Base (100% watermark-free, zero API key)
  useEffect(() => {
    if (!mapRef.current) return;

    if (tilesRef.current) {
      tilesRef.current.remove();
    }

    // Light mode gets the light-grey canvas so markers and labels stay
    // readable; the previous code always used the dark tiles, which washed
    // out in light mode. (theme here is the resolved theme.)
    const tileBase = theme === "dark" ? "World_Dark_Gray_Base" : "World_Light_Gray_Base";
    const tileUrl = `https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/${tileBase}/MapServer/tile/{z}/{y}/{x}`;

    tilesRef.current = L.tileLayer(tileUrl, {
      attribution:
        '&copy; <a href="https://www.esri.com/" target="_blank" rel="noopener noreferrer">Esri</a> &mdash; Esri, DeLorme, NAVTEQ',
      maxZoom: 16,
    }).addTo(mapRef.current);
  }, [theme]);

  // Update Markers & Tactical Clusters
  useEffect(() => {
    if (!markersLayerRef.current || !mapRef.current) return;
    markersLayerRef.current.clearLayers();

    if (densityMode) {
      // Density Mode: Tactical Glassmorphic Cluster Badges
      const cityMap: Record<
        string,
        { lat: number; lng: number; count: number; city: string; state: string; events: SportingEvent[] }
      > = {};

      for (const ev of events) {
        if (!ev.latitude || !ev.longitude) continue;
        const key = `${ev.city}_${ev.state_or_union_territory}`;
        if (!cityMap[key]) {
          cityMap[key] = {
            lat: ev.latitude,
            lng: ev.longitude,
            count: 0,
            city: ev.city,
            state: ev.state_or_union_territory,
            events: [],
          };
        }
        cityMap[key].count++;
        cityMap[key].events.push(ev);
      }

      for (const [, data] of Object.entries(cityMap)) {
        // Dark glassmorphic cluster badge: bg-[var(--surface)]/90 text-orange-400 font-bold shadow-lg border-none
        const clusterHtml = `
          <div style="
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px;
            border-radius: 9999px;
            background-color: rgba(13, 17, 26, 0.92);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            color: #fb923c;
            font-family: inherit;
            font-size: 11px;
            font-weight: 800;
            box-shadow: 0 8px 24px rgba(0,0,0,0.65), 0 0 10px rgba(251,146,60,0.25);
            border: none;
            cursor: pointer;
            white-space: nowrap;
            transform: translate(-50%, -50%);
          ">
            <span style="width: 7px; height: 7px; border-radius: 50%; background-color: #f97316; box-shadow: 0 0 8px #f97316; flex-shrink: 0;"></span>
            <span>${data.city}</span>
            <span style="background-color: rgba(249, 115, 22, 0.2); color: #fb923c; padding: 1px 6px; border-radius: 9999px; font-size: 10px; font-weight: 800;">
              ${data.count}
            </span>
          </div>
        `;

        const clusterIcon = L.divIcon({
          html: clusterHtml,
          className: "tactical-cluster-badge",
          iconSize: [0, 0],
          iconAnchor: [0, 0],
        });

        const marker = L.marker([data.lat, data.lng], { icon: clusterIcon });

        marker.bindPopup(`
          <div style="font-family: inherit; font-size: 13px; color: #f1f5f9; padding: 4px;">
            <div style="font-weight: 800; font-size: 15px; color: #ffffff; margin-bottom: 2px;">${data.city}</div>
            <div style="color: #94a3b8; font-size: 12px; margin-bottom: 8px;">${data.state}</div>
            <div style="font-weight: 700; color: #f97316; font-size: 12px; margin-bottom: 6px;">${data.count} Competitions in 2026</div>
            <ul style="margin: 6px 0 0 0; padding-left: 14px; font-size: 12px; color: #cbd5e1; space-y: 4px;">
              ${data.events.slice(0, 4).map(e => `<li><b>${e.event_name}</b> <span style="color: #94a3b8;">(${e.sport})</span></li>`).join("")}
              ${data.events.length > 4 ? `<li style="color: #f97316; font-weight: 600;">+ ${data.events.length - 4} more</li>` : ""}
            </ul>
          </div>
        `, { maxWidth: 320 });

        marker.addTo(markersLayerRef.current);
      }
    } else {
      // Tactical Glowing Sport Markers (7px–10px radius, weight: 0 / zero white border, colored by sport category with soft drop-shadow glow)
      for (const ev of events) {
        if (!ev.latitude || !ev.longitude) continue;

        const color = CATEGORY_COLORS[ev.sport_category] || CATEGORY_COLORS.Default;
        const isSelected = selectedEventId === ev.event_id;
        const radius = isSelected ? 10 : 8;
        const size = radius * 2;

        const iconHtml = `
          <div style="
            position: relative;
            width: ${size}px;
            height: ${size}px;
            background-color: ${color};
            border-radius: 50%;
            border: none;
            box-shadow: 0 0 12px ${color}, 0 0 4px ${color};
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          ">
            <span style="width: 4px; height: 4px; background-color: rgba(255,255,255,0.95); border-radius: 50%; display: block;"></span>
          </div>
        `;

        const customIcon = L.divIcon({
          html: iconHtml,
          className: "sport-tactical-marker",
          iconSize: [size, size],
          iconAnchor: [radius, radius],
        });

        const marker = L.marker([ev.latitude, ev.longitude], { icon: customIcon });
        const readableDates = formatEventDateBadge(ev.start_date, ev.end_date);

        // Escape event data before it reaches innerHTML: event names and
        // venues come from synced external data and must never be able to
        // inject markup (stored XSS via a crafted event name).
        const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
        const popupContent = document.createElement("div");
        popupContent.style.fontFamily = "inherit";
        popupContent.style.fontSize = "13px";
        popupContent.style.color = "#f1f5f9";
        popupContent.style.minWidth = "220px";

        popupContent.innerHTML = `
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px; margin-bottom: 6px;">
            <span style="font-size: 10px; font-weight: 800; text-transform: uppercase; background-color: ${color}; color: #FFFFFF; padding: 2px 7px; border-radius: 9999px; border: none;">
              ${esc(ev.sport)}
            </span>
            <span style="font-size: 10px; font-weight: 700; color: #4ade80; background: rgba(34, 197, 94, 0.15); padding: 2px 6px; border-radius: 4px; border: none;">
              ${esc(ev.verification_status)}
            </span>
          </div>
          <div style="font-weight: 800; font-size: 14px; line-height: 1.25; margin-bottom: 4px; color: #ffffff;">
            ${esc(ev.event_name)}
          </div>
          <div style="font-size: 11px; color: #94a3b8; margin-bottom: 4px;">
            📍 ${ev.venue ? `${esc(ev.venue)}, ` : ""}${esc(ev.city)}, ${esc(ev.state_or_union_territory)}
          </div>
          <div style="font-size: 11px; font-weight: 600; color: #cbd5e1; margin-bottom: 10px;">
            🗓️ ${readableDates} · ${esc(ev.competition_level)}
          </div>
        `;

        const btn = document.createElement("button");
        btn.textContent = "Inspect Full Intel";
        btn.style.width = "100%";
        btn.style.padding = "7px 12px";
        btn.style.fontSize = "12px";
        btn.style.fontWeight = "700";
        btn.style.color = "#FFFFFF";
        btn.style.backgroundColor = "#f97316";
        btn.style.border = "none";
        btn.style.borderRadius = "8px";
        btn.style.cursor = "pointer";
        btn.onclick = () => onSelectEvent(ev);

        popupContent.appendChild(btn);

        marker.bindPopup(popupContent, { maxWidth: 300 });
        marker.addTo(markersLayerRef.current);
      }
    }
  }, [events, densityMode, selectedEventId, onSelectEvent]);

  const handleResetView = () => {
    mapRef.current?.setView([22.5, 79.0], 4.8);
  };

  return (
    <div className="relative isolate z-0 overflow-hidden rounded-2xl bg-[var(--surface)] shadow-md border-none">
      {/* Map Control Pill Overlay */}
      <div className="absolute top-4 left-4 z-[500] flex flex-wrap items-center gap-2">
        <button
          onClick={() => setDensityMode((prev) => !prev)}
          className={`tap-target px-3.5 py-1.5 rounded-full text-xs font-bold shadow-md transition-all flex items-center gap-1.5 border-none ${
            densityMode
              ? "bg-orange-500 text-[var(--text)]"
              : "bg-[var(--surface)]/90 backdrop-blur-md text-[var(--text)] hover:bg-[var(--surface-2)]"
          }`}
          title="Toggle City Density Heatmap"
        >
          <Layers className="h-3.5 w-3.5" />
          <span>{densityMode ? "Tactical Density Active" : "Cluster Density View"}</span>
        </button>

        <button
          onClick={handleResetView}
          className="tap-target px-3 py-1.5 rounded-full text-xs font-semibold bg-[var(--surface)]/90 backdrop-blur-md text-[var(--text)] hover:bg-[var(--surface-2)] shadow-md flex items-center gap-1.5 border-none"
          title="Center on National Map"
        >
          <RotateCcw className="h-3 w-3" />
          <span>Reset India View</span>
        </button>
      </div>

      {/* Legend Badge Bar */}
      <div className="absolute bottom-4 left-4 right-4 z-[500] hidden sm:flex flex-wrap items-center gap-3 bg-[var(--surface)]/90 backdrop-blur-md px-3.5 py-2 rounded-xl text-[11px] font-semibold text-[var(--text-muted)] shadow-md border-none">
        <span className="text-[var(--text)] font-bold">Categories:</span>
        <span className="inline-flex items-center gap-1">
          <span className="h-2 w-2 rounded-full bg-amber-500 shadow-[0_0_6px_#f59e0b]" /> Olympic
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="h-2 w-2 rounded-full bg-cyan-500 shadow-[0_0_6px_#06b6d4]" /> Marathons
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="h-2 w-2 rounded-full bg-red-500 shadow-[0_0_6px_#ef4444]" /> HYROX
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="h-2 w-2 rounded-full bg-purple-500 shadow-[0_0_6px_#a855f7]" /> Chess
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_6px_#10b981]" /> Para
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="h-2 w-2 rounded-full bg-green-500 shadow-[0_0_6px_#22c55e]" /> Leagues
        </span>
      </div>

      {/* Map Container Element */}
      <div
        ref={containerRef}
        className="h-[460px] sm:h-[540px] md:h-[620px] w-full bg-[var(--bg)]"
        role="region"
        aria-label="National Map of Indian Sporting Events 2026"
      />
    </div>
  );
}
