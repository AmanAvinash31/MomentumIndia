import React, { useState } from "react";
import { type StateSummary, type SportingEvent } from "./events-types";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { MapPin, Trophy, ShieldCheck, CheckCircle2, Award, Calendar } from "lucide-react";

interface StateExplorerProps {
  states: StateSummary[];
  onSelectState?: (state: string) => void;
  onSelectEvent?: (event: SportingEvent) => void;
}

export function EventsStateExplorer({ states, onSelectState }: StateExplorerProps) {
  const [selectedStateName, setSelectedStateName] = useState<string>(states[0]?.state || "Maharashtra");

  const currentState = states.find((s) => s.state === selectedStateName) || states[0];

  const monthLabels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const monthlyChartData = currentState
    ? currentState.monthly.map((count, idx) => ({
        month: monthLabels[idx],
        events: count,
      }))
    : [];

  const sportsChartData = currentState
    ? Object.entries(currentState.sports)
        .map(([sport, count]) => ({ sport, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 6)
    : [];

  return (
    <div className="rounded-2xl bg-[var(--surface)] p-4 sm:p-6 shadow-sm border-none space-y-6">
      {/* State Selection Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-none">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-orange-400">
            36 States & Union Territories
          </span>
          <h3 className="font-display text-xl sm:text-2xl font-extrabold text-[var(--text)] mt-0.5">
            Regional Sports Intelligence Explorer
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <label htmlFor="state-select" className="text-xs font-bold text-[var(--text-muted)] shrink-0">
            Select State/UT:
          </label>
          <select
            id="state-select"
            value={selectedStateName}
            onChange={(e) => {
              setSelectedStateName(e.target.value);
              onSelectState?.(e.target.value);
            }}
            className="tap-target px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] text-[var(--text)] text-xs font-bold border-none outline-none focus:ring-0 cursor-pointer max-w-[220px]"
          >
            {states.map((s) => (
              <option key={s.state} value={s.state} className="bg-[var(--surface)] text-[var(--text)]">
                {s.state} ({s.count} events)
              </option>
            ))}
          </select>
        </div>
      </div>

      {currentState && (
        <div className="space-y-6">
          {/* Key State Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-xl bg-[var(--surface-2)] p-4 border-none">
              <span className="text-[11px] font-bold text-[var(--text-muted)] uppercase tracking-wider block">
                Total Events
              </span>
              <p className="font-display text-2xl font-extrabold text-[var(--text)] mt-1">
                {currentState.count}
              </p>
              <span className="text-[10px] text-[var(--text-muted)]">In 2026 Calendar</span>
            </div>

            <div className="rounded-xl bg-[var(--surface-2)] p-4 border-none">
              <span className="text-[11px] font-bold text-[var(--text-muted)] uppercase tracking-wider block">
                Coverage Metric
              </span>
              <p className="font-display text-2xl font-extrabold text-emerald-400 mt-1">
                {currentState.completeness}%
              </p>
              <span className="text-[10px] text-[var(--text-muted)] flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3 text-emerald-400" /> Research Verified
              </span>
            </div>

            <div className="rounded-xl bg-[var(--surface-2)] p-4 border-none">
              <span className="text-[11px] font-bold text-[var(--text-muted)] uppercase tracking-wider block">
                Key Host Cities
              </span>
              <p className="font-display text-base font-bold text-[var(--text)] mt-1 truncate">
                {currentState.cities.slice(0, 2).join(", ") || "Statewide"}
              </p>
              <span className="text-[10px] text-[var(--text-muted)]">{currentState.cities.length} verified cities</span>
            </div>

            <div className="rounded-xl bg-[var(--surface-2)] p-4 border-none">
              <span className="text-[11px] font-bold text-[var(--text-muted)] uppercase tracking-wider block">
                Top Discipline
              </span>
              <p className="font-display text-base font-bold text-orange-400 mt-1 truncate">
                {sportsChartData[0]?.sport || "Multi-Discipline"}
              </p>
              <span className="text-[10px] text-[var(--text-muted)]">
                {sportsChartData[0]?.count || currentState.count} competitions
              </span>
            </div>
          </div>

          {/* Visual Analytics Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Monthly Distribution Chart */}
            <div className="rounded-xl bg-[var(--surface-2)] p-4 border-none">
              <h4 className="font-display text-sm font-bold text-[var(--text)] mb-3 flex items-center gap-2">
                <Calendar className="h-4 w-4 text-orange-400" />
                <span>Monthly Event Distribution in {currentState.state}</span>
              </h4>
              <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <XAxis
                      dataKey="month"
                      stroke="hsl(var(--border))"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      stroke="hsl(var(--border))"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                      allowDecimals={false}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#0d111a",
                        border: "none",
                        borderRadius: "10px",
                        fontSize: "12px",
                        color: "#fff",
                        boxShadow: "0 8px 24px rgba(0,0,0,0.6)",
                      }}
                    />
                    <Bar dataKey="events" fill="#f97316" radius={[6, 6, 0, 0]}>
                      {monthlyChartData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.events > 0 ? "#f97316" : "rgba(255,255,255,0.05)"}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Top Sports Disciplines in State */}
            <div className="rounded-xl bg-[var(--surface-2)] p-4 border-none">
              <h4 className="font-display text-sm font-bold text-[var(--text)] mb-3 flex items-center gap-2">
                <Trophy className="h-4 w-4 text-orange-400" />
                <span>Leading Sports Hosted in {currentState.state}</span>
              </h4>
              <div className="space-y-2.5">
                {sportsChartData.map((s, idx) => {
                  const pct = Math.round((s.count / Math.max(1, currentState.count)) * 100);
                  return (
                    <div key={s.sport} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-semibold">
                        <span className="text-[var(--text)]">{s.sport}</span>
                        <span className="text-orange-400 font-mono font-bold">
                          {s.count} ({pct}%)
                        </span>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-white/[0.05] overflow-hidden border-none">
                        <div
                          className="h-full bg-orange-500 rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
