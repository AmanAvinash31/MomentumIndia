import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import {
  Home,
  Radio,
  Newspaper,
  Search,
  Menu,
  X,
  Trophy,
  Medal,
  Users,
  CalendarDays,
  Tv,
  Flame,
  Award,
  Sparkles,
  Gamepad2,
  HelpCircle,
  Info,
  ChevronDown,
  ChevronRight,
  Target,
  Landmark,
  Compass,
  HeartHandshake,
  Accessibility,
  BookOpen,
  Bell,
  Dumbbell,
  BarChart3,
  Footprints,
  Crown,
  Globe2,
  MapPin,
  Star,
  Sprout,
  type LucideIcon
} from "lucide-react";
import { cn } from "@/lib/utils";
import { ThemeToggle } from "./theme-toggle";
import { LiteToggle } from "./site";

interface MobileNavProps {
  onSearchOpen: () => void;
}

interface NavDestination {
  href: string;
  title: string;
  desc: string;
  icon: LucideIcon;
}

const TOP_8_DESTINATIONS: NavDestination[] = [
  { href: "/events", title: "Events 2026", desc: "Interactive map & 36 States/UTs calendar", icon: CalendarDays },
  { href: "/match-centre", title: "Match Centre", desc: "All 26 sports scores and reports", icon: Radio },
  { href: "/leagues", title: "Domestic Leagues", desc: "ISL, Pro Kabaddi and HIL", icon: Trophy },
  { href: "/schedule", title: "Schedule", desc: "Fixtures and countdowns in IST", icon: CalendarDays },
  { href: "/watch", title: "Where to Watch", desc: "Channels, apps and stream guide", icon: Tv },
  { href: "/games/asian-para-games-2026", title: "Asian Para Games", desc: "Live hub · Aichi-Nagoya 2026", icon: Accessibility },
  { href: "/games/asian-games-2026", title: "Asian Games 2026", desc: "Aichi-Nagoya roadmap and guide", icon: Flame },
  { href: "/games/glasgow-2026", title: "Glasgow 2026", desc: "Commonwealth Games results", icon: Crown },
  { href: "/road-to-la-2028", title: "Road to LA 2028", desc: "Olympic Games watchlist", icon: Target },
];

// Same groups as the starting zip: Athletes & Stories ->
// Grassroots & Next Gen -> Community & About.
const ACCORDION_GROUPS: { name: string; icon: LucideIcon; items: NavDestination[] }[] = [
  {
    name: "Athletes & Stories",
    icon: Medal,
    items: [
      { href: "/athletes", title: "India's Medallists", desc: "Podium finishers across major Games", icon: Medal },
      { href: "/stories", title: "Where Champions Began", desc: "Sourced origin stories of greats", icon: BookOpen },
      { href: "/my-momentum", title: "My Momentum", desc: "Follow athlete stars and alerts", icon: Bell },
      { href: "/sports", title: "Sports Directory", desc: "Every discipline India competes in", icon: Dumbbell },
      { href: "/states", title: "State Leaderboards", desc: "National Games and Khelo India rank", icon: BarChart3 },
      { href: "/pathway", title: "Pathway for Parents", desc: "Find my sport quiz, grants and safety", icon: Footprints },
    ]
  },
  {
    name: "Grassroots & Next Gen",
    icon: HeartHandshake,
    items: [
      { href: "/sporting-nation", title: "Build a Sporting Nation", desc: "Local stars, fixtures and sponsors", icon: HeartHandshake },
      { href: "/facilities", title: "Facilities by State", desc: "SAI centres and Khelo academies", icon: MapPin },
      { href: "/clubs", title: "Clubs and Coaches", desc: "Verified local coaching directory", icon: Users },
      { href: "/para", title: "Para Sport Hub", desc: "Classes explained and how to start", icon: Accessibility },
      { href: "/women", title: "Women in Sport", desc: "Medals, safe sport and milestones", icon: Star },
      { href: "/adopt-a-ground", title: "Adopt a Ground", desc: "Support local sports grounds", icon: Sprout },
    ]
  },
  {
    name: "Community & About",
    icon: Gamepad2,
    items: [
      { href: "/fan-zone", title: "Fan Zone & Predictions", desc: "Predictions, medal quiz and trivia", icon: Gamepad2 },
      { href: "/golden-moments", title: "Golden Moments", desc: "Greatest podium milestones in sport", icon: Sparkles },
      { href: "/nations", title: "Nations Comparison", desc: "How India stacks up against peers", icon: Globe2 },
      { href: "/medals", title: "All-Time Medal Overview", desc: "Edition breakdowns across 3 Games", icon: BarChart3 },
      { href: "/about", title: "About Momentum", desc: "Sources, methodology and mission", icon: Info },
      { href: "/faq", title: "FAQ", desc: "Quick answers about sports data", icon: HelpCircle },
    ]
  }
];

export function MobileTabBar({ onSearchOpen }: MobileNavProps) {
  const [loc] = useLocation();
  const [moreOpen, setMoreOpen] = useState(false);
  const [openAccordions, setOpenAccordions] = useState<Record<string, boolean>>({
    "Athletes & Stories": false,
    "Grassroots & Next Gen": false,
    "Community & About": false
  });

  useEffect(() => {
    setMoreOpen(false);
  }, [loc]);

  const toggleAccordion = (name: string) => {
    setOpenAccordions(prev => ({ ...prev, [name]: !prev[name] }));
  };

  const isActive = (path: string) => {
    if (path === "/") return loc === "/";
    return loc === path || loc.startsWith(path + "/");
  };

  return (
    <>
      {/* Sticky Bottom Tab Bar (56px + safe-area): Home, Results, News, Search, More */}
      <nav
        aria-label="Mobile Bottom Navigation"
        className="fixed bottom-0 inset-x-0 z-40 lg:hidden bg-[var(--surface)] text-[var(--text)] backdrop-blur-xl shadow-lg"
        style={{ paddingBottom: "max(env(safe-area-inset-bottom, 0px), 6px)" }}
      >
        <div className="grid grid-cols-5 h-14 items-center px-1">
          {/* 1. Home */}
          <Link
            href="/"
            data-testid="tab-home"
            className={cn(
              "tap-target flex flex-col items-center justify-center gap-1 rounded-xl py-1 transition-colors text-xs font-semibold",
              isActive("/") && !moreOpen ? "text-[var(--accent)]" : "text-[var(--text-muted)] hover:text-[var(--text)]"
            )}
          >
            <Home className="h-5 w-5 shrink-0" strokeWidth={1.75} />
            <span className="text-[11px] leading-none">Home</span>
          </Link>

          {/* 2. Results */}
          <Link
            href="/match-centre"
            data-testid="tab-results"
            className={cn(
              "tap-target flex flex-col items-center justify-center gap-1 rounded-xl py-1 transition-colors text-xs font-semibold relative",
              isActive("/match-centre") && !moreOpen ? "text-[var(--accent)]" : "text-[var(--text-muted)] hover:text-[var(--text)]"
            )}
          >
            <div className="relative">
              <Radio className="h-5 w-5 shrink-0" strokeWidth={1.75} />
              <span className="absolute -top-1 -right-1 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            </div>
            <span className="text-[11px] leading-none">Results</span>
          </Link>

          {/* 3. News */}
          <Link
            href="/news"
            data-testid="tab-news"
            className={cn(
              "tap-target flex flex-col items-center justify-center gap-1 rounded-xl py-1 transition-colors text-xs font-semibold",
              isActive("/news") && !moreOpen ? "text-[var(--accent)]" : "text-[var(--text-muted)] hover:text-[var(--text)]"
            )}
          >
            <Newspaper className="h-5 w-5 shrink-0" strokeWidth={1.75} />
            <span className="text-[11px] leading-none">News</span>
          </Link>

          {/* 4. Search */}
          <button
            onClick={onSearchOpen}
            data-testid="tab-search"
            aria-label="Open search"
            className="tap-target flex flex-col items-center justify-center gap-1 rounded-xl py-1 text-[var(--text-muted)] hover:text-[var(--text)] transition-colors"
          >
            <Search className="h-5 w-5 shrink-0" strokeWidth={1.75} />
            <span className="text-[11px] leading-none font-semibold">Search</span>
          </button>

          {/* 5. More */}
          <button
            onClick={() => setMoreOpen(!moreOpen)}
            data-testid="tab-more"
            aria-label="Open more menu"
            aria-expanded={moreOpen}
            className={cn(
              "tap-target flex flex-col items-center justify-center gap-1 rounded-xl py-1 transition-colors text-xs font-semibold",
              moreOpen ? "text-[var(--accent)]" : "text-[var(--text-muted)] hover:text-[var(--text)]"
            )}
          >
            <Menu className="h-5 w-5 shrink-0" strokeWidth={1.75} />
            <span className="text-[11px] leading-none">More</span>
          </button>
        </div>
      </nav>

      {/* "More" Bottom Sheet Dialog */}
      {moreOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="More navigation items"
          className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm lg:hidden animate-in fade-in duration-200"
        >
          <div
            className="w-full max-h-[88vh] flex flex-col rounded-t-[20px] bg-[var(--surface)] text-[var(--text)] shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-300"
            style={{ paddingBottom: "max(env(safe-area-inset-bottom, 0px), 16px)" }}
          >
            {/* Sheet Header */}
            <div className="flex items-center justify-between px-4 py-3.5 bg-black/[0.02] dark:bg-white/[0.02]">
              <div>
                <p className="font-display text-base font-bold text-[var(--text)]">More from Momentum India</p>
                <p className="text-xs text-[var(--text-muted)]">Every sport, athlete, and guide in 2 taps</p>
              </div>
              <div className="flex items-center gap-2">
                <ThemeToggle />
                <button
                  onClick={() => setMoreOpen(false)}
                  aria-label="Close menu"
                  className="tap-target grid h-9 w-9 place-items-center rounded-[10px] bg-[var(--surface-2)] text-[var(--text-muted)] hover:text-[var(--text)]"
                >
                  <X className="h-4 w-4" strokeWidth={1.75} />
                </button>
              </div>
            </div>

            {/* Search Box inside Sheet */}
            <div className="p-4">
              <button
                onClick={() => {
                  setMoreOpen(false);
                  onSearchOpen();
                }}
                className="w-full flex items-center gap-2.5 rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3.5 py-2.5 text-xs text-[var(--text-muted)] hover:border-primary/50 text-left transition"
              >
                <Search className="h-4 w-4 shrink-0 text-[var(--accent)]" strokeWidth={1.75} />
                <span className="flex-1">Search sports, athletes, medals...</span>
              </button>
            </div>

            {/* Sheet Scrollable Body */}
            <div className="flex-1 overflow-y-auto px-4 py-3 space-y-5">
              {/* Pinned most-used links, above the long directories */}
              <div className="flex flex-wrap gap-2">
                {[["/match-centre", "Match Centre"], ["/news", "News"], ["/medals", "Medals"], ["/schedule", "Schedule"]].map(([href, label]) => (
                  <Link key={href} href={href} onClick={() => setMoreOpen(false)} className="rounded-full bg-[var(--accent)] px-4 py-2 text-xs font-bold text-white">{label}</Link>
                ))}
              </div>
              {/* Top 8 Destinations (2-column grid, same icon-tile style) */}
              <div>
                <p className="mb-2 px-1 text-[11px] font-bold uppercase tracking-wider text-[var(--accent)]">
                  Top Destinations
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {TOP_8_DESTINATIONS.map(d => {
                    const Ic = d.icon;
                    const on = loc === d.href || loc.startsWith(d.href + "/");
                    return (
                      <Link
                        key={d.href}
                        href={d.href}
                        onClick={() => setMoreOpen(false)}
                        className={cn(
                          "flex flex-col justify-between rounded-[10px] p-2.5 transition-colors border min-h-[72px]",
                          on
                            ? "border-[var(--accent)] bg-[var(--surface-2)]"
                            : "border-[var(--border)] bg-[var(--surface-2)] hover:border-primary/40"
                        )}
                      >
                        <div className="flex items-center gap-2">
                          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-[8px] bg-[var(--surface)] text-[var(--accent)] border border-[var(--border)]">
                            <Ic className="h-4 w-4" strokeWidth={1.75} />
                          </span>
                          <span className="text-xs font-bold leading-tight text-[var(--text)] truncate">
                            {d.title}
                          </span>
                        </div>
                        <p className="text-[11px] text-[var(--text-muted)] leading-tight mt-1 line-clamp-1">
                          {d.desc}
                        </p>
                      </Link>
                    );
                  })}
                </div>
              </div>

              {/* Accordions for the rest */}
              <div className="space-y-2 pt-1">
                <p className="px-1 text-[11px] font-bold uppercase tracking-wider text-[var(--accent)]">
                  Directories & Guides
                </p>
                {ACCORDION_GROUPS.map(group => {
                  const isOpen = openAccordions[group.name];
                  const GroupIcon = group.icon;
                  return (
                    <div
                      key={group.name}
                      className="rounded-[10px] border border-[var(--border)] bg-[var(--surface)] overflow-hidden"
                    >
                      <button
                        onClick={() => toggleAccordion(group.name)}
                        className="w-full flex items-center justify-between p-3 text-left font-semibold text-xs text-[var(--text)] hover:bg-[var(--surface-2)] transition-colors"
                      >
                        <span className="flex items-center gap-2">
                          <GroupIcon className="h-4 w-4 text-[var(--accent)]" strokeWidth={1.75} />
                          <span>{group.name}</span>
                        </span>
                        <ChevronDown
                          className={cn(
                            "h-4 w-4 text-[var(--text-muted)] transition-transform duration-200",
                            isOpen && "rotate-180"
                          )}
                          strokeWidth={1.75}
                        />
                      </button>

                      {isOpen && (
                        <div className="border-t border-[var(--border)] p-2 space-y-1 bg-[var(--surface-2)]/40">
                          {group.items.map(item => {
                            const Ic = item.icon;
                            const on = loc === item.href || loc.startsWith(item.href + "/");
                            return (
                              <Link
                                key={item.href}
                                href={item.href}
                                onClick={() => setMoreOpen(false)}
                                className={cn(
                                  "group flex h-14 min-w-0 items-center gap-3 rounded-[10px] px-2.5 transition-colors hover:bg-[var(--surface-2)]",
                                  on && "bg-[var(--surface-2)] border border-[var(--border)]"
                                )}
                              >
                                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-[10px] bg-[var(--surface)] text-[var(--accent)] border border-[var(--border)]">
                                  <Ic className="h-[18px] w-[18px]" strokeWidth={1.75} />
                                </span>
                                <span className="min-w-0 flex-1">
                                  <span className="block text-sm font-semibold leading-tight text-[var(--text)] truncate">
                                    {item.title}
                                  </span>
                                  <span className="block text-xs leading-tight text-[var(--text-muted)] mt-0.5 truncate">
                                    {item.desc}
                                  </span>
                                </span>
                                <ChevronRight className="h-4 w-4 shrink-0 text-[var(--text-muted)]" strokeWidth={1.75} />
                              </Link>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Lite Mode Toggle */}
              <div className="pt-2 pb-1">
                <LiteToggle />
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
