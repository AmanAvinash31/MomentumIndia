import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { ChevronDown, ChevronUp, Sparkles, Accessibility, HeartHandshake, Sprout, Gamepad2, Tv, CalendarDays, BarChart3, Medal, Globe2, HelpCircle, Info, Dumbbell, Compass, MapPin, Building2, Flame, BookOpen, Star, Trophy, Users, School, Crown, Footprints, type LucideIcon, Menu, Moon, Search, Sun, ArrowRight, ArrowUpRight, Check, Loader2, Bell, Feather, Radio, Target, Award, Landmark } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { usePrefs } from "@/lib/prefs";
import { useQuery } from "@tanstack/react-query";
import { ARTICLES, PEOPLE, TICKER, UPDATED, IMG, fmtDate, type MedalCode, OLY, CWG, ASIAN, sumEditions, total } from "@/data";
import { apiRequest } from "@/lib/queryClient";
import { ThemeToggle3Way } from "./theme-toggle";
import { cn } from "@/lib/utils";

/* ---------------- primitives ---------------- */
export const Container = ({ className, children }: { className?: string; children: ReactNode }) => (
  <div className={cn("mx-auto w-full max-w-[1320px] px-4 sm:px-6 lg:px-10", className)}>{children}</div>
);

export function Logo({ className, animated = true }: { className?: string; animated?: boolean }) {
  const id = useId().replace(/:/g, "");
  const spokes = Array.from({ length: 24 }, (_, i) => i * 15);
  return (
    <svg viewBox="0 0 40 40" className={cn("mi-logo overflow-visible", animated && "mi-logo--anim", className)} aria-hidden="true" fill="none">
      <defs>
        <linearGradient id={`tri-${id}`} x1="0" y1="0" x2="40" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#FF9933" /><stop offset=".36" stopColor="#FF9933" />
          <stop offset=".36" stopColor="#F7F7F2" /><stop offset=".64" stopColor="#F7F7F2" />
          <stop offset=".64" stopColor="#1DB954" /><stop offset="1" stopColor="#138808" />
        </linearGradient>
        <linearGradient id={`glint-${id}`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#fff" stopOpacity="0" /><stop offset=".5" stopColor="#fff" stopOpacity=".9" /><stop offset="1" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
        <clipPath id={`clip-${id}`}><rect x="1" y="1" width="38" height="38" rx="9" /></clipPath>
      </defs>
      <rect x="1" y="1" width="38" height="38" rx="9" fill="hsl(var(--ink))" />
      <rect x="1.5" y="1.5" width="37" height="37" rx="8.5" stroke="hsl(var(--paper) / .14)" />
      <g clipPath={`url(#clip-${id})`}>
        <rect className="mi-logo-glint" x="-20" y="-4" width="14" height="48" fill={`url(#glint-${id})`} opacity=".22" transform="skewX(-18)" />
      </g>
      <path className="mi-logo-pulse" pathLength={100} d="M5 23h7l3.5-11 6 17 3.5-10 2.5 4H30" stroke={`url(#tri-${id})`} strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round" />
      <g className="mi-logo-chakra">
        <circle cx="33.5" cy="23" r="4.2" fill="#F7F7F2" />
        <circle cx="33.5" cy="23" r="3.5" stroke="#0A2A8C" strokeWidth=".7" />
        {spokes.map(a => <line key={a} x1="33.5" y1="23" x2={33.5 + 3.3 * Math.cos((a * Math.PI) / 180)} y2={23 + 3.3 * Math.sin((a * Math.PI) / 180)} stroke="#0A2A8C" strokeWidth=".32" />)}
        <circle cx="33.5" cy="23" r=".9" fill="#0A2A8C" />
      </g>
    </svg>
  );
}

export const TAGLINE = "Celebrating the rise of a sporting nation";

export function Wordmark({ tagline = true, dark, className }: { tagline?: boolean; dark?: boolean; className?: string }) {
  return (
    <span className={cn("flex flex-col justify-center leading-none", className)}>
      <span className="font-display text-[1.15rem] font-semibold leading-none tracking-tight">Momentum <span className={dark ? "text-saffron" : "text-primary"}>India</span></span>
      {tagline && <span className={cn("mi-tagline mt-1 text-[0.62rem] font-bold uppercase tracking-[0.12em]", dark ? "text-paper/65" : "text-muted-foreground")}>{TAGLINE}</span>}
    </span>
  );
}

export function Kicker({ children, className, color }: { children: ReactNode; className?: string; color?: string }) {
  return (
    <span className={cn("mi-eyebrow inline-flex items-center gap-2 font-mono text-[0.72rem] font-semibold uppercase tracking-[0.18em]", className)} style={color ? { color } : undefined}>
      <Sparkles className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
      {children}
    </span>
  );
}

const slug = (n: ReactNode) => typeof n === "string" ? n.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) : undefined;

export function SectionHead({ kicker, title, action, className, dek }: { kicker?: string; title: ReactNode; action?: ReactNode; className?: string; dek?: ReactNode }) {
  const id = slug(title);
  return (
    <div id={id ? `s-${id}` : undefined} className={cn("mi-section-head mb-7 scroll-mt-36 md:mb-10", className)}>
      <div className="mi-sh-grid grid gap-4">
      <div className="min-w-0">
        {kicker && <Kicker className="mb-3 text-gold-ink">{kicker}</Kicker>}
        <h2 className="text-balance font-display text-[clamp(1.7rem,1.1rem+2vw,2.9rem)] font-bold leading-[1.02] text-foreground">{title}</h2>
      </div>
      {(dek || action) && <div className="mi-sh-side flex flex-col items-start gap-3">
        {dek && <p className="max-w-xl text-pretty text-muted-foreground">{dek}</p>}
        {action}
      </div>}
      </div>
    </div>
  );
}

export function ScrollButtons() {
  const [y, setY] = useState(0);
  const [scrollingDown, setScrollingDown] = useState(false);
  const prevY = useRef(0);

  useEffect(() => {
    const on = () => {
      const currentY = window.scrollY;
      setScrollingDown(currentY > prevY.current && currentY > 600);
      prevY.current = currentY;
      setY(currentY);
    };
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  if (y < 600 || scrollingDown) return null;

  return (
    <div className="fixed bottom-20 md:bottom-6 right-4 z-40">
      <button
        data-testid="button-scroll-top"
        aria-label="Back to top"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className="mi-fab grid h-10 w-10 place-items-center rounded-full shadow-lg transition-transform hover:scale-105 active:scale-95"
      >
        <ChevronUp className="h-5 w-5" />
      </button>
    </div>
  );
}

export const MoreLink = ({ href, children, testid }: { href: string; children: ReactNode; testid?: string }) => (
  <Link href={href} data-testid={testid} className="group inline-flex items-center gap-1.5 text-sm font-bold text-foreground hover:text-primary">
    {children}<ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
  </Link>
);

export const MEDAL_CLS: Record<MedalCode, string> = { G: "bg-gold", S: "bg-silver", B: "bg-bronze" };
export const MedalDot = ({ m, className }: { m: MedalCode; className?: string }) => (
  <span role="img" className={cn("inline-block h-3 w-3 shrink-0 rounded-full ring-2 ring-background", MEDAL_CLS[m], className)} aria-label={{ G: "Gold", S: "Silver", B: "Bronze" }[m]} />
);

export function MedalTriplet({ g, s, b, size = "md", className }: { g: number; s: number; b: number; size?: "sm" | "md" | "lg"; className?: string }) {
  const num = size === "lg" ? "text-3xl md:text-4xl" : size === "md" ? "text-xl" : "text-base";
  return (
    <div className={cn("flex items-center gap-4 tnum", className)}>
      {([["G", g], ["S", s], ["B", b]] as [MedalCode, number][]).map(([m, v]) => (
        <span key={m} className="flex items-center gap-1.5"><MedalDot m={m} /><span className={cn("font-display font-semibold", num)}>{v}</span></span>
      ))}
    </div>
  );
}

export function StackBar({ g, s, b, max, className }: { g: number; s: number; b: number; max?: number; className?: string }) {
  const t = g + s + b; const m = max ?? t;
  return (
    <div className={cn("flex h-2.5 w-full overflow-hidden rounded-full bg-muted", className)} role="img" aria-label={`${g} gold, ${s} silver, ${b} bronze`}>
      {t > 0 && <><span className="bg-gold" style={{ width: `${(g / m) * 100}%` }} /><span className="bg-silver" style={{ width: `${(s / m) * 100}%` }} /><span className="bg-bronze" style={{ width: `${(b / m) * 100}%` }} /></>}
    </div>
  );
}

export function CountUp({ to, className }: { to: number; className?: string; duration?: number }) {
  // Render the final total immediately: animating up from 0 briefly showed a
  // wrong intermediate value next to its gold/silver/bronze breakdown, and to
  // screen readers. Totals are facts, not decoration.
  return <span className={cn("tnum", className)} aria-label={to.toLocaleString("en-IN")}>{to.toLocaleString("en-IN")}</span>;
}

export function Reveal({ children, className }: { children: ReactNode; className?: string; delay?: number }) {
  return <div className={className}>{children}</div>;
}

export function Img({
  src,
  srcSet,
  sizes,
  alt,
  className,
  eager,
  width = 800,
  height = 600,
  fallbackIcon: FallbackIcon = Trophy,
}: {
  src?: string | null;
  srcSet?: string;
  sizes?: string;
  alt: string;
  className?: string;
  eager?: boolean;
  width?: number;
  height?: number;
  fallbackIcon?: LucideIcon;
}) {
  const { lite } = usePrefs();
  const [error, setError] = useState(!src);
  const cleanSrc = src ? (src.startsWith("./") ? src.slice(1) : src) : "";

  if (lite) return <div role={alt ? "img" : undefined} aria-label={alt || undefined} className={cn("lite-ph h-full w-full", className)} />;

  // Responsive WebP variants for the two largest photos. The original JPG
  // stays as src (fallback + Open Graph), but browsers that support srcSet
  // download the 800w/1200w WebP instead of the 7-8 MB original. An explicit
  // srcSet prop always wins over this map.
  const RESPONSIVE_SRCSET: Record<string, string> = {
    "/img/real-nagoya-stadium.jpg": "/img/real-nagoya-stadium-800.webp 800w, /img/real-nagoya-stadium-1200.webp 1200w",
    "/img/real-relay-action.jpg": "/img/real-relay-action-800.webp 800w, /img/real-relay-action-1200.webp 1200w",
  };
  const effectiveSrcSet = srcSet ?? RESPONSIVE_SRCSET[cleanSrc];
  const effectiveSizes = sizes ?? (effectiveSrcSet ? "(max-width: 768px) 800px, 1200px" : undefined);

  if (error || !cleanSrc) {
    return (
      <div
        role="img"
        aria-label={alt || "Sport illustration"}
        className={cn(
          "relative flex h-full w-full items-center justify-center overflow-hidden bg-[var(--surface-2)] border border-[var(--border)]",
          className
        )}
        style={{
          background: "linear-gradient(135deg, var(--surface-2) 0%, var(--surface) 100%)",
        }}
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(255,138,43,0.12),transparent_70%)] pointer-events-none" />
        <FallbackIcon className="h-8 w-8 text-[var(--accent)] opacity-70" strokeWidth={1.5} />
      </div>
    );
  }

  return (
    <img
      src={cleanSrc}
      srcSet={effectiveSrcSet}
      sizes={effectiveSizes}
      alt={alt}
      width={width}
      height={height}
      loading={eager ? "eager" : "lazy"}
      decoding="async"
      onError={() => setError(true)}
      className={cn("h-full w-full object-cover", className)}
    />
  );
}

export function useCountdown(at: string | null) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { if (!at) return; const id = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id); }, [at]);
  if (!at) return null;
  const ms = Math.max(0, new Date(at).getTime() - now);
  return { d: Math.floor(ms / 864e5), h: Math.floor(ms / 36e5) % 24, m: Math.floor(ms / 6e4) % 60, s: Math.floor(ms / 1e3) % 60, done: ms === 0 };
}

/* ---------------- navigation ---------------- */
type NavLink = { label: string; href: string; desc?: string; img?: string; icon?: LucideIcon; group?: string };
type NavFeature = { kicker: string; title: string; desc: string; href: string; img: string; cta: string };
const NAV: { key: string; href?: string; items?: NavLink[]; feature?: NavFeature }[] = [
  { key: "games", items: [
    { group: "Live & Leagues", label: "Events 2026 Intelligence", href: "/events", desc: "National map, 2026 calendar & 36 States/UTs intelligence", icon: CalendarDays },
    { group: "Live & Leagues", label: "Match Centre & Day Ledger", href: "/match-centre", desc: "All 26 sports match scorecards & dispatches", icon: Radio },
    { group: "Live & Leagues", label: "Domestic Leagues", href: "/leagues", desc: "ISL, Pro Kabaddi & Hockey India League", icon: Trophy },
    { group: "Live & Leagues", label: "Schedule & Countdowns", href: "/schedule", desc: "Every Games & league fixture in IST", icon: CalendarDays },
    { group: "Live & Leagues", label: "Where to watch", href: "/watch", desc: "Channels, apps and live broadcast guide", icon: Tv },
    { group: "Major Games", label: "Asian Para Games 2026", href: "/games/asian-para-games-2026", desc: "Live hub · 18 to 24 October", icon: Accessibility },
    { group: "Major Games", label: "Asian Games 2026", href: "/games/asian-games-2026", desc: "Aichi-Nagoya, Japan · 19 Sep to 4 Oct 2026", icon: Flame },
    { group: "Major Games", label: "Glasgow 2026", href: "/games/glasgow-2026", desc: "Commonwealth Games · 23 Jul – 2 Aug 2026", icon: Crown },
    { group: "Major Games", label: "Road to LA 2028", href: "/road-to-la-2028", desc: "Olympic Games · 14 to 30 July 2028", icon: Target },
    { group: "Major Games", label: "Ahmedabad 2030", href: "/games/ahmedabad-2030", desc: "India hosts the Centenary Games", icon: Landmark },
  ] },
  { key: "athletes", items: [
    { group: "Medallists & Stories", label: "India's Medallists", href: "/athletes", desc: "Every Indian podium finisher across Games", icon: Medal },
    { group: "Medallists & Stories", label: "Where champions began", href: "/stories", desc: "Seven sourced origin stories of Indian greats", icon: BookOpen },
    { group: "Medallists & Stories", label: "My Momentum", href: "/my-momentum", desc: "Follow athletes, set custom alerts", icon: Bell },
    { group: "Sports & Standings", label: "Sports Directory", href: "/sports", desc: "Every discipline India competes in", icon: Dumbbell },
    { group: "Sports & Standings", label: "State leaderboards", href: "/states", desc: "National Games & Khelo India rankings", icon: BarChart3 },
    { group: "Sports & Standings", label: "Pathway for parents", href: "/pathway", desc: "Find my sport quiz, schemes, safety", icon: Footprints },
  ] },
  { key: "news", href: "/news" },
  { key: "explore", items: [
    { group: "Medal History & Legends", label: "All-time overview", href: "/medals", desc: "Edition breakdowns across 3 Games", icon: BarChart3 },
    { group: "Medal History & Legends", label: "Olympic Games", href: "/medals/olympics", desc: "41 medals from Norman Pritchard on", icon: Medal },
    { group: "Medal History & Legends", label: "Asian Games", href: "/medals/asian-games", desc: "The last five editions in depth", icon: Trophy },
    { group: "Medal History & Legends", label: "Commonwealth Games", href: "/medals/commonwealth", desc: "563 medals, 4th on all-time table", icon: Crown },
    { group: "Medal History & Legends", label: "Hall of Fame", href: "/hall-of-fame", desc: "India's greatest individual legends", icon: Award },
    { group: "Next Gen & Grassroots", label: "Build a sporting nation", href: "/sporting-nation", desc: "Local stars, fixtures and sponsors", icon: HeartHandshake },
    { group: "Next Gen & Grassroots", label: "Pathway and parents", href: "/pathway", desc: "Find my sport quiz and safety guide", icon: Footprints },
    { group: "Next Gen & Grassroots", label: "Clubs and coaches", href: "/clubs", desc: "Verified local coaching directory", icon: Users },
    { group: "Next Gen & Grassroots", label: "Facilities by state", href: "/facilities", desc: "SAI centres and Khelo academies", icon: MapPin },
    { group: "Next Gen & Grassroots", label: "Para sport hub", href: "/para", desc: "Classes explained and how to start", icon: Accessibility },
    { group: "Next Gen & Grassroots", label: "Women in sport", href: "/women", desc: "Medals, safe sport and milestones", icon: Star },
    { group: "Community & About", label: "Fan Zone & Predictions", href: "/fan-zone", desc: "Predictions, medal quiz and trivia", icon: Gamepad2 },
    { group: "Community & About", label: "Golden moments", href: "/golden-moments", desc: "Greatest podium milestones in sport", icon: Sparkles },
    { group: "Community & About", label: "Nations comparison", href: "/nations", desc: "How India stacks up against peers", icon: Globe2 },
    { group: "Community & About", label: "Sports Desk Q&A", href: "/match-centre", desc: "Verified match data and records", icon: Radio },
    { group: "Community & About", label: "About Momentum", href: "/about", desc: "Sources, methodology and mission", icon: Info },
  ] },
];

function useActive() {
  const [loc] = useLocation();
  return (href: string) => (href === "/" ? loc === "/" : loc === href || loc.startsWith(href + "/"));
}

export function LangSwitch(_props?: { compact?: boolean }) {
  return null;
}

export function ThemeToggle({ compact, className }: { compact?: boolean; className?: string }) {
  return <ThemeToggle3Way compact={compact} className={className} />;
}

export function Ticker() {
  const { data: status } = useQuery<{ updated_at: string | null }>({
    queryKey: ["/api/site-status"],
    queryFn: async () => { const res = await apiRequest("GET", "/api/site-status"); return res.json(); },
    staleTime: 60000,
  });
  const items = [...TICKER, ...TICKER];
  return (
    <div className="bg-ink text-paper" aria-label="Latest results">
      <Container className="flex h-9 items-center gap-4 text-[0.8rem]">
        <span className="flex shrink-0 items-center gap-2 font-bold uppercase tracking-[0.14em] text-saffron">
          <span className="relative flex h-2 w-2"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-saffron opacity-60 motion-reduce:hidden" /><span className="relative inline-flex h-2 w-2 rounded-full bg-saffron" /></span>
          Results
        </span>
        <div className="relative min-w-0 flex-1 overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_4%,#000_96%,transparent)]">
          <div className="ticker-track flex w-max animate-marquee gap-10 whitespace-nowrap">
            {items.map(([a, b], i) => (
              <span key={i} className="flex items-center gap-2" aria-hidden={i >= TICKER.length}>
                <span className="font-bold text-paper">{a}</span><span className="text-paper/70">{b}</span>
              </span>
            ))}
          </div>
        </div>
        <span className="hidden shrink-0 text-paper/60 md:inline">Updated {status?.updated_at ? new Date(status.updated_at).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }) : UPDATED}</span>
      </Container>
    </div>
  );
}

/* Rebuilt clean, organized mega-menu matching design system */
function NavDropdown({ n, open, setOpen, label, isActive }: { n: { key: string; items?: NavLink[]; feature?: NavFeature }; open: boolean; setOpen: (v: boolean) => void; label: string; isActive: boolean }) {
  const wrap = useRef<HTMLDivElement>(null);
  const hoverTimer = useRef<NodeJS.Timeout | null>(null);
  const active = useActive();

  const [box, setBox] = useState<{ left: number; width: number; maxH: number }>({
    left: 16,
    width: 1240,
    maxH: 560
  });

  const measure = useCallback(() => {
    const vw = document.documentElement.clientWidth;
    const vh = window.innerHeight;
    const width = Math.min(1240, vw - 32);
    const left = Math.max(16, (vw - width) / 2);
    setBox({ left, width, maxH: Math.max(340, vh - 90) });
  }, []);

  useLayoutEffect(() => {
    if (!open) return;
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [open, measure]);

  const handleMouseEnter = () => {
    if (hoverTimer.current) clearTimeout(hoverTimer.current);
    hoverTimer.current = setTimeout(() => setOpen(true), 120);
  };

  const handleMouseLeave = () => {
    if (hoverTimer.current) clearTimeout(hoverTimer.current);
    hoverTimer.current = setTimeout(() => setOpen(false), 180);
  };

  const groups = n.items?.some(i => i.group)
    ? [...new Set(n.items!.map(i => i.group!))].map(g => [g, n.items!.filter(i => i.group === g)] as const)
    : [["", n.items!] as const];

  const Item = ({ i }: { i: NavLink }) => {
    const on = active(i.href);
    const Ic = i.icon ?? Compass;
    return (
      <Link
        href={i.href}
        data-testid={`navitem-${i.href.replace(/\W+/g, "-")}`}
        aria-current={on ? "page" : undefined}
        onClick={() => setOpen(false)}
        className={cn(
          "group flex h-14 min-w-0 items-center gap-3 rounded-[10px] px-2.5 transition-colors hover:bg-[var(--surface-2)]",
          on && "bg-[var(--surface-2)] border border-[var(--border)]"
        )}
      >
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-[10px] bg-[var(--surface-2)] text-[var(--accent)] border border-[var(--border)] group-hover:bg-[var(--accent)] group-hover:text-[#0F172A] transition-colors">
          <Ic className="h-[18px] w-[18px]" strokeWidth={1.75} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block text-[15px] font-semibold leading-tight text-[var(--text)] group-hover:text-[var(--accent)] transition-colors truncate">
            {i.label}
          </span>
          {i.desc && (
            <span className="block text-[13px] leading-tight text-[var(--text-muted)] mt-0.5 truncate">
              {i.desc}
            </span>
          )}
        </span>
      </Link>
    );
  };

  const viewAllMap: Record<string, { href: string; label: string; featured: string; featuredHref: string }> = {
    past: {
      href: "/medals",
      label: "View all medal tallies and records",
      featured: "Stories: Where India's greatest champions began",
      featuredHref: "/stories"
    },
    present: {
      href: "/match-centre",
      label: "View all live results and fixtures",
      featured: "Live: Follow 26 sports match dispatches in Match Centre",
      featuredHref: "/match-centre"
    },
    future: {
      href: "/road-to-la-2028",
      label: "View the road to LA 2028",
      featured: "Pathway: From the school ground to the podium",
      featuredHref: "/pathway"
    }
  };

  const meta = viewAllMap[n.key] || {
    href: "/",
    label: "View all",
    featured: "Momentum India: Celebrating the rise of a sporting nation",
    featuredHref: "/"
  };

  return (
    <div
      ref={wrap}
      className="relative flex h-full items-center"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <button
        data-testid={`nav-${n.key}`}
        aria-expanded={open}
        aria-haspopup="true"
        onClick={() => setOpen(!open)}
        className={cn(
          "relative flex h-full items-center gap-1.5 whitespace-nowrap px-3 text-sm font-bold text-[#0F172A] dark:text-[#E6EAF5] transition-colors hover:text-primary xl:px-4",
          (isActive || open) && "text-primary dark:text-primary",
          isActive && "after:absolute after:inset-x-3 xl:after:inset-x-4 after:bottom-0 after:h-[3px] after:rounded-t after:bg-primary"
        )}
      >
        {label}
        <ChevronDown className={cn("h-3.5 w-3.5 transition-transform duration-200 opacity-70", open && "rotate-180 text-primary opacity-100")} />
      </button>

      {open && (
        <div
          className="fixed top-[65px] z-50 rounded-[14px] border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] shadow-2xl p-5 overflow-y-auto"
          style={{ left: box.left, width: box.width, maxHeight: box.maxH }}
          data-testid={`menu-${n.key}`}
        >
          {/* Layout: up to 3 columns, each with small group heading and at most 6 rows */}
          <div className={cn(
            "grid gap-6",
            groups.length >= 3 ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" : "grid-cols-1 sm:grid-cols-2 max-w-4xl mx-auto"
          )}>
            {groups.map(([g, items]) => (
              <div key={g || "main"} className="min-w-0">
                {g && (
                  <p className="mb-2 px-2.5 text-xs font-bold uppercase tracking-wider text-[var(--accent)] flex items-center gap-1.5">
                    {g}
                  </p>
                )}
                <div className="space-y-1">
                  {items.slice(0, 6).map(i => (
                    <Item key={i.href} i={i} />
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Bottom featured link row and View everything link */}
          <div className="mt-5 pt-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-[var(--text-muted)]">
              <span className="rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-bold px-2 py-0.5 text-[10px] uppercase tracking-wider">
                Featured
              </span>
              <span className="truncate max-w-md">{meta.featured}</span>
              <Link
                href={meta.featuredHref}
                onClick={() => setOpen(false)}
                className="font-bold text-[var(--accent)] hover:underline inline-flex items-center gap-0.5 shrink-0"
              >
                Go <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            <Link
              href={meta.href}
              onClick={() => setOpen(false)}
              className="font-bold text-[var(--accent)] hover:underline inline-flex items-center gap-1 shrink-0"
            >
              <span>{meta.label}</span>
              <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

export function Header({ onSearch, onSubscribe }: { onSearch: () => void; onSubscribe: () => void }) {
  const { t } = usePrefs();
  const active = useActive();
  const [menu, setMenu] = useState<string | null>(null);
  const [loc] = useLocation();
  const navRef = useRef<HTMLElement>(null);

  const { data: calData } = useQuery<{ events: { status: string }[] }>({
    queryKey: ["/api/calendar"],
    staleTime: 60000,
  });
  const isAnyLive = calData?.events?.some(e => e.status === "Live") ?? false;

  useEffect(() => { setMenu(null); }, [loc]);
  useEffect(() => {
    if (!menu) return;
    const out = (e: PointerEvent) => { if (navRef.current && !navRef.current.contains(e.target as Node)) setMenu(null); };
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") setMenu(null); };
    document.addEventListener("pointerdown", out);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("pointerdown", out);
      document.removeEventListener("keydown", esc);
    };
  }, [menu]);

  return (
    <header className="sticky top-0 z-50 transition-colors liquid-glass-nav">
      <div className="tricolour h-[3px]" aria-hidden="true" />
      <Container className="flex h-14 md:h-16 items-center justify-between gap-2 sm:gap-6 min-w-0">
        {/* Logo and Wordmark */}
        <Link href="/" data-testid="link-home" className="flex shrink-0 items-center gap-2 sm:gap-2.5 min-w-0" aria-label="Momentum India home">
          <Logo className="h-7 w-7 sm:h-9 sm:w-9" />
          <Wordmark tagline={false} />
        </Link>

        {/* Primary Desktop Navigation: Games | Athletes | News | Explore (as in the starting zip) */}
        <nav ref={navRef} aria-label="Primary" className="hidden h-full items-center gap-1 xl:gap-2 lg:flex" onMouseLeave={() => setMenu(null)}>
          {NAV.map(n => n.href ? (
            <Link
              key={n.key}
              href={n.href}
              data-testid={`nav-${n.key}`}
              onMouseEnter={() => setMenu(null)}
              className={cn(
                "relative flex h-full items-center whitespace-nowrap px-3 text-sm font-bold text-[#0F172A] dark:text-[#E6EAF5] transition-colors hover:text-primary xl:px-4",
                active(n.href) && "text-primary dark:text-primary after:absolute after:inset-x-3 xl:after:inset-x-4 after:bottom-0 after:h-[3px] after:rounded-t after:bg-primary"
              )}
            >
              {t(n.key)}
            </Link>
          ) : (
            <NavDropdown
              key={n.key}
              n={n}
              open={menu === n.key}
              setOpen={v => setMenu(v ? n.key : null)}
              label={t(n.key)}
              isActive={n.items!.some(i => active(i.href))}
            />
          ))}
        </nav>

        {/* Right Actions: Visible Desktop Search, Match Centre pill, Theme button, Subscribe */}
        <div className="ml-auto flex items-center gap-2 sm:gap-2.5 shrink-0">
          {/* Desktop visible search box with Ctrl/Cmd+K hint */}
          <button
            onClick={onSearch}
            data-testid="header-search-bar"
            className="hidden md:flex items-center gap-2 rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3.5 py-1.5 text-xs text-[var(--text-muted)] hover:border-primary/50 hover:text-[var(--text)] transition shadow-sm w-36 lg:w-48"
          >
            <Search className="h-3.5 w-3.5 shrink-0" strokeWidth={1.75} />
            <span className="flex-1 text-left truncate">Search sports...</span>
            <kbd className="hidden lg:inline-block rounded border border-[var(--border)] bg-[var(--surface)] px-1.5 py-0.5 text-[10px] font-mono text-[var(--text-muted)]">⌘K</kbd>
          </button>

          {/* Match Centre pill: active pulse only when events are Live */}
          <Link
            href="/match-centre"
            data-testid="link-header-agent"
            className="hidden sm:inline-flex whitespace-nowrap shrink-0 items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1.5 text-xs font-bold text-[var(--text)] hover:border-primary transition shadow-sm"
          >
            {isAnyLive ? (
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            ) : (
              <Radio className="h-3.5 w-3.5 text-primary" />
            )}
            <span>Match Centre{isAnyLive ? " · Live" : ""}</span>
          </Link>

          {/* Theme button (Sun/Moon icon) */}
          <ThemeToggle />

          {/* Compact Search Trigger Icon Button on Mobile */}
          <button
            onClick={onSearch}
            data-testid="button-search"
            className="flex md:hidden h-8 w-8 shrink-0 items-center justify-center rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-muted)] transition hover:text-[var(--text)] shadow-sm"
            title="Search"
            aria-label="Search"
          >
            <Search className="h-4 w-4 shrink-0" strokeWidth={1.75} />
          </button>
        </div>
      </Container>
    </header>
  );
}

/* ---------------- search palette ---------------- */
export function SearchPalette({ open, setOpen }: { open: boolean; setOpen: (v: boolean) => void }) {
  const [, nav] = useLocation();
  useEffect(() => {
    const f = (e: KeyboardEvent) => { if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setOpen(!open); } };
    window.addEventListener("keydown", f); return () => window.removeEventListener("keydown", f);
  }, [open, setOpen]);
  const go = (h: string) => { setOpen(false); nav(h); };
  const o = sumEditions(OLY), c = sumEditions(CWG), a = sumEditions(ASIAN);
  const answers: [string, string, string][] = [
    ["How many Olympic medals has India won?", `${total(o)} medals: ${o.g} gold, ${o.s} silver, ${o.b} bronze`, "/medals/olympics"],
    ["Asian Games record (Hangzhou 2022)", "107 medals, 4th: 28 gold, 38 silver, 41 bronze", "/medals/asian-games"],
    ["Asian Games 2026 schedule", "19 September to 4 October 2026 in Aichi-Nagoya", "/games/asian-games-2026"],
    ["Where can I watch the ISL?", "Sony Sports Network, SonyLIV, and free on YouTube", "/watch"],
    ["When are the Asian Para Games?", "18 to 24 October 2026 in Aichi-Nagoya", "/games/asian-para-games-2026"],
    ["When is the next Olympics?", "Los Angeles, 14 to 30 July 2028", "/schedule"],
  ];
  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Search athletes, stories, Games or ask a question" data-testid="input-search" />
      <CommandList className="max-h-[60vh]">
        <CommandEmpty>Nothing matches yet. Try an athlete like "Neeraj" or a Games like "Glasgow".</CommandEmpty>
        <CommandGroup heading="Quick answers">
          {answers.map(([q, ans, h]) => <CommandItem key={q} value={q} onSelect={() => go(h)}><div><div className="font-bold">{q}</div><div className="text-xs text-muted-foreground">{ans}</div></div></CommandItem>)}
        </CommandGroup>
        <CommandGroup heading="Pages">
          {[["Asian Para Games 2026 live hub", "/games/asian-para-games-2026"], ["Where to watch: TV and streaming", "/watch"], ["Leagues: ISL, Pro Kabaddi, Hockey India League", "/leagues"], ["Fan zone: predictions, quiz, on this day", "/fan-zone"], ["State leaderboards", "/states"], ["Clubs and coaches near me", "/clubs"], ["Adopt a ground and donate gear", "/adopt-a-ground"], ["Build a sporting nation: grassroots, local stars, sponsors", "/sporting-nation"], ["Sponsor a budding athlete", "/sporting-nation/sponsor"], ["Road to LA 2028", "/road-to-la-2028"], ["Para sport hub and Asian Para Games", "/para"], ["Women in sport", "/women"], ["My Momentum: follow athletes and sports", "/my-momentum"], ["Editorial standards and corrections", "/about/standards"], ["Pathway for young athletes and parents", "/pathway"], ["Find sports facilities by state", "/facilities"], ["Success stories", "/stories"], ["Golden moments slideshow", "/golden-moments"], ["Asian Games 2026 hub", "/games/asian-games-2026"], ["Glasgow 2026 hub", "/games/glasgow-2026"], ["Ahmedabad 2030 guide", "/games/ahmedabad-2030"], ["Olympic medal history", "/medals/olympics"], ["Commonwealth medal history", "/medals/commonwealth"], ["Asian Games medal history", "/medals/asian-games"], ["Schedule", "/schedule"], ["Hall of fame", "/hall-of-fame"], ["Nations", "/nations"], ["FAQ", "/faq"]].map(([l, h]) => <CommandItem key={h} value={l} onSelect={() => go(h)}>{l}</CommandItem>)}
        </CommandGroup>
        <CommandGroup heading="Athletes">
          {PEOPLE.map(p => <CommandItem key={p.slug} value={`${p.name} ${p.sport}`} onSelect={() => go(`/athletes/${p.slug}`)}><span className="font-bold">{p.name}</span><span className="ml-2 text-xs text-muted-foreground">{p.sport}</span></CommandItem>)}
        </CommandGroup>
        <CommandGroup heading="Stories">
          {ARTICLES.map(a => <CommandItem key={a.slug} value={a.title} onSelect={() => go(`/news/${a.slug}`)}><div><div className="font-bold">{a.title}</div><div className="text-xs text-muted-foreground">{fmtDate(a.date)}</div></div></CommandItem>)}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}

/* ---------------- newsletter ---------------- */
const INTERESTS = [["asian", "Asian Games"], ["cwg", "Commonwealth Games"], ["oly", "Olympics"]] as const;
export function NewsletterForm({ tone = "dark", id = "nl" }: { tone?: "dark" | "light"; id?: string }) {
  const lang = "en";
  const [email, setEmail] = useState("");
  const [website, setWebsite] = useState("");
  const [picks, setPicks] = useState<string[]>(["asian", "cwg", "oly"]);
  const [state, setState] = useState<{ s: "idle" | "busy" | "ok" | "err"; msg?: string }>({ s: "idle" });
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) { setState({ s: "err", msg: "Enter a valid email address, like name@example.com." }); return; }
    setState({ s: "busy" });
    try {
      const r = await apiRequest("POST", "/api/subscribe", { email, interests: JSON.stringify(picks), lang, website });
      const j = await r.json();
      if (j.manage_token) {
        try {
          localStorage.setItem("mi_manage_token", j.manage_token);
          localStorage.setItem(`mi_manage_token_${j.email.toLowerCase()}`, j.manage_token);
        } catch {}
      }
      setState({ s: "ok", msg: j.existed ? `${j.email} was already subscribed. We've updated your preferences.` : `You're in. The next briefing goes to ${j.email}.` });
    } catch (err) {
      const m = String((err as Error).message);
      setState({ s: "err", msg: m.startsWith("400") ? "That email doesn't look right. Check it and try again." : "We couldn't reach the newsletter service. Try again in a moment." });
    }
  };
  const dark = tone === "dark";
  if (state.s === "ok") return (
    <div role="status" className={cn("flex items-start gap-3 rounded-lg border p-4", dark ? "border-white/15 bg-white/5 text-paper" : "border-border bg-card")}>
      <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-indgreen text-white"><Check className="h-4 w-4" /></span>
      <p className="text-sm">{state.msg}</p>
    </div>
  );
  return (
    <form onSubmit={submit} noValidate className="space-y-3" aria-describedby={`${id}-msg`}>
      {/* Honeypot: hidden from humans, filled by bots; the server rejects it. */}
      <input type="text" name="website" value={website} onChange={e => setWebsite(e.target.value)} tabIndex={-1} autoComplete="off" aria-hidden="true" className="hidden" />
      <div className="flex flex-col gap-2 sm:flex-row">
        <label htmlFor={`${id}-email`} className="sr-only">Email address</label>
        <input id={`${id}-email`} type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" data-testid={`input-${id}-email`}
          aria-invalid={state.s === "err"}
          className={cn("h-12 flex-1 rounded-full border px-5 text-base outline-none transition focus:ring-2 focus:ring-primary", dark ? "border-white/20 bg-white/5 text-paper placeholder:text-paper/50" : "border-input bg-background")} />
        <button type="submit" disabled={state.s === "busy"} data-testid={`button-${id}-submit`} className="flex h-12 items-center justify-center gap-2 rounded-full bg-primary px-6 font-bold text-primary-foreground hover:brightness-110 disabled:opacity-70">
          {state.s === "busy" ? <><Loader2 className="h-4 w-4 animate-spin" />Subscribing</> : <>Get the briefing<ArrowRight className="h-4 w-4" /></>}
        </button>
      </div>
      <fieldset className="flex flex-wrap gap-2">
        <legend className="sr-only">Topics</legend>
        {INTERESTS.map(([k, l]) => {
          const on = picks.includes(k);
          return <button type="button" key={k} aria-pressed={on} data-testid={`toggle-${id}-${k}`} onClick={() => setPicks(on ? picks.filter(x => x !== k) : [...picks, k])}
            className={cn("rounded-full border px-3 py-1.5 text-xs font-bold transition", on ? "border-primary bg-primary/15 text-primary" : dark ? "border-white/20 text-paper/70" : "border-border text-muted-foreground")}>{on && "✓ "}{l}</button>;
        })}
      </fieldset>
      <p id={`${id}-msg`} role={state.s === "err" ? "alert" : undefined} className={cn("min-h-5 text-sm", state.s === "err" ? "text-[hsl(2_80%_62%)]" : dark ? "text-paper/60" : "text-muted-foreground")}>
        {state.s === "err" ? state.msg : "One email after each big day. No spam, unsubscribe anytime."}
      </p>
    </form>
  );
}

export function SubscribeDialog({ open, setOpen }: { open: boolean; setOpen: (v: boolean) => void }) {
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">The Momentum briefing</DialogTitle>
          <DialogDescription>Results, medal counts and the stories behind them, after every big day of competition.</DialogDescription>
        </DialogHeader>
        <NewsletterForm tone="light" id="dlg" />
      </DialogContent>
    </Dialog>
  );
}

export function LiteToggle({ dark }: { dark?: boolean }) {
  const { lite, setLite } = usePrefs();
  return (
    <button role="switch" aria-checked={lite} data-testid="button-lite" onClick={() => setLite(!lite)}
      className={cn("flex w-full items-center gap-3 rounded-lg border px-3 py-2.5 text-left text-sm", dark ? "border-white/15 text-paper hover:border-white/40" : "border-border hover:border-foreground")}>
      <Feather className="h-4 w-4 shrink-0" />
      <span className="flex-1"><b className="block">Lite mode</b><span className={cn("text-xs", dark ? "text-paper/60" : "text-muted-foreground")}>No photos or animation. Saves data on slow connections.</span></span>
      <span className={cn("relative h-5 w-9 shrink-0 rounded-full transition-colors", lite ? "bg-primary" : dark ? "bg-white/20" : "bg-muted")}><span className={cn("absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all", lite ? "left-[18px]" : "left-0.5")} /></span>
    </button>
  );
}

/* ---------------- footer ---------------- */
export function Footer() {
  const { data: status } = useQuery<{ updated_at: string | null }>({
    queryKey: ["/api/site-status"],
    queryFn: async () => { const res = await apiRequest("GET", "/api/site-status"); return res.json(); },
    staleTime: 60000,
  });
  const cols: [string, [string, string][]][] = [
    ["Games", [["Asian Games 2026", "/games/asian-games-2026"], ["Glasgow 2026", "/games/glasgow-2026"], ["Ahmedabad 2030", "/games/ahmedabad-2030"], ["Schedule", "/schedule"]]],
    ["Medal History", [["Overview", "/medals"], ["Olympics", "/medals/olympics"], ["Commonwealth Games", "/medals/commonwealth"], ["Asian Games", "/medals/asian-games"]]],
    ["Grassroots & Stars", [["Road to LA 2028", "/road-to-la-2028"], ["Sporting Nation", "/sporting-nation"], ["Pathway & Parents", "/pathway"], ["Facilities by State", "/facilities"], ["Success Stories", "/stories"], ["Para Sport Hub", "/para"]]],
    ["Explore & About", [["Athletes", "/athletes"], ["News", "/news"], ["Hall of Fame", "/hall-of-fame"], ["About Us", "/about"], ["Data Sources", "/about/sources"], ["Standards", "/about/standards"], ["Privacy & Terms", "/about/legal"]]],
  ];
  return (
    <footer className="relative mt-24 overflow-hidden bg-ink text-paper">
      <div className="tricolour h-1" aria-hidden="true" />
      <Container className="py-16">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_2fr]">
          <div>
            <div className="flex items-center gap-3"><Logo className="h-12 w-12" />
              <span className="flex flex-col"><span className="font-display text-2xl font-semibold leading-none">Momentum India</span><span className="mt-1.5 text-xs font-bold uppercase tracking-[0.12em] text-saffron">{TAGLINE}</span></span></div>
            <p className="mt-4 max-w-sm text-paper/70">The pulse of Indian sport. An independent fan publication covering India at the Olympics, Asian Games and Commonwealth Games.</p>
            <div className="mt-6 max-w-md"><LiteToggle dark /></div>
          </div>
          <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
            {cols.map(([h, ls]) => (
              <div key={h}><p className="mb-4 text-xs font-bold uppercase tracking-[0.14em] text-paper/50">{h}</p>
                <ul className="space-y-2.5">{ls.map(([l, href]) => <li key={href}><Link href={href} className="text-sm text-paper/85 hover:text-saffron">{l}</Link></li>)}</ul></div>
            ))}
          </div>
        </div>
        <div className="mt-14 flex flex-col gap-3 pt-6 text-xs text-paper/50 md:flex-row md:justify-between">
          <p>Independent reporting & archival records on Indian sport. Sourced from the Sports Authority of India (SAI), Indian Olympic Association (IOA), and official federation records. Feed last updated {status?.updated_at ? new Date(status.updated_at).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }) : UPDATED}; medal history is archival and is updated when a Games concludes.</p>
          <a href="https://en.wikipedia.org/wiki/India_at_the_Olympics" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 hover:text-paper">Primary data sources<ArrowUpRight className="h-3 w-3" /></a>
        </div>
      </Container>
    </footer>
  );
}

/* ---------------- page hero ---------------- */
export function PageHero({ kicker, title, dek, img, children, accent }: { kicker: string; title: ReactNode; dek?: ReactNode; img: string; children?: ReactNode; accent?: string }) {
  return (
    <section className="grain mi-hero relative isolate overflow-hidden bg-ink text-paper">
      <div className="absolute inset-0 -z-10"><Img src={img} alt="" eager className="scale-105" /></div>
      <div className="scrim-l absolute inset-0 -z-10" /><div className="scrim-b absolute inset-0 -z-10 opacity-80" />
      <div className="mi-hero-glow absolute inset-0 -z-10" aria-hidden="true" />
      <Container className="flex min-h-[380px] flex-col justify-end pb-12 pt-24 md:min-h-[480px] md:pb-16">
        <span className="mi-glass inline-flex w-fit max-w-full items-center rounded-2xl px-3.5 py-1.5 sm:rounded-full"><Kicker color={accent ?? "hsl(var(--gold-bright))"} className="text-[0.66rem] leading-snug sm:text-[0.72rem]">{kicker}</Kicker></span>
        <h1 className="mt-5 max-w-4xl text-balance font-display text-[clamp(2.5rem,1.2rem+4.4vw,5.4rem)] font-bold leading-[0.94]">{title}</h1>
        <span className="mi-swoosh mt-5 block h-[3px] w-28 rounded-full" aria-hidden="true" />
        {dek && <p className="mt-5 max-w-2xl text-pretty text-lg text-paper/80">{dek}</p>}
        {children}
      </Container>
    </section>
  );
}

export function Tabs<T extends string>({ tabs, value, onChange, className }: { tabs: [T, string][]; value: T; onChange: (v: T) => void; className?: string }) {
  return (
    <div role="tablist" className={cn("no-scrollbar -mx-4 flex gap-1 overflow-x-auto px-4 sm:mx-0 sm:px-0", className)}>
      {tabs.map(([k, l]) => (
        <button key={k} role="tab" aria-selected={value === k} data-testid={`tab-${k}`} onClick={() => onChange(k)}
          className={cn("relative shrink-0 whitespace-nowrap px-4 py-3 text-sm font-bold transition-colors", value === k ? "text-foreground after:absolute after:inset-x-2 after:-bottom-px after:h-[3px] after:rounded-t after:bg-primary" : "text-muted-foreground hover:text-foreground")}>{l}</button>
      ))}
    </div>
  );
}
