import { useState, useMemo } from "react";
import { Trophy, Flame, Sparkles, CheckCircle2, XCircle, Lightbulb, RotateCcw, ArrowRight, Share2, Award, Zap } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { generateQuizRound, fisherYates, type QuizQuestion } from "@/data/quiz";
import { cn } from "@/lib/utils";

const OPTION_LABELS = ["A", "B", "C", "D"] as const;

export function DynamicQuiz({ embedded = false }: { embedded?: boolean }) {
  const [roundId, setRoundId] = useState(1);

  const { data: quizApiData, isLoading: quizLoading } = useQuery<{
    count: number;
    quizzes: {
      id: number;
      sport: string;
      question: string;
      options: string[];
      answer: string;
      explanation: string;
      difficulty: string;
    }[];
    telemetry_source: string;
    updated_at: string;
  }>({
    queryKey: ["/api/fan/quizzes"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/fan/quizzes");
      return res.json();
    },
    staleTime: 60000,
  });

  const questions: QuizQuestion[] = useMemo(() => {
    if (quizApiData?.quizzes?.length) {
      return quizApiData.quizzes.map((item, idx) => ({
        id: `dyn-q-${item.id || idx}`,
        sport: item.sport,
        difficulty: (item.difficulty === "easy" ? "easy" : "hard") as "easy" | "hard",
        q: item.question,
        options: (item.options.slice(0, 4) as [string, string, string, string]),
        answer: item.answer,
        fact: item.explanation,
      }));
    }
    return generateQuizRound();
  }, [quizApiData, roundId]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [chosenAnswer, setChosenAnswer] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);
  const [isCopied, setIsCopied] = useState(false);

  const currentQ = questions[currentIndex];

  const shuffledOptions = useMemo(() => {
    if (!currentQ) return [];
    return fisherYates(currentQ.options);
  }, [currentQ]);

  const isDone = currentIndex >= questions.length;

  const handleSelect = (option: string) => {
    if (chosenAnswer !== null) return;
    setChosenAnswer(option);

    if (option === currentQ.answer) {
      setScore(s => s + 1);
      setStreak(s => {
        const next = s + 1;
        if (next > maxStreak) setMaxStreak(next);
        return next;
      });
    } else {
      setStreak(0);
    }
  };

  const handleNext = () => {
    setChosenAnswer(null);
    setCurrentIndex(i => i + 1);
  };

  const restartQuiz = () => {
    setRoundId(r => r + 1);
    setCurrentIndex(0);
    setChosenAnswer(null);
    setScore(0);
    setStreak(0);
    setMaxStreak(0);
  };

  const handleShare = () => {
    const text = `🇮🇳 I scored ${score}/8 on the Momentum India Sports Quiz! (Max Streak: ${maxStreak}🔥) Can you beat it? Test your knowledge: https://momentum.in/fan-zone`;
    if (navigator.share) {
      navigator.share({ title: "Momentum India Sports Quiz", text }).catch(() => {});
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  if (isDone) {
    const pct = (score / questions.length) * 100;
    const tier =
      score === 8
        ? { title: "National Legend", desc: "Perfection! You have encyclopedia-level mastery of Indian sports history.", icon: Trophy, color: "text-amber-500" }
        : score >= 6
        ? { title: "Podium Finisher", desc: "Sensational run! You know India's champions and iconic moments inside out.", icon: Award, color: "text-[var(--accent)]" }
        : score >= 4
        ? { title: "Strong Contender", desc: "Great effort! A few tie-breakers caught you, but the foundation is solid.", icon: Zap, color: "text-emerald-500" }
        : { title: "Training Ground", desc: "A great start! Dive into the scoreboards and historical annals to level up.", icon: Flame, color: "text-orange-500" };

    const TierIcon = tier.icon;

    return (
      <div
        className={cn(
          "rounded-2xl p-6 text-center text-[var(--text)] border-none bg-[#0d111a] shadow-lg mx-auto max-w-xl",
          embedded && "w-full"
        )}
      >
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[#131926] border-none">
          <TierIcon className={cn("h-7 w-7", tier.color)} strokeWidth={1.75} />
        </div>

        <span className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-[#131926] px-3 py-1 text-xs font-bold text-orange-400 border-none">
          <Sparkles className="h-3.5 w-3.5" />
          Round Completed
        </span>

        <h3 className="mt-2 font-display text-4xl font-extrabold tnum text-[var(--text)]">
          {score} <span className="text-xl text-[var(--text-muted)]">/ {questions.length}</span>
        </h3>

        <p className="mt-1 font-sans text-lg font-bold text-[var(--accent)]">{tier.title}</p>
        <p className="mx-auto mt-2 max-w-md text-sm text-[var(--text-muted)] leading-relaxed">{tier.desc}</p>

        {/* Stats strip */}
        <div className="mt-5 grid grid-cols-2 gap-3 rounded-xl border-none bg-[#131926] p-3">
          <div>
            <p className="text-[0.68rem] font-bold uppercase tracking-wider text-[var(--text-muted)]">Accuracy</p>
            <p className="mt-0.5 text-xl font-extrabold text-[var(--text)] tnum">{Math.round(pct)}%</p>
          </div>
          <div>
            <p className="text-[0.68rem] font-bold uppercase tracking-wider text-[var(--text-muted)]">Max Streak</p>
            <p className="mt-0.5 text-xl font-extrabold text-[var(--accent)] tnum flex items-center justify-center gap-1">
              <Flame className="h-4 w-4 fill-current" />
              {maxStreak}
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={restartQuiz}
            data-testid="quiz-play-again"
            className="btn-primary inline-flex h-11 items-center gap-2 rounded-xl px-6 text-sm font-bold shadow-md border-none"
          >
            <RotateCcw className="h-4 w-4" />
            <span>Play New Round</span>
          </button>

          <button
            onClick={handleShare}
            data-testid="quiz-share"
            className="inline-flex h-11 items-center gap-2 rounded-xl border-none bg-[#131926] px-5 text-sm font-semibold text-slate-200 hover:bg-[#182030] transition-colors"
          >
            <Share2 className="h-4 w-4 text-[var(--accent)]" />
            <span>{isCopied ? "Score Copied!" : "Share Score"}</span>
          </button>
        </div>
      </div>
    );
  }

  const isHard = currentQ.difficulty === "hard";

  return (
    <div className={cn("mx-auto max-w-2xl w-full", embedded && "w-full")}>
      {/* Question and Score on ONE row */}
      <div className="mb-3 flex items-center justify-between text-xs font-semibold text-slate-400">
        <div className="flex items-center gap-2">
          <span>
            Question <b className="text-slate-100 font-bold">{currentIndex + 1}</b> of {questions.length}
          </span>
          {isHard ? (
            <span className="rounded-full bg-rose-500/15 border-none px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-rose-400">
              Hard
            </span>
          ) : (
            <span className="rounded-full bg-emerald-500/15 border-none px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-400">
              Standard
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {streak > 1 && (
            <span className="rounded-full bg-amber-500/15 border-none px-2 py-0.5 text-[10px] font-bold text-amber-400 flex items-center gap-1">
              <Flame className="h-3 w-3 fill-current" /> {streak} Streak
            </span>
          )}
          <span className="font-mono text-xs font-bold text-slate-200">
            Score: <span className="text-orange-400">{score}</span>
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.05] mb-4 border-none">
        <div
          className="h-full bg-gradient-to-r from-saffron to-[var(--accent)] rounded-full transition-all duration-300"
          style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
        />
      </div>

      {/* Question Card */}
      <div
        className={cn(
          "rounded-2xl p-5 md:p-6 border-none bg-[#0d111a] shadow-sm"
        )}
      >
        {/* Sport category label */}
        <div className="mb-2">
          <span className="text-xs font-bold uppercase tracking-wider text-orange-400">
            {currentQ.sport}
          </span>
        </div>

        {/* Question in Body font */}
        <h4
          className="font-sans text-lg sm:text-xl font-bold leading-snug text-slate-100"
          data-testid="quiz-question-text"
        >
          {currentQ.q}
        </h4>

        {/* 56px Answer Buttons with clear correct and wrong states (colour + icon) */}
        <div className="mt-5 grid gap-2.5 sm:grid-cols-2">
          {shuffledOptions.map((opt, idx) => {
            const label = OPTION_LABELS[idx];
            const isSelected = chosenAnswer === opt;
            const isCorrect = opt === currentQ.answer;

            let btnStyle =
              "border-none bg-[#131926] text-slate-200 hover:bg-[#182030]";

            if (chosenAnswer !== null) {
              if (isCorrect) {
                btnStyle =
                  "border-none bg-emerald-500/20 text-emerald-300 font-bold";
              } else if (isSelected) {
                btnStyle =
                  "border-none bg-rose-500/20 text-rose-300 font-bold";
              } else {
                btnStyle = "border-none bg-[#131926] opacity-40 text-slate-500";
              }
            }

            return (
              <button
                key={opt}
                type="button"
                disabled={chosenAnswer !== null}
                onClick={() => handleSelect(opt)}
                data-testid={`quiz-option-${label}`}
                className={cn(
                  "group relative flex min-h-[56px] h-14 items-center gap-3 rounded-xl border-none px-3.5 py-2 text-left text-sm font-semibold transition-all duration-150",
                  btnStyle
                )}
              >
                <span
                  className={cn(
                    "flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold transition-colors border-none",
                    chosenAnswer === null
                      ? "bg-white/[0.05] text-slate-200 group-hover:bg-orange-500 group-hover:text-white"
                      : isCorrect
                      ? "bg-emerald-600 text-white"
                      : isSelected
                      ? "bg-rose-600 text-white"
                      : "bg-white/[0.05] text-slate-500"
                  )}
                >
                  {label}
                </span>
                <span className="min-w-0 flex-1 leading-snug truncate">{opt}</span>

                {chosenAnswer !== null && isCorrect && (
                  <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-400" />
                )}
                {chosenAnswer !== null && isSelected && !isCorrect && (
                  <XCircle className="h-5 w-5 shrink-0 text-rose-400" />
                )}
              </button>
            );
          })}
        </div>

        {/* Feedback & Did You Know Reveal */}
        {chosenAnswer !== null && (
          <div className="mt-5 border-none pt-2">
            <div className="flex items-center gap-2">
              {chosenAnswer === currentQ.answer ? (
                <span className="inline-flex items-center gap-1.5 text-sm font-bold text-emerald-700 dark:text-emerald-400">
                  <CheckCircle2 className="h-4 w-4" /> Correct Answer!
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-sm font-bold text-rose-700 dark:text-rose-400">
                  <XCircle className="h-4 w-4" /> Incorrect Answer!
                </span>
              )}
            </div>

            {/* Did You Know Box */}
            <div className="mt-3 rounded-xl border-none bg-[#131926] p-3.5">
              <div className="flex items-start gap-2.5">
                <Lightbulb className="h-4 w-4 shrink-0 text-orange-400 mt-0.5" />
                <div className="text-xs leading-relaxed text-slate-200">
                  <b className="font-bold text-orange-400 uppercase tracking-wider block mb-0.5">
                    Did You Know?
                  </b>
                  {currentQ.fact}
                </div>
              </div>
            </div>

            {/* Next Question CTA */}
            <div className="mt-4 flex items-center justify-between gap-2 pt-2 border-none">
              <span className="flex items-center gap-1.5 text-[11px] text-[var(--text-muted)]">
                <span className="h-1.5 w-1.5 rounded-full bg-indgreen animate-pulse" />
                {quizApiData?.telemetry_source ?? "Interactive Knowledge Graph"}
              </span>
              <button
                onClick={handleNext}
                data-testid="quiz-next-button"
                className="btn-primary inline-flex h-10 items-center gap-2 rounded-[10px] px-5 text-xs font-bold shadow-md"
              >
                <span>{currentIndex + 1 === questions.length ? "View Final Score" : "Next Question"}</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
