import { createRoot } from "react-dom/client";
import App from "./App";
import "./fonts.css";
import "./index.css";
import { initWebVitals } from "./lib/vitals";

// Initialize anonymous web vitals beaconing
initWebVitals();

// Installable app: register the service worker (static assets + shell only;
// API/admin are never cached, see client/public/sw.js).
if (typeof window !== "undefined" && "serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}

// The production server injects window.__MI_PATH__ and serves real paths (/news/...).
// Static previews (no server) fall back to hash addresses (#/news/...).
export const PATH_MODE = typeof window !== "undefined" && !!(window as any).__MI_PATH__;

if (PATH_MODE) {
  // Old shared links like /#/news/story move to /news/story.
  if (window.location.hash.startsWith("#/")) window.history.replaceState(null, "", window.location.hash.slice(1) || "/");
} else if (!window.location.hash) {
  window.location.hash = "#/";
}

createRoot(document.getElementById("root")!).render(<App />);
