import { useEffect, useState, lazy, Suspense } from "react";
import { Switch, Route, Router, Redirect, useLocation } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { PrefsProvider, usePrefs } from "@/lib/prefs";
import { MotionConfig } from "framer-motion";
import { ScrollButtons, Header, Footer, SubscribeDialog } from "@/components/site";
import { MobileTabBar } from "@/components/mobile-nav";
import { UnifiedSearch } from "@/components/unified-search";
import { CmpBanner } from "@/components/cmp-banner";
import Home from "@/pages/home";
import NotFound from "@/pages/not-found";
import { LEGACY, seoFor } from "@/lib/seo";
import { Analytics } from "@/lib/analytics";

// Route-level code-splitting with React.lazy
const NewsIndex = lazy(() => import("@/pages/news").then(m => ({ default: m.NewsIndex })));
const ArticlePage = lazy(() => import("@/pages/news").then(m => ({ default: m.ArticlePage })));
const MedalsOverview = lazy(() => import("@/pages/medals").then(m => ({ default: m.MedalsOverview })));
const MedalsGames = lazy(() => import("@/pages/medals").then(m => ({ default: m.MedalsGames })));
const AsianGames2026 = lazy(() => import("@/pages/games").then(m => ({ default: m.AsianGames2026 })));
const Glasgow2026 = lazy(() => import("@/pages/games").then(m => ({ default: m.Glasgow2026 })));
const Ahmedabad2030 = lazy(() => import("@/pages/games").then(m => ({ default: m.Ahmedabad2030 })));
const AthletesIndex = lazy(() => import("@/pages/athletes").then(m => ({ default: m.AthletesIndex })));
const AthleteProfile = lazy(() => import("@/pages/athletes").then(m => ({ default: m.AthleteProfile })));
const Schedule = lazy(() => import("@/pages/explore").then(m => ({ default: m.Schedule })));
const HallOfFame = lazy(() => import("@/pages/explore").then(m => ({ default: m.HallOfFame })));
const Sports = lazy(() => import("@/pages/explore").then(m => ({ default: m.Sports })));
const Nations = lazy(() => import("@/pages/explore").then(m => ({ default: m.Nations })));
const Faq = lazy(() => import("@/pages/explore").then(m => ({ default: m.Faq })));
const About = lazy(() => import("@/pages/explore").then(m => ({ default: m.About })));
const RoadToLA = lazy(() => import("@/pages/rise").then(m => ({ default: m.RoadToLA })));
const Pathway = lazy(() => import("@/pages/rise").then(m => ({ default: m.Pathway })));
const Facilities = lazy(() => import("@/pages/rise").then(m => ({ default: m.Facilities })));
const Stories = lazy(() => import("@/pages/rise").then(m => ({ default: m.Stories })));
const GoldenMoments = lazy(() => import("@/pages/rise").then(m => ({ default: m.GoldenMoments })));
const ParaHub = lazy(() => import("@/pages/plus").then(m => ({ default: m.ParaHub })));
const WomenInSport = lazy(() => import("@/pages/plus").then(m => ({ default: m.WomenInSport })));
const MyMomentum = lazy(() => import("@/pages/plus").then(m => ({ default: m.MyMomentum })));
const SportingNation = lazy(() => import("@/pages/nation"));
const AdminPage = lazy(() => import("@/pages/admin"));
const ParaGames2026 = lazy(() => import("@/pages/live").then(m => ({ default: m.ParaGames2026 })));
const WhereToWatch = lazy(() => import("@/pages/live").then(m => ({ default: m.WhereToWatch })));
const Leagues = lazy(() => import("@/pages/live").then(m => ({ default: m.Leagues })));
const StateLeaderboards = lazy(() => import("@/pages/live").then(m => ({ default: m.StateLeaderboards })));
const FanZone = lazy(() => import("@/pages/fan"));
const Clubs = lazy(() => import("@/pages/community").then(m => ({ default: m.Clubs })));
const AdoptGround = lazy(() => import("@/pages/community").then(m => ({ default: m.AdoptGround })));
const SportsAgentPage = lazy(() => import("@/pages/agent"));
const DataSourcesPage = lazy(() => import("@/pages/sources"));
const EventsPage = lazy(() => import("@/pages/events"));

const PATH_MODE = typeof window !== "undefined" && !!(window as any).__MI_PATH__;

function setMeta(sel: string, attr: string, val: string, create: () => HTMLElement) {
  let el = document.head.querySelector(sel) as HTMLElement | null;
  if (!el) { el = create(); document.head.appendChild(el); }
  el.setAttribute(attr, val);
}

function ScrollTop() {
  const [loc] = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [loc]);
  useEffect(() => {
    const s = seoFor(loc);
    document.title = s.title;
    setMeta('meta[name="description"]', "content", s.description, () => Object.assign(document.createElement("meta"), { name: "description" }));
    setMeta('meta[name="robots"]', "content", s.noindex ? "noindex, follow" : "index, follow", () => Object.assign(document.createElement("meta"), { name: "robots" }));
    if (PATH_MODE) setMeta('link[rel="canonical"]', "href", window.location.origin + s.path, () => Object.assign(document.createElement("link"), { rel: "canonical" }));
  }, [loc]);
  return null;
}

export function PageSkeleton() {
  return (
    <div className="mx-auto max-w-[1320px] px-4 sm:px-6 lg:px-10 py-12 space-y-6 animate-pulse" role="status" aria-label="Loading page">
      <div className="h-4 w-32 rounded bg-muted"></div>
      <div className="h-10 w-3/4 max-w-md rounded-lg bg-muted"></div>
      <div className="h-4 w-full max-w-xl rounded bg-muted/60"></div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-6">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="h-48 rounded-xl bg-card border border-border/60"></div>
        ))}
      </div>
    </div>
  );
}

function AppRouter() {
  return (
    <Suspense fallback={<PageSkeleton />}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/events" component={EventsPage} />
        <Route path="/games/events" component={EventsPage} />
        <Route path="/match-centre" component={SportsAgentPage} />
        <Route path="/news" component={NewsIndex} />
        <Route path="/news/:slug" component={ArticlePage} />
        <Route path="/medals" component={MedalsOverview} />
        <Route path="/medals/:games" component={MedalsGames} />
        <Route path="/games/asian-games-2026" component={AsianGames2026} />
        <Route path="/games/asian-para-games-2026" component={ParaGames2026} />
        <Route path="/watch" component={WhereToWatch} />
        <Route path="/leagues" component={Leagues} />
        <Route path="/states" component={StateLeaderboards} />
        <Route path="/fan-zone" component={FanZone} />
        <Route path="/clubs" component={Clubs} />
        <Route path="/adopt-a-ground" component={AdoptGround} />
        <Route path="/games/glasgow-2026" component={Glasgow2026} />
        <Route path="/games/ahmedabad-2030" component={Ahmedabad2030} />
        <Route path="/athletes" component={AthletesIndex} />
        <Route path="/athletes/:slug" component={AthleteProfile} />
        <Route path="/road-to-la-2028" component={RoadToLA} />
        <Route path="/sporting-nation" component={SportingNation} />
        <Route path="/sporting-nation/:section" component={SportingNation} />
        <Route path="/pathway" component={Pathway} />
        <Route path="/facilities" component={Facilities} />
        <Route path="/stories" component={Stories} />
        <Route path="/golden-moments" component={GoldenMoments} />
        <Route path="/para" component={ParaHub} />
        <Route path="/women" component={WomenInSport} />
        <Route path="/my-momentum" component={MyMomentum} />
        <Route path="/schedule" component={Schedule} />
        <Route path="/hall-of-fame" component={HallOfFame} />
        <Route path="/sports" component={Sports} />
        <Route path="/nations" component={Nations} />
        <Route path="/faq" component={Faq} />
        <Route path="/about/sources" component={DataSourcesPage} />
        <Route path="/sources" component={DataSourcesPage} />
        <Route path="/about" component={About} />
        <Route path="/about/:tab" component={About} />
        <Route path="/admin" component={AdminPage} />
        {LEGACY.map(([from, to]) => <Route key={from} path={from}><Redirect to={to} replace /></Route>)}
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function Shell() {
  const { lite } = usePrefs();
  const [search, setSearch] = useState(false);
  const [sub, setSub] = useState(false);

  return (
    <MotionConfig reducedMotion={lite ? "always" : "user"}>
      <a
        href="#main"
        onClick={e => { e.preventDefault(); document.getElementById("main")?.focus(); }}
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:font-bold focus:text-primary-foreground focus:shadow-lg focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
      >
        Skip to content
      </a>
      <Header onSearch={() => setSearch(true)} onSubscribe={() => setSub(true)} />
      <div className="pb-safe-bottom">
        <main id="main" tabIndex={-1} className="outline-none"><ScrollTop /><Analytics /><AppRouter /></main>
      </div>
      <Footer />
      <ScrollButtons />
      <MobileTabBar onSearchOpen={() => setSearch(true)} />
      <UnifiedSearch open={search} onClose={() => setSearch(false)} />
      <SubscribeDialog open={sub} setOpen={setSub} />
      <CmpBanner />
    </MotionConfig>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <PrefsProvider>
        <TooltipProvider>
          <Toaster />
          {PATH_MODE ? <Router><Shell /></Router> : <Router hook={useHashLocation}><Shell /></Router>}
        </TooltipProvider>
      </PrefsProvider>
    </QueryClientProvider>
  );
}
