export type QuizQuestion = {
  id: string;
  sport: string;
  difficulty: "easy" | "hard";
  q: string;
  options: [string, string, string, string];
  answer: string;
  fact: string;
};

export const QUIZ_BANK: QuizQuestion[] = [
  /* ---------- ATHLETICS ---------- */
  {
    id: "ath-1",
    sport: "Athletics",
    difficulty: "easy",
    q: "What was Neeraj Chopra's gold medal-winning throw distance at the Tokyo 2020 Olympic Games?",
    options: ["87.58 m", "89.94 m", "86.48 m", "88.17 m"],
    answer: "87.58 m",
    fact: "Neeraj's 87.58 m throw on 7 August 2021 made him the first Indian track & field Olympic champion and only the second individual Indian Olympic gold medallist in history."
  },
  {
    id: "ath-2",
    sport: "Athletics",
    difficulty: "easy",
    q: "Who was the first Indian woman to reach an Olympic track & field final (Los Angeles 1984)?",
    options: ["P.T. Usha", "Kamaljeet Sandhu", "Shiny Wilson", "Anju Bobby George"],
    answer: "P.T. Usha",
    fact: "P.T. Usha finished 4th in the 400m hurdles final, missing the bronze medal by a heartbreaking 1/100th of a second (0.01s), but inspiring generations of Indian runners."
  },
  {
    id: "ath-3",
    sport: "Athletics",
    difficulty: "easy",
    q: "Which legendary Indian sprinter was famously known as 'The Flying Sikh'?",
    options: ["Milkha Singh", "Gurbachan Singh Randhawa", "Makhan Singh", "Paramjit Singh"],
    answer: "Milkha Singh",
    fact: "The moniker 'The Flying Sikh' was bestowed on Milkha Singh in 1960 by Pakistan's General Ayub Khan after Milkha defeated Abdul Khaliq in Lahore."
  },
  {
    id: "ath-4",
    sport: "Athletics",
    difficulty: "easy",
    q: "Who won India's first-ever medal at the World Athletics Championships in Paris 2003?",
    options: ["Anju Bobby George", "Neeraj Chopra", "P.T. Usha", "Jyotirmoyee Sikdar"],
    answer: "Anju Bobby George",
    fact: "Anju leaped 6.70m to capture the bronze medal in women's long jump, cementing her name in Indian sports folklore under the guidance of World record holder Mike Powell and Robert Bobby George."
  },
  {
    id: "ath-5",
    sport: "Athletics",
    difficulty: "easy",
    q: "Avinash Sable won a landmark silver medal at the 2022 Commonwealth Games in which event?",
    options: ["3000m Steeplechase", "5000m", "Marathon", "1500m"],
    answer: "3000m Steeplechase",
    fact: "Sable shattered the Kenyan podium clean sweep that had lasted uninterrupted at the Commonwealth Games since 1994, missing gold by just 0.05 seconds."
  },
  {
    id: "ath-6",
    sport: "Athletics",
    difficulty: "hard",
    q: "In the 1960 Rome Olympics 400m final, Milkha Singh set an Indian national record (45.73s) that stood unbroken for how many years?",
    options: ["38 years", "24 years", "16 years", "44 years"],
    answer: "38 years",
    fact: "Milkha Singh's Rome 1960 timing of 45.73 seconds stood for 38 years until Paramjit Singh broke it in 1998 at the National Open in Kolkata."
  },
  {
    id: "ath-7",
    sport: "Athletics",
    difficulty: "hard",
    q: "What distance did Neeraj Chopra throw to win India's first World Athletics Championships Gold in Budapest 2023?",
    options: ["88.17 m", "89.30 m", "87.58 m", "86.67 m"],
    answer: "88.17 m",
    fact: "Neeraj's 88.17m throw in Budapest completed his career golden slam (Olympics, World Championships, Asian Games, Commonwealth Games, and Diamond League title)."
  },

  /* ---------- CRICKET ---------- */
  {
    id: "cri-1",
    sport: "Cricket",
    difficulty: "easy",
    q: "Who captained India to its historic first Cricket World Cup title at Lord's in 1983?",
    options: ["Kapil Dev", "Sunil Gavaskar", "Mohinder Amarnath", "Dilip Vengsarkar"],
    answer: "Kapil Dev",
    fact: "Kapil Dev's iconic running catch to dismiss Viv Richards at 57/2 turned the Lord's final on its head as India defended a modest 183 against the mighty West Indies."
  },
  {
    id: "cri-2",
    sport: "Cricket",
    difficulty: "easy",
    q: "Which Indian captain sealed the 2011 ICC Cricket World Cup at Wankhede Stadium with a famous six?",
    options: ["MS Dhoni", "Sachin Tendulkar", "Gautam Gambhir", "Virat Kohli"],
    answer: "MS Dhoni",
    fact: "MS Dhoni scored an unbeaten 91 off 79 balls and promoted himself ahead of Yuvraj Singh, ending India's 28-year wait for an ODI World Cup trophy."
  },
  {
    id: "cri-3",
    sport: "Cricket",
    difficulty: "easy",
    q: "Who was named Player of the Tournament in India's triumphant 2011 ICC World Cup campaign?",
    options: ["Yuvraj Singh", "Zaheer Khan", "Sachin Tendulkar", "MS Dhoni"],
    answer: "Yuvraj Singh",
    fact: "Yuvraj scored 362 runs and claimed 15 wickets across 9 matches, putting on one of the greatest all-round individual World Cup performances in history."
  },
  {
    id: "cri-4",
    sport: "Cricket",
    difficulty: "easy",
    q: "Who bowled the dramatic final over for India against Pakistan in the inaugural 2007 ICC T20 World Cup final?",
    options: ["Joginder Sharma", "S. Sreesanth", "Irfan Pathan", "RP Singh"],
    answer: "Joginder Sharma",
    fact: "Misbah-ul-Haq attempted a scoop shot over fine leg, straight into the safe hands of S. Sreesanth, crowning MS Dhoni's young brigade as world champions in Johannesburg."
  },
  {
    id: "cri-5",
    sport: "Cricket",
    difficulty: "easy",
    q: "Against which nation did Sachin Tendulkar score his monumental 100th international century in March 2012?",
    options: ["Bangladesh", "Australia", "Sri Lanka", "England"],
    answer: "Bangladesh",
    fact: "Tendulkar achieved the milestone at Mirpur, Dhaka, compiling 114 runs to become the only cricketer in history with 100 international centuries (51 Test, 49 ODI)."
  },
  {
    id: "cri-6",
    sport: "Cricket",
    difficulty: "easy",
    q: "In the 2024 ICC Men's T20 World Cup final against South Africa, who took the match-winning boundary catch to dismiss David Miller?",
    options: ["Suryakumar Yadav", "Hardik Pandya", "Axar Patel", "Virat Kohli"],
    answer: "Suryakumar Yadav",
    fact: "Suryakumar Yadav's juggling acrobatic catch on the boundary rope off Hardik Pandya in the 20th over sealed India's thrilling 7-run victory in Barbados."
  },
  {
    id: "cri-7",
    sport: "Cricket",
    difficulty: "hard",
    q: "Who was India's highest wicket-taker in the triumphant 1983 Cricket World Cup campaign?",
    options: ["Roger Binny", "Madan Lal", "Kapil Dev", "Balwinder Sandhu"],
    answer: "Roger Binny",
    fact: "Roger Binny took 18 wickets at an average of 18.66, finishing as the top wicket-taker of the entire 1983 World Cup tournament ahead of Bob Willis and Richard Hadlee."
  },
  {
    id: "cri-8",
    sport: "Cricket",
    difficulty: "hard",
    q: "Who holds the record for the highest individual Test score by an Indian batsman (319 against South Africa in Chennai, 2008)?",
    options: ["Virender Sehwag", "Karun Nair", "VVS Laxman", "Sachin Tendulkar"],
    answer: "Virender Sehwag",
    fact: "Sehwag reached 300 in just 278 balls — the fastest recorded triple century in Test cricket history."
  },

  /* ---------- OLYMPICS ---------- */
  {
    id: "oly-1",
    sport: "Olympics",
    difficulty: "easy",
    q: "Who won independent India's first-ever individual Olympic medal at the 1952 Helsinki Games?",
    options: ["K.D. Jadhav", "Milkha Singh", "Dhyan Chand", "Norman Pritchard"],
    answer: "K.D. Jadhav",
    fact: "Khashaba Dadasaheb Jadhav won bronze in freestyle wrestling (bantamweight) at Helsinki 1952, despite travelling on crowd-funded community donations."
  },
  {
    id: "oly-2",
    sport: "Olympics",
    difficulty: "easy",
    q: "Who became the first Indian woman to win an Olympic medal (Sydney 2000)?",
    options: ["Karnam Malleswari", "Mary Kom", "Saina Nehwal", "P.T. Usha"],
    answer: "Karnam Malleswari",
    fact: "Malleswari lifted 240kg in the 69kg weightlifting class in Sydney to claim bronze, etching her name forever in the Olympic history books."
  },
  {
    id: "oly-3",
    sport: "Olympics",
    difficulty: "easy",
    q: "Who won India's first-ever individual Olympic gold medal in Beijing 2008?",
    options: ["Abhinav Bindra", "Rajyavardhan Rathore", "Gagan Narang", "Sushil Kumar"],
    answer: "Abhinav Bindra",
    fact: "Bindra shot a nearly flawless 10.8 on his final shot in the 10m Air Rifle final to secure India's maiden individual gold medal."
  },
  {
    id: "oly-4",
    sport: "Olympics",
    difficulty: "easy",
    q: "Who is the only Indian woman to win two consecutive individual Olympic medals (Rio 2016 & Tokyo 2020)?",
    options: ["P.V. Sindhu", "Manu Bhaker", "Mary Kom", "Sakshi Malik"],
    answer: "P.V. Sindhu",
    fact: "Sindhu captured silver in badminton singles in Rio 2016 and followed it with bronze in Tokyo 2020, becoming the first Indian woman double-medallist."
  },
  {
    id: "oly-5",
    sport: "Olympics",
    difficulty: "easy",
    q: "Who won India's first-ever Olympic medal in boxing (Bronze, Beijing 2008)?",
    options: ["Vijender Singh", "Mary Kom", "Lovlina Borgohain", "Akhil Kumar"],
    answer: "Vijender Singh",
    fact: "Vijender defeated Carlos Gongora of Ecuador in the middleweight quarterfinals to guarantee India's first Olympic boxing podium."
  },
  {
    id: "oly-6",
    sport: "Olympics",
    difficulty: "easy",
    q: "Mirabai Chanu won India's opening-day silver medal at Tokyo 2020 in which weightlifting weight category?",
    options: ["49 kg", "55 kg", "45 kg", "53 kg"],
    answer: "49 kg",
    fact: "Mirabai lifted 87kg in snatch and an Olympic clean & jerk record 115kg for a total of 202kg to claim silver."
  },
  {
    id: "oly-7",
    sport: "Olympics",
    difficulty: "hard",
    q: "Norman Pritchard won two silver medals for British India at the 1900 Paris Olympics in which events?",
    options: ["200m & 200m Hurdles", "100m & 200m", "110m Hurdles & Long Jump", "400m & 800m"],
    answer: "200m & 200m Hurdles",
    fact: "Pritchard was born in Calcutta and was the first Asian-born athlete to win an Olympic medal; he later became a Hollywood silent film actor under the name Norman Trevor."
  },
  {
    id: "oly-8",
    sport: "Olympics",
    difficulty: "hard",
    q: "Before 2024, who was the only Indian athlete to win individual Olympic medals at two separate Olympic Games in independent India?",
    options: ["Sushil Kumar", "K.D. Jadhav", "Yogeshwar Dutt", "Leander Paes"],
    answer: "Sushil Kumar",
    fact: "Sushil Kumar won wrestling bronze in Beijing 2008 and silver in London 2012 in the men's 66kg freestyle category."
  },

  /* ---------- PARA SPORTS ---------- */
  {
    id: "para-1",
    sport: "Para Sports",
    difficulty: "easy",
    q: "Which sensation became the world's first armless woman archer to win international medals using her legs and feet?",
    options: ["Sheetal Devi", "Avani Lekhara", "Bhavina Patel", "Deepa Malik"],
    answer: "Sheetal Devi",
    fact: "Born with phocomelia in Jammu & Kashmir, Sheetal Devi won double gold at the Asian Para Games 2022 and bronze at the Paris 2024 Paralympics at age 17."
  },
  {
    id: "para-2",
    sport: "Para Sports",
    difficulty: "easy",
    q: "Who broke the world record multiple times to win back-to-back Paralympic golds in javelin F64 (Tokyo 2020 & Paris 2024)?",
    options: ["Sumit Antil", "Devendra Jhajharia", "Sundar Singh Gurjar", "Navdeep Singh"],
    answer: "Sumit Antil",
    fact: "Sumit Antil set a staggering world record of 70.59m in Paris 2024, defending his Paralympic crown with supreme dominance."
  },
  {
    id: "para-3",
    sport: "Para Sports",
    difficulty: "easy",
    q: "Who was the first Indian woman to win a Paralympic gold medal (Tokyo 2020 10m Air Rifle SH1)?",
    options: ["Avani Lekhara", "Deepa Malik", "Bhavina Patel", "Ekta Bhyan"],
    answer: "Avani Lekhara",
    fact: "Avani Lekhara made history in Tokyo and went on to defend her gold medal at Paris 2024, becoming India's most successful female Paralympian."
  },
  {
    id: "para-4",
    sport: "Para Sports",
    difficulty: "easy",
    q: "Who is India's most decorated javelin Paralympian with two gold medals (2004, 2016) and one silver (2020)?",
    options: ["Devendra Jhajharia", "Sumit Antil", "Mariyappan Thangavelu", "Pramod Bhagat"],
    answer: "Devendra Jhajharia",
    fact: "Devendra set world records at Athens 2004 and Rio 2016 in the F46 category, and now serves as the President of the Paralympic Committee of India."
  },
  {
    id: "para-5",
    sport: "Para Sports",
    difficulty: "easy",
    q: "In which sport did Pramod Bhagat win India's first-ever Paralympic gold medal at Tokyo 2020?",
    options: ["Para Badminton", "Para Table Tennis", "Para Archery", "Para Shooting"],
    answer: "Para Badminton",
    fact: "Pramod Bhagat captured gold in the Men's Singles SL3 category in Tokyo as badminton made its long-awaited debut in the Paralympic Games."
  },
  {
    id: "para-6",
    sport: "Para Sports",
    difficulty: "hard",
    q: "Who won India's first-ever Paralympic gold medal in history at the Heidelberg 1972 Games?",
    options: ["Murlikant Petkar", "Bhimrao Kesarkar", "Devendra Jhajharia", "Joginder Singh Bedi"],
    answer: "Murlikant Petkar",
    fact: "Petkar, a war veteran of the 1965 India-Pakistan war who survived nine bullet wounds, clocked 37.33 seconds in the 50m freestyle swimming event to set a world record."
  },
  {
    id: "para-7",
    sport: "Para Sports",
    difficulty: "hard",
    q: "Deepa Malik made history as India's first female Paralympic medallist at Rio 2016 in which event?",
    options: ["Shot Put F53", "Javelin F53", "Discus F53", "Club Throw F51"],
    answer: "Shot Put F53",
    fact: "Deepa Malik threw 4.61m in the shot put F53 to win silver at age 45, proving that determination defies any physical barrier."
  },

  /* ---------- HOCKEY ---------- */
  {
    id: "hoc-1",
    sport: "Hockey",
    difficulty: "easy",
    q: "Which legendary hockey maestro led India to three consecutive Olympic golds (1928, 1932, 1936) and scored over 400 international goals?",
    options: ["Major Dhyan Chand", "K.D. Singh Babu", "Balbir Singh Sr.", "Roop Singh"],
    answer: "Major Dhyan Chand",
    fact: "Dhyan Chand's stick control was so magical that officials in the Netherlands once broke his hockey stick to check if there was a magnet hidden inside."
  },
  {
    id: "hoc-2",
    sport: "Hockey",
    difficulty: "easy",
    q: "After a 41-year medal wait, India's men's hockey team won Olympic bronze in Tokyo 2020 by defeating which nation 5-4?",
    options: ["Germany", "Australia", "Belgium", "Great Britain"],
    answer: "Germany",
    fact: "Down 1-3 early in the match, India mounted an unforgettable comeback with Simranjeet's brace and PR Sreejesh's penalty corner save in the final six seconds."
  },
  {
    id: "hoc-3",
    sport: "Hockey",
    difficulty: "easy",
    q: "Which iconic Indian goalkeeper earned the title 'The Wall' and bowed out after securing back-to-back Olympic bronze medals in Paris 2024?",
    options: ["PR Sreejesh", "Bharat Chetri", "Adrian D'Souza", "Devesh Chauhan"],
    answer: "PR Sreejesh",
    fact: "PR Sreejesh played over 330 international caps for India across nearly two decades and was named FIH World Goalkeeper of the Year multiple times."
  },
  {
    id: "hoc-4",
    sport: "Hockey",
    difficulty: "easy",
    q: "In which year did India win its only Men's FIH Hockey World Cup title in Kuala Lumpur?",
    options: ["1975", "1971", "1982", "1978"],
    answer: "1975",
    fact: "Captain Ajit Pal Singh led India, with Ashok Kumar (son of Major Dhyan Chand) scoring the famous winning goal against Pakistan in the final (2-1)."
  },
  {
    id: "hoc-5",
    sport: "Hockey",
    difficulty: "hard",
    q: "Who holds the Olympic record for the most goals scored by an individual in a men's Olympic hockey final (5 goals vs Netherlands, 1952)?",
    options: ["Balbir Singh Sr.", "Dhyan Chand", "Surjit Singh", "Roop Singh"],
    answer: "Balbir Singh Sr.",
    fact: "Balbir Singh Sr. scored 5 goals in India's 6-1 victory over the Netherlands in the Helsinki 1952 final — a Guinness World Record that remains untouched."
  },
  {
    id: "hoc-6",
    sport: "Hockey",
    difficulty: "hard",
    q: "Who scored the golden goal that gave the Indian women's hockey team gold at the 2002 Manchester Commonwealth Games?",
    options: ["Mamta Kharab", "Pritam Rani Siwach", "Jyoti Sunita Kullu", "Suraj Lata Devi"],
    answer: "Mamta Kharab",
    fact: "Mamta Kharab's overtime strike inspired the climax of the Bollywood film 'Chak De! India', cementing that gold medal in Indian pop culture."
  },

  /* ---------- BADMINTON ---------- */
  {
    id: "bad-1",
    sport: "Badminton",
    difficulty: "easy",
    q: "In May 2022, the Indian men's badminton team scripted history by winning which world team championship for the first time?",
    options: ["Thomas Cup", "Uber Cup", "Sudirman Cup", "All England Open"],
    answer: "Thomas Cup",
    fact: "India became only the 6th nation in 73 years to lift the Thomas Cup, sweeping 14-time champions Indonesia 3-0 in the Bangkok final."
  },
  {
    id: "bad-2",
    sport: "Badminton",
    difficulty: "easy",
    q: "Who was the first Indian badminton player to win the prestigious All England Open Championship in 1980?",
    options: ["Prakash Padukone", "Pullela Gopichand", "Syed Modi", "Dinesh Khanna"],
    answer: "Prakash Padukone",
    fact: "Padukone defeated Indonesia's Liem Swie King in straight sets (15-3, 15-10) in Wembley to achieve the World No. 1 ranking."
  },
  {
    id: "bad-3",
    sport: "Badminton",
    difficulty: "easy",
    q: "Who won India's first-ever Olympic medal in badminton with a bronze at London 2012?",
    options: ["Saina Nehwal", "P.V. Sindhu", "Jwala Gutta", "Ashwini Ponnappa"],
    answer: "Saina Nehwal",
    fact: "Saina Nehwal's historic bronze in London opened the floodgates for Indian badminton's modern global supremacy."
  },
  {
    id: "bad-4",
    sport: "Badminton",
    difficulty: "easy",
    q: "In 2019, who became the first Indian ever to be crowned BWF World Champion in badminton (Basel, Switzerland)?",
    options: ["P.V. Sindhu", "Saina Nehwal", "Kidambi Srikanth", "Lakshya Sen"],
    answer: "P.V. Sindhu",
    fact: "Sindhu blew away Nozomi Okuhara 21-7, 21-7 in just 38 minutes to capture gold after two consecutive silver medal finishes in 2017 and 2018."
  },
  {
    id: "bad-5",
    sport: "Badminton",
    difficulty: "easy",
    q: "What is the popular nickname of India's World No. 1 men's doubles pair, Satwiksairaj Rankireddy & Chirag Shetty?",
    options: ["Sat-Chi", "Chir-Sat", "Twin Towers", "Smash Bros"],
    answer: "Sat-Chi",
    fact: "Satwik and Chirag won the 2022 Commonwealth Games Gold, 2023 Asian Games Gold, Asian Championships, and multiple World Tour Super 1000 titles."
  },
  {
    id: "bad-6",
    sport: "Badminton",
    difficulty: "hard",
    q: "Who coached both Saina Nehwal to London 2012 bronze and P.V. Sindhu to Rio 2016 silver from his Hyderabad academy?",
    options: ["Pullela Gopichand", "Vimal Kumar", "Prakash Padukone", "U. Vimal"],
    answer: "Pullela Gopichand",
    fact: "Gopichand, himself the 2001 All England Champion, mortgaged his house to build the Gopichand Badminton Academy in Gachibowli, transforming Indian sport."
  },

  /* ---------- CHESS ---------- */
  {
    id: "che-1",
    sport: "Chess",
    difficulty: "easy",
    q: "Who became India's first International Grandmaster in 1988 and went on to become a 5-time World Chess Champion?",
    options: ["Viswanathan Anand", "P. Harikrishna", "Vidit Gujrathi", "Dibyendu Barua"],
    answer: "Viswanathan Anand",
    fact: "'Vishy' won World Championship matches against Kramnik, Topalov, and Gelfand, inspiring India's current generation of grandmaster wunderkinds."
  },
  {
    id: "che-2",
    sport: "Chess",
    difficulty: "easy",
    q: "In April 2024, which 17-year-old prodigy from Chennai won the FIDE Candidates Tournament to become the youngest World Championship challenger in history?",
    options: ["D Gukesh", "R Praggnanandhaa", "Arjun Erigaisi", "Nihal Sarin"],
    answer: "D Gukesh",
    fact: "Gukesh broke Garry Kasparov's 40-year-old record by winning the Candidates Tournament in Toronto at just 17 years and 11 months old."
  },
  {
    id: "che-3",
    sport: "Chess",
    difficulty: "easy",
    q: "Which teenage Indian grandmaster defeated Magnus Carlsen multiple times online and reached the 2023 FIDE World Cup final?",
    options: ["R Praggnanandhaa", "D Gukesh", "Arjun Erigaisi", "Raunak Sadhwani"],
    answer: "R Praggnanandhaa",
    fact: "'Pragg' reached the World Cup final in Baku at age 18, qualifying for the Candidates alongside his grandmaster sister Vaishali Rameshbabu."
  },
  {
    id: "che-4",
    sport: "Chess",
    difficulty: "easy",
    q: "In September 2024, India made history by winning double gold medals (open and women's teams) at which prestigious tournament in Budapest?",
    options: ["45th FIDE Chess Olympiad", "World Team Championship", "Asian Chess Championship", "FIDE World Cup"],
    answer: "45th FIDE Chess Olympiad",
    fact: "India dominated the Budapest Olympiad with historic individual gold performances on board 1 by D Gukesh (TPR 3056) and Arjun Erigaisi (TPR 2968)."
  },
  {
    id: "che-5",
    sport: "Chess",
    difficulty: "hard",
    q: "Who was India's first female Grandmaster, achieving the title in 2002 at the age of 15?",
    options: ["Koneru Humpy", "Dronavalli Harika", "Subbaraman Vijayalakshmi", "Tania Sachdev"],
    answer: "Koneru Humpy",
    fact: "At age 15 years, 1 month, and 27 days, Koneru Humpy broke Judit Polgar's record to become the youngest woman ever to achieve the men's Grandmaster title at that time."
  },

  /* ---------- KABADDI ---------- */
  {
    id: "kab-1",
    sport: "Kabaddi",
    difficulty: "easy",
    q: "Which legendary raider holds the all-time raid point record in Pro Kabaddi League history and is called the 'Dubki King'?",
    options: ["Pardeep Narwal", "Anup Kumar", "Pawan Sehrawat", "Rahul Chaudhari"],
    answer: "Pardeep Narwal",
    fact: "Pardeep Narwal became the first player in PKL history to cross 1,000, 1,500, and 1,700 raid points, famous for his trademark 8-point super raid against Haryana Steelers."
  },
  {
    id: "kab-2",
    sport: "Kabaddi",
    difficulty: "easy",
    q: "Which team won the inaugural season of the Pro Kabaddi League in 2014?",
    options: ["Jaipur Pink Panthers", "U Mumba", "Patna Pirates", "Bengaluru Bulls"],
    answer: "Jaipur Pink Panthers",
    fact: "Captain Navneet Gautam and star raider Maninder Singh guided the Pink Panthers to victory over U Mumba in the 2014 final at the Sardar Vallabhbhai Patel Stadium."
  },
  {
    id: "kab-3",
    sport: "Kabaddi",
    difficulty: "hard",
    q: "How many consecutive Asian Games gold medals did the Indian men's kabaddi team win between 1990 and 2014?",
    options: ["7 consecutive golds", "5 consecutive golds", "4 consecutive golds", "8 consecutive golds"],
    answer: "7 consecutive golds",
    fact: "From Beijing 1990 to Incheon 2014, India remained undefeated in men's kabaddi at the Asian Games for 24 uninterrupted years."
  },

  /* ---------- SHOOTING & WRESTLING & TENNIS ---------- */
  {
    id: "sho-1",
    sport: "Shooting",
    difficulty: "easy",
    q: "At Paris 2024, who became the first athlete in independent India's history to win two Olympic medals at a single edition?",
    options: ["Manu Bhaker", "Neeraj Chopra", "Sarabjot Singh", "Swapnil Kusale"],
    answer: "Manu Bhaker",
    fact: "Manu won bronze in the Women's 10m Air Pistol and followed it with bronze in the 10m Air Pistol Mixed Team event with Sarabjot Singh."
  },
  {
    id: "sho-2",
    sport: "Shooting",
    difficulty: "hard",
    q: "Who won India's first-ever individual Olympic silver medal in independent India (Athens 2004, Double Trap)?",
    options: ["Rajyavardhan Singh Rathore", "Abhinav Bindra", "Gagan Narang", "Vijay Kumar"],
    answer: "Rajyavardhan Singh Rathore",
    fact: "Col. Rathore hit 179 out of 200 targets in Athens, bringing India its first individual silver medal since Norman Pritchard in 1900."
  },
  {
    id: "wre-1",
    sport: "Wrestling",
    difficulty: "easy",
    q: "Who won India's first-ever Olympic medal in women's wrestling with a bronze in Rio 2016?",
    options: ["Sakshi Malik", "Vinesh Phogat", "Geeta Phogat", "Babita Kumari"],
    answer: "Sakshi Malik",
    fact: "Down 0-5 against Aisuluu Tynybekova of Kyrgyzstan, Sakshi Malik scored a dramatic 8-5 comeback in the repechage final to win bronze."
  },
  {
    id: "wre-2",
    sport: "Wrestling",
    difficulty: "easy",
    q: "At Paris 2024, who became India's youngest individual Olympic medallist at age 21 (Men's 57kg freestyle wrestling)?",
    options: ["Aman Sehrawat", "Bajrang Punia", "Ravi Dahiya", "Deepak Punia"],
    answer: "Aman Sehrawat",
    fact: "Orphaned at age 11, Aman trained at Chhatrasal Stadium and defeated Puerto Rico's Darian Cruz 13-5 to win Olympic bronze at 21 years and 24 days."
  },
  {
    id: "ten-1",
    sport: "Tennis",
    difficulty: "easy",
    q: "Who won India's first and only individual Olympic medal in tennis (Bronze, Atlanta 1996)?",
    options: ["Leander Paes", "Mahesh Bhupathi", "Rohan Bopanna", "Somdev Devvarman"],
    answer: "Leander Paes",
    fact: "Leander Paes defeated Fernando Meligeni of Brazil in the bronze medal playoff in Atlanta, playing with a wrist sprain and his legendary chest-thumping energy."
  },
  {
    id: "ten-2",
    sport: "Tennis",
    difficulty: "hard",
    q: "In January 2024, who became the oldest man in the Open Era (age 43) to win a Grand Slam men's doubles title at the Australian Open?",
    options: ["Rohan Bopanna", "Leander Paes", "Mahesh Bhupathi", "Sania Mirza"],
    answer: "Rohan Bopanna",
    fact: "Rohan Bopanna partnered Matthew Ebden to capture the Australian Open crown and ascended to the World No. 1 ranking at age 43 years and 329 days."
  },
  {
    id: "cue-1",
    sport: "Cue Sports",
    difficulty: "hard",
    q: "Which iconic Indian cueist has won a staggering 27 World Championship titles across Billiards and Snooker?",
    options: ["Pankaj Advani", "Geet Sethi", "Michael Ferreira", "Yasin Merchant"],
    answer: "Pankaj Advani",
    fact: "Pankaj Advani is the only player in the world to have won world titles in all formats of both Billiards and Snooker (timed and point formats)."
  }
];

/**
 * Fisher-Yates array shuffle utility
 */
export function fisherYates<T>(array: readonly T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/**
 * Generate a clean 8-question round with guaranteed 80/20 difficulty split:
 * - 6 Easy questions (Questions 1 to 6)
 * - 2 Hard boss questions (Questions 7 & 8)
 * - Options shuffled on every render
 */
export function generateQuizRound(): QuizQuestion[] {
  const easyPool = QUIZ_BANK.filter(q => q.difficulty === "easy");
  const hardPool = QUIZ_BANK.filter(q => q.difficulty === "hard");

  const chosenEasy = fisherYates(easyPool).slice(0, 6);
  const chosenHard = fisherYates(hardPool).slice(0, 2);

  // Return 6 easy questions followed by the 2 hard boss questions
  return [...chosenEasy, ...chosenHard];
}
