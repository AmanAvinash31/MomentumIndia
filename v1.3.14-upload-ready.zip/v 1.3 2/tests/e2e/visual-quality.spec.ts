import { test, expect } from "@playwright/test";

test.describe("Momentum India - Visual Quality & Zero-Ghosting Gates", () => {
  const pages = ["/", "/agent", "/news", "/fan-zone"];
  const themes = ["dark", "light"] as const;

  for (const theme of themes) {
    for (const path of pages) {
      test(`Verify effective opacity >= 0.99 on ${path} in ${theme} mode`, async ({ page }) => {
        await page.addInitScript((t) => {
          localStorage.setItem("momentum_theme", t);
          localStorage.setItem("momentum_cookie_consent", "accepted");
          document.documentElement.setAttribute("data-theme", t);
          document.documentElement.classList.toggle("dark", t === "dark");
        }, theme);

        await page.goto(path, { waitUntil: "networkidle" });

        // Scroll the entire page in increments to trigger any potential scroll reveals
        await page.evaluate(async () => {
          let lastY = -1;
          for (let step = 0; step < 30; step++) {
            window.scrollBy(0, 600);
            await new Promise((r) => setTimeout(r, 40));
            const curY = window.scrollY;
            if (curY === lastY) break;
            lastY = curY;
          }
          window.scrollTo(0, 0);
        });

        await page.waitForTimeout(300);

        // Check that NO visible text element has effective opacity < 0.99
        const lowOpacityCount = await page.evaluate(() => {
          const textNodes: Node[] = [];
          const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
          while (walker.nextNode()) {
            if (walker.currentNode.textContent && walker.currentNode.textContent.trim().length > 0) {
              textNodes.push(walker.currentNode);
            }
          }

          let lowOpacityElements = 0;
          for (const node of textNodes) {
            let el = node.parentElement;
            if (!el) continue;
            // Skip elements that are aria-hidden, script, or hidden
            if (el.closest("[aria-hidden='true'], [role='status'], script, style, noscript")) continue;
            const rect = el.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) continue;

            // Calculate effective opacity across ancestors
            let current: HTMLElement | null = el;
            let effectiveOpacity = 1;
            while (current && current !== document.body) {
              const comp = window.getComputedStyle(current);
              if (comp.display === "none" || comp.visibility === "hidden") {
                effectiveOpacity = 0;
                break;
              }
              const op = parseFloat(comp.opacity);
              if (!isNaN(op)) effectiveOpacity *= op;
              current = current.parentElement;
            }

            // If effective opacity is lower than 0.99 on a visible rendered element
            if (effectiveOpacity > 0 && effectiveOpacity < 0.985) {
              lowOpacityElements++;
            }
          }
          return lowOpacityElements;
        });

        expect(lowOpacityCount).toBe(0);
      });
    }
  }

  test("Language control must NOT exist at any width", async ({ page }) => {
    const viewports = [320, 360, 390, 768, 1280, 1440];
    for (const w of viewports) {
      await page.setViewportSize({ width: w, height: 800 });
      await page.goto("/", { waitUntil: "networkidle" });

      const langControls = page.locator("button:has-text('English'), button:has-text('हिन्दी'), button:has-text('ગુજરાતી'), [data-testid='lang-switch'], [data-testid^='button-article-lang-']");
      const count = await langControls.count();
      expect(count).toBe(0);
    }
  });

  test("Theme toggle has exactly TWO states (dark and light only)", async ({ page }) => {
    await page.goto("/", { waitUntil: "networkidle" });
    const toggle = page.locator("[data-testid='button-theme-toggle'], [data-testid='theme-toggle']").first();
    await expect(toggle).toBeVisible();

    // Click toggle and check <html> class
    const initialTheme = await page.evaluate(() => document.documentElement.getAttribute("data-theme"));
    expect(["dark", "light"]).toContain(initialTheme);

    await toggle.click();
    await page.waitForTimeout(200);

    const toggledTheme = await page.evaluate(() => document.documentElement.getAttribute("data-theme"));
    expect(["dark", "light"]).toContain(toggledTheme);
    expect(toggledTheme).not.toBe(initialTheme);

    // Toggle back
    await toggle.click();
    await page.waitForTimeout(200);

    const revertedTheme = await page.evaluate(() => document.documentElement.getAttribute("data-theme"));
    expect(revertedTheme).toBe(initialTheme);
  });

  test("No horizontal scroll at 320, 360, 390 and 430px", async ({ page }) => {
    const widths = [320, 360, 390, 430];
    for (const w of widths) {
      await page.setViewportSize({ width: w, height: 800 });
      for (const p of pages) {
        await page.goto(p, { waitUntil: "networkidle" });
        const hasHorizontalScroll = await page.evaluate(() => {
          return document.documentElement.scrollWidth > window.innerWidth;
        });
        expect(hasHorizontalScroll).toBe(false);
      }
    }
  });
});
