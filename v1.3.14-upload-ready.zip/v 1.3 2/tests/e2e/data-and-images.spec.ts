import { test, expect } from "@playwright/test";

const ROUTES = [
  "/",
  "/agent",
  "/news",
  "/fan-zone",
  "/schedule",
  "/sports",
  "/nations",
  "/hall-of-fame",
  "/sporting-nation",
  "/road-to-la-2028",
  "/pathway",
  "/facilities",
  "/stories",
  "/golden-moments",
  "/games/asian-para-games-2026",
  "/games/asian-games-2026",
  "/leagues",
  "/watch",
  "/about/sources",
];

const VIEWPORTS = [
  { name: "390px", width: 390, height: 844 },
  { name: "1440px", width: 1440, height: 900 },
];

const THEMES = ["dark", "light"] as const;

test.describe("Playwright Data & Image Audit Pass", () => {
  for (const vp of VIEWPORTS) {
    for (const theme of THEMES) {
      test(`Audit images and data integrity at ${vp.name} in ${theme} mode`, async ({ page }) => {
        test.setTimeout(180000);
        await page.setViewportSize({ width: vp.width, height: vp.height });

        const failedImages: { route: string; url: string; status?: number }[] = [];

        // Intercept failed responses
        page.on("response", (response) => {
          const url = response.url();
          const req = response.request();
          const resourceType = req.resourceType();
          const status = response.status();

          if (
            (resourceType === "image" || url.match(/\.(png|jpe?g|webp|svg|gif)(\?.*)?$/i)) &&
            status >= 400
          ) {
            failedImages.push({ route: page.url(), url, status });
          }
        });

        for (const route of ROUTES) {
          // Set theme
          await page.addInitScript((t) => {
            localStorage.setItem("momentum_theme", t);
            localStorage.setItem("momentum_cookie_consent", "accepted");
            document.documentElement.setAttribute("data-theme", t);
            document.documentElement.classList.toggle("dark", t === "dark");
          }, theme);

          const res = await page.goto(route, { waitUntil: "networkidle" });
          expect(res?.status()).toBeLessThan(400);

          // Scroll page in steps to trigger any lazy loaders or image tags
          await page.evaluate(async () => {
            let lastY = -1;
            for (let step = 0; step < 15; step++) {
              window.scrollBy(0, 800);
              await new Promise((r) => setTimeout(r, 30));
              if (window.scrollY === lastY) break;
              lastY = window.scrollY;
            }
            window.scrollTo(0, 0);
          });

          await page.waitForTimeout(200);

          // Check 1: No broken images without fallback
          const brokenImgElements = await page.evaluate(() => {
            const imgs = Array.from(document.querySelectorAll("img"));
            const broken: string[] = [];
            for (const img of imgs) {
              // If img has completed loading but naturalWidth is 0 and no error fallback tile
              if (img.complete && img.naturalWidth === 0) {
                // If the element or its parent is marked with data-image-fallback or hidden, skip
                if (!img.closest("[data-image-fallback='true']")) {
                  broken.push(img.src || img.getAttribute("src") || "unknown");
                }
              }
            }
            return broken;
          });

          expect(
            brokenImgElements,
            `Found broken img tags without fallback on ${route}: ${brokenImgElements.join(", ")}`
          ).toHaveLength(0);

          // Check 2: No visible "0 / 0 / 0" or "0-0-0-0" medal counter without data
          const hasZeroCounters = await page.evaluate((currentRoute) => {
            const zeroPatterns = [
              /\b0\s*-\s*0\s*-\s*0\s*-\s*0\b/,
              /\b0\s*\/\s*0\s*\/\s*0\b/,
              /0\s*Gold\s*,\s*0\s*Silver\s*,\s*0\s*Bronze/i,
            ];
            // Check all medal counters, triplets, and tnum number groups
            const medalElements = Array.from(document.querySelectorAll("[data-testid*='medal'], .medal-triplet, [class*='counter'], .tnum"));
            for (const el of medalElements) {
              const text = el.textContent || "";
              for (const p of zeroPatterns) {
                if (p.test(text)) return true;
              }
            }
            // General text check across data routes
            if (!currentRoute.includes("about") && !currentRoute.includes("faq")) {
              const bodyText = document.body.innerText;
              for (const p of zeroPatterns) {
                if (p.test(bodyText)) return true;
              }
            }
            return false;
          }, route);

          expect(
            hasZeroCounters,
            `Found forbidden '0 / 0 / 0' or '0-0-0-0' empty counter on ${route}`
          ).toBe(false);

          // Check 3: Blank areas taller than 160px
          const blankTallBoxes = await page.evaluate(() => {
            const cards = Array.from(document.querySelectorAll(".card, [data-card], section, article"));
            const blanks: string[] = [];
            for (const el of cards) {
              const rect = el.getBoundingClientRect();
              if (rect.height > 160 && rect.width > 200) {
                const text = el.textContent?.trim() || "";
                const hasImgs = el.querySelectorAll("img, svg, canvas").length > 0;
                if (text.length === 0 && !hasImgs) {
                  blanks.push(`${el.tagName}.${el.className} (${Math.round(rect.width)}x${Math.round(rect.height)})`);
                }
              }
            }
            return blanks;
          });

          expect(
            blankTallBoxes,
            `Found blank areas taller than 160px on ${route}: ${blankTallBoxes.join(", ")}`
          ).toHaveLength(0);

          // Check 4: Ended event checks on /games/asian-para-games-2026
          if (route === "/games/asian-para-games-2026") {
            const preEventPhrases = await page.evaluate(() => {
              const bodyText = document.body.innerText;
              const forbidden = [
                "Live Hub",
                "so far",
                "Starts in",
                "From 18 Oct",
                "Predict",
                "Add to calendar",
              ];
              const matches: string[] = [];
              for (const f of forbidden) {
                if (new RegExp(`\\b${f}\\b`, "i").test(bodyText)) {
                  matches.push(f);
                }
              }
              return matches;
            });

            expect(
              preEventPhrases,
              `Found pre-event phrases on ended event route ${route}: ${preEventPhrases.join(", ")}`
            ).toHaveLength(0);
          }

          // Check 5: No repeated stories on home page (/)
          if (route === "/") {
            const repeatedTitles = await page.evaluate(() => {
              // Gather story headline links or headings
              const titles = Array.from(
                document.querySelectorAll("[data-testid='top-stories-grid'] h3, [data-testid='top-stories-grid'] .font-bold")
              )
                .map((el) => el.textContent?.trim().toLowerCase())
                .filter((t): t is string => Boolean(t && t.length > 10));

              const seen = new Set<string>();
              const duplicates: string[] = [];
              for (const t of titles) {
                if (seen.has(t)) {
                  duplicates.push(t);
                }
                seen.add(t);
              }
              return duplicates;
            });

            expect(
              repeatedTitles,
              `Found repeated stories on home page: ${repeatedTitles.join("; ")}`
            ).toHaveLength(0);
          }
        }

        // Global check: no failed 404 images across any visited routes
        expect(
          failedImages,
          `Found 404 images during crawl: ${JSON.stringify(failedImages, null, 2)}`
        ).toHaveLength(0);
      });
    }
  }
});
