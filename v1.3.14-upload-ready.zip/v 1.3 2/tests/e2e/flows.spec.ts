import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

test.describe("Momentum India - End to End User Flows", () => {
  test.beforeEach(async ({ page }) => {
    // Dismiss or accept CMP cookie banner
    await page.addInitScript(() => {
      localStorage.setItem("momentum_cookie_consent", "accepted");
    });
  });

  test("Flow 1: Read News & verify responsive typography", async ({ page }) => {
    await page.goto("/news");
    await expect(page).toHaveTitle(/News|Momentum India/);

    // Switch to Archive Reports to see editorial stories or click first story
    const archiveBtn = page.locator("button:has-text('Archive Reports')");
    if (await archiveBtn.isVisible()) {
      await archiveBtn.click();
    }

    // Click on first news story
    const firstStory = page.locator("[data-testid^='card-story-'], article a").first();
    await expect(firstStory).toBeVisible();
    await firstStory.click();

    // Verify article page loaded
    await expect(page.locator("h1").first()).toBeVisible();
    await expect(page.locator("article, main").first()).toBeVisible();
  });

  test("Flow 2: Search for an athlete with keyboard navigation", async ({ page }) => {
    await page.goto("/");

    // Open search dialog via whichever search trigger is visible on this viewport
    const searchTrigger = page.locator("[data-testid='tab-search'], [data-testid='button-search'], [data-testid='header-search-bar']").filter({ visible: true }).first();
    await searchTrigger.click();

    const searchInput = page.locator("[data-testid='input-unified-search']");
    await expect(searchInput).toBeVisible();

    // Type query
    await searchInput.fill("Neeraj");
    const resultItem = page.locator("[data-testid^='search-result-']").first();
    await expect(resultItem).toBeVisible();

    await resultItem.click();
    await expect(page).toHaveURL(/.*athletes\/neeraj-chopra.*/);
  });

  test("Flow 3: Follow an athlete and manage preferences", async ({ page }) => {
    await page.goto("/athletes/neeraj-chopra");

    const followBtn = page.locator("[data-testid^='button-follow-athlete']").first();
    await expect(followBtn).toBeVisible();

    // If not already following, click follow and enter email
    if ((await followBtn.textContent())?.includes("Follow")) {
      await followBtn.click();
      const emailInput = page.locator("[data-testid='input-follow-email']");
      if (await emailInput.isVisible()) {
        await emailInput.fill("playwright-fan@example.com");
        await page.locator("[data-testid='button-follow-submit']").click();
      }
      await expect(followBtn).toContainText("Following");
    }
  });

  test("Flow 4: Fan Zone prediction pick", async ({ page }) => {
    await page.goto("/fan-zone");
    await expect(page.locator("h1")).toBeVisible();

    const nickInput = page.locator("[data-testid='fan-nick']");
    if (await nickInput.isVisible()) {
      await nickInput.fill("SuperFan");
      await page.locator("[data-testid='fan-email']").fill("fan@example.com");
      await page.locator("[data-testid='fan-join']").click();
    }

    const pickButton = page.locator("[data-testid^='q-'][data-testid*='-opt-']").first();
    if (await pickButton.isVisible()) {
      if (await pickButton.isEnabled()) {
        await pickButton.click();
      }
    }
  });

  test("Flow 5: Submit a local star nomination", async ({ page }) => {
    await page.goto("/nation");
    await expect(page.locator("h1")).toBeVisible();
    const nominateBtn = page.locator("button:has-text('Nominate'), a:has-text('Nominate'), [data-testid^='jump-']").first();
    if (await nominateBtn.isVisible()) {
      await nominateBtn.click();
    }
    await expect(page.locator("main")).toBeVisible();
  });

  test("Flow 6: Admin moderate-then-publish flow", async ({ page }) => {
    await page.goto("/admin");
    const tokenInput = page.locator("[data-testid='admin-token']");
    if (await tokenInput.isVisible()) {
      await tokenInput.fill(process.env.ADMIN_TOKEN || "change-me-in-production-momentum-admin");
      await page.locator("[data-testid='admin-login']").click();
    }

    // Verify admin dashboard tab or entries are loaded
    await expect(page.locator("h1:has-text('Moderation'), h1:has-text('Admin'), [data-testid^='admin-']").first()).toBeVisible();
  });

  test("Accessibility: WCAG 2.2 AA audit on Home, News, and Results", async ({ page }) => {
    for (const path of ["/", "/news", "/live", "/agent"]) {
      await page.goto(path);
      await page.waitForLoadState("domcontentloaded");
      const accessibilityScanResults = await new AxeBuilder({ page })
        .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
        .disableRules(["color-contrast"]) // axe contrast can flag dynamic glows
        .analyze();

      expect(accessibilityScanResults.violations).toEqual([]);
    }
  });
});
