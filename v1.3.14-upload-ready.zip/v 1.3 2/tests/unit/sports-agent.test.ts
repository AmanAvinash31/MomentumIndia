import { describe, it, expect } from "vitest";
import { extractLiteralScore, cleanText, formatISTDate } from "../../server/sports-agent";
import { coerce } from "../../server/routes-live";
import { Limit } from "../../server/routes-agent";
import { z } from "zod";

describe("extractLiteralScore unit tests", () => {
  it("must NOT parse as scores: 21-19, 18-21, 21-18", () => {
    expect(extractLiteralScore("21-19, 18-21, 21-18")).toBeNull();
  });

  it("must NOT parse as scores: 2026-27", () => {
    expect(extractLiteralScore("ISL 2026-27 season kicks off")).toBeNull();
    expect(extractLiteralScore("2026-27")).toBeNull();
  });

  it("must NOT parse as scores: 24-year-old", () => {
    expect(extractLiteralScore("The 24-year-old athlete claimed victory")).toBeNull();
    expect(extractLiteralScore("24-year-old")).toBeNull();
  });

  it("must NOT parse as scores: 18-24 October", () => {
    expect(extractLiteralScore("Competition runs 18-24 October 2026")).toBeNull();
    expect(extractLiteralScore("18-24 October")).toBeNull();
  });

  it("must NOT parse as scores: 4/5 stars", () => {
    expect(extractLiteralScore("Rated 4/5 stars by reviewers")).toBeNull();
    expect(extractLiteralScore("4/5 stars")).toBeNull();
  });

  it("must parse valid cricket score: 115/4", () => {
    expect(extractLiteralScore("India were 115/4 at stumps")).toBe("115/4");
    expect(extractLiteralScore("115/4")).toBe("115/4");
  });

  it("parses cricket victory margins and single match scorelines", () => {
    expect(extractLiteralScore("India won by 6 wickets against Pakistan")).toBe("won by 6 wickets");
    expect(extractLiteralScore("Bengaluru FC beat FC Goa 3-1 in thrilling match")).toBe("3-1");
  });
});

describe("cleanText unit tests", () => {
  it("strips CDATA blocks cleanly", () => {
    expect(cleanText("<![CDATA[PV Sindhu wins opening round]]>")).toBe("PV Sindhu wins opening round");
  });

  it("strips HTML tags and decodes HTML entities", () => {
    const raw = "<p>India &amp; Japan <b>contest</b> final match &lt;Day 3&gt; &#39;live&#39;</p>";
    expect(cleanText(raw)).toBe("India & Japan contest final match <Day 3> 'live'");
  });

  it("normalizes and trims whitespace", () => {
    expect(cleanText("   Multiple    spaces   between   words   ")).toBe("Multiple spaces between words");
  });
});

describe("formatISTDate at midnight 00:00", () => {
  it("formats correctly across timezone boundary (18:30 UTC = 00:00 IST next day)", () => {
    // 2026-10-24 18:30:00 UTC is exactly 2026-10-25 00:00:00 IST
    const midnightUtc = new Date("2026-10-24T18:30:00.000Z");
    expect(formatISTDate(midnightUtc)).toBe("2026-10-25");

    // 2026-10-24 18:29:59 UTC is still 2026-10-24 in IST
    const justBefore = new Date("2026-10-24T18:29:59.000Z");
    expect(formatISTDate(justBefore)).toBe("2026-10-24");
  });
});

describe("coerce() validator tests", () => {
  const fields = [
    { name: "athlete", label: "Athlete", type: "text" as const, required: true, max: 50 },
    { name: "score", label: "Score", type: "number" as const, required: true },
    { name: "category", label: "Category", type: "select" as const, options: ["gold", "silver", "bronze"], required: true },
    { name: "event_date", label: "Event Date", type: "date" as const },
    { name: "event_time", label: "Event Time", type: "datetime" as const },
  ];

  it("coerces and validates valid body", () => {
    const body = {
      athlete: "Neeraj Chopra",
      score: "89",
      category: "gold",
      event_date: "2026-10-20",
      event_time: "2026-10-20T10:00:00Z",
    };
    const res = coerce(fields, body, false);
    expect(res.error).toBeUndefined();
    expect(res.row?.athlete).toBe("Neeraj Chopra");
    expect(res.row?.score).toBe(89);
    expect(res.row?.category).toBe("gold");
  });

  it("rejects missing required field in non-partial mode", () => {
    const body = { athlete: "Neeraj Chopra" };
    const res = coerce(fields, body, false);
    expect(res.error).toContain("required");
  });

  it("rejects non-numeric values for number fields", () => {
    const body = { athlete: "Neeraj", score: "not-a-number", category: "gold" };
    const res = coerce(fields, body, false);
    expect(res.error).toContain("must be a number");
  });

  it("rejects invalid select options", () => {
    const body = { athlete: "Neeraj", score: 89, category: "platinum" };
    const res = coerce(fields, body, false);
    expect(res.error).toContain("must be one of gold, silver, bronze");
  });
});

describe("Limit helper validator tests", () => {
  const newsLimit = Limit(50, 100);

  it("returns default when limit is invalid or omitted", () => {
    expect(newsLimit.parse(undefined)).toBe(50);
    expect(newsLimit.parse("abc")).toBe(50);
    expect(newsLimit.parse(-1)).toBe(1); // clamped to 1
  });

  it("clamps large values to max", () => {
    expect(newsLimit.parse("1000000000")).toBe(100);
    expect(newsLimit.parse(500)).toBe(100);
  });

  it("allows valid limits within bounds", () => {
    expect(newsLimit.parse("25")).toBe(25);
    expect(newsLimit.parse(75)).toBe(75);
  });
});
