import { describe, it, expect } from "vitest";
import { agentStorage } from "../../server/storage";

describe("addResult deduplication tests", () => {
  it("deduplicates identical normalized headlines and identical URLs", () => {
    const item1 = {
      sport: "Athletics",
      date_ist: "2026-10-25",
      headline: "Neeraj Chopra Wins Gold With 89.45m Throw",
      score_text: "89.45m",
      source: "PIB Sports",
      url: "https://pib.gov.in/test-unique-result-1",
      published_at: "2026-10-25T10:00:00Z",
    };

    const id1 = agentStorage.addResult(item1);
    expect(id1).toBeGreaterThan(0);

    // 1. Same URL should return id1
    const id2 = agentStorage.addResult({
      ...item1,
      headline: "Slightly Different Headline But Same URL",
    });
    expect(id2).toBe(id1);

    // 2. Same normalized headline (case insensitive) should return id1
    const id3 = agentStorage.addResult({
      ...item1,
      url: "https://pib.gov.in/test-different-url",
      headline: "  neeraj chopra wins gold with 89.45m throw  ",
    });
    expect(id3).toBe(id1);

    // 3. Brand new item should return a new ID
    const id4 = agentStorage.addResult({
      sport: "Badminton",
      date_ist: "2026-10-25",
      headline: "Satwik and Chirag Win French Open Final",
      score_text: "won by 2 sets",
      source: "BWF",
      url: "https://bwf.org/test-unique-result-2",
      published_at: "2026-10-25T11:00:00Z",
    });
    expect(id4).toBeGreaterThan(0);
    expect(id4).not.toBe(id1);
  });
});
