import { describe, it, expect } from "vitest";
import {
  wikipediaMedalsProvider,
  validateMedalTableSanity,
} from "../../server/providers/wikipedia-medals";
import { theSportsDbProvider } from "../../server/providers/thesportsdb";
import { GDELTNewsProvider } from "../../server/providers/gdelt";
import { getEventStatus, getNowIST } from "../../shared/lifecycle";
import type { MedalTableRow } from "../../server/providers/types";

/* -------------------------------------------------------------
   FIXTURES: Recorded real-world and synthetic edge-case samples
------------------------------------------------------------- */

const WIKITEXT_SAMPLE = `
{| class="wikitable sortable plainrowheaders" style="text-align:center"
|-
! scope="col" | Rank
! scope="col" | Nation
! scope="col" style="background:#f7f6a8;" | Gold
! scope="col" style="background:#dce5e5;" | Silver
! scope="col" style="background:#ffddab;" | Bronze
! scope="col" | Total
|-
| 1 || align="left" | {{flagIOC2team|CHN|2026 Asian Games}} || 201 || 111 || 71 || 383
|-
| 2 || align="left" | {{flagIOC2team|JPN|2026 Asian Games}} || 52 || 67 || 69 || 188
|-
| 3 || align="left" | {{flagIOC2team|KOR|2026 Asian Games}} || 42 || 59 || 89 || 190
|-
| 4 || align="left" | {{flagIOC2team|IND|2026 Asian Games}} || 21 || 27 || 37 || 85
|-
| 5 || align="left" | {{flagIOC2team|UZB|2026 Asian Games}} || 22 || 18 || 31 || 71
|}
`;

const WIKITEXT_MALFORMED = `
Random unstructured text that is not a wikitable.
No brackets, no pipes, just plain strings.
`;

const THESPORTSDB_STANDINGS_FIXTURE = {
  table: [
    {
      idStanding: "123",
      intRank: "1",
      idTeam: "135882",
      strTeam: "Mohun Bagan Super Giant",
      strBadge: "https://www.thesportsdb.com/images/media/team/badge/mohun.png",
      idLeague: "4791",
      strLeague: "Indian Super League",
      strSeason: "2025-2026",
      strForm: "WWWDW",
      strDescription: "",
      intPlayed: "6",
      intWin: "4",
      intLoss: "0",
      intDraw: "2",
      intGoalsFor: "12",
      intGoalsAgainst: "5",
      intGoalDifference: "7",
      intPoints: "14",
    },
    {
      idStanding: "124",
      intRank: "2",
      idTeam: "135883",
      strTeam: "Bengaluru FC",
      strBadge: "",
      idLeague: "4791",
      strLeague: "Indian Super League",
      strSeason: "2025-2026",
      strForm: "WWWWL",
      strDescription: "",
      intPlayed: "6",
      intWin: "4",
      intLoss: "1",
      intDraw: "1",
      intGoalsFor: "10",
      intGoalsAgainst: "4",
      intGoalDifference: "6",
      intPoints: "13",
    },
  ],
};

const GDELT_FIXTURE = {
  articles: [
    {
      url: "https://timesofindia.indiatimes.com/sports/asian-games/india-medals-tally",
      title: "India finish 4th at Asian Games 2026 with 85 medals haul",
      seendate: "20261005T143000Z",
      socialimage: "https://static.toiimg.com/thumb/msid-123.jpg",
      domain: "timesofindia.indiatimes.com",
      language: "English",
      sourcecountry: "India",
    },
    {
      url: "https://sportstar.thehindu.com/athletics/sheetal-devi-gold-asian-para-games",
      title: "Sheetal Devi strikes double gold in archery at Asian Para Games",
      seendate: "20261022T091500Z",
      socialimage: null,
      domain: "sportstar.thehindu.com",
      language: "English",
      sourcecountry: "India",
    },
  ],
};

/* -------------------------------------------------------------
   UNIT TESTS
------------------------------------------------------------- */

describe("Wikipedia Medals Provider Parser & Sanity", () => {
  it("parses valid MediaWiki wikitext into structured medal rows", () => {
    const rows = wikipediaMedalsProvider.parseWikitextTable(WIKITEXT_SAMPLE);
    expect(rows.length).toBe(5);

    const ind = rows.find((r) => r.nation === "India");
    expect(ind).toBeDefined();
    expect(ind?.rank).toBe(4);
    expect(ind?.gold).toBe(21);
    expect(ind?.silver).toBe(27);
    expect(ind?.bronze).toBe(37);
    expect(ind?.total).toBe(85);
  });

  it("handles malformed wikitext gracefully without throwing", () => {
    const rows = wikipediaMedalsProvider.parseWikitextTable(WIKITEXT_MALFORMED);
    expect(Array.isArray(rows)).toBe(true);
    expect(rows.length).toBe(0);
  });

  it("sanity check: passes when G + S + B === Total across all rows", () => {
    const validRows: MedalTableRow[] = [
      { rank: 1, nation: "China", gold: 200, silver: 100, bronze: 50, total: 350 },
      { rank: 2, nation: "India", gold: 20, silver: 20, bronze: 20, total: 60 },
    ];
    const res = validateMedalTableSanity(validRows);
    expect(res.valid).toBe(true);
    expect(res.errors).toHaveLength(0);
  });

  it("sanity check: rejects row with math mismatch G + S + B !== Total", () => {
    const corruptRows: MedalTableRow[] = [
      { rank: 1, nation: "China", gold: 200, silver: 100, bronze: 50, total: 350 },
      { rank: 2, nation: "India", gold: 20, silver: 20, bronze: 20, total: 99 }, // 20+20+20 = 60 != 99
    ];
    const res = validateMedalTableSanity(corruptRows);
    expect(res.valid).toBe(false);
    expect(res.errors[0]).toContain("Math mismatch for India");
  });

  it("sanity check: rejects live total decreasing", () => {
    const prevRows: MedalTableRow[] = [
      { rank: 4, nation: "India", gold: 20, silver: 25, bronze: 35, total: 80 },
    ];
    const newDecreasedRows: MedalTableRow[] = [
      { rank: 4, nation: "India", gold: 18, silver: 25, bronze: 35, total: 78 },
    ];
    const res = validateMedalTableSanity(newDecreasedRows, prevRows, true /* isLive */);
    expect(res.valid).toBe(false);
    expect(res.errors[0]).toContain("Total decreased during live games: was 80, now 78");
  });

  it("sanity check: rejects row set that shrinks by > 5%", () => {
    // 20 rows down to 10 rows is a 50% shrinkage (> 5%)
    const prevRows: MedalTableRow[] = Array.from({ length: 20 }, (_, i) => ({
      rank: i + 1,
      nation: `Nation ${i + 1}`,
      gold: 1,
      silver: 1,
      bronze: 1,
      total: 3,
    }));
    const shrunkRows: MedalTableRow[] = Array.from({ length: 10 }, (_, i) => ({
      rank: i + 1,
      nation: `Nation ${i + 1}`,
      gold: 1,
      silver: 1,
      bronze: 1,
      total: 3,
    }));

    const res = validateMedalTableSanity(shrunkRows, prevRows, false);
    expect(res.valid).toBe(false);
    expect(res.errors[0]).toContain("Row set shrank by more than 5%");
  });
});

describe("TheSportsDB Standings & Data Ingestion", () => {
  it("processes standings data correctly from API structure", () => {
    const standings = THESPORTSDB_STANDINGS_FIXTURE.table.map((row, idx) => ({
      rank: idx + 1,
      team: row.strTeam,
      played: parseInt(row.intPlayed, 10),
      won: parseInt(row.intWin, 10),
      drawn: parseInt(row.intDraw, 10),
      lost: parseInt(row.intLoss, 10),
      points: parseInt(row.intPoints, 10),
      goalDiff: parseInt(row.intGoalDifference, 10),
    }));

    expect(standings).toHaveLength(2);
    expect(standings[0].team).toBe("Mohun Bagan Super Giant");
    expect(standings[0].points).toBe(14);
    expect(standings[1].team).toBe("Bengaluru FC");
    expect(standings[1].goalDiff).toBe(6);
  });

  it("handles malformed/null API response gracefully with fallback", async () => {
    const res = await theSportsDbProvider.getStandings();
    expect(res).toBeDefined();
    expect(res.standings.length).toBeGreaterThan(0);
    expect(res.source).toBeDefined();
  });
});

describe("GDELT DOC 2.0 Ingest & Parsing", () => {
  it("parses GDELT articles into standardized news models with ISO timestamps", () => {
    const items = GDELT_FIXTURE.articles.map((a) => {
      let pubDate = "";
      if (a.seendate && a.seendate.length >= 8) {
        const yr = a.seendate.slice(0, 4);
        const mo = a.seendate.slice(4, 6);
        const da = a.seendate.slice(6, 8);
        pubDate = `${yr}-${mo}-${da}T12:00:00Z`;
      }
      return {
        title: a.title,
        url: a.url,
        publishedAt: pubDate,
        source: a.domain ? `GDELT (${a.domain})` : "GDELT",
      };
    });

    expect(items).toHaveLength(2);
    expect(items[0].publishedAt).toBe("2026-10-05T12:00:00Z");
    expect(items[1].source).toBe("GDELT (sportstar.thehindu.com)");
  });
});

describe("Shared Event Lifecycle Helper", () => {
  it("determines Upcoming status for future games", () => {
    const res = getEventStatus("2028-07-14", "2028-07-30", "2026-10-25");
    expect(res.status).toBe("Upcoming");
    expect(res.isUpcoming).toBe(true);
    expect(res.isLive).toBe(false);
    expect(res.isEnded).toBe(false);
    expect(res.daysToStart).toBeGreaterThan(0);
  });

  it("determines Live status when current date is between start and end", () => {
    const res = getEventStatus("2026-10-20", "2026-10-30", "2026-10-25");
    expect(res.status).toBe("Live");
    expect(res.isLive).toBe(true);
  });

  it("determines Ended status when current date is past end date", () => {
    const res = getEventStatus("2026-10-18", "2026-10-24", "2026-10-25");
    expect(res.status).toBe("Ended");
    expect(res.isEnded).toBe(true);
    expect(res.daysSinceEnd).toBeGreaterThan(0);
  });
});
