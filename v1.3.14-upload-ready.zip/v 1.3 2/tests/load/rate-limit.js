import http from "k6/http";
import { check, sleep } from "k6";

export const options = {
  scenarios: {
    write_abuse: {
      executor: "constant-arrival-rate",
      rate: 100, // 100 requests per second
      timeUnit: "1s",
      duration: "30s",
      preAllocatedVUs: 50,
      maxVUs: 100,
    },
  },
  thresholds: {
    // We expect rate limiting (429) to kick in and protect the server
    "http_req_failed": ["rate>0.5"], // Over 50% should be blocked by rate limiter
  },
};

const BASE_URL = __ENV.BASE_URL || "http://127.0.0.1:5000";

export default function () {
  const payload = JSON.stringify({
    email: `spammer_${__VU}_${__ITER}@example.com`,
  });

  const params = {
    headers: {
      "Content-Type": "application/json",
      // All requests simulate the same originating IP
      "X-Forwarded-For": "203.0.113.195",
    },
  };

  const res = http.post(`${BASE_URL}/api/subscribe`, payload, params);

  // Once 30 requests within 10 minutes are exceeded, server must return 429
  check(res, {
    "rate limiter triggers 429": (r) => r.status === 429 || r.status === 201 || r.status === 200,
  });
}
