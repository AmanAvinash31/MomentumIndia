import http from "k6/http";
import { check, sleep } from "k6";

export const options = {
  stages: [
    { duration: "60s", target: 5000 }, // Spike from 0 to 5,000 VUs in 60s
    { duration: "30s", target: 5000 }, // Hold peak
    { duration: "30s", target: 0 },    // Ramp-down
  ],
  thresholds: {
    // p99 latency under 300ms
    http_req_duration: ["p(99)<300"],
    // Error rate under 0.5%
    http_req_failed: ["rate<0.005"],
  },
};

const BASE_URL = __ENV.BASE_URL || "http://127.0.0.1:5000";

export default function () {
  // Test both cached public endpoints
  const res1 = http.get(`${BASE_URL}/api/agent/results?limit=50`);
  check(res1, {
    "results status is 200 or 304": (r) => r.status === 200 || r.status === 304,
    "results has cache-control": (r) => r.headers["Cache-Control"] !== undefined,
  });

  const res2 = http.get(`${BASE_URL}/api/live/apg2026`);
  check(res2, {
    "live medals status is 200": (r) => r.status === 200,
  });

  sleep(0.1);
}
