import http from "k6/http";
import { check, sleep } from "k6";

export const options = {
  stages: [
    { duration: "2m", target: 500 },  // Ramp-up to 500 users
    { duration: "30m", target: 500 }, // 30-minute steady soak
    { duration: "2m", target: 0 },    // Ramp-down
  ],
  thresholds: {
    // p95 latency under 200ms
    http_req_duration: ["p(95)<200"],
    // Error rate under 0.1%
    http_req_failed: ["rate<0.001"],
  },
};

const BASE_URL = __ENV.BASE_URL || "http://127.0.0.1:5000";

export default function () {
  // Rotate through common public routes
  const endpoints = [
    "/api/agent/news?limit=25",
    "/api/agent/results?limit=50",
    "/api/live/apg2026",
    "/api/articles",
    "/api/fixtures?league=isl",
  ];

  const url = `${BASE_URL}${endpoints[Math.floor(Math.random() * endpoints.length)]}`;
  const res = http.get(url);

  check(res, {
    "status is 200 or 304": (r) => r.status === 200 || r.status === 304,
  });

  sleep(1);
}
