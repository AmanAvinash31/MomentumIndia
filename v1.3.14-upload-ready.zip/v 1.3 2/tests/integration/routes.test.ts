import { describe, it, expect, beforeAll } from "vitest";
import request from "supertest";
import express from "express";
import { createServer } from "node:http";
import { registerRoutes, sanitizeCsvCell } from "../../server/routes";
import { generateManageToken } from "../../server/manage-token";
import { fetchFeedSafely } from "../../server/sports-agent";
import { fan } from "../../server/storage";

let app: express.Express;

beforeAll(async () => {
  app = express();
  app.use(express.json({ limit: "64kb" }));
  app.use(express.urlencoded({ extended: false, limit: "64kb" }));
  const server = createServer(app);
  await registerRoutes(server, app);
});

describe("Integration Tests - Security & Query Boundaries", () => {
  it("bounds limits on /api/agent/news and /api/agent/results (never dumps table)", async () => {
    // 1. limit = -1
    const resNeg = await request(app).get("/api/agent/news?limit=-1");
    expect(resNeg.status).toBe(200);
    expect(Array.isArray(resNeg.body.news)).toBe(true);
    expect(resNeg.body.news.length).toBeLessThanOrEqual(50);

    // 2. limit = abc
    const resAbc = await request(app).get("/api/agent/news?limit=abc");
    expect(resAbc.status).toBe(200);
    expect(Array.isArray(resAbc.body.news)).toBe(true);
    expect(resAbc.body.news.length).toBeLessThanOrEqual(50);

    // 3. limit = 1e9 (must be clamped to max 100)
    const resHuge = await request(app).get("/api/agent/news?limit=1000000000");
    expect(resHuge.status).toBe(200);
    expect(Array.isArray(resHuge.body.news)).toBe(true);
    expect(resHuge.body.news.length).toBeLessThanOrEqual(100);

    // Results table limit = 1e9 (clamped to max 200)
    const resResults = await request(app).get("/api/agent/results?limit=1000000000");
    expect(resResults.status).toBe(200);
    expect(Array.isArray(resResults.body.results)).toBe(true);
    expect(resResults.body.results.length).toBeLessThanOrEqual(200);
  });

  it("rejects sport=%00 null byte with 400 Bad Request", async () => {
    const res = await request(app).get("/api/agent/news?sport=%00");
    expect(res.status).toBe(400);
    expect(res.body.message).toContain("Invalid characters in query parameter");
  });

  it("rejects oversize request bodies (> 64kb) with 413", async () => {
    const oversizeBody = {
      email: "test@example.com",
      junk: "x".repeat(70 * 1024), // 70 KB
    };
    const res = await request(app).post("/api/subscribe").send(oversizeBody);
    expect(res.status).toBe(413);
  });
});

describe("Integration Tests - PII Protection and Manage Tokens", () => {
  const email = "fan.athlete+olympics@example.com";
  const token = generateManageToken(email);

  it("blocks unauthenticated access to /api/follow/:email with 403", async () => {
    const res = await request(app).get(`/api/follow/${encodeURIComponent(email)}`);
    expect(res.status).toBe(403);
    expect(res.body.message).toContain("manage token is required");
  });

  it("allows access to /api/follow/:email when valid x-manage-token header is present", async () => {
    const res = await request(app)
      .get(`/api/follow/${encodeURIComponent(email)}`)
      .set("x-manage-token", token);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.follows)).toBe(true);
  });

  it("blocks DELETE /api/subscribe/:email without token with 403", async () => {
    const res = await request(app).delete(`/api/subscribe/${encodeURIComponent(email)}`);
    expect(res.status).toBe(403);
  });

  it("prevents email enumeration on GET /api/subscribe/:email", async () => {
    // Both existing and non-existing emails should return identical 200 response when valid token is provided
    const resExists = await request(app)
      .get(`/api/subscribe/${encodeURIComponent(email)}`)
      .set("x-manage-token", token);
    expect(resExists.status).toBe(200);
    expect(resExists.body).toHaveProperty("subscribed");

    const nonExistent = "doesnotexist999@example.com";
    const nonToken = generateManageToken(nonExistent);
    const resNon = await request(app)
      .get(`/api/subscribe/${encodeURIComponent(nonExistent)}`)
      .set("x-manage-token", nonToken);
    expect(resNon.status).toBe(200);
    expect(resNon.body).toHaveProperty("subscribed");
  });

  it("handles email variations (+, mixed case, percent-encoding) cleanly", async () => {
    const mixedEmail = "User.Special+Tag@Example.COM";
    const subRes = await request(app).post("/api/subscribe").send({ email: mixedEmail });
    expect([200, 201]).toContain(subRes.status);
    expect(subRes.body).toHaveProperty("manage_token");

    const followRes = await request(app).post("/api/follow").send({
      email: mixedEmail,
      items: [{ kind: "sport", key: "hockey", label: "Hockey" }],
    });
    expect([200, 201]).toContain(followRes.status);
    expect(followRes.body).toHaveProperty("manage_token");
  });
});

describe("Integration Tests - CSV Formula Injection Neutralization", () => {
  it("neutralizes formula injection characters (= + - @ \\t \\r) by prepending '", () => {
    expect(sanitizeCsvCell("=SUM(A1:B10)")).toBe("\"'=SUM(A1:B10)\"");
    expect(sanitizeCsvCell("+1234567890")).toBe("\"'+1234567890\"");
    expect(sanitizeCsvCell("-cmd /c calc")).toBe("\"'-cmd /c calc\"");
    expect(sanitizeCsvCell("@SUM")).toBe("\"'@SUM\"");
    expect(sanitizeCsvCell("\tTabIndent")).toBe("\"'\tTabIndent\"");
    expect(sanitizeCsvCell("\rCarriageReturn")).toBe("\"'\rCarriageReturn\"");

    // Regular strings formatted in quotes
    expect(sanitizeCsvCell("Neeraj Chopra")).toBe('"Neeraj Chopra"');

    // Numeric values should never be prefixed with '
    expect(sanitizeCsvCell(100)).toBe("100");
    expect(sanitizeCsvCell(42.5)).toBe("42.5");
    expect(sanitizeCsvCell(null)).toBe('""');
  });
});

describe("Integration Tests - Fan Zone Picks & Concurrency", () => {
  it("rejects fan-zone pick at or after closes_at with 409", async () => {
    const res = await request(app).post("/api/fan/pick").send({
      qid: 1, // ISL opener question was 2026-10-10
      choice: "Bengaluru FC",
      nickname: "TestFan",
      email: "testfan@example.com",
    });
    expect([404, 409]).toContain(res.status);
  });

  it("handles double picks cleanly without corrupting leaderboard", async () => {
    const res1 = await request(app).post("/api/fan/pick").send({
      qid: 1,
      choice: "Bengaluru FC",
      nickname: "DoublePicker",
      email: "double@example.com",
    });
    const res2 = await request(app).post("/api/fan/pick").send({
      qid: 1,
      choice: "Draw",
      nickname: "DoublePicker",
      email: "double@example.com",
    });
    expect([404, 409]).toContain(res1.status);
    expect([404, 409]).toContain(res2.status);
  });
});

describe("Integration Tests - Feed Circuit Breaker & Safety", () => {
  it("rejects feeds returning 200 with HTML error pages safely", async () => {
    const result = await fetchFeedSafely({
      id: "mock_error_feed",
      name: "Mock Error Feed",
      url: "https://httpbin.org/status/200",
    });

    expect(result).toHaveProperty("itemBlocks");
    expect(Array.isArray(result.itemBlocks)).toBe(true);
  });
});
