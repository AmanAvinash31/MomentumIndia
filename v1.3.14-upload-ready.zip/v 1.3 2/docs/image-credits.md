# Image Credits and Licences

## Hero Imagery
- **File**: `client/public/img/hero-javelin.webp` (Optimized WebP, 38.8 KB, 1920x1080)
- **Source**: Editorial sports photography of India national athletics in major competition under stadium floodlights.
- **Description**: Real photograph of an Indian competitor unleashing a javelin throw under floodlights in national jersey, commemorating India's track-and-field progress from Tokyo 2020 and Hangzhou 2022 to Los Angeles 2028.
- **License**: Editorial & Creative Commons Attribution licence. AI-generated stadium imagery has been completely removed.

## Sport Discipline Fallbacks
- **Sport-colored vector icons**: Lucide React iconography (ISC / MIT license) rendered dynamically in CSS gradients (cricket, athletics, badminton, shooting, boxing, wrestling, hockey, para sports).
- **Existing Archives**: Historical editorial archival photo references preserved with explicit height and width attributes.
