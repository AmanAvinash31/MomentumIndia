# Momentum India Design System Specification

## 1. Theme Tokens (Exact Two: Dark and Light)

### Color Tokens
| Token | Dark Mode Value | Light Mode Value | Purpose / Usage |
| :--- | :--- | :--- | :--- |
| `--bg` | `#0A0F1E` (deep stadium navy) | `#FBF8F3` (warm textured paper) | Page background |
| `--surface` | `#101833` (solid navy card) | `#FFFFFF` (crisp white card) | Primary content cards, modals, sheets |
| `--surface-2` | `#17213F` (elevated surface) | `#F3EEE6` (warm contrast tile) | Icon tile backgrounds, nested modules |
| `--border` | `rgba(255, 255, 255, 0.09)` | `rgba(15, 23, 42, 0.10)` | 1px crisp separation borders |
| `--text` | `#F4F6FB` (high contrast white) | `#0F172A` (deep slate navy) | Headings, primary body text |
| `--text-muted`| `#A8B1C7` (slate tint) | `#55607A` (readable neutral) | Secondary captions, timestamps, sources |
| `--accent` | `#FF8A2B` (vibrant Indian saffron) | `#E8590C` (rich contrast saffron) | Primary brand accent, focus states |
| `--accent-small`| `#FFA454` | `#C2410C` (WCAG AAA small accent)| Small badge text & micro-labels |
| `--accent-contrast`| `#0F172A` | `#0F172A` | Text on saffron buttons (passes 4.5:1) |
| `--live-green` | `#2FD07F` (pulsing neon) | `#15803D` (bold field green) | Live match indicators, active dots |
| `--gold` | `#F59E0B` | `#D97706` | Gold medals, honors, leaderboard #1 |
| `--silver` | `#CBD5E1` | `#64748B` | Silver medals, leaderboard #2 |
| `--bronze` | `#D97706` | `#B45309` | Bronze medals, leaderboard #3 |
| `--glow-saffron`| `0 0 24px rgba(255,138,43,0.35)` | `0 8px 30px rgba(232,89,12,0.18)`| Focused hero accents, active states |

### Primary Buttons
- **Gradient**: `linear-gradient(135deg, #FF9933 0%, #FF7700 100%)` in Dark; `linear-gradient(135deg, #FF8A2B 0%, #E8590C 100%)` in Light.
- **Text**: Deep navy `#0F172A` bold 16px. Never white text on orange, ensuring WCAG 2.2 AA (and AAA) contrast.

---

## 2. Typography Scale & Hierarchy

- **Display Font (`Clash Display`)**:
  - Reserved strictly for short H1 and H2 headings (<= 8 words).
  - Letter spacing: `-0.01em` minimum (never tighter; no merged words).
  - Word spacing: `0.05em`.
  - Line height: `1.1` to `1.2`.
- **Body Font (`Satoshi`)**:
  - Used for ALL card titles, article headlines, quiz questions, navigation items, and descriptions.
  - Headings / Card Titles: Semi-bold, 17px to 20px on mobile, line-height `1.3`, up to 3 lines max.
  - Body Text: 16px minimum (`1rem`), line-height `1.6`.
- **Eyebrow Labels**:
  - Max ONE eyebrow per section.
  - Font: Body font (`Satoshi`), bold, 12px minimum, tracking capped at `0.06em`.
  - Content: At most 4 words (e.g. "Live Sports Wire", "National Benchmark", "Medal Timeline").
- **Monospace Font (`JetBrains Mono`)**:
  - Reserved strictly for scores, times, dates, and medal tallies.

---

## 3. Spacing Scale & Container Layout

- **Base Grid**: 4px.
- **Section Vertical Rhythm**:
  - Mobile: `48px` to `64px` (`py-12` to `py-16`).
  - Desktop: `80px` to `96px` (`py-20` to `py-24`).
  - Zero dead zones (no 100px-160px gaps).
- **Container**:
  - `max-width: 1240px` (`max-w-[1240px]`).
  - Gutters: `16px` on mobile (`px-4`), `32px` on desktop (`px-8`).
- **Card Spacing**:
  - Card gaps: `12px` on mobile (`gap-3`), `16px` on desktop (`gap-4`).
- **Safe Areas**:
  - `padding-bottom: max(env(safe-area-inset-bottom, 0px), 16px)`.

---

## 4. Radii & Surface Styling

- **Cards**: `rounded-[14px]` (14px).
- **Buttons & Form Inputs**: `rounded-[10px]` (10px).
- **Chips, Badges & Avatars**: `rounded-full`.
- **Borders**: 1px crisp separation (`border border-[var(--border)]`).
- **Shadows**:
  - Dark: Subtle border glow with no muddy grey casts.
  - Light: Soft saffron-tinted depth (`box-shadow: 0 4px 20px -2px rgba(232, 89, 12, 0.08), 0 2px 6px -1px rgba(0, 0, 0, 0.04)`).

---

## 5. Icon Standards

- **Icon Family**: Lucide React.
- **Stroke Width**: Uniform `1.75` stroke width across all instances.
- **Icon Tiles**: 36px rounded-square (`w-9 h-9 rounded-[10px] bg-[var(--surface-2)] flex items-center justify-center text-[var(--accent)]`).

---

## 6. Shared Component Specifications

1. **Button**:
   - `primary`: Saffron gradient, dark navy text `#0F172A`, 10px radius, 44px+ height on mobile.
   - `secondary`: Surface background with 1px border and hover glow.
   - `ghost`: Transparent with subtle hover tint.
2. **Chip**:
   - Height 36px, `rounded-full`, swipeable horizontally with scroll snap and edge gradient fade.
3. **Badge**:
   - Status indicators (Live with green pulse, Upcoming with amber, Ended with neutral grey).
4. **Card**:
   - 14px radius, surface color, 1px border. Entire card is clickable where applicable.
5. **SectionHeader**:
   - One short 2-4 word eyebrow label (body font, 12px min) + H2 (Clash Display <= 8 words).
6. **StatCard**:
   - Compact 4-across desktop, 2x2 grid mobile. Value in large display/mono, label in muted text.
7. **ResultCard**:
   - Whole card clickable. Large scoreline (e.g. "IND 3-2 JPN"), sport badge, relative timestamp ("2h ago"), external icon.
8. **NewsCard**:
   - 16:9 thumbnail or sport icon tile fallback. Max 3-line readable title.
9. **Tabs**:
   - Equal width, scroll-snap chips with next chip peeking on mobile.
10. **Sheet**:
    - Bottom drawer for mobile "More" menu. 2-column icon tile grid + expandable accordions.
11. **MenuItem**:
    - 56px row height with 36px icon tile, 15px title, <45 character description, hover feedback.
12. **ThemeToggle**:
    - 2-state toggle (Sun for dark mode, Moon for light mode). Visible in desktop header and mobile top bar.
13. **EmptyState**:
    - Replaces missing data with friendly message, relevant icon, and schedule/action link.
14. **Skeleton**:
    - Theme-aware pulsing placeholder matching exact card dimensions to eliminate CLS.
