import { chromium } from "playwright";
import fs from "node:fs";
import path from "node:path";

const targetDir = process.argv[2] || "before";
const outDir = path.resolve(process.cwd(), "ui-screenshots", targetDir);
fs.mkdirSync(outDir, { recursive: true });

const viewports = [
  { name: "360x800", width: 360, height: 800, isMobile: true },
  { name: "390x844", width: 390, height: 844, isMobile: true },
  { name: "412x915", width: 412, height: 915, isMobile: true },
  { name: "768x1024", width: 768, height: 1024, isMobile: false },
  { name: "1440x900", width: 1440, height: 900, isMobile: false },
  { name: "844x390-landscape", width: 844, height: 390, isMobile: true },
];

const themes = ["dark", "light"] as const;

async function run() {
  const browser = await chromium.launch();

  for (const theme of themes) {
    for (const vp of viewports) {
      const context = await browser.newContext({
        viewport: { width: vp.width, height: vp.height },
        colorScheme: theme,
      });
      const page = await context.newPage();

      // Ensure theme is set in localStorage
      await page.addInitScript((t) => {
        localStorage.setItem("momentum_theme", t);
        localStorage.setItem("momentum_cookie_consent", "accepted");
        document.documentElement.setAttribute("data-theme", t);
        document.documentElement.classList.toggle("dark", t === "dark");
      }, theme);

      try {
        // 1. Home full page
        await page.goto("http://127.0.0.1:5055/", { waitUntil: "networkidle" });
        await page.screenshot({
          path: path.join(outDir, `home-${theme}-${vp.name}.png`),
          fullPage: true,
        });

        // 2. Quiz block on Home
        const quizEl = page.locator("[data-testid='dynamic-quiz-block'], section:has-text('Sports Quiz'), section:has-text('Quiz')").first();
        if (await quizEl.isVisible()) {
          await quizEl.scrollIntoViewIfNeeded();
          await page.waitForTimeout(300);
          await quizEl.screenshot({
            path: path.join(outDir, `quiz-${theme}-${vp.name}.png`),
          });
        }

        // 3. Explore menu or Phone More sheet
        if (vp.isMobile && vp.height > 500) {
          // Open More sheet on phone
          const moreTab = page.locator("[data-testid='tab-more'], button:has-text('More')").first();
          if (await moreTab.isVisible()) {
            await moreTab.click();
            await page.waitForTimeout(400);
            await page.screenshot({
              path: path.join(outDir, `more-sheet-${theme}-${vp.name}.png`),
            });
          }
        } else if (!vp.isMobile) {
          // Open Explore menu on desktop/tablet
          const exploreBtn = page.locator("button:has-text('Explore'), [data-testid='nav-explore']").first();
          if (await exploreBtn.isVisible()) {
            await exploreBtn.click();
            await page.waitForTimeout(400);
            await page.screenshot({
              path: path.join(outDir, `explore-menu-${theme}-${vp.name}.png`),
            });
          }
        }

        // 4. Results / News page
        await page.goto("http://127.0.0.1:5055/news", { waitUntil: "networkidle" });
        await page.screenshot({
          path: path.join(outDir, `news-${theme}-${vp.name}.png`),
          fullPage: false,
        });

        await page.goto("http://127.0.0.1:5055/agent", { waitUntil: "networkidle" });
        await page.screenshot({
          path: path.join(outDir, `results-${theme}-${vp.name}.png`),
          fullPage: false,
        });
      } catch (err) {
        console.error(`Error capturing ${theme} ${vp.name}:`, err);
      } finally {
        await context.close();
      }
    }
  }

  await browser.close();
  console.log(`Saved screenshots to ${outDir}`);
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
