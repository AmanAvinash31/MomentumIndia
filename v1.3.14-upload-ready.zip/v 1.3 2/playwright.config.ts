import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./tests/e2e",
  timeout: 30000,
  expect: { timeout: 5000 },
  fullyParallel: true,
  retries: 0,
  workers: 1,
  reporter: "list",
  use: {
    baseURL: process.env.BASE_URL || "http://127.0.0.1:5055",
    trace: "retain-on-failure",
  },
  projects: [
    {
      name: "Mobile Chrome - Light",
      use: {
        ...devices["Pixel 5"],
        viewport: { width: 390, height: 844 },
        colorScheme: "light",
      },
    },
    {
      name: "Mobile Chrome - Dark",
      use: {
        ...devices["Pixel 5"],
        viewport: { width: 390, height: 844 },
        colorScheme: "dark",
      },
    },
    {
      name: "Desktop Chrome - Light",
      use: {
        ...devices["Desktop Chrome"],
        viewport: { width: 1280, height: 800 },
        colorScheme: "light",
      },
    },
    {
      name: "Desktop Chrome - Dark",
      use: {
        ...devices["Desktop Chrome"],
        viewport: { width: 1280, height: 800 },
        colorScheme: "dark",
      },
    },
  ],
  webServer: {
    command: "PORT=5055 MANAGE_SECRET=ci-manage-secret-momentum-test-token-key-256 npm run start",
    url: "http://127.0.0.1:5055/healthz",
    reuseExistingServer: true,
    timeout: 120000,
  },
});
