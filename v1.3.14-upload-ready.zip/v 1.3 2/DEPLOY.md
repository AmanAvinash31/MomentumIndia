# Deployment Guide: Momentum India

Momentum India runs as a single persistent Node.js (Node >= 22) service that hosts:
- The React client (bundled via Vite)
- The Express HTTP API and background RSS ingest engine
- Autonomous background `node-cron` workers (news every 10 min, results at 06:00 IST and every 2 hours after)
- A persistent SQLite database (`data.db`) managed via `node:sqlite` inside `DATA_DIR`

> [!IMPORTANT]
> This application relies on a persistent SQLite volume and continuous background cron tasks. It cannot be hosted on ephemeral serverless platforms (such as standard Vercel or Netlify) without losing state. Deploy to **Railway**, **Render with Persistent Disk**, or **Fly.io**.

---

## 1. Railway (Recommended: Click-by-Click Guide)

### Prerequisites: What you must do in your own accounts
- [ ] Have a GitHub account with this repository pushed.
- [ ] Create an account at [Railway.app](https://railway.app).

### Step 1: Push Code to GitHub (You must do this yourself)
```bash
git add .
git commit -m "Configure production deployment with persistent SQLite volume"
git push origin main
```

### Step 2: Create a New Project on Railway
1. Log in to your Railway dashboard at `https://railway.app/dashboard`.
2. Click **"+ New Project"**.
3. Select **"Deploy from GitHub repo"**.
4. Choose your `momentum-india` repository from the list.

### Step 3: Add a Persistent Volume (Critical for SQLite)
1. In your Railway project canvas, click on your newly added service.
2. Navigate to the **"Settings"** tab or right-click the canvas and select **"Add Volume"** (or in service settings scroll down to **Volumes**).
3. Click **"+ Add Volume"**.
4. Configure the volume mount:
   - **Mount Path**: `/data`
5. Click **Add / Save**.

### Step 4: Configure Build & Start Commands
Under your service's **"Settings"** tab:
1. Verify **Build Command**: `npm run build`
2. Verify **Start Command**: `npm start`
3. Node Version: Railway automatically reads `"engines": { "node": ">=22" }` from `package.json` and `.nvmrc` (v22).

### Step 5: Configure Environment Variables
Navigate to the **"Variables"** tab in your service and add:
- `DATA_DIR`: `/data` (points to the persistent volume mount)
- `NODE_ENV`: `production`
- `SITE_URL`: `https://${{RAILWAY_PUBLIC_DOMAIN}}` (or your custom domain)
- `ADMIN_TOKEN`: generate a random string, e.g. run `node -e "console.log(require('crypto').randomBytes(24).toString('base64url'))"`
- `VITE_GA_MEASUREMENT_ID`: optional override for the Google Analytics 4 Measurement ID. The site's own ID (`G-SZCX58T0Z4`, stream "Momentum India Website") is already built into the code as the default since v1.3.14, so a plain build tracks without setting this. Set it only to rotate to a different GA4 property — it is a **build-time** variable, so set it before `npm run build` and rebuild after changing it. Analytics only loads for visitors who accept it in the cookie consent banner, regardless of the ID.
- `PORT`: Leave unset (Railway injects `PORT` automatically; the app listens on `process.env.PORT` bound to `0.0.0.0`).

### Step 6: Generate Public Domain & Deploy
1. In the **"Networking"** section of **Settings**, click **"Generate Domain"** (e.g. `momentum-india-production.up.railway.app`).
2. Click **"Deploy"** (or trigger redeploy).
3. Watch the deployment log:
   - You should see: `serving on port ...`
   - `[cron] cron started: news (every 10m), results (at 06:00 IST and every 2h after), retention 90d (daily)`

### Step 7: Verify Live Health
Open your browser and navigate to:
```
https://<YOUR-RAILWAY-DOMAIN>/api/agent/health
```
Verify the JSON response returns:
- `"status": "ok"`
- `"totalNewsStored": > 0`
- `"totalResultsStored": > 0`
- Feed status list and last fetch times.

---

## 2. Render (with Persistent Disk)

### What you must do in your own accounts:
1. Push repository to GitHub.
2. Sign in to [Render.com](https://render.com).
3. Click **New + > Web Service** and link your GitHub repo.
4. Settings:
   - **Environment**: Node
   - **Node Version**: Select `22` in Environment Variables (`NODE_VERSION = 22`).
   - **Build Command**: `npm run build`
   - **Start Command**: `npm start`
5. Add Disk:
   - Scroll down to **Disks** and click **Add Disk**.
   - **Name**: `momentum-data`
   - **Mount Path**: `/data`
   - **Size**: 1 GB
6. Environment Variables:
   - `DATA_DIR`: `/data`
   - `NODE_ENV`: `production`
   - `SITE_URL`: your render domain or custom domain
7. Click **Create Web Service**. Verify health at `https://<YOUR-RENDER-DOMAIN>/api/agent/health`.

---

## 3. Fly.io

### What you must do in your own accounts:
1. Install Fly CLI: `curl -L https://fly.io/install.sh | sh`
2. Run in project directory:
```bash
fly launch --no-deploy
```
3. Create a 1GB persistent volume:
```bash
fly volumes create momentum_data --size 1
```
4. In `fly.toml`, ensure the volume is mounted:
```toml
[mounts]
  source = "momentum_data"
  destination = "/data"

[env]
  DATA_DIR = "/data"
  NODE_ENV = "production"
```
5. Deploy:
```bash
fly deploy
```
6. Check health at `https://<YOUR-FLY-APP>.fly.dev/api/agent/health`.

---

## 4. Verification Checklist

- [ ] `/api/agent/health` returns HTTP 200 with JSON metrics.
- [ ] `/api/agent/news` returns real sports news articles from publisher wires.
- [ ] `/api/agent/results` returns daily results grouped by IST dates.
- [ ] Home page command center displays live wire news and daily results feed with "Results from the past day, via news wires".
- [ ] Database survives service redeployment (verified by `/data/data.db` persisting on volume).
