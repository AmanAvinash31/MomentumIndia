/**
 * Shared Event Lifecycle Helper (IST - Indian Standard Time, UTC+5:30)
 * Evaluates whether an event is Upcoming, Live, or Ended according to its calendar dates.
 */

export type EventStatus = "Upcoming" | "Live" | "Ended";

export interface EventLifecycleResult {
  status: EventStatus;
  daysToStart: number;
  daysSinceEnd: number;
  label: string;
  isLive: boolean;
  isEnded: boolean;
  isUpcoming: boolean;
}

/**
 * Returns current Date in IST (UTC+5:30).
 */
export function getNowIST(): Date {
  // Convert current time to IST
  const now = new Date();
  const utcMs = now.getTime() + now.getTimezoneOffset() * 60000;
  return new Date(utcMs + 5.5 * 3600000);
}

/**
 * Parses YYYY-MM-DD string into an IST Date representing start or end of the day.
 */
function parseISTDate(dateStr: string, isEndOfDay = false): Date {
  const parts = dateStr.split("T")[0].split("-");
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);

  // UTC timestamp for the IST time
  // IST is UTC+5.5, so 00:00:00 IST is 18:30:00 UTC previous day
  // 23:59:59 IST is 18:29:59 UTC same day
  const hours = isEndOfDay ? 23 : 0;
  const minutes = isEndOfDay ? 59 : 0;
  const seconds = isEndOfDay ? 59 : 0;
  const ms = isEndOfDay ? 999 : 0;

  // Compute UTC ms
  const utc = Date.UTC(year, month, day, hours - 5, minutes - 30, seconds, ms);
  return new Date(utc);
}

/**
 * Computes event lifecycle status strictly based on IST calendar boundaries.
 */
export function getEventStatus(
  startDateStr: string,
  endDateStr: string,
  refDate?: Date | string
): EventLifecycleResult {
  const now = refDate ? (refDate instanceof Date ? refDate.getTime() : new Date(refDate).getTime()) : Date.now();
  const start = parseISTDate(startDateStr, false).getTime();
  const end = parseISTDate(endDateStr, true).getTime();

  const msPerDay = 86400000;

  if (now < start) {
    const daysToStart = Math.max(1, Math.ceil((start - now) / msPerDay));
    return {
      status: "Upcoming",
      daysToStart,
      daysSinceEnd: 0,
      label: daysToStart === 1 ? "Starts tomorrow" : `Starts in ${daysToStart} days`,
      isLive: false,
      isEnded: false,
      isUpcoming: true,
    };
  }

  if (now <= end) {
    return {
      status: "Live",
      daysToStart: 0,
      daysSinceEnd: 0,
      label: "Live Now",
      isLive: true,
      isEnded: false,
      isUpcoming: false,
    };
  }

  const daysSinceEnd = Math.max(1, Math.floor((now - end) / msPerDay));
  return {
    status: "Ended",
    daysToStart: 0,
    daysSinceEnd,
    label: "Final Results",
    isLive: false,
    isEnded: true,
    isUpcoming: false,
  };
}

/**
 * Human-friendly date formatting in IST (e.g. "19 Sep – 4 Oct 2026")
 */
export function formatDateRangeIST(startDateStr: string, endDateStr: string): string {
  try {
    const s = new Date(startDateStr);
    const e = new Date(endDateStr);
    const sMonth = s.toLocaleString("en-US", { month: "short", timeZone: "Asia/Kolkata" });
    const eMonth = e.toLocaleString("en-US", { month: "short", timeZone: "Asia/Kolkata" });
    const sDay = s.toLocaleString("en-US", { day: "numeric", timeZone: "Asia/Kolkata" });
    const eDay = e.toLocaleString("en-US", { day: "numeric", timeZone: "Asia/Kolkata" });
    const year = e.toLocaleString("en-US", { year: "numeric", timeZone: "Asia/Kolkata" });

    if (sMonth === eMonth) {
      return `${sDay}–${eDay} ${eMonth} ${year}`;
    }
    return `${sDay} ${sMonth} – ${eDay} ${eMonth} ${year}`;
  } catch {
    return `${startDateStr} to ${endDateStr}`;
  }
}
