import { eventsStorage, type Event2026Record } from "./events-storage";
import { SEED_EVENTS_2026 } from "./events-seed";
import { fetchFeedSafely, cleanText } from "./sports-agent";
import { fetchJsonSafely } from "./providers/safe-fetch";

export class EventsSyncEngine {
  private isSyncing = false;

  /**
   * Initializes baseline dataset and executes initial verification sweep.
   */
  async initialize(): Promise<void> {
    console.log("[events-sync] Initializing India Sports Events 2026 Telemetry Engine...");
    try {
      // 0. Retire entries proven wrong after the fact (the 38th National
      // Games were held in Uttarakhand in Jan-Feb 2025, not 2026). Deleting
      // here, rather than only removing it from the seed, also cleans
      // persistent production databases that the seed alone cannot delete.
      const RETIRED_EVENT_IDS = ["national-games-uttarakhand-2026"];
      for (const id of RETIRED_EVENT_IDS) eventsStorage.remove(id);

      // 1. Seed or ensure baseline events
      let inserted = 0;
      for (const ev of SEED_EVENTS_2026) {
        eventsStorage.upsert(ev);
        inserted++;
      }
      console.log(`[events-sync] Verified ${inserted} baseline 2026 events across all 36 States & UTs.`);

      // 2. Perform live lifecycle status refresh
      this.refreshLifecycleStatuses();

      // 3. Run background live telemetry sweep
      await this.runFullSync();
    } catch (err: any) {
      console.error("[events-sync] Initialization error:", err?.message || err);
    }
  }

  /**
   * Run full multi-source synchronization sweep.
   */
  async runFullSync(): Promise<{ discovered: number; updated: number }> {
    if (this.isSyncing) {
      console.log("[events-sync] Sync already in progress, skipping.");
      return { discovered: 0, updated: 0 };
    }

    this.isSyncing = true;
    console.log(`[events-sync ${new Date().toISOString()}] Starting multi-source telemetry sweep...`);

    let totalDiscovered = 0;
    let totalUpdated = 0;

    try {
      // 0. Ensure baseline verified events are updated
      for (const ev of SEED_EVENTS_2026) {
        eventsStorage.upsert(ev);
      }

      // 1. Google News / Google Sports RSS Telemetry
      const rssResult = await this.syncFromGoogleSportsRSS();
      totalDiscovered += rssResult.discovered;
      totalUpdated += rssResult.updated;

      // 2. Wikipedia MediaWiki Sports API Telemetry
      const wikiResult = await this.syncFromWikipedia();
      totalDiscovered += wikiResult.discovered;
      totalUpdated += wikiResult.updated;

      // 3. Refresh lifecycle statuses (UPCOMING / ONGOING / COMPLETED)
      const lifecycle = this.refreshLifecycleStatuses();
      totalUpdated += lifecycle.updated;

      eventsStorage.logSync(
        "MULTI_SOURCE_TELEMETRY",
        totalDiscovered,
        0,
        totalUpdated,
        "SUCCESS"
      );
      console.log(`[events-sync] Sweep finished: discovered ${totalDiscovered}, updated ${totalUpdated}.`);
    } catch (err: any) {
      console.warn("[events-sync] Sweep warning:", err?.message || err);
      eventsStorage.logSync(
        "MULTI_SOURCE_TELEMETRY",
        totalDiscovered,
        0,
        totalUpdated,
        "PARTIAL_ERROR",
        err?.message
      );
    } finally {
      this.isSyncing = false;
    }

    return { discovered: totalDiscovered, updated: totalUpdated };
  }

  /**
   * Evaluates current Indian Standard Time (IST) date and updates event statuses
   */
  refreshLifecycleStatuses(): { updated: number } {
    const now = new Date();
    // Calculate IST Date (UTC + 5:30)
    const istOffsetMs = 5.5 * 60 * 60 * 1000;
    const istDate = new Date(now.getTime() + istOffsetMs);
    const isoDateString = istDate.toISOString().split("T")[0]; // YYYY-MM-DD

    return eventsStorage.updateLifecycleStatuses(isoDateString);
  }

  /**
   * Geocode a stadium or city using OpenStreetMap Nominatim with local cache
   */
  async geocodeVenue(venue: string, city: string, state: string): Promise<{ lat: number; lng: number } | null> {
    const query = `${venue}, ${city}, ${state}, India`.trim();
    const cached = eventsStorage.getCachedGeocode(query);
    if (cached) {
      return { lat: cached.latitude, lng: cached.longitude };
    }

    const fallbackQuery = `${city}, ${state}, India`.trim();
    const cachedCity = eventsStorage.getCachedGeocode(fallbackQuery);
    if (cachedCity) {
      return { lat: cachedCity.latitude, lng: cachedCity.longitude };
    }

    try {
      const url = `https://nominatim.openstreetmap.org/search?format=json&countrycodes=in&q=${encodeURIComponent(query)}&limit=1`;
      const res = await fetch(url, {
        headers: {
          "User-Agent": "MomentumIndia-SportsEventsBot/1.0 (sports@themomentum.in)",
          "Accept": "application/json",
        },
      });

      if (!res.ok) return null;
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        const lat = parseFloat(data[0].lat);
        const lng = parseFloat(data[0].lon);
        eventsStorage.cacheGeocode(query, lat, lng, data[0].display_name || query);
        return { lat, lng };
      }

      // Try city fallback
      const cityUrl = `https://nominatim.openstreetmap.org/search?format=json&countrycodes=in&q=${encodeURIComponent(fallbackQuery)}&limit=1`;
      const cityRes = await fetch(cityUrl, {
        headers: {
          "User-Agent": "MomentumIndia-SportsEventsBot/1.0 (sports@themomentum.in)",
          "Accept": "application/json",
        },
      });
      if (cityRes.ok) {
        const cityData = await cityRes.json();
        if (Array.isArray(cityData) && cityData.length > 0) {
          const lat = parseFloat(cityData[0].lat);
          const lng = parseFloat(cityData[0].lon);
          eventsStorage.cacheGeocode(fallbackQuery, lat, lng, cityData[0].display_name || fallbackQuery);
          return { lat, lng };
        }
      }
    } catch {
      // Nominatim rate limiting or network issues handled gracefully
    }
    return null;
  }

  /**
   * Google Sports / News RSS feed queries for Indian sporting events
   */
  private async syncFromGoogleSportsRSS(): Promise<{ discovered: number; updated: number }> {
    const RSS_QUERIES = [
      {
        url: "https://news.google.com/rss/search?q=India+national+championship+2026+sport&hl=en-IN&gl=IN&ceid=IN:en",
        name: "Google News - National Championships 2026"
      },
      {
        url: "https://news.google.com/rss/search?q=marathon+India+2026+schedule&hl=en-IN&gl=IN&ceid=IN:en",
        name: "Google News - Marathon & Endurance 2026"
      },
      {
        url: "https://news.google.com/rss/search?q=Khelo+India+2026+schedule&hl=en-IN&gl=IN&ceid=IN:en",
        name: "Google News - Khelo India 2026"
      },
      {
        url: "https://news.google.com/rss/search?q=chess+tournament+India+2026&hl=en-IN&gl=IN&ceid=IN:en",
        name: "Google News - Chess Tournaments 2026"
      },
      {
        url: "https://news.google.com/rss/search?q=HYROX+IRONMAN+India+2026&hl=en-IN&gl=IN&ceid=IN:en",
        name: "Google News - HYROX & IRONMAN 2026"
      }
    ];

    let discovered = 0;
    let updated = 0;

    for (const query of RSS_QUERIES) {
      try {
        const res = await fetchFeedSafely(query.url, query.name, 8000);
        if (!res.ok || res.itemBlocks.length === 0) continue;

        for (const block of res.itemBlocks.slice(0, 15)) {
          const itemText = block[0];
          const titleMatch = itemText.match(/<title>([\s\S]*?)<\/title>/i);
          const linkMatch = itemText.match(/<link>([\s\S]*?)<\/link>/i);
          const pubDateMatch = itemText.match(/<pubDate>([\s\S]*?)<\/pubDate>/i);

          const title = cleanText(titleMatch ? titleMatch[1] : "");
          const link = cleanText(linkMatch ? linkMatch[1] : "");
          const pubDate = pubDateMatch ? pubDateMatch[1] : new Date().toISOString();

          if (!title || !title.toLowerCase().includes("2026")) continue;

          discovered++;

          // Check if it corroborates any existing event to upgrade verification to CROSS-VERIFIED
          const existingList = eventsStorage.list({ limit: 1000 }).items;
          for (const ev of existingList) {
            const evKeywords = ev.event_name.toLowerCase().split(/\s+/).filter(w => w.length > 3);
            const matches = evKeywords.filter(k => title.toLowerCase().includes(k));

            if (matches.length >= 2) {
              // Add source to event
              let sources: string[] = [];
              try { sources = JSON.parse(ev.source_urls); } catch {}
              if (!sources.includes(link) && link) {
                sources.push(link);
                ev.source_urls = JSON.stringify(sources);
                if (ev.verification_status === "CONFIRMED") {
                  ev.verification_status = "CROSS-VERIFIED";
                }
                ev.last_verified_at = new Date().toISOString();
                ev.last_updated_at = new Date().toISOString();
                eventsStorage.upsert(ev);
                updated++;
              }
            }
          }
        }
      } catch (err: any) {
        console.warn(`[events-sync] RSS feed error for ${query.name}:`, err?.message || err);
      }
    }

    return { discovered, updated };
  }

  /**
   * MediaWiki API - Query 2026 in Indian Sport & Federation Schedules
   */
  private async syncFromWikipedia(): Promise<{ discovered: number; updated: number }> {
    let discovered = 0;
    let updated = 0;

    try {
      const endpoint = "https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=2026+in+Indian+sport+championship&format=json&origin=*";
      const result = await fetchJsonSafely<any>(endpoint, { timeoutMs: 8000 });

      if (result && result.ok && result.data && result.data.query && Array.isArray(result.data.query.search)) {
        for (const item of result.data.query.search.slice(0, 10)) {
          discovered++;
          const title = item.title;
          const snippet = item.snippet;

          // Cross-verify existing events with Wikipedia mentions
          const existingList = eventsStorage.list({ limit: 1000 }).items;
          for (const ev of existingList) {
            if (title.toLowerCase().includes(ev.sport.toLowerCase()) || snippet.toLowerCase().includes(ev.event_name.toLowerCase())) {
              let sources: string[] = [];
              try { sources = JSON.parse(ev.source_urls); } catch {}
              const wikiUrl = `https://en.wikipedia.org/wiki/${encodeURIComponent(title.replace(/ /g, "_"))}`;
              if (!sources.includes(wikiUrl)) {
                sources.push(wikiUrl);
                ev.source_urls = JSON.stringify(sources);
                ev.verification_status = "CROSS-VERIFIED";
                ev.last_verified_at = new Date().toISOString();
                ev.last_updated_at = new Date().toISOString();
                eventsStorage.upsert(ev);
                updated++;
              }
            }
          }
        }
      }
    } catch (err: any) {
      console.warn("[events-sync] Wikipedia query error:", err?.message || err);
    }

    return { discovered, updated };
  }
}

export const eventsSyncEngine = new EventsSyncEngine();
