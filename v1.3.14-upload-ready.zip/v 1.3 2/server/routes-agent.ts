import type { Express } from "express";
import { sportsAgent, LISTED_SPORTS, getFeedStatusList } from "./sports-agent";
import { agentStorage } from "./storage";
import { requireAdmin } from "./auth";
import { cache, publicCache } from "./cache";
import { z } from "zod";

export const Limit = (def: number, max: number) =>
  z.coerce.number().int().catch(def).transform(n => Math.min(Math.max(n, 1), max));

const SafeQueryString = (max = 60) =>
  z.string().max(max).refine(val => !val.includes("\0") && !/%00/i.test(val), {
    message: "Invalid characters in query parameter",
  });

const NewsQuerySchema = z.object({
  sport: SafeQueryString(60).optional(),
  limit: Limit(50, 100),
  cursor: z.coerce.number().int().positive().optional(),
});

const ResultsQuerySchema = z.object({
  sport: SafeQueryString(60).optional(),
  date_ist: SafeQueryString(20).optional(),
  date: SafeQueryString(20).optional(),
  limit: Limit(100, 200),
  cursor: z.coerce.number().int().positive().optional(),
});

export function registerAgentRoutes(app: Express) {
  sportsAgent.init();

  /* GET /api/agent/health - detailed diagnostics endpoint (admin-only) */
  app.get("/api/agent/health", requireAdmin, (_req, res) => {
    const news = agentStorage.listNews(undefined, 500);
    let directPublisherCount = 0;
    let googleRedirectCount = 0;

    for (const n of news) {
      if (!n.url) continue;
      if (n.url.includes("news.google.com")) {
        googleRedirectCount++;
      } else {
        directPublisherCount++;
      }
    }

    const perSportCounts: Record<string, number> = {};
    for (const sp of LISTED_SPORTS) {
      perSportCounts[sp] = agentStorage.countResults(sp);
    }

    const feeds = getFeedStatusList();
    const perFeedStatus: Record<string, any> = {};
    for (const f of feeds) {
      perFeedStatus[f.name || f.url] = {
        url: f.url,
        lastStatus: f.lastStatus,
        itemCount: f.itemCount,
        consecutiveFailures: f.consecutiveFailures,
        isStale: f.isStale,
        lastFetchTime: f.lastFetchTime,
        error: f.error,
      };
    }

    const stats = agentStorage.stats();

    res.json({
      status: "ok",
      lastNewsFetchTime: sportsAgent.lastNewsFetchTime,
      lastResultsFetchTime: sportsAgent.lastResultsFetchTime,
      totalNewsStored: stats.totalNews,
      totalResultsStored: stats.totalResults,
      newestArticleTime: stats.newestArticleTime,
      newestResultTime: stats.newestResultTime,
      directPublisherCount,
      googleRedirectCount,
      perFeedStatus,
      perSportResultsCount: perSportCounts,
      timestamp: new Date().toISOString(),
    });
  });

  /* GET /api/agent/status - health and overview (cheap) */
  app.get("/api/agent/status", (_req, res) => {
    res.json({
      online: true,
      sports: LISTED_SPORTS,
      stats: agentStorage.stats(),
      lastNewsTimestamp: sportsAgent.lastNewsFetchTime || new Date(agentStorage.getLatestNewsTimestamp()).toISOString(),
      timestamp: new Date().toISOString(),
    });
  });

  /* GET /api/agent/news - fetch curated real sports news */
  app.get("/api/agent/news", publicCache(10, 30), async (req, res) => {
    const parsed = NewsQuerySchema.safeParse(req.query);
    if (!parsed.success) {
      const msg = parsed.error.issues[0]?.message || "Invalid query parameters";
      return res.status(400).json({ message: msg, error: msg });
    }
    const { sport, limit, cursor } = parsed.data;

    const cacheKey = `news:${sport || "all"}:${limit}:${cursor || 0}`;
    const payload = await cache.getOrSet(cacheKey, 10_000, () => {
      const news = agentStorage.listNews(sport, limit, cursor);
      const nextCursor = news.length === limit && news[news.length - 1]?.id ? news[news.length - 1].id : null;
      return {
        sport: sport || "all",
        count: news.length,
        limit,
        nextCursor,
        news,
        lastUpdated: sportsAgent.lastNewsFetchTime || (news[0]?.published_at ?? null),
      };
    });

    res.json(payload);
  });

  let lastNewsFetchAt = 0;
  let lastResultsFetchAt = 0;
  // Per-IP fetch throttle, on top of the global 60s throttle below: one IP
  // must not be able to starve every other reader's refresh button.
  const ipFetchAt = new Map<string, number>();
  const ipFetchOk = (ip: string) => {
    const now = Date.now();
    const last = ipFetchAt.get(ip) ?? 0;
    if (now - last < 60_000) return false;
    ipFetchAt.set(ip, now); return true;
  };

  /* POST /api/agent/news/fetch - trigger agent to pull latest sports news (rate-limited to once per 60s) */
  app.post("/api/agent/news/fetch", async (req, res) => {
    const sportParam = typeof req.body?.sport === "string" ? req.body.sport : undefined;
    if (sportParam && !(LISTED_SPORTS as readonly string[]).includes(sportParam) && sportParam !== "All") {
      return res.status(400).json({ message: "Unknown sport" });
    }
    const fip = req.ip ?? req.socket.remoteAddress ?? "?";
    if (!ipFetchOk(`news:${fip}`)) return res.json({ ok: true, rateLimited: true, message: "Rate limited: next fetch available in under a minute.", count: agentStorage.listNews().length });
    const now = Date.now();
    if (now - lastNewsFetchAt < 60_000) {
      const waitSec = Math.ceil((60_000 - (now - lastNewsFetchAt)) / 1000);
      return res.json({
        ok: true,
        rateLimited: true,
        message: `Rate limited: next fetch available in ${waitSec}s. Feeds update automatically via cron every 10m.`,
        count: agentStorage.listNews().length,
      });
    }
    lastNewsFetchAt = now;
    try {
      const sport = typeof req.body?.sport === "string" ? req.body.sport : undefined;
      const result = await sportsAgent.fetchLatestNews(sport);
      res.json({ ok: true, ...result });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Failed to fetch news" });
    }
  });

  /* GET /api/agent/results - daily results feed across all 26 sports */
  app.get("/api/agent/results", publicCache(10, 30), async (req, res) => {
    const parsed = ResultsQuerySchema.safeParse(req.query);
    if (!parsed.success) {
      const msg = parsed.error.issues[0]?.message || "Invalid query parameters";
      return res.status(400).json({ message: msg, error: msg });
    }
    const { sport, date_ist, date, limit, cursor } = parsed.data;
    const effectiveDate = date_ist || date;

    const cacheKey = `results:${sport || "all"}:${effectiveDate || "all"}:${limit}:${cursor || 0}`;
    const payload = await cache.getOrSet(cacheKey, 10_000, () => {
      const results = agentStorage.listResults(sport, effectiveDate, limit, cursor);
      const nextCursor = results.length === limit && results[results.length - 1]?.id ? results[results.length - 1].id : null;
      return {
        sport: sport || "all",
        date_ist: effectiveDate || "all",
        count: results.length,
        limit,
        nextCursor,
        results,
        lastUpdated: sportsAgent.lastResultsFetchTime || (results[0]?.published_at ?? null),
      };
    });

    res.json(payload);
  });

  /* GET /api/agent/results/dates - available real dates from stored results */
  app.get("/api/agent/results/dates", (_req, res) => {
    const dates = agentStorage.listResultDates();
    res.json({ dates });
  });

  /* POST /api/agent/results/fetch - trigger agent to pull latest results across 26 sports (rate-limited to once per 60s) */
  app.post("/api/agent/results/fetch", async (req, res) => {
    const fip = req.ip ?? req.socket.remoteAddress ?? "?";
    if (!ipFetchOk(`results:${fip}`)) return res.json({ ok: true, rateLimited: true, message: "Rate limited: next fetch available in under a minute.", count: agentStorage.listResults().length });
    const now = Date.now();
    if (now - lastResultsFetchAt < 60_000) {
      const waitSec = Math.ceil((60_000 - (now - lastResultsFetchAt)) / 1000);
      return res.json({
        ok: true,
        rateLimited: true,
        message: `Rate limited: next fetch available in ${waitSec}s. Results update automatically via cron.`,
        count: agentStorage.listResults().length,
      });
    }
    lastResultsFetchAt = now;
    try {
      const result = await sportsAgent.fetchLatestResults();
      res.json({ ok: true, ...result });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Failed to fetch results" });
    }
  });

  /* GET /api/agent/scorecards - legacy stub returning empty */
  app.get("/api/agent/scorecards", (_req, res) => {
    res.json({ count: 0, scorecards: [] });
  });

  /* GET /api/agent/scorecards/:id - legacy stub */
  app.get("/api/agent/scorecards/:id", (_req, res) => {
    res.status(404).json({ error: "Scorecard not found" });
  });

  /* POST /api/agent/scorecards/refresh - legacy stub triggers results (authenticated with admin token) */
  app.post("/api/agent/scorecards/refresh", requireAdmin, async (_req, res) => {
    try {
      const result = await sportsAgent.fetchLatestResults();
      res.json({ ok: true, updated: result.count, scorecards: [] });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Failed to refresh results" });
    }
  });

  /* POST /api/agent/query - conversational sports query */
  app.post("/api/agent/query", async (req, res) => {
    const bodySchema = z.object({
      query: z.string().trim().min(1, "Please provide a sports query").max(500),
    });
    const parsed = bodySchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.issues[0]?.message || "Invalid query" });
    }

    try {
      const response = await sportsAgent.answerQuery(parsed.data.query);
      res.json({ ok: true, ...response });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Failed to process query" });
    }
  });
}
