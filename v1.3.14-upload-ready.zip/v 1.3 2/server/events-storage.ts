import { sqlite } from "./storage";

export interface Event2026Record {
  event_id: string;
  event_name: string;
  official_event_name: string | null;
  sport: string;
  discipline: string | null;
  sport_category: string;
  event_type: string | null;
  competition_level: "International" | "National" | "State" | "Zonal" | "Mass-Participation";
  gender_category: "Open" | "Men" | "Women" | "Mixed" | null;
  age_category: "Senior" | "Junior" | "Youth" | "Sub-Junior" | "Masters" | "Open" | null;
  para_sport: number;
  international_or_domestic: "International" | "Domestic";
  start_date: string;
  end_date: string;
  date_precision: "EXACT" | "APPROXIMATE" | "MONTH" | "TBA";
  date_status: "CONFIRMED" | "TENTATIVE" | "TBA";
  country: string;
  state_or_union_territory: string;
  city: string;
  district: string | null;
  venue: string | null;
  venue_address: string | null;
  latitude: number;
  longitude: number;
  organizer: string | null;
  governing_federation: string | null;
  event_description: string | null;
  competition_format: string | null;
  registration_url: string | null;
  official_event_url: string | null;
  source_urls: string; // JSON array string
  verification_status: "CONFIRMED" | "CROSS-VERIFIED" | "PARTIALLY VERIFIED" | "UNCONFIRMED";
  last_verified_at: string;
  event_status: "UPCOMING" | "ONGOING" | "COMPLETED" | "POSTPONED" | "CANCELLED";
  price_or_registration_fee: string | null;
  registration_deadline: string | null;
  recurring_event: number;
  expected_participants: number | null;
  national_or_international_significance: string | null;
  data_completeness: number;
  last_updated_at: string;
}

export interface EventsKPIs {
  totalUnique: number;
  confirmed: number;
  crossVerified: number;
  partiallyVerified: number;
  unconfirmed: number;
  upcoming: number;
  ongoing: number;
  completed: number;
  postponed: number;
  cancelled: number;
  international: number;
  national: number;
  stateLevel: number;
  massParticipation: number;
  marathonEndurance: number;
  ultraTrail: number;
  ironmanTriathlon: number;
  hyroxFitness: number;
  chessMindSports: number;
  olympicSports: number;
  commonwealthSports: number;
  asianGamesSports: number;
  paraSports: number;
  indigenousSports: number;
  awaitingVerification: number;
  statesRepresented: number;
  citiesRepresented: number;
  lastUpdatedAt: string;
}

// Initialize tables in SQLite
sqlite.exec(`
CREATE TABLE IF NOT EXISTS events_2026 (
  event_id TEXT PRIMARY KEY,
  event_name TEXT NOT NULL,
  official_event_name TEXT,
  sport TEXT NOT NULL,
  discipline TEXT,
  sport_category TEXT NOT NULL,
  event_type TEXT,
  competition_level TEXT NOT NULL,
  gender_category TEXT,
  age_category TEXT,
  para_sport INTEGER NOT NULL DEFAULT 0,
  international_or_domestic TEXT NOT NULL DEFAULT 'Domestic',
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  date_precision TEXT NOT NULL DEFAULT 'EXACT',
  date_status TEXT NOT NULL DEFAULT 'CONFIRMED',
  country TEXT NOT NULL DEFAULT 'India',
  state_or_union_territory TEXT NOT NULL,
  city TEXT NOT NULL,
  district TEXT,
  venue TEXT,
  venue_address TEXT,
  latitude REAL NOT NULL,
  longitude REAL NOT NULL,
  organizer TEXT,
  governing_federation TEXT,
  event_description TEXT,
  competition_format TEXT,
  registration_url TEXT,
  official_event_url TEXT,
  source_urls TEXT NOT NULL DEFAULT '[]',
  verification_status TEXT NOT NULL DEFAULT 'CONFIRMED',
  last_verified_at TEXT NOT NULL,
  event_status TEXT NOT NULL DEFAULT 'UPCOMING',
  price_or_registration_fee TEXT,
  registration_deadline TEXT,
  recurring_event INTEGER NOT NULL DEFAULT 1,
  expected_participants INTEGER,
  national_or_international_significance TEXT,
  data_completeness REAL NOT NULL DEFAULT 1.0,
  last_updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_events_dates ON events_2026 (start_date, end_date);
CREATE INDEX IF NOT EXISTS idx_events_state ON events_2026 (state_or_union_territory);
CREATE INDEX IF NOT EXISTS idx_events_sport ON events_2026 (sport);
CREATE INDEX IF NOT EXISTS idx_events_category ON events_2026 (sport_category);
CREATE INDEX IF NOT EXISTS idx_events_status ON events_2026 (event_status);

CREATE TABLE IF NOT EXISTS events_sync_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL,
  discovered_count INTEGER NOT NULL DEFAULT 0,
  inserted_count INTEGER NOT NULL DEFAULT 0,
  updated_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  error_message TEXT,
  executed_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS geocoding_cache (
  query TEXT PRIMARY KEY,
  latitude REAL NOT NULL,
  longitude REAL NOT NULL,
  display_name TEXT,
  cached_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

export const eventsStorage = {
  upsert(ev: Event2026Record): void {
    const stmt = sqlite.prepare(`
      INSERT INTO events_2026 (
        event_id, event_name, official_event_name, sport, discipline, sport_category,
        event_type, competition_level, gender_category, age_category, para_sport,
        international_or_domestic, start_date, end_date, date_precision, date_status,
        country, state_or_union_territory, city, district, venue, venue_address,
        latitude, longitude, organizer, governing_federation, event_description,
        competition_format, registration_url, official_event_url, source_urls,
        verification_status, last_verified_at, event_status, price_or_registration_fee,
        registration_deadline, recurring_event, expected_participants,
        national_or_international_significance, data_completeness, last_updated_at
      ) VALUES (
        @event_id, @event_name, @official_event_name, @sport, @discipline, @sport_category,
        @event_type, @competition_level, @gender_category, @age_category, @para_sport,
        @international_or_domestic, @start_date, @end_date, @date_precision, @date_status,
        @country, @state_or_union_territory, @city, @district, @venue, @venue_address,
        @latitude, @longitude, @organizer, @governing_federation, @event_description,
        @competition_format, @registration_url, @official_event_url, @source_urls,
        @verification_status, @last_verified_at, @event_status, @price_or_registration_fee,
        @registration_deadline, @recurring_event, @expected_participants,
        @national_or_international_significance, @data_completeness, @last_updated_at
      )
      ON CONFLICT(event_id) DO UPDATE SET
        event_name = excluded.event_name,
        official_event_name = COALESCE(excluded.official_event_name, events_2026.official_event_name),
        sport = excluded.sport,
        discipline = COALESCE(excluded.discipline, events_2026.discipline),
        sport_category = excluded.sport_category,
        event_type = COALESCE(excluded.event_type, events_2026.event_type),
        competition_level = excluded.competition_level,
        gender_category = COALESCE(excluded.gender_category, events_2026.gender_category),
        age_category = COALESCE(excluded.age_category, events_2026.age_category),
        para_sport = excluded.para_sport,
        international_or_domestic = excluded.international_or_domestic,
        start_date = excluded.start_date,
        end_date = excluded.end_date,
        date_precision = excluded.date_precision,
        date_status = excluded.date_status,
        state_or_union_territory = excluded.state_or_union_territory,
        city = excluded.city,
        district = COALESCE(excluded.district, events_2026.district),
        venue = COALESCE(excluded.venue, events_2026.venue),
        venue_address = COALESCE(excluded.venue_address, events_2026.venue_address),
        latitude = excluded.latitude,
        longitude = excluded.longitude,
        organizer = COALESCE(excluded.organizer, events_2026.organizer),
        governing_federation = COALESCE(excluded.governing_federation, events_2026.governing_federation),
        event_description = COALESCE(excluded.event_description, events_2026.event_description),
        competition_format = COALESCE(excluded.competition_format, events_2026.competition_format),
        registration_url = COALESCE(excluded.registration_url, events_2026.registration_url),
        official_event_url = COALESCE(excluded.official_event_url, events_2026.official_event_url),
        source_urls = excluded.source_urls,
        verification_status = CASE
          WHEN events_2026.verification_status = 'CONFIRMED' THEN 'CONFIRMED'
          ELSE excluded.verification_status
        END,
        last_verified_at = excluded.last_verified_at,
        event_status = excluded.event_status,
        price_or_registration_fee = COALESCE(excluded.price_or_registration_fee, events_2026.price_or_registration_fee),
        registration_deadline = COALESCE(excluded.registration_deadline, events_2026.registration_deadline),
        recurring_event = excluded.recurring_event,
        expected_participants = COALESCE(excluded.expected_participants, events_2026.expected_participants),
        national_or_international_significance = COALESCE(excluded.national_or_international_significance, events_2026.national_or_international_significance),
        data_completeness = excluded.data_completeness,
        last_updated_at = excluded.last_updated_at
    `);
    stmt.run(ev);
  },

  bulkUpsert(records: Event2026Record[]): number {
    let count = 0;
    const tx = sqlite.transaction(() => {
      for (const r of records) {
        this.upsert(r);
        count++;
      }
    });
    tx();
    return count;
  },

  getById(eventId: string): Event2026Record | undefined {
    return sqlite.prepare("SELECT * FROM events_2026 WHERE event_id = ?").get(eventId) as Event2026Record | undefined;
  },

  list(params: {
    category?: string;
    sport?: string;
    state?: string;
    city?: string;
    level?: string;
    verification?: string;
    status?: string;
    search?: string;
    startDate?: string;
    endDate?: string;
    month?: number; // 1-12
    limit?: number;
    offset?: number;
  } = {}): { items: Event2026Record[]; total: number } {
    const conditions: string[] = [];
    const args: any[] = [];

    if (params.category && params.category !== "All") {
      conditions.push("(sport_category = ? OR sport_category LIKE ?)");
      args.push(params.category, `%${params.category}%`);
    }

    if (params.sport && params.sport !== "All") {
      conditions.push("sport = ?");
      args.push(params.sport);
    }

    if (params.state && params.state !== "All") {
      conditions.push("state_or_union_territory = ?");
      args.push(params.state);
    }

    if (params.city && params.city !== "All") {
      conditions.push("city = ?");
      args.push(params.city);
    }

    if (params.level && params.level !== "All") {
      conditions.push("competition_level = ?");
      args.push(params.level);
    }

    if (params.verification && params.verification !== "All") {
      conditions.push("verification_status = ?");
      args.push(params.verification);
    }

    if (params.status && params.status !== "All") {
      conditions.push("event_status = ?");
      args.push(params.status);
    }

    if (params.startDate) {
      conditions.push("end_date >= ?");
      args.push(params.startDate);
    }

    if (params.endDate) {
      conditions.push("start_date <= ?");
      args.push(params.endDate);
    }

    if (params.month) {
      const monthStr = String(params.month).padStart(2, "0");
      conditions.push("(start_date LIKE ? OR end_date LIKE ?)");
      args.push(`2026-${monthStr}%`, `2026-${monthStr}%`);
    }

    if (params.search && params.search.trim()) {
      const term = `%${params.search.trim()}%`;
      conditions.push(`(
        event_name LIKE ? OR
        sport LIKE ? OR
        city LIKE ? OR
        state_or_union_territory LIKE ? OR
        venue LIKE ? OR
        organizer LIKE ? OR
        sport_category LIKE ?
      )`);
      args.push(term, term, term, term, term, term, term);
    }

    const whereClause = conditions.length > 0 ? "WHERE " + conditions.join(" AND ") : "";

    const countRow = sqlite.prepare(`SELECT COUNT(*) as n FROM events_2026 ${whereClause}`).get(...args) as { n: number };
    const total = countRow?.n || 0;

    const limit = Math.min(params.limit || 500, 1000);
    const offset = Math.max(params.offset || 0, 0);

    const items = sqlite.prepare(`
      SELECT * FROM events_2026
      ${whereClause}
      ORDER BY start_date ASC, event_name ASC
      LIMIT ? OFFSET ?
    `).all(...args, limit, offset) as Event2026Record[];

    return { items, total };
  },

  getMapMarkers(params: {
    category?: string;
    sport?: string;
    state?: string;
    level?: string;
    status?: string;
    verification?: string;
    month?: number;
    search?: string;
  } = {}) {
    const { items } = this.list({
      ...params,
      limit: 1000,
    });

    return items.map((ev) => ({
      id: ev.event_id,
      name: ev.event_name,
      sport: ev.sport,
      category: ev.sport_category,
      level: ev.competition_level,
      city: ev.city,
      state: ev.state_or_union_territory,
      venue: ev.venue || `${ev.city}, ${ev.state_or_union_territory}`,
      lat: ev.latitude,
      lng: ev.longitude,
      startDate: ev.start_date,
      endDate: ev.end_date,
      status: ev.event_status,
      verification: ev.verification_status,
      sourceUrl: ev.official_event_url || (JSON.parse(ev.source_urls || "[]")[0] || null),
      organizer: ev.organizer,
      para: ev.para_sport === 1,
    }));
  },

  remove(eventId: string): void {
    sqlite.prepare("DELETE FROM events_2026 WHERE event_id = ?").run(eventId);
  },

  getKpis(): EventsKPIs {
    const row = sqlite.prepare(`
      SELECT
        COUNT(*) as totalUnique,
        SUM(CASE WHEN verification_status = 'CONFIRMED' THEN 1 ELSE 0 END) as confirmed,
        SUM(CASE WHEN verification_status = 'CROSS-VERIFIED' THEN 1 ELSE 0 END) as crossVerified,
        SUM(CASE WHEN verification_status = 'PARTIALLY VERIFIED' THEN 1 ELSE 0 END) as partiallyVerified,
        SUM(CASE WHEN verification_status = 'UNCONFIRMED' THEN 1 ELSE 0 END) as unconfirmed,
        SUM(CASE WHEN event_status = 'UPCOMING' THEN 1 ELSE 0 END) as upcoming,
        SUM(CASE WHEN event_status = 'ONGOING' THEN 1 ELSE 0 END) as ongoing,
        SUM(CASE WHEN event_status = 'COMPLETED' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN event_status = 'POSTPONED' THEN 1 ELSE 0 END) as postponed,
        SUM(CASE WHEN event_status = 'CANCELLED' THEN 1 ELSE 0 END) as cancelled,
        SUM(CASE WHEN competition_level = 'International' THEN 1 ELSE 0 END) as international,
        SUM(CASE WHEN competition_level = 'National' THEN 1 ELSE 0 END) as national,
        SUM(CASE WHEN competition_level = 'State' THEN 1 ELSE 0 END) as stateLevel,
        SUM(CASE WHEN competition_level = 'Mass-Participation' THEN 1 ELSE 0 END) as massParticipation,
        SUM(CASE WHEN sport_category LIKE '%Marathon%' OR sport_category LIKE '%Endurance%' OR sport LIKE '%Marathon%' OR sport LIKE '%Running%' THEN 1 ELSE 0 END) as marathonEndurance,
        SUM(CASE WHEN event_name LIKE '%Ultra%' OR event_description LIKE '%trail%' OR sport LIKE '%Ultra%' THEN 1 ELSE 0 END) as ultraTrail,
        SUM(CASE WHEN sport_category LIKE '%IRONMAN%' OR sport LIKE '%Triathlon%' OR event_name LIKE '%IRONMAN%' THEN 1 ELSE 0 END) as ironmanTriathlon,
        SUM(CASE WHEN sport_category LIKE '%HYROX%' OR event_name LIKE '%HYROX%' OR sport LIKE '%Fitness%' THEN 1 ELSE 0 END) as hyroxFitness,
        SUM(CASE WHEN sport_category LIKE '%Chess%' OR sport = 'Chess' THEN 1 ELSE 0 END) as chessMindSports,
        SUM(CASE WHEN sport_category = 'Olympic Sports' OR sport_category LIKE '%Olympic%' THEN 1 ELSE 0 END) as olympicSports,
        SUM(CASE WHEN sport_category = 'Commonwealth Games' OR sport_category LIKE '%Commonwealth%' THEN 1 ELSE 0 END) as commonwealthSports,
        SUM(CASE WHEN sport_category = 'Asian Games' OR sport_category LIKE '%Asian Games%' THEN 1 ELSE 0 END) as asianGamesSports,
        SUM(CASE WHEN para_sport = 1 THEN 1 ELSE 0 END) as paraSports,
        SUM(CASE WHEN sport_category LIKE '%Indigenous%' OR sport IN ('Kabaddi', 'Kho Kho', 'Mallakhamb', 'Kalaripayattu') THEN 1 ELSE 0 END) as indigenousSports,
        SUM(CASE WHEN verification_status IN ('PARTIALLY VERIFIED', 'UNCONFIRMED') THEN 1 ELSE 0 END) as awaitingVerification,
        COUNT(DISTINCT CASE WHEN country = 'India' THEN state_or_union_territory END) as statesRepresented,
        COUNT(DISTINCT CASE WHEN country = 'India' THEN city END) as citiesRepresented,
        MAX(last_updated_at) as lastUpdatedAt
      FROM events_2026
    `).get() as any;

    return {
      totalUnique: Number(row?.totalUnique || 0),
      confirmed: Number(row?.confirmed || 0),
      crossVerified: Number(row?.crossVerified || 0),
      partiallyVerified: Number(row?.partiallyVerified || 0),
      unconfirmed: Number(row?.unconfirmed || 0),
      upcoming: Number(row?.upcoming || 0),
      ongoing: Number(row?.ongoing || 0),
      completed: Number(row?.completed || 0),
      postponed: Number(row?.postponed || 0),
      cancelled: Number(row?.cancelled || 0),
      international: Number(row?.international || 0),
      national: Number(row?.national || 0),
      stateLevel: Number(row?.stateLevel || 0),
      massParticipation: Number(row?.massParticipation || 0),
      marathonEndurance: Number(row?.marathonEndurance || 0),
      ultraTrail: Number(row?.ultraTrail || 0),
      ironmanTriathlon: Number(row?.ironmanTriathlon || 0),
      hyroxFitness: Number(row?.hyroxFitness || 0),
      chessMindSports: Number(row?.chessMindSports || 0),
      olympicSports: Number(row?.olympicSports || 0),
      commonwealthSports: Number(row?.commonwealthSports || 0),
      asianGamesSports: Number(row?.asianGamesSports || 0),
      paraSports: Number(row?.paraSports || 0),
      indigenousSports: Number(row?.indigenousSports || 0),
      awaitingVerification: Number(row?.awaitingVerification || 0),
      statesRepresented: Number(row?.statesRepresented || 0),
      citiesRepresented: Number(row?.citiesRepresented || 0),
      lastUpdatedAt: row?.lastUpdatedAt || new Date().toISOString(),
    };
  },

  getStateSummaries() {
    const states = [
      // 28 States
      "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
      "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
      "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur",
      "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab",
      "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
      "Uttar Pradesh", "Uttarakhand", "West Bengal",
      // 8 Union Territories
      "Andaman and Nicobar Islands", "Chandigarh",
      "Dadra and Nagar Haveli and Daman and Diu", "Delhi",
      "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry"
    ];

    const allEvents = sqlite.prepare("SELECT * FROM events_2026 ORDER BY start_date ASC").all() as Event2026Record[];

    return states.map((stateName) => {
      const stateEvents = allEvents.filter(
        (e) => e.state_or_union_territory.toLowerCase() === stateName.toLowerCase()
      );

      const sports: Record<string, number> = {};
      const monthly = Array(12).fill(0);
      const majorEvents: string[] = [];

      for (const ev of stateEvents) {
        sports[ev.sport] = (sports[ev.sport] || 0) + 1;

        const m = parseInt(ev.start_date.split("-")[1], 10);
        if (m >= 1 && m <= 12) {
          monthly[m - 1]++;
        }

        if (ev.competition_level === "National" || ev.competition_level === "International") {
          if (majorEvents.length < 5) {
            majorEvents.push(ev.event_name);
          }
        }
      }

      // Calculate research completeness score (0 to 100%)
      const verifiedCount = stateEvents.filter(e => e.verification_status === "CONFIRMED" || e.verification_status === "CROSS-VERIFIED").length;
      const completeness = stateEvents.length === 0 ? 0 : Math.round((verifiedCount / stateEvents.length) * 100);

      return {
        state: stateName,
        count: stateEvents.length,
        sports,
        monthly,
        majorEvents,
        completeness,
        upcomingCount: stateEvents.filter(e => e.event_status === "UPCOMING").length,
        cities: Array.from(new Set(stateEvents.map(e => e.city))),
      };
    }).sort((a, b) => b.count - a.count || a.state.localeCompare(b.state));
  },

  getMonthlyBreakdown() {
    const monthNames = [
      "Jan 2026", "Feb 2026", "Mar 2026", "Apr 2026", "May 2026", "Jun 2026",
      "Jul 2026", "Aug 2026", "Sep 2026", "Oct 2026", "Nov 2026", "Dec 2026"
    ];

    const events = sqlite.prepare("SELECT * FROM events_2026").all() as Event2026Record[];

    return monthNames.map((name, idx) => {
      const mStr = String(idx + 1).padStart(2, "0");
      const inMonth = events.filter(e => e.start_date.startsWith(`2026-${mStr}`) || (e.start_date <= `2026-${mStr}-31` && e.end_date >= `2026-${mStr}-01`));

      const sports: Record<string, number> = {};
      const levels: Record<string, number> = {};

      for (const e of inMonth) {
        sports[e.sport] = (sports[e.sport] || 0) + 1;
        levels[e.competition_level] = (levels[e.competition_level] || 0) + 1;
      }

      return {
        month: name,
        monthIndex: idx + 1,
        total: inMonth.length,
        sports,
        levels,
      };
    });
  },

  updateLifecycleStatuses(nowIsoDate: string): { updated: number } {
    const events = sqlite.prepare("SELECT event_id, start_date, end_date, event_status FROM events_2026").all() as Array<{
      event_id: string;
      start_date: string;
      end_date: string;
      event_status: string;
    }>;

    let updated = 0;
    const stmt = sqlite.prepare("UPDATE events_2026 SET event_status = ?, last_updated_at = ? WHERE event_id = ?");

    const nowUtc = new Date().toISOString();

    for (const ev of events) {
      if (ev.event_status === "POSTPONED" || ev.event_status === "CANCELLED") continue;

      let newStatus: "UPCOMING" | "ONGOING" | "COMPLETED" = "UPCOMING";
      if (nowIsoDate > ev.end_date) {
        newStatus = "COMPLETED";
      } else if (nowIsoDate >= ev.start_date && nowIsoDate <= ev.end_date) {
        newStatus = "ONGOING";
      } else {
        newStatus = "UPCOMING";
      }

      if (newStatus !== ev.event_status) {
        stmt.run(newStatus, nowUtc, ev.event_id);
        updated++;
      }
    }

    return { updated };
  },

  logSync(source: string, discovered: number, inserted: number, updated: number, status: string, error?: string): void {
    sqlite.prepare(`
      INSERT INTO events_sync_audit (source, discovered_count, inserted_count, updated_count, status, error_message, executed_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
    `).run(source, discovered, inserted, updated, status, error || null);
  },

  getLatestSyncAudit() {
    return sqlite.prepare("SELECT * FROM events_sync_audit ORDER BY executed_at DESC LIMIT 10").all();
  },

  getCachedGeocode(query: string) {
    return sqlite.prepare("SELECT latitude, longitude FROM geocoding_cache WHERE query = ?").get(query) as { latitude: number; longitude: number } | undefined;
  },

  cacheGeocode(query: string, lat: number, lng: number, displayName: string) {
    sqlite.prepare("INSERT OR REPLACE INTO geocoding_cache (query, latitude, longitude, display_name) VALUES (?, ?, ?, ?)").run(query, lat, lng, displayName);
  }
};
