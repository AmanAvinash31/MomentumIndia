import type { Request, Response, NextFunction } from "express";

interface CacheEntry<T = any> {
  value: T;
  expiresAt: number;
}

const MAX_CACHE_KEYS = 500;
const cacheStore = new Map<string, CacheEntry>();

/**
 * Prunes expired cache entries or evicts oldest entries if exceeding MAX_CACHE_KEYS.
 */
function pruneCache(): void {
  const now = Date.now();
  for (const [key, entry] of cacheStore.entries()) {
    if (now > entry.expiresAt) {
      cacheStore.delete(key);
    }
  }

  if (cacheStore.size > MAX_CACHE_KEYS) {
    // Evict oldest entries
    const keysToDelete = Array.from(cacheStore.keys()).slice(0, cacheStore.size - MAX_CACHE_KEYS);
    for (const k of keysToDelete) {
      cacheStore.delete(k);
    }
  }
}

setInterval(pruneCache, 60 * 1000).unref();

export const cache = {
  get<T = any>(key: string): T | undefined {
    const entry = cacheStore.get(key);
    if (!entry) return undefined;
    if (Date.now() > entry.expiresAt) {
      cacheStore.delete(key);
      return undefined;
    }
    return entry.value as T;
  },

  set<T = any>(key: string, value: T, ttlMs: number): void {
    if (cacheStore.size >= MAX_CACHE_KEYS) {
      pruneCache();
    }
    cacheStore.set(key, {
      value,
      expiresAt: Date.now() + ttlMs,
    });
  },

  delete(key: string): boolean {
    return cacheStore.delete(key);
  },

  clear(): void {
    cacheStore.clear();
  },

  size(): number {
    return cacheStore.size;
  },

  async getOrSet<T = any>(key: string, ttlMs: number, fetcher: () => Promise<T> | T): Promise<T> {
    const cached = cache.get<T>(key);
    if (cached !== undefined) return cached;
    const fresh = await fetcher();
    cache.set(key, fresh, ttlMs);
    return fresh;
  },
};

/**
 * Middleware: sets Cache-Control header for public endpoints.
 * @param s max-age in seconds
 * @param swr stale-while-revalidate in seconds
 */
export function publicCache(s = 10, swr = 30) {
  return (_req: Request, res: Response, next: NextFunction): void => {
    res.setHeader("Cache-Control", `public, max-age=${s}, stale-while-revalidate=${swr}`);
    next();
  };
}
