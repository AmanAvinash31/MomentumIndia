import crypto from "node:crypto";

export function getManageSecret(): string {
  const secret = process.env.MANAGE_SECRET;
  if (!secret) {
    if (process.env.NODE_ENV === "production") {
      throw new Error("MANAGE_SECRET environment variable must be set in production");
    }
    return "dev-manage-secret-change-in-production-min32chars";
  }
  return secret;
}

export function generateManageToken(email: string): string {
  const secret = getManageSecret();
  const normalized = email.trim().toLowerCase();
  return crypto.createHmac("sha256", secret).update(normalized).digest("hex");
}

export function verifyManageToken(email: string, token: string | undefined | null): boolean {
  if (!token || typeof token !== "string") return false;
  try {
    const expected = generateManageToken(email);
    const tokenBuf = Buffer.from(token, "hex");
    const expectedBuf = Buffer.from(expected, "hex");
    if (tokenBuf.length !== expectedBuf.length) return false;
    return crypto.timingSafeEqual(tokenBuf, expectedBuf);
  } catch {
    return false;
  }
}
