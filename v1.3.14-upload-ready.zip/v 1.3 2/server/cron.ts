import cron from "node-cron";
import { sportsAgent } from "./sports-agent";
import { agentStorage, cronLocks } from "./storage";
import { providerManager } from "./providers/manager";
import { dynamicSyncEngine } from "./dynamic-sync";
import { eventsSyncEngine } from "./events-sync";

export function initCronJobs() {
  console.log("[cron] cron started: news (10m), results (2h), calendar (daily), medals (15m live/6h ended), fixtures (30m)");

  // 1. News job every 10 minutes (Asia/Kolkata timezone)
  cron.schedule("*/10 * * * *", async () => {
    if (!cronLocks.canRun("cron_news", 8 * 60 * 1000)) {
      console.log("[cron] Skipping news job; ran recently or locked by another instance.");
      return;
    }
    try {
      console.log(`[cron ${new Date().toISOString()}] Running news fetch job...`);
      const res = await sportsAgent.fetchLatestNews();
      console.log(`[cron] news job finished: ingested ${res.count} new items. Total news stored: ${agentStorage.stats().totalNews}`);
    } catch (err: any) {
      console.warn("[cron] news job error:", err?.message || err);
    }
  }, {
    timezone: "Asia/Kolkata"
  });

  // 2. Results job at 06:00 IST and every 2 hours after (00:00, 02:00, 04:00, 06:00, 08:00, 10:00, 12:00, 14:00, 16:00, 18:00, 20:00, 22:00 IST)
  cron.schedule("0 0,2,4,6,8,10,12,14,16,18,20,22 * * *", async () => {
    if (!cronLocks.canRun("cron_results", 60 * 60 * 1000)) {
      console.log("[cron] Skipping results job; ran recently or locked by another instance.");
      return;
    }
    try {
      console.log(`[cron ${new Date().toISOString()}] Running results fetch job (IST schedule)...`);
      const res = await sportsAgent.fetchLatestResults();
      console.log(`[cron] results job finished: ingested ${res.count} new results. Total results stored: ${agentStorage.stats().totalResults}`);
    } catch (err: any) {
      console.warn("[cron] results job error:", err?.message || err);
    }
  }, {
    timezone: "Asia/Kolkata"
  });

  // 3. 90-day retention cleanup daily at midnight IST
  cron.schedule("0 0 * * *", async () => {
    if (!cronLocks.canRun("cron_retention", 12 * 60 * 60 * 1000)) return;
    try {
      console.log(`[cron ${new Date().toISOString()}] Running 90-day retention cleanup...`);
      agentStorage.purgeOldRecords();
      console.log("[cron] 90-day retention cleanup finished.");
    } catch (err: any) {
      console.warn("[cron] retention cleanup error:", err?.message || err);
    }
  }, {
    timezone: "Asia/Kolkata"
  });

  // 4. Real Data Providers & Dynamic Telemetry: periodic cron tick (every 15 min)
  cron.schedule("*/15 * * * *", async () => {
    try {
      await providerManager.scheduleCronTick();
      await dynamicSyncEngine.syncAll();
    } catch (err: any) {
      console.warn("[cron] provider tick error:", err?.message || err);
    }
  }, {
    timezone: "Asia/Kolkata"
  });

  // 5. India Sports Events 2026 Telemetry Ingestion (every 6 hours)
  cron.schedule("0 */6 * * *", async () => {
    try {
      console.log(`[cron ${new Date().toISOString()}] Running 2026 Events multi-source telemetry refresh...`);
      await eventsSyncEngine.runFullSync();
    } catch (err: any) {
      console.warn("[cron] events sync error:", err?.message || err);
    }
  }, {
    timezone: "Asia/Kolkata"
  });

  // Run initial fetch on startup ONLY if not fetched recently (guards restarts and multi-instance sweeps)
  if (cronLocks.canRun("startup_news", 8 * 60 * 1000)) {
    console.log("[cron] Running startup news fetch...");
    sportsAgent.fetchLatestNews().catch(e => console.warn("[cron] Initial news fetch warning:", e?.message || e));
  } else {
    console.log("[cron] Startup news fetch skipped (sweep executed within last 8m).");
  }

  if (cronLocks.canRun("startup_results", 30 * 60 * 1000)) {
    console.log("[cron] Running startup results fetch...");
    sportsAgent.fetchLatestResults().catch(e => console.warn("[cron] Initial results fetch warning:", e?.message || e));
  } else {
    console.log("[cron] Startup results fetch skipped (sweep executed within last 30m).");
  }

  // Initialize data provider manager (loads calendar, medal tables, ISL fixtures, GDELT)
  providerManager.init().catch(e => console.warn("[cron] providerManager init warning:", e?.message || e));

  // Initialize full-site dynamic telemetry tables & feeds
  dynamicSyncEngine.initialize().catch(e => console.warn("[cron] dynamicSyncEngine init warning:", e?.message || e));

  // Initialize India Sports Events 2026 telemetry engine
  eventsSyncEngine.initialize().catch(e => console.warn("[cron] eventsSyncEngine init warning:", e?.message || e));
}
