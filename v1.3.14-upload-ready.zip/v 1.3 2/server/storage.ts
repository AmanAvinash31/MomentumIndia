import { subscribers } from "@shared/schema";
import type { Subscriber, InsertSubscriber } from "@shared/schema";
import { drizzle } from "drizzle-orm/better-sqlite3";
import { eq, count } from "drizzle-orm";
import { liveEvents } from "./events";

import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const nodeRequire: NodeRequire = typeof require !== "undefined"
  ? require
  : createRequire(typeof import.meta !== "undefined" && import.meta.url ? import.meta.url : "file:///index.js");

// DATA_DIR should point at a persistent disk in production (e.g. /var/data on Render).
const DATA_DIR = process.env.DATA_DIR || ".";
fs.mkdirSync(DATA_DIR, { recursive: true });
export const DB_PATH = path.resolve(DATA_DIR, "data.db");

// Universal crash-proof SQLite adapter (supports built-in node:sqlite or better-sqlite3)
export class UniversalSqlite {
  raw: any;
  mode: "node:sqlite" | "better-sqlite3";
  filePath: string;

  constructor(filePath: string) {
    this.filePath = filePath;
    let nodeSqlite: any = null;
    try {
      // Node 22+ & 24+ built-in sqlite: Zero native compilation, cannot core dump
      nodeSqlite = nodeRequire("node:sqlite");
    } catch {
      nodeSqlite = null;
    }

    if (nodeSqlite && nodeSqlite.DatabaseSync) {
      this.mode = "node:sqlite";
      this.raw = new nodeSqlite.DatabaseSync(filePath);
    } else {
      try {
        const BetterSqlite = nodeRequire("better-sqlite3");
        this.mode = "better-sqlite3";
        this.raw = new BetterSqlite(filePath);
      } catch (err) {
        console.warn("[storage] better-sqlite3 failed, falling back to node:sqlite in-memory:", err);
        const fb = nodeRequire("node:sqlite");
        this.mode = "node:sqlite";
        this.raw = new fb.DatabaseSync(filePath);
      }
    }
  }

  pragma(sql: string) {
    if (this.mode === "better-sqlite3") return this.raw.pragma(sql);
    try {
      if (sql.includes("=")) {
        this.raw.exec("PRAGMA " + sql);
        return [];
      }
      return this.raw.prepare("PRAGMA " + sql).all();
    } catch {
      return [];
    }
  }

  exec(sql: string) {
    return this.raw.exec(sql);
  }

  backup(dest: string) {
    if (this.mode === "better-sqlite3" && typeof this.raw.backup === "function") {
      return this.raw.backup(dest);
    }
    try {
      fs.copyFileSync(this.filePath, dest);
      return Promise.resolve();
    } catch (e) {
      return Promise.reject(e);
    }
  }

  transaction(fn: (...args: any[]) => any) {
    if (this.mode === "better-sqlite3") return this.raw.transaction(fn);
    return (...args: any[]) => {
      this.raw.exec("BEGIN");
      try {
        const res = fn(...args);
        this.raw.exec("COMMIT");
        return res;
      } catch (err) {
        this.raw.exec("ROLLBACK");
        throw err;
      }
    };
  }

  prepare(sql: string) {
    if (this.mode === "better-sqlite3") return this.raw.prepare(sql);
    let stmt: any;
    try {
      stmt = this.raw.prepare(sql);
    } catch (e) {
      return {
        raw: () => this,
        all: () => [],
        get: () => undefined,
        run: () => ({ changes: 0, lastInsertRowid: 0 }),
        iterate: () => [][Symbol.iterator](),
      };
    }
    let isRaw = false;
    const wrapper: any = {
      raw: (mode = true) => {
        isRaw = mode;
        return wrapper;
      },
      all: (...args: any[]) => {
        let params = args;
        if (args.length === 1 && args[0] && typeof args[0] === "object" && !Array.isArray(args[0])) {
          params = [args[0]];
        }
        const rows = stmt.all(...params);
        if (isRaw) return rows.map((r: any) => Object.values(r));
        return rows;
      },
      get: (...args: any[]) => {
        let params = args;
        if (args.length === 1 && args[0] && typeof args[0] === "object" && !Array.isArray(args[0])) {
          params = [args[0]];
        }
        const row = stmt.get(...params);
        if (!row) return undefined;
        if (isRaw) return Object.values(row);
        return row;
      },
      run: (...args: any[]) => {
        let params = args;
        if (args.length === 1 && args[0] && typeof args[0] === "object" && !Array.isArray(args[0])) {
          params = [args[0]];
        }
        const res = stmt.run(...params);
        return {
          changes: Number(res.changes || 0),
          lastInsertRowid: Number(res.lastInsertRowid || 0),
        };
      },
      iterate: (...args: any[]) => wrapper.all(...args)[Symbol.iterator](),
    };
    return wrapper;
  }
}

export const sqlite = new UniversalSqlite(DB_PATH);
sqlite.pragma("journal_mode = WAL");
sqlite.pragma("busy_timeout = 5000");
sqlite.exec(`CREATE TABLE IF NOT EXISTS subscribers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  interests TEXT NOT NULL DEFAULT '[]',
  lang TEXT NOT NULL DEFAULT 'en'
)`);

export const db = drizzle(sqlite as any);

export interface IStorage {
  findSubscriber(email: string): Promise<Subscriber | undefined>;
  upsertSubscriber(s: InsertSubscriber): Promise<{ subscriber: Subscriber; existed: boolean }>;
  removeSubscriber(email: string): Promise<boolean>;
  countSubscribers(): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  async findSubscriber(email: string) {
    return db.select().from(subscribers).where(eq(subscribers.email, email)).get();
  }
  async upsertSubscriber(s: InsertSubscriber) {
    const found = await this.findSubscriber(s.email);
    if (found) {
      const subscriber = db.update(subscribers).set({ interests: s.interests, lang: s.lang }).where(eq(subscribers.email, s.email)).returning().get();
      return { subscriber, existed: true };
    }
    return { subscriber: db.insert(subscribers).values(s).returning().get(), existed: false };
  }
  async removeSubscriber(email: string) {
    return db.delete(subscribers).where(eq(subscribers.email, email)).run().changes > 0;
  }
  async countSubscribers() {
    return db.select({ n: count() }).from(subscribers).get()?.n ?? 0;
  }
}

export const storage = new DatabaseStorage();

/* ---------- follows and listing claims ---------- */
sqlite.exec(`CREATE TABLE IF NOT EXISTS follows (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL, kind TEXT NOT NULL, key TEXT NOT NULL, label TEXT NOT NULL,
  created TEXT NOT NULL DEFAULT (datetime('now')), UNIQUE(email, kind, key)
);
CREATE TABLE IF NOT EXISTS alert_prefs (
  email TEXT PRIMARY KEY, whatsapp TEXT, channels TEXT NOT NULL DEFAULT '["email"]'
);
CREATE TABLE IF NOT EXISTS listing_claims (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  listing TEXT NOT NULL, kind TEXT NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL,
  email TEXT NOT NULL, phone TEXT NOT NULL, fees TEXT, coaches TEXT, website TEXT, notes TEXT,
  status TEXT NOT NULL DEFAULT 'pending', created TEXT NOT NULL DEFAULT (datetime('now'))
);`);

export type FollowRow = { kind: string; key: string; label: string; created: string };
export const follows = {
  list: (email: string) => sqlite.prepare("SELECT kind, key, label, created FROM follows WHERE email = ? ORDER BY created DESC").all(email) as FollowRow[],
  add: (email: string, items: { kind: string; key: string; label: string }[]) => {
    const st = sqlite.prepare("INSERT OR IGNORE INTO follows (email, kind, key, label) VALUES (?, ?, ?, ?)");
    let n = 0; sqlite.transaction(() => { for (const i of items) n += st.run(email, i.kind, i.key, i.label).changes; })(); return n;
  },
  remove: (email: string, kind: string, key: string) => sqlite.prepare("DELETE FROM follows WHERE email = ? AND kind = ? AND key = ?").run(email, kind, key).changes > 0,
  prefs: (email: string) => sqlite.prepare("SELECT whatsapp, channels FROM alert_prefs WHERE email = ?").get(email) as { whatsapp: string | null; channels: string } | undefined,
  setPrefs: (email: string, whatsapp: string | null, channels: string[]) =>
    sqlite.prepare("INSERT INTO alert_prefs (email, whatsapp, channels) VALUES (?, ?, ?) ON CONFLICT(email) DO UPDATE SET whatsapp = excluded.whatsapp, channels = excluded.channels").run(email, whatsapp, JSON.stringify(channels)),
  count: () => (sqlite.prepare("SELECT COUNT(DISTINCT email) n FROM follows").get() as { n: number }).n,
};
export const claims = {
  add: (c: Record<string, string | null>) => Number(sqlite.prepare(`INSERT INTO listing_claims (listing, kind, name, role, email, phone, fees, coaches, website, notes)
    VALUES (@listing, @kind, @name, @role, @email, @phone, @fees, @coaches, @website, @notes)`).run(c).lastInsertRowid),
  count: () => (sqlite.prepare("SELECT COUNT(*) n FROM listing_claims").get() as { n: number }).n,
};

sqlite.exec(`CREATE TABLE IF NOT EXISTS corrections (
  id INTEGER PRIMARY KEY AUTOINCREMENT, page TEXT NOT NULL, detail TEXT NOT NULL, source TEXT, email TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open', created TEXT NOT NULL DEFAULT (datetime('now'))
)`);
export const corrections = {
  add: (c: { page: string; detail: string; source: string | null; email: string }) => Number(sqlite.prepare("INSERT INTO corrections (page, detail, source, email) VALUES (@page, @detail, @source, @email)").run(c).lastInsertRowid),
};

/* ---------- sporting nation: pledges, local stars, competitions, sponsorship ---------- */
sqlite.exec(`CREATE TABLE IF NOT EXISTS nation_pledges (
  id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, actions TEXT NOT NULL, state TEXT, created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS nation_nominations (
  id INTEGER PRIMARY KEY AUTOINCREMENT, athlete TEXT NOT NULL, sport TEXT NOT NULL, district TEXT NOT NULL, state TEXT NOT NULL,
  age_band TEXT NOT NULL, achievement TEXT NOT NULL, link TEXT, nominator TEXT NOT NULL, email TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS nation_competitions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, sport TEXT NOT NULL, city TEXT NOT NULL, state TEXT NOT NULL,
  date TEXT NOT NULL, ages TEXT NOT NULL, level TEXT NOT NULL, link TEXT, email TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS nation_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT, sport TEXT NOT NULL, state TEXT NOT NULL, age_band TEXT NOT NULL, level TEXT NOT NULL,
  need TEXT NOT NULL, amount INTEGER NOT NULL, story TEXT NOT NULL, name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS nation_offers (
  id INTEGER PRIMARY KEY AUTOINCREMENT, org TEXT NOT NULL, kind TEXT NOT NULL, budget TEXT NOT NULL, sports TEXT NOT NULL, states TEXT NOT NULL,
  request_id INTEGER, contact TEXT NOT NULL, email TEXT NOT NULL, csr INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending', created TEXT NOT NULL DEFAULT (datetime('now'))
);`);

// Light migrations for databases created by earlier versions.
const cols = (t: string) => (sqlite.prepare(`PRAGMA table_info(${t})`).all() as { name: string }[]).map(c => c.name);
for (const t of ["nation_competitions", "nation_offers"]) if (!cols(t).includes("status")) sqlite.exec(`ALTER TABLE ${t} ADD COLUMN status TEXT NOT NULL DEFAULT 'pending'`);
sqlite.exec("UPDATE nation_requests SET status = 'pending' WHERE status = 'open'");

sqlite.exec(`CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin',
  action TEXT NOT NULL,
  target_table TEXT NOT NULL,
  target_id INTEGER,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS admin_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  token TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('editor', 'moderator', 'admin')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_log_target ON audit_log(target_table, target_id);
`);

export const auditLog = {
  record: (entry: { actor: string; role?: string; action: string; target_table: string; target_id?: number | null; details?: string | null }) => {
    try {
      sqlite.prepare(`INSERT INTO audit_log (actor, role, action, target_table, target_id, details) VALUES (?, ?, ?, ?, ?, ?)`).run(
        entry.actor || "admin", entry.role || "admin", entry.action, entry.target_table, entry.target_id ?? null, entry.details ?? null
      );
    } catch (e) {
      console.error("[audit_log] failed to record:", e);
    }
  },
  list: (limit = 100) => {
    return sqlite.prepare(`SELECT * FROM audit_log ORDER BY id DESC LIMIT ?`).all(limit);
  }
};


export const q = (sql: string) => sqlite.prepare(sql);
export const nation = {
  pledge: (role: string, actions: string[], state: string | null) => Number(q("INSERT INTO nation_pledges (role, actions, state) VALUES (?, ?, ?)").run(role, JSON.stringify(actions), state).lastInsertRowid),
  nominate: (n: Record<string, string | null>) => Number(q(`INSERT INTO nation_nominations (athlete, sport, district, state, age_band, achievement, link, nominator, email)
    VALUES (@athlete, @sport, @district, @state, @age_band, @achievement, @link, @nominator, @email)`).run(n).lastInsertRowid),
  addCompetition: (c: Record<string, string | null>) => Number(q(`INSERT INTO nation_competitions (name, sport, city, state, date, ages, level, link, email)
    VALUES (@name, @sport, @city, @state, @date, @ages, @level, @link, @email)`).run(c).lastInsertRowid),
  addRequest: (r: Record<string, string | number | null>) => Number(q(`INSERT INTO nation_requests (sport, state, age_band, level, need, amount, story, name, email, phone)
    VALUES (@sport, @state, @age_band, @level, @need, @amount, @story, @name, @email, @phone)`).run(r).lastInsertRowid),
  addOffer: (o: Record<string, string | number | null>) => Number(q(`INSERT INTO nation_offers (org, kind, budget, sports, states, request_id, contact, email, csr)
    VALUES (@org, @kind, @budget, @sports, @states, @request_id, @contact, @email, @csr)`).run(o).lastInsertRowid),
  requestExists: (id: number) => !!q("SELECT 1 FROM nation_requests WHERE id = ? AND status = 'approved'").get(id),
  summary: () => {
    const pledges = q("SELECT role, COUNT(*) n FROM nation_pledges GROUP BY role").all() as { role: string; n: number }[];
    // Public views never include names, emails or phone numbers. Minors are shown only by age band, sport and state.
    const stars = q(`SELECT id, substr(athlete, 1, instr(athlete || ' ', ' ') - 1) first, sport, district, state, age_band, achievement, created
      FROM nation_nominations WHERE status = 'approved' ORDER BY id DESC LIMIT 12`).all();
    const competitions = q(`SELECT id, name, sport, city, state, date, ages, level, link FROM nation_competitions WHERE status = 'approved' AND date >= date('now', '-1 day') ORDER BY date ASC LIMIT 40`).all();
    const requests = q(`SELECT r.id, r.sport, r.state, r.age_band, r.level, r.need, r.amount, r.story, r.created,
      (SELECT COUNT(*) FROM nation_offers o WHERE o.request_id = r.id) backers FROM nation_requests r WHERE r.status = 'approved' ORDER BY r.id DESC LIMIT 24`).all();
    const offers = (q("SELECT COUNT(*) n FROM nation_offers").get() as { n: number }).n;
    const nominations = (q("SELECT COUNT(*) n FROM nation_nominations").get() as { n: number }).n;
    return { pledges, stars, competitions, requests, offers, nominations };
  },
};

/* ---------- admin ---------- */
// Whitelisted tables only. `moderated` tables have a status the admin can change.
const MOD = ["pending", "approved", "rejected"];
export const ADMIN_TABLES: Record<string, { table: string; label: string; statuses: string[]; content?: boolean; create?: AdminField[]; edit?: AdminField[] }> = {
  nominations: { table: "nation_nominations", label: "Local star nominations", statuses: MOD },
  requests: { table: "nation_requests", label: "Sponsorship requests", statuses: MOD },
  offers: { table: "nation_offers", label: "Sponsor offers", statuses: ["pending", "introduced", "rejected"] },
  competitions: { table: "nation_competitions", label: "Community competitions", statuses: MOD },
  claims: { table: "listing_claims", label: "Facility listing claims", statuses: MOD },
  corrections: { table: "corrections", label: "Corrections", statuses: ["open", "resolved"] },
  pledges: { table: "nation_pledges", label: "Pledges", statuses: [] },
  subscribers: { table: "subscribers", label: "Newsletter subscribers", statuses: [] },
  follows: { table: "follows", label: "Follows", statuses: [] },
};
export const admin = {
  overview: () => Object.entries(ADMIN_TABLES).map(([k, t]) => {
    const tableCols = cols(t.table);
    const has = t.statuses.length > 0 && tableCols.includes("status");
    const hasDeletedAt = tableCols.includes("deleted_at");
    const notDeleted = hasDeletedAt ? " WHERE deleted_at IS NULL" : "";
    const total = (q(`SELECT COUNT(*) n FROM ${t.table}${notDeleted}`).get() as { n: number }).n;
    const pending = has ? (q(`SELECT COUNT(*) n FROM ${t.table} WHERE status = ?${hasDeletedAt ? " AND deleted_at IS NULL" : ""}`).get(t.statuses[0]) as { n: number }).n : 0;
    return { key: k, label: t.label, statuses: has ? t.statuses : [], total, pending: t.content ? 0 : pending, content: !!t.content, create: t.create ?? null, edit: t.edit ?? null };
  }),
  list: (k: string, status?: string, limit = 200, includeDeleted = false) => {
    const t = ADMIN_TABLES[k]; const tableCols = cols(t.table);
    const has = tableCols.includes("status");
    const hasDeletedAt = tableCols.includes("deleted_at");
    let sql = `SELECT * FROM ${t.table}`;
    const where: string[] = [];
    const params: any[] = [];
    if (hasDeletedAt && !includeDeleted) {
      where.push("deleted_at IS NULL");
    }
    if (status && has) {
      where.push("status = ?");
      params.push(status);
    }
    if (where.length > 0) sql += " WHERE " + where.join(" AND ");
    sql += " ORDER BY id DESC LIMIT ?";
    params.push(limit);
    return q(sql).all(...params);
  },
  setStatus: (k: string, id: number, status: string, actor = "admin", role = "admin") => {
    const changes = q(`UPDATE ${ADMIN_TABLES[k].table} SET status = ? WHERE id = ?`).run(status, id).changes > 0;
    if (changes) {
      auditLog.record({ actor, role, action: "set_status", target_table: ADMIN_TABLES[k].table, target_id: id, details: status });
    }
    return changes;
  },
  remove: (k: string, id: number, actor = "admin", role = "admin") => {
    const t = ADMIN_TABLES[k];
    const tableCols = cols(t.table);
    let changes = 0;
    if (tableCols.includes("deleted_at")) {
      changes = q(`UPDATE ${t.table} SET deleted_at = datetime('now') WHERE id = ?`).run(id).changes;
    } else {
      changes = q(`DELETE FROM ${t.table} WHERE id = ?`).run(id).changes;
    }
    if (changes > 0) {
      auditLog.record({ actor, role, action: "soft_delete", target_table: t.table, target_id: id });
    }
    return changes > 0;
  },
  all: (k: string) => {
    const t = ADMIN_TABLES[k];
    const tableCols = cols(t.table);
    const where = tableCols.includes("deleted_at") ? " WHERE deleted_at IS NULL" : "";
    return q(`SELECT * FROM ${t.table}${where} ORDER BY id`).all() as Record<string, unknown>[];
  },
  backup: (dest: string) => sqlite.backup(dest),
  auditLogs: (limit = 100) => auditLog.list(limit),
};

/* ---------- live results, leagues, fan zone, community (v3) ---------- */
sqlite.exec(`CREATE TABLE IF NOT EXISTS live_medals (
  id INTEGER PRIMARY KEY AUTOINCREMENT, games TEXT NOT NULL DEFAULT 'apg2026', date TEXT NOT NULL, athlete TEXT NOT NULL, sport TEXT NOT NULL,
  event TEXT NOT NULL, medal TEXT NOT NULL CHECK (medal IN ('G','S','B')), state TEXT, link TEXT, ext_id TEXT UNIQUE,
  status TEXT NOT NULL DEFAULT 'published', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS fixtures (
  id INTEGER PRIMARY KEY AUTOINCREMENT, league TEXT NOT NULL, date TEXT NOT NULL, time TEXT, home TEXT NOT NULL, away TEXT NOT NULL, venue TEXT,
  home_score INTEGER, away_score INTEGER, status TEXT NOT NULL DEFAULT 'scheduled', ext_id TEXT UNIQUE, created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS predictions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, options TEXT NOT NULL, closes_at TEXT NOT NULL, answer TEXT, points INTEGER NOT NULL DEFAULT 10,
  topic TEXT, status TEXT NOT NULL DEFAULT 'open', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS picks (
  id INTEGER PRIMARY KEY AUTOINCREMENT, qid INTEGER NOT NULL, nickname TEXT NOT NULL, email TEXT NOT NULL, choice TEXT NOT NULL,
  created TEXT NOT NULL DEFAULT (datetime('now')), UNIQUE(qid, email)
);
CREATE TABLE IF NOT EXISTS clubs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, kind TEXT NOT NULL, sport TEXT NOT NULL, city TEXT NOT NULL, state TEXT NOT NULL,
  ages TEXT, fees TEXT, timings TEXT, girls_only INTEGER NOT NULL DEFAULT 0, about TEXT, contact_name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL, website TEXT,
  status TEXT NOT NULL DEFAULT 'pending', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS grounds (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, place TEXT NOT NULL, district TEXT NOT NULL, state TEXT NOT NULL, sport TEXT NOT NULL,
  need TEXT NOT NULL, budget INTEGER NOT NULL, story TEXT NOT NULL, users TEXT, contact_name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS adoptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ground_id INTEGER NOT NULL, org TEXT NOT NULL, kind TEXT NOT NULL, amount TEXT NOT NULL, contact TEXT NOT NULL, email TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS gear (
  id INTEGER PRIMARY KEY AUTOINCREMENT, item TEXT NOT NULL, sport TEXT NOT NULL, size TEXT, condition TEXT NOT NULL, city TEXT NOT NULL, state TEXT NOT NULL,
  donor TEXT NOT NULL, email TEXT NOT NULL, phone TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS gear_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT, gear_id INTEGER NOT NULL, name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT NOT NULL, note TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS successes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, athlete TEXT NOT NULL, sport TEXT NOT NULL, state TEXT NOT NULL, backed_year INTEGER NOT NULL, via TEXT NOT NULL,
  result TEXT NOT NULL, link TEXT, status TEXT NOT NULL DEFAULT 'published', created TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS feed_log (id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, medals INTEGER NOT NULL, fixtures INTEGER NOT NULL, error TEXT, created TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE NOT NULL,
  g TEXT NOT NULL DEFAULT 'asian',
  title TEXT NOT NULL,
  dek TEXT NOT NULL DEFAULT '',
  body TEXT NOT NULL DEFAULT '',
  paras TEXT NOT NULL DEFAULT '[]',
  author TEXT NOT NULL DEFAULT 'Momentum India',
  lead INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'published',
  published_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_articles_slug ON articles(slug);
CREATE INDEX IF NOT EXISTS idx_articles_status_pub ON articles(status, published_at DESC);
CREATE TABLE IF NOT EXISTS web_vitals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  value REAL NOT NULL,
  rating TEXT NOT NULL,
  path TEXT NOT NULL DEFAULT '/',
  user_agent TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_web_vitals_name ON web_vitals(name, created_at);`);

/* Seeds: first-phase ISL fixtures as announced, and opening fan-zone questions. Only run on an empty table. */
if ((q("SELECT COUNT(*) n FROM fixtures").get() as { n: number }).n === 0) {
  const isl: [string, string, string, string, string][] = [
    ["2026-10-10", "17:00", "Bengaluru FC", "Sporting Club Delhi", "Kanteerava Stadium, Bengaluru"],
    ["2026-10-10", "19:30", "FC Goa", "Chennaiyin FC", "Fatorda Stadium, Goa"],
    ["2026-10-11", "17:00", "Inter Kashi", "Kerala Blasters FC", "To be confirmed"],
    ["2026-10-11", "19:30", "Churchill Brothers", "Mumbai City FC", "Fatorda Stadium, Goa"],
    ["2026-10-12", "19:30", "NorthEast United FC", "Mohun Bagan Super Giant", "Sarusajai Stadium, Guwahati"],
    ["2026-10-14", "19:30", "Punjab FC", "Odisha FC", "JLN Stadium, Delhi"],
    ["2026-10-16", "19:30", "Sporting Club Delhi", "Mohun Bagan Super Giant", "JLN Stadium, Delhi"],
    ["2026-10-17", "17:00", "Inter Kashi", "Odisha FC", "To be confirmed"],
    ["2026-10-17", "19:30", "Bengaluru FC", "Chennaiyin FC", "Kanteerava Stadium, Bengaluru"],
    ["2026-10-18", "17:00", "Churchill Brothers", "East Bengal FC", "Fatorda Stadium, Goa"],
    ["2026-10-18", "19:30", "NorthEast United FC", "Kerala Blasters FC", "Sarusajai Stadium, Guwahati"],
    ["2026-10-19", "19:30", "Punjab FC", "Mumbai City FC", "JLN Stadium, Delhi"],
    ["2026-10-23", "17:00", "Inter Kashi", "East Bengal FC", "To be confirmed"],
    ["2026-10-24", "19:30", "Odisha FC", "NorthEast United FC", "Kalinga Stadium, Bhubaneswar"],
    ["2026-10-25", "17:00", "Churchill Brothers", "Punjab FC", "Fatorda Stadium, Goa"],
    ["2026-10-25", "19:30", "Kerala Blasters FC", "Mumbai City FC", "JLN Stadium, Kochi"],
    ["2026-10-26", "19:30", "Mohun Bagan Super Giant", "Chennaiyin FC", "VYBK, Kolkata"],
  ];
  const st = q("INSERT INTO fixtures (league, date, time, home, away, venue, ext_id) VALUES ('isl', ?, ?, ?, ?, ?, ?)");
  sqlite.transaction(() => { for (const [d, t, h, a, v] of isl) st.run(d, t, h, a, v, `isl-${d}-${h}-${a}`.toLowerCase().replace(/[^a-z0-9]+/g, "-")); })();
}
if ((q("SELECT COUNT(*) n FROM predictions").get() as { n: number }).n === 0) {
  const ps: [string, string[], string, string, number][] = [
    ["ISL opener, 10 October: Bengaluru FC vs Sporting Club Delhi. Who wins?", ["Bengaluru FC", "Draw", "Sporting Club Delhi"], "2026-10-10T17:00:00+05:30", "ISL", 10],
    ["How many medals will India win at the Aichi-Nagoya 2026 Asian Para Games?", ["Under 80", "80 to 99", "100 to 119", "120 or more"], "2026-10-18T00:00:00+09:00", "Asian Para Games", 20],
    ["How many gold medals will India win at the Asian Para Games?", ["Under 20", "20 to 29", "30 to 39", "40 or more"], "2026-10-18T00:00:00+09:00", "Asian Para Games", 20],
    ["Which sport will give India the most medals in Aichi-Nagoya?", ["Para athletics", "Para badminton", "Para shooting", "Para swimming", "Para archery"], "2026-10-18T00:00:00+09:00", "Asian Para Games", 10],
    ["Will Sumit Antil win men's javelin F64 gold?", ["Yes", "No"], "2026-10-18T00:00:00+09:00", "Asian Para Games", 10],
    ["Will Sheetal Devi win a gold medal in para archery?", ["Yes", "No"], "2026-10-18T00:00:00+09:00", "Asian Para Games", 10],
  ];
  const st = q("INSERT INTO predictions (question, options, closes_at, topic, points) VALUES (?, ?, ?, ?, ?)");
  sqlite.transaction(() => { for (const [qq, o, c, t, p] of ps) st.run(qq, o.join(" | "), c, t, p); })();
}

if ((q("SELECT COUNT(*) n FROM articles").get() as { n: number }).n === 0) {
  try {
    const fs = createRequire(typeof import.meta !== "undefined" && import.meta.url ? import.meta.url : "file:///index.js")("fs");
    const p = path.resolve(process.cwd(), "client/src/data/content.json");
    if (fs.existsSync(p)) {
      const raw = JSON.parse(fs.readFileSync(p, "utf-8"));
      if (Array.isArray(raw.ARTICLES)) {
        const stmt = q(`INSERT OR IGNORE INTO articles (slug, g, title, dek, body, paras, author, lead, status, published_at, updated_at)
          VALUES (@slug, @g, @title, @dek, @body, @paras, @author, @lead, 'published', @published_at, @updated_at)`);
        for (const a of raw.ARTICLES) {
          stmt.run({
            slug: a.slug,
            g: a.g || "asian",
            title: a.title,
            dek: a.body || "",
            body: Array.isArray(a.paras) ? a.paras.join("\n\n") : (a.body || ""),
            paras: JSON.stringify(a.paras || []),
            author: "Momentum India Editorial",
            lead: a.lead ? 1 : 0,
            published_at: a.date ? `${a.date}T10:00:00Z` : new Date().toISOString(),
            updated_at: a.date ? `${a.date}T10:00:00Z` : new Date().toISOString(),
          });
        }
      }
    }
  } catch (e) {
    console.warn("Could not seed articles:", e);
  }
}

const n = (sql: string, ...a: unknown[]) => (q(sql).get(...a) as { n: number }).n;
const splitOpts = (s: string) => s.split("|").map(x => x.trim()).filter(Boolean);

export const live = {
  medals: (games: string) => {
    const rows = q("SELECT id, date, athlete, sport, event, medal, state, link FROM live_medals WHERE games = ? AND status = 'published' ORDER BY date DESC, id DESC").all(games) as { medal: string }[];
    const tally = { G: 0, S: 0, B: 0 } as Record<string, number>; rows.forEach(r => tally[r.medal]++);
    const last = q("SELECT MAX(created) t FROM live_medals WHERE games = ?").get(games) as { t: string | null };
    return { tally, medals: rows, updated: last.t };
  },
  fixtures: (league?: string) => (league ? q("SELECT id, league, date, time, home, away, venue, home_score, away_score, status FROM fixtures WHERE league = ? ORDER BY date, time").all(league)
    : q("SELECT id, league, date, time, home, away, venue, home_score, away_score, status FROM fixtures WHERE date >= date('now', '-1 day') ORDER BY date, time LIMIT 60").all()),
  ingest: (data: { medals?: any[]; fixtures?: any[] }, source: string) => {
    let m = 0, f = 0;
    const um = q(`INSERT INTO live_medals (games, date, athlete, sport, event, medal, state, link, ext_id) VALUES (@games, @date, @athlete, @sport, @event, @medal, @state, @link, @ext_id)
      ON CONFLICT(ext_id) DO UPDATE SET date = excluded.date, athlete = excluded.athlete, sport = excluded.sport, event = excluded.event, medal = excluded.medal, state = excluded.state, link = excluded.link`);
    const uf = q(`INSERT INTO fixtures (league, date, time, home, away, venue, home_score, away_score, status, ext_id) VALUES (@league, @date, @time, @home, @away, @venue, @home_score, @away_score, @status, @ext_id)
      ON CONFLICT(ext_id) DO UPDATE SET date = excluded.date, time = excluded.time, venue = excluded.venue, home_score = excluded.home_score, away_score = excluded.away_score, status = excluded.status`);
    const key = (...p: unknown[]) => p.map(x => String(x ?? "")).join("-").toLowerCase().replace(/[^a-z0-9]+/g, "-");
    sqlite.transaction(() => {
      for (const x of data.medals ?? []) { um.run({ games: x.games ?? "apg2026", date: x.date, athlete: x.athlete, sport: x.sport, event: x.event, medal: x.medal, state: x.state ?? null, link: x.link ?? null, ext_id: x.ext_id ?? key(x.games ?? "apg2026", x.event, x.athlete, x.medal) }); m++; }
      for (const x of data.fixtures ?? []) { uf.run({ league: x.league, date: x.date, time: x.time ?? null, home: x.home, away: x.away, venue: x.venue ?? null, home_score: x.home_score ?? null, away_score: x.away_score ?? null, status: x.status ?? "scheduled", ext_id: x.ext_id ?? key(x.league, x.date, x.home, x.away) }); f++; }
    })();
    q("INSERT INTO feed_log (source, medals, fixtures) VALUES (?, ?, ?)").run(source, m, f);
    return { medals: m, fixtures: f };
  },
  logError: (source: string, error: string) => q("INSERT INTO feed_log (source, medals, fixtures, error) VALUES (?, 0, 0, ?)").run(source, error.slice(0, 400)),
  lastFeed: () => q("SELECT source, medals, fixtures, error, created FROM feed_log ORDER BY id DESC LIMIT 5").all(),
};

export const fan = {
  questions: () => {
    const qs = q("SELECT id, question, options, closes_at, answer, points, topic, status FROM predictions WHERE status != 'hidden' ORDER BY closes_at ASC, id").all() as any[];
    const counts = q("SELECT qid, choice, COUNT(*) n FROM picks GROUP BY qid, choice").all() as { qid: number; choice: string; n: number }[];
    return qs.map(x => ({ ...x, options: splitOpts(x.options), votes: Object.fromEntries(counts.filter(c => c.qid === x.id).map(c => [c.choice, c.n])) }));
  },
  question: (id: number) => q("SELECT * FROM predictions WHERE id = ?").get(id) as { id: number; options: string; closes_at: string; status: string } | undefined,
  pick: (qid: number, nickname: string, email: string, choice: string) =>
    q("INSERT INTO picks (qid, nickname, email, choice) VALUES (?, ?, ?, ?) ON CONFLICT(qid, email) DO UPDATE SET choice = excluded.choice, nickname = excluded.nickname").run(qid, nickname, email, choice),
  mine: (email: string) => q("SELECT qid, choice FROM picks WHERE email = ?").all(email),
  leaderboard: () => q(`SELECT (SELECT nickname FROM picks p2 WHERE p2.email = p.email ORDER BY p2.id DESC LIMIT 1) nickname,
      SUM(CASE WHEN pr.answer IS NOT NULL AND pr.answer = p.choice THEN pr.points ELSE 0 END) points, SUM(CASE WHEN pr.answer IS NOT NULL AND pr.answer = p.choice THEN 1 ELSE 0 END) correct, COUNT(*) picks
    FROM picks p JOIN predictions pr ON pr.id = p.qid GROUP BY p.email ORDER BY points DESC, correct DESC, MIN(p.id) ASC LIMIT 25`).all(),
  players: () => n("SELECT COUNT(DISTINCT email) n FROM picks"),
};

export const community = {
  clubs: () => q("SELECT id, name, kind, sport, city, state, ages, fees, timings, girls_only, about, contact_name, phone, website FROM clubs WHERE status = 'approved' ORDER BY state, city, name").all(),
  addClub: (c: Record<string, unknown>) => Number(q(`INSERT INTO clubs (name, kind, sport, city, state, ages, fees, timings, girls_only, about, contact_name, phone, email, website)
    VALUES (@name, @kind, @sport, @city, @state, @ages, @fees, @timings, @girls_only, @about, @contact_name, @phone, @email, @website)`).run(c).lastInsertRowid),
  grounds: () => q(`SELECT g.id, g.name, g.place, g.district, g.state, g.sport, g.need, g.budget, g.story, g.users, g.created,
    (SELECT COUNT(*) FROM adoptions a WHERE a.ground_id = g.id AND a.status != 'rejected') adopters FROM grounds g WHERE g.status = 'approved' ORDER BY g.id DESC LIMIT 60`).all(),
  addGround: (g: Record<string, unknown>) => Number(q(`INSERT INTO grounds (name, place, district, state, sport, need, budget, story, users, contact_name, email, phone)
    VALUES (@name, @place, @district, @state, @sport, @need, @budget, @story, @users, @contact_name, @email, @phone)`).run(g).lastInsertRowid),
  groundOpen: (id: number) => !!q("SELECT 1 FROM grounds WHERE id = ? AND status = 'approved'").get(id),
  adopt: (a: Record<string, unknown>) => Number(q("INSERT INTO adoptions (ground_id, org, kind, amount, contact, email) VALUES (@ground_id, @org, @kind, @amount, @contact, @email)").run(a).lastInsertRowid),
  gear: () => q(`SELECT g.id, g.item, g.sport, g.size, g.condition, g.city, g.state, g.created,
    (SELECT COUNT(*) FROM gear_requests r WHERE r.gear_id = g.id AND r.status != 'rejected') requests FROM gear g WHERE g.status = 'approved' ORDER BY g.id DESC LIMIT 80`).all(),
  addGear: (g: Record<string, unknown>) => Number(q("INSERT INTO gear (item, sport, size, condition, city, state, donor, email, phone) VALUES (@item, @sport, @size, @condition, @city, @state, @donor, @email, @phone)").run(g).lastInsertRowid),
  gearOpen: (id: number) => !!q("SELECT 1 FROM gear WHERE id = ? AND status = 'approved'").get(id),
  requestGear: (r: Record<string, unknown>) => Number(q("INSERT INTO gear_requests (gear_id, name, email, phone, note) VALUES (@gear_id, @name, @email, @phone, @note)").run(r).lastInsertRowid),
  successes: () => q("SELECT id, athlete, sport, state, backed_year, via, result, link FROM successes WHERE status = 'published' ORDER BY id DESC LIMIT 24").all(),
  districts: () => q(`SELECT state, district, COUNT(*) n, GROUP_CONCAT(DISTINCT sport) sports FROM nation_nominations WHERE status = 'approved' GROUP BY state, district ORDER BY n DESC, state LIMIT 60`).all(),
  stats: () => ({ clubs: n("SELECT COUNT(*) n FROM clubs WHERE status = 'approved'"), grounds: n("SELECT COUNT(*) n FROM grounds WHERE status = 'approved'"), gear: n("SELECT COUNT(*) n FROM gear WHERE status = 'approved'"), successes: n("SELECT COUNT(*) n FROM successes WHERE status = 'published'") }),
};

export const articlesStorage = {
  list: (status = "published", limit = 50) => {
    if (status === "all") {
      return q(`SELECT id, slug, g, title, dek, body, paras, author, lead, status, published_at, updated_at, deleted_at FROM articles WHERE deleted_at IS NULL ORDER BY published_at DESC LIMIT ?`).all(limit);
    }
    return q(`SELECT id, slug, g, title, dek, body, paras, author, lead, status, published_at, updated_at FROM articles WHERE status = ? AND deleted_at IS NULL ORDER BY published_at DESC LIMIT ?`).all(status, limit);
  },
  get: (slug: string) => {
    return q(`SELECT id, slug, g, title, dek, body, paras, author, lead, status, published_at, updated_at FROM articles WHERE slug = ? AND deleted_at IS NULL`).get(slug);
  },
  sitemap: () => {
    return q(`SELECT slug, updated_at FROM articles WHERE status = 'published' AND deleted_at IS NULL ORDER BY updated_at DESC`).all() as { slug: string; updated_at: string }[];
  },
  create: (a: Record<string, unknown>, actor = "admin", role = "admin") => {
    const res = q(`INSERT INTO articles (slug, g, title, dek, body, paras, author, lead, status, published_at, updated_at)
      VALUES (@slug, @g, @title, @dek, @body, @paras, @author, @lead, @status, datetime('now'), datetime('now'))`).run({
        slug: a.slug,
        g: a.g ?? "asian",
        title: a.title,
        dek: a.dek ?? "",
        body: a.body ?? "",
        paras: a.paras ? (typeof a.paras === "string" ? a.paras : JSON.stringify(a.paras)) : "[]",
        author: a.author ?? "Momentum India Editorial",
        lead: a.lead ? 1 : 0,
        status: a.status ?? "published"
      });
    const id = Number(res.lastInsertRowid);
    auditLog.record({ actor, role, action: "create_article", target_table: "articles", target_id: id, details: String(a.slug) });
    return id;
  },
  update: (id: number, a: Record<string, unknown>, actor = "admin", role = "admin") => {
    const fields = Object.keys(a).filter(k => ["title", "dek", "body", "paras", "author", "status", "lead", "g"].includes(k));
    if (!fields.length) return false;
    const sets = fields.map(f => `${f} = @${f}`).join(", ") + ", updated_at = datetime('now')";
    const res = q(`UPDATE articles SET ${sets} WHERE id = @id AND deleted_at IS NULL`).run({ ...a, id });
    if (res.changes > 0) {
      auditLog.record({ actor, role, action: "update_article", target_table: "articles", target_id: id, details: fields.join(",") });
      return true;
    }
    return false;
  },
  delete: (id: number, actor = "admin", role = "admin") => {
    const res = q(`UPDATE articles SET deleted_at = datetime('now') WHERE id = ?`).run(id);
    if (res.changes > 0) {
      auditLog.record({ actor, role, action: "delete_article", target_table: "articles", target_id: id });
      return true;
    }
    return false;
  }
};

export const vitalsStorage = {
  record: (v: { name: string; value: number; rating: string; path?: string; user_agent?: string }) => {
    return Number(q(`INSERT INTO web_vitals (name, value, rating, path, user_agent) VALUES (@name, @value, @rating, @path, @user_agent)`).run({
      name: v.name,
      value: v.value,
      rating: v.rating,
      path: v.path || "/",
      user_agent: v.user_agent || null
    }).lastInsertRowid);
  }
};

/* Admin: tables that the dashboard can create and edit, with field specs. */
export type AdminField = { name: string; label: string; type: "text" | "textarea" | "date" | "number" | "select" | "datetime"; options?: string[]; required?: boolean; max?: number; hint?: string };
const PUB = ["published", "hidden"];
Object.assign(ADMIN_TABLES, {
  live_medals: { table: "live_medals", label: "Live medals (Games)", statuses: PUB, content: true, create: [
    { name: "games", label: "Games", type: "select", options: ["apg2026"], required: true },
    { name: "date", label: "Date", type: "date", required: true },
    { name: "medal", label: "Medal", type: "select", options: ["G", "S", "B"], required: true },
    { name: "athlete", label: "Athlete or team", type: "text", required: true, max: 120 },
    { name: "sport", label: "Sport", type: "text", required: true, max: 60 },
    { name: "event", label: "Event and class", type: "text", required: true, max: 160, hint: "For example: Men's javelin F64" },
    { name: "state", label: "Home state", type: "text", max: 60 },
    { name: "link", label: "Source link", type: "text", max: 300 },
  ] },
  fixtures: { table: "fixtures", label: "League fixtures and results", statuses: ["scheduled", "live", "final", "postponed"], content: true, create: [
    { name: "league", label: "League", type: "select", options: ["isl", "pkl", "hil", "whil"], required: true },
    { name: "date", label: "Date", type: "date", required: true }, { name: "time", label: "Start (IST, HH:MM)", type: "text", max: 5 },
    { name: "home", label: "Home team", type: "text", required: true, max: 80 }, { name: "away", label: "Away team", type: "text", required: true, max: 80 },
    { name: "venue", label: "Venue", type: "text", max: 120 },
  ], edit: [{ name: "home_score", label: "Home score", type: "number" }, { name: "away_score", label: "Away score", type: "number" }, { name: "time", label: "Start (IST)", type: "text", max: 5 }, { name: "venue", label: "Venue", type: "text", max: 120 }] },
  predictions: { table: "predictions", label: "Fan zone predictions", statuses: ["open", "settled", "hidden"], content: true, create: [
    { name: "question", label: "Question", type: "text", required: true, max: 200 },
    { name: "options", label: "Options, separated by |", type: "text", required: true, max: 400, hint: "For example: Yes | No" },
    { name: "closes_at", label: "Picks close at", type: "datetime", required: true },
    { name: "topic", label: "Topic", type: "text", max: 60 }, { name: "points", label: "Points", type: "number" },
  ], edit: [{ name: "answer", label: "Correct answer (exactly as an option)", type: "text", max: 120 }, { name: "closes_at", label: "Picks close at", type: "datetime" }] },
  picks: { table: "picks", label: "Prediction picks", statuses: [] },
  clubs: { table: "clubs", label: "Clubs and coaches", statuses: MOD },
  grounds: { table: "grounds", label: "Adopt a ground: listings", statuses: MOD },
  adoptions: { table: "adoptions", label: "Adopt a ground: offers", statuses: ["pending", "introduced", "rejected"] },
  gear: { table: "gear", label: "Gear donations", statuses: ["pending", "approved", "given", "rejected"] },
  gear_requests: { table: "gear_requests", label: "Gear requests", statuses: ["pending", "introduced", "rejected"] },
  successes: { table: "successes", label: "Success wall", statuses: PUB, content: true, create: [
    { name: "athlete", label: "Athlete (first name only for minors)", type: "text", required: true, max: 80 },
    { name: "sport", label: "Sport", type: "text", required: true, max: 60 }, { name: "state", label: "State", type: "text", required: true, max: 60 },
    { name: "backed_year", label: "Year backed here", type: "number", required: true },
    { name: "via", label: "How we helped", type: "select", options: ["Sponsored", "Local star spotlight", "Gear exchange", "Club directory", "Adopted ground"], required: true },
    { name: "result", label: "Result", type: "text", required: true, max: 200, hint: "For example: State U-17 champion, 2027" },
    { name: "link", label: "Source link", type: "text", max: 300 },
  ] },
  articles: {
    table: "articles",
    label: "Editorial Articles",
    statuses: ["published", "draft"],
    content: true,
    create: [
      { name: "slug", label: "Slug (URL path)", type: "text", required: true, max: 120, hint: "e.g. road-to-la-2028" },
      { name: "g", label: "Category", type: "select", options: ["asian", "oly", "cwg", "policy", "blog"], required: true },
      { name: "title", label: "Title", type: "text", required: true, max: 200 },
      { name: "dek", label: "Dek / Subheading", type: "textarea", required: true, hint: "Short summary shown on cards" },
      { name: "body", label: "Body content", type: "textarea", required: true, hint: "Full article text" },
      { name: "author", label: "Author", type: "text", required: true, max: 80 },
    ],
    edit: [
      { name: "title", label: "Title", type: "text" },
      { name: "dek", label: "Dek / Subheading", type: "textarea" },
      { name: "body", label: "Body content", type: "textarea" },
      { name: "author", label: "Author", type: "text" },
    ]
  },
});

// Additive migration: ensure deleted_at exists on all admin tables
for (const info of Object.values(ADMIN_TABLES)) {
  try {
    if (!cols(info.table).includes("deleted_at")) {
      sqlite.exec(`ALTER TABLE ${info.table} ADD COLUMN deleted_at TEXT;`);
    }
  } catch {}
}

export const adminX = {
  create: (k: string, row: Record<string, unknown>, actor = "admin", role = "admin") => {
    const t = ADMIN_TABLES[k] as any; const keys = Object.keys(row);
    const id = Number(q(`INSERT INTO ${t.table} (${keys.join(", ")}) VALUES (${keys.map(x => "@" + x).join(", ")})`).run(row).lastInsertRowid);
    if (id > 0) {
      auditLog.record({ actor, role, action: "create", target_table: t.table, target_id: id, details: JSON.stringify(row) });
    }
    return id;
  },
  update: (k: string, id: number, row: Record<string, unknown>, actor = "admin", role = "admin") => {
    const t = ADMIN_TABLES[k] as any; const keys = Object.keys(row); if (!keys.length) return false;
    const ok = q(`UPDATE ${t.table} SET ${keys.map(x => `${x} = @${x}`).join(", ")} WHERE id = @id`).run({ ...row, id }).changes > 0;
    if (ok) {
      auditLog.record({ actor, role, action: "update", target_table: t.table, target_id: id, details: JSON.stringify(row) });
    }
    return ok;
  },
};

/* ---------- AI Sports Agent Storage ---------- */
sqlite.exec(`CREATE TABLE IF NOT EXISTS agent_news (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sport TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT,
  source TEXT NOT NULL,
  url TEXT,
  image_url TEXT,
  published_at TEXT NOT NULL DEFAULT (datetime('now')),
  sentiment TEXT NOT NULL DEFAULT 'neutral',
  key_points TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sport TEXT NOT NULL,
  date_ist TEXT NOT NULL,
  headline TEXT NOT NULL,
  score_text TEXT,
  source TEXT NOT NULL,
  url TEXT NOT NULL,
  published_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_results_sport ON results(sport);
CREATE INDEX IF NOT EXISTS idx_results_date ON results(date_ist);
CREATE INDEX IF NOT EXISTS idx_results_pub ON results(published_at);
CREATE INDEX IF NOT EXISTS idx_agent_news_pub_desc ON agent_news(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_news_sport_pub ON agent_news(sport, published_at);
CREATE INDEX IF NOT EXISTS idx_agent_news_url ON agent_news(url);
CREATE TABLE IF NOT EXISTS cron_locks (
  job_name TEXT PRIMARY KEY,
  last_run_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS agent_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event TEXT NOT NULL,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);`);

// Additive column migrations & indexes for fast title/headline normalization and real data providers
try {
  sqlite.exec("DROP TABLE IF EXISTS agent_scorecards;");
} catch {}
try {
  sqlite.exec("ALTER TABLE agent_news ADD COLUMN image_url TEXT;");
} catch {}
try {
  sqlite.exec("ALTER TABLE agent_news ADD COLUMN normalized_title TEXT;");
} catch {}
try {
  sqlite.exec("CREATE INDEX IF NOT EXISTS idx_agent_news_norm_title ON agent_news(normalized_title);");
} catch {}
try {
  sqlite.exec("ALTER TABLE results ADD COLUMN normalized_headline TEXT;");
} catch {}
try {
  sqlite.exec("CREATE INDEX IF NOT EXISTS idx_results_norm_headline ON results(normalized_headline);");
} catch {}
try {
  sqlite.exec("UPDATE agent_news SET normalized_title = LOWER(TRIM(title)) WHERE normalized_title IS NULL;");
  sqlite.exec("UPDATE results SET normalized_headline = LOWER(TRIM(headline)) WHERE normalized_headline IS NULL;");
} catch {}

// Provider metadata migrations (source, source_url, fetched_at)
try { sqlite.exec("ALTER TABLE live_medals ADD COLUMN source TEXT;"); } catch {}
try { sqlite.exec("ALTER TABLE live_medals ADD COLUMN source_url TEXT;"); } catch {}
try { sqlite.exec("ALTER TABLE live_medals ADD COLUMN fetched_at TEXT;"); } catch {}

try { sqlite.exec("ALTER TABLE fixtures ADD COLUMN source TEXT;"); } catch {}
try { sqlite.exec("ALTER TABLE fixtures ADD COLUMN source_url TEXT;"); } catch {}
try { sqlite.exec("ALTER TABLE fixtures ADD COLUMN fetched_at TEXT;"); } catch {}

try { sqlite.exec("ALTER TABLE results ADD COLUMN source_url TEXT;"); } catch {}
try { sqlite.exec("ALTER TABLE results ADD COLUMN fetched_at TEXT;"); } catch {}

try { sqlite.exec("ALTER TABLE agent_news ADD COLUMN source_url TEXT;"); } catch {}
try { sqlite.exec("ALTER TABLE agent_news ADD COLUMN fetched_at TEXT;"); } catch {}

// Dedicated tables for automatic provider-backed medal tables and event calendar
sqlite.exec(`
CREATE TABLE IF NOT EXISTS medal_tables (
  games_id TEXT PRIMARY KEY,
  games_name TEXT NOT NULL,
  source TEXT NOT NULL,
  source_url TEXT NOT NULL,
  fetched_at TEXT NOT NULL,
  is_live INTEGER NOT NULL DEFAULT 0,
  india_rank INTEGER,
  india_gold INTEGER,
  india_silver INTEGER,
  india_bronze INTEGER,
  india_total INTEGER,
  table_data TEXT NOT NULL,
  warnings TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS event_calendar (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  short_name TEXT NOT NULL,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  location TEXT NOT NULL,
  venue TEXT,
  wikidata_id TEXT,
  wikipedia_title TEXT,
  source TEXT NOT NULL,
  source_url TEXT NOT NULL,
  fetched_at TEXT NOT NULL,
  featured INTEGER NOT NULL DEFAULT 0,
  raw_data TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS athletes (
  slug TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  sport TEXT NOT NULL,
  gender TEXT NOT NULL DEFAULT '',
  tagline TEXT,
  games TEXT NOT NULL DEFAULT '[]',
  career_json TEXT NOT NULL DEFAULT '[]',
  honours_json TEXT NOT NULL DEFAULT '[]',
  is_team INTEGER NOT NULL DEFAULT 0,
  featured INTEGER NOT NULL DEFAULT 0,
  img_url TEXT,
  bio TEXT,
  medals_g INTEGER NOT NULL DEFAULT 0,
  medals_s INTEGER NOT NULL DEFAULT 0,
  medals_b INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL DEFAULT 'Momentum India Verified Database',
  source_url TEXT NOT NULL DEFAULT 'https://olympics.com',
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS hall_of_fame (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  athlete_slug TEXT NOT NULL,
  name TEXT NOT NULL,
  sport TEXT NOT NULL,
  era TEXT NOT NULL,
  milestone TEXT NOT NULL,
  medals_text TEXT NOT NULL,
  img_url TEXT,
  source TEXT NOT NULL DEFAULT 'Indian Sports Archives & MYAS',
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS broadcast_schedule (
  id TEXT PRIMARY KEY,
  event_title TEXT NOT NULL,
  sport TEXT NOT NULL,
  tournament TEXT NOT NULL,
  channel TEXT NOT NULL,
  stream_app TEXT NOT NULL,
  stream_url TEXT,
  start_time_ist TEXT NOT NULL,
  end_time_ist TEXT,
  is_live INTEGER NOT NULL DEFAULT 0,
  badge TEXT,
  source TEXT NOT NULL DEFAULT 'Official Broadcaster Schedules (Sony, Star, JioHotstar)',
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS fan_quizzes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sport TEXT NOT NULL,
  question TEXT NOT NULL,
  options_json TEXT NOT NULL,
  answer_index INTEGER NOT NULL,
  explanation TEXT,
  difficulty TEXT NOT NULL DEFAULT 'medium',
  category TEXT NOT NULL DEFAULT 'Olympics',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS fan_polls (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  options_json TEXT NOT NULL,
  votes_json TEXT NOT NULL DEFAULT '{}',
  closes_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS paralympic_telemetry (
  id TEXT PRIMARY KEY,
  games_name TEXT NOT NULL,
  year INTEGER NOT NULL,
  host TEXT NOT NULL,
  dates TEXT NOT NULL,
  india_rank INTEGER,
  gold INTEGER NOT NULL DEFAULT 0,
  silver INTEGER NOT NULL DEFAULT 0,
  bronze INTEGER NOT NULL DEFAULT 0,
  total INTEGER NOT NULL DEFAULT 0,
  sports_count INTEGER NOT NULL DEFAULT 0,
  top_athletes_json TEXT NOT NULL DEFAULT '[]',
  table_json TEXT NOT NULL DEFAULT '[]',
  source TEXT NOT NULL DEFAULT 'International Paralympic Committee (IPC) & Wikipedia CC BY-SA',
  source_url TEXT NOT NULL DEFAULT 'https://www.paralympic.org',
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS medal_editions (
  id TEXT PRIMARY KEY,
  games_type TEXT NOT NULL,
  year INTEGER NOT NULL,
  host TEXT NOT NULL,
  gold INTEGER NOT NULL DEFAULT 0,
  silver INTEGER NOT NULL DEFAULT 0,
  bronze INTEGER NOT NULL DEFAULT 0,
  total INTEGER NOT NULL DEFAULT 0,
  athletes_count INTEGER,
  rank TEXT,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'concluded',
  source TEXT NOT NULL DEFAULT 'Official Games Archives & Wikipedia CC BY-SA',
  source_url TEXT NOT NULL DEFAULT 'https://en.wikipedia.org',
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

export const cronLocks = {
  canRun: (jobName: string, minIntervalMs: number): boolean => {
    const row = q("SELECT last_run_at FROM cron_locks WHERE job_name = ?").get(jobName) as { last_run_at: number } | undefined;
    const now = Date.now();
    if (!row) {
      q("INSERT INTO cron_locks (job_name, last_run_at) VALUES (?, ?)").run(jobName, now);
      return true;
    }
    if (now - row.last_run_at < minIntervalMs) {
      return false;
    }
    q("UPDATE cron_locks SET last_run_at = ? WHERE job_name = ?").run(now, jobName);
    return true;
  },
  recordRun: (jobName: string): void => {
    const now = Date.now();
    q("INSERT INTO cron_locks (job_name, last_run_at) VALUES (?, ?) ON CONFLICT(job_name) DO UPDATE SET last_run_at = excluded.last_run_at").run(jobName, now);
  },
  getLastRun: (jobName: string): number => {
    const row = q("SELECT last_run_at FROM cron_locks WHERE job_name = ?").get(jobName) as { last_run_at: number } | undefined;
    return row?.last_run_at ?? 0;
  }
};

export interface AgentNewsItem {
  id?: number;
  sport: string;
  title: string;
  summary: string | null;
  source: string;
  url?: string | null;
  image_url?: string | null;
  published_at?: string;
  sentiment?: "positive" | "neutral" | "caution";
  key_points?: string[];
  created_at?: string;
}

export interface ResultItem {
  id?: number;
  sport: string;
  date_ist: string;
  headline: string;
  score_text?: string | null;
  source: string;
  url: string;
  published_at: string;
  created_at?: string;
}

export interface AgentScorecardItem {
  id?: number;
  match_id: string;
  sport: string;
  tournament: string;
  home_team: string;
  away_team: string;
  home_score: string;
  away_score: string;
  status: "live" | "final" | "upcoming";
  day_tag?: string | null;
  match_time?: string | null;
  venue?: string | null;
  summary?: string | null;
  detailed_data?: Record<string, any>;
  updated_at?: string;
}

/** Feed publish-gate helpers (kept in storage so the startup cleanup can use
 *  them without importing sports-agent, which would be circular). */
export function feedNormalizeKey(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\b(the|a|an)\b/g, " ").replace(/\s+/g, " ").trim();
}
export function feedStripMarkup(s: string): string {
  let text = s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1");
  for (let i = 0; i < 3; i++) {
    const decoded = text
      .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"').replace(/&#039;|&#39;|&apos;/g, "'").replace(/&nbsp;/g, " ")
      .replace(/&#(\d+);/g, (_: string, n: string) => String.fromCharCode(Number(n)))
      .replace(/&#x([0-9a-fA-F]+);/g, (_: string, h: string) => String.fromCharCode(parseInt(h, 16)));
    const stripped = decoded.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/<[^>]*$/, " ");
    if (stripped === text) { text = stripped; break; }
    text = stripped;
  }
  return text.replace(/\s+/g, " ").trim();
}
export function feedIsGossip(text: string): boolean {
  return /\b(wwe|wrestlemania|bigg boss|big boss|reality show|reality tv|streamer|twitch|influencer|weight loss|weight-loss|kaun banega|kbc contestant)\b/i.test(text);
}

export const agentStorage = {
  listNews: (sport?: string, limit = 50, cursor?: number): AgentNewsItem[] => {
    const conditions: string[] = [];
    const params: any[] = [];
    if (sport && sport !== "all" && sport !== "All") {
      conditions.push("LOWER(sport) = LOWER(?)");
      params.push(sport);
    }
    if (cursor) {
      conditions.push("id < ?");
      params.push(cursor);
    }
    const where = conditions.length ? "WHERE " + conditions.join(" AND ") : "";
    const rows = q(`SELECT * FROM agent_news ${where} ORDER BY published_at DESC, id DESC LIMIT ?`).all(...params, limit) as any[];
    return rows.map(r => ({
      ...r,
      key_points: typeof r.key_points === "string" ? JSON.parse(r.key_points || "[]") : r.key_points || [],
    }));
  },

  addNews: (item: AgentNewsItem) => {
    // Publish gate: an excerpt still containing markup after cleaning is
    // stored as null, never as raw HTML text.
    let summary = item.summary ?? null;
    if (summary) {
      const cleaned = feedStripMarkup(summary);
      summary = cleaned.length < 25 || /<[a-z][^>]*>/i.test(cleaned) ? null : cleaned;
    }
    // Deduplicate on normalised title + published date, not URL alone: the
    // same story via Google News and via its publisher has different URLs
    // but is one story for the reader.
    const cleanTitle = item.title.trim();
    const normTitle = feedNormalizeKey(cleanTitle);
    const itemDate = (item.published_at || "").slice(0, 10);
    const existing = item.url
      ? q("SELECT id FROM agent_news WHERE url = ? OR normalized_title = ? LIMIT 1").get(item.url, normTitle)
      : q("SELECT id FROM agent_news WHERE normalized_title = ? LIMIT 1").get(normTitle);
    if (existing) return (existing as any).id;
    if (itemDate) {
      const recent = q("SELECT id, title, published_at FROM agent_news WHERE published_at >= datetime(?, '-14 days')").all(item.published_at) as any[];
      const dup = recent.find(r => feedNormalizeKey(r.title) === normTitle && (r.published_at || "").slice(0, 10) === itemDate);
      if (dup) return dup.id;
    }

    const rowId = Number(q(`INSERT INTO agent_news (sport, title, normalized_title, summary, source, url, image_url, published_at, sentiment, key_points)
      VALUES (@sport, @title, @normalized_title, @summary, @source, @url, @image_url, @published_at, @sentiment, @key_points)`).run({
      sport: item.sport,
      title: cleanTitle,
      normalized_title: normTitle,
      summary,
      source: item.source || "",
      url: item.url || null,
      image_url: item.image_url || null,
      published_at: item.published_at || new Date().toISOString(),
      sentiment: item.sentiment || "neutral",
      key_points: JSON.stringify(item.key_points || []),
    }).lastInsertRowid);

    // Broadcast live event to SSE subscribers
    liveEvents.broadcast("news", { ...item, id: rowId });

    // Mirror to persistent JSON disk backup
    try {
      const backupPath = path.resolve(DATA_DIR, "live_news_archive.json");
      const current = agentStorage.listNews(undefined, 100);
      fs.writeFileSync(backupPath, JSON.stringify(current, null, 2), "utf8");
    } catch {}

    return rowId;
  },

  getLatestNewsTimestamp: (): number => {
    const row = q("SELECT published_at FROM agent_news ORDER BY published_at DESC LIMIT 1").get() as any;
    if (!row || !row.published_at) return 0;
    const ts = new Date(row.published_at).getTime();
    return isNaN(ts) ? 0 : ts;
  },

  /* Results Table Methods */
  addResult: (item: {
    sport: string;
    date_ist: string;
    headline: string;
    score_text?: string | null;
    source: string;
    url: string;
    published_at: string;
  }): number => {
    const cleanHeadline = item.headline.trim();
    const normHeadline = feedNormalizeKey(cleanHeadline);
    // Dedupe by normalised headline + IST date, not URL alone.
    const existing = q("SELECT id FROM results WHERE url = ? OR normalized_headline = ? LIMIT 1").get(item.url, normHeadline);
    if (existing) return (existing as any).id;
    {
      const recent = q("SELECT id, headline, date_ist FROM results WHERE date_ist = ?").all(item.date_ist) as any[];
      const dup = recent.find(r => feedNormalizeKey(r.headline) === normHeadline);
      if (dup) return dup.id;
    }

    const res = q(`INSERT INTO results (sport, date_ist, headline, normalized_headline, score_text, source, url, published_at)
      VALUES (@sport, @date_ist, @headline, @normalized_headline, @score_text, @source, @url, @published_at)`).run({
      sport: item.sport,
      date_ist: item.date_ist,
      headline: cleanHeadline,
      normalized_headline: normHeadline,
      score_text: item.score_text || null,
      source: item.source || "",
      url: item.url,
      published_at: item.published_at,
    });
    const rowId = Number(res.lastInsertRowid || 0);
    if (rowId > 0) {
      liveEvents.broadcast("result", { ...item, id: rowId });
    }
    return rowId;
  },

  listResults: (sport?: string, dateIst?: string, limit = 100, cursor?: number): ResultItem[] => {
    const conditions: string[] = [];
    const params: any[] = [];
    if (sport && sport !== "all" && sport !== "All") {
      conditions.push("LOWER(sport) = LOWER(?)");
      params.push(sport);
    }
    if (dateIst && dateIst !== "all" && dateIst !== "All") {
      conditions.push("date_ist = ?");
      params.push(dateIst);
    }
    if (cursor) {
      conditions.push("id < ?");
      params.push(cursor);
    }
    const where = conditions.length ? "WHERE " + conditions.join(" AND ") : "";
    return q(`SELECT * FROM results ${where} ORDER BY published_at DESC, id DESC LIMIT ?`).all(...params, limit) as ResultItem[];
  },

  updateResultSport: (id: number, sport: string) => {
    q("UPDATE results SET sport = ? WHERE id = ?").run(sport, id);
  },

  deleteResult: (id: number) => {
    q("DELETE FROM results WHERE id = ?").run(id);
  },

  listResultDates: (): string[] => {
    const rows = q("SELECT DISTINCT date_ist FROM results ORDER BY date_ist DESC").all() as { date_ist: string }[];
    return rows.map(r => r.date_ist);
  },

  countResults: (sport?: string): number => {
    if (sport && sport !== "all" && sport !== "All") {
      return (q("SELECT COUNT(*) c FROM results WHERE LOWER(sport) = LOWER(?)").get(sport) as any)?.c || 0;
    }
    return (q("SELECT COUNT(*) c FROM results").get() as any)?.c || 0;
  },

  getLatestResultTimestamp: (): number => {
    const row = q("SELECT published_at FROM results ORDER BY published_at DESC LIMIT 1").get() as any;
    if (!row || !row.published_at) return 0;
    const ts = new Date(row.published_at).getTime();
    return isNaN(ts) ? 0 : ts;
  },

  /* 90-Day Retention Cleanup */
  purgeOldRecords: () => {
    try {
      q("DELETE FROM agent_news WHERE datetime(published_at) < datetime('now', '-90 days')").run();
      q("DELETE FROM results WHERE datetime(published_at) < datetime('now', '-90 days')").run();
      console.log("[storage] Purged records older than 90 days from agent_news and results.");
    } catch (e: any) {
      console.warn("[storage] purgeOldRecords error:", e?.message);
    }
  },

  /* Comprehensive news cleanup and reclassification */
  cleanupAndReclassify: () => {
    try {
      // 0. Feed publish gate for rows already stored: strip markup from
      // excerpts (null if nothing readable remains), drop foreign-league and
      // gossip rows, and collapse duplicates by normalised title + date.
      try {
        const newsRows = q("SELECT id, title, summary FROM agent_news").all() as any[];
        for (const r of newsRows) {
          if (r.summary && /</.test(r.summary)) {
            const cleaned = feedStripMarkup(r.summary);
            q("UPDATE agent_news SET summary = ? WHERE id = ?").run(
              cleaned.length < 25 || /<[a-z][^>]*>/i.test(cleaned) ? null : cleaned, r.id);
          }
        }
        q("DELETE FROM agent_news WHERE sport = 'International'").run();
        const gossipRows = q("SELECT id, title, summary FROM agent_news").all() as any[];
        for (const r of gossipRows) {
          if (feedIsGossip(`${r.title} ${r.summary || ""}`)) q("DELETE FROM agent_news WHERE id = ?").run(r.id);
        }
        const dedupe = (table: string, col: string, dateCol: string) => {
          const rows = q(`SELECT id, ${col}, ${dateCol} FROM ${table} ORDER BY id ASC`).all() as any[];
          const seen = new Map<string, number>();
          for (const r of rows) {
            const date = dateCol === "date_ist" ? r[dateCol] : (r[dateCol] || "").slice(0, 10);
            const key = `${feedNormalizeKey(r[col])}|${date}`;
            if (seen.has(key)) q(`DELETE FROM ${table} WHERE id = ?`).run(r.id);
            else seen.set(key, r.id);
          }
        };
        dedupe("agent_news", "title", "published_at");
        dedupe("results", "headline", "date_ist");
      } catch (e: any) {
        console.warn("[storage] feed gate cleanup error:", e?.message);
      }

      // 1. Delete fake scorecards completely and permanently
      try {
        sqlite.exec("DROP TABLE IF EXISTS agent_scorecards;");
      } catch {}

      // 2. Null out any existing rows containing the fake fallback strings
      q(`UPDATE agent_news SET summary = NULL WHERE 
        summary LIKE '%sports desk%'
        OR summary LIKE '%field dispatch%'
        OR summary LIKE '%Live report filed by%'
        OR summary LIKE '%Momentum Sports AI Desk%'
        OR summary LIKE '%biometric telemetry%'
      `).run();

      // 3. Remove synthetic articles
      q(`DELETE FROM agent_news WHERE 
        title LIKE '%Momentum High-Performance Flash%' 
        OR source LIKE '%Momentum Sports AI Desk%' 
        OR source LIKE '%Momentum AI Cricket Wire%' 
        OR title LIKE '%ISL 2026-27 Season Kicks Off in Bengaluru%'
        OR title LIKE '%India Squad Announced for Upcoming T20 Series%'
        OR title LIKE '%Hockey India League 2027 Player Auctions Slated%'
        OR title LIKE '%India Fields 121-Strong Contingent for Aichi-Nagoya%'
        OR title LIKE '%Pro Kabaddi League Season 13 Schedule Released%'
        OR title LIKE '%Neeraj Chopra & Sumit Antil Train in Europe%'
        OR title LIKE '%Satwik-Chirag Reclaim World No. 1 Ranking Following Asian Tour%'
        OR title LIKE '%Indian Rifle & Pistol Shooters Dominate ISSF Junior World Cup%'
        OR title LIKE '%Sheetal Devi Sweeps Triple Gold%'
        OR title LIKE '%Project LA 2028: The Science%'
        OR title LIKE '%India\\'s T20 Metamorphosis: Dynamic Powerplay%'
      `).run();

      // 4. Re-classify all existing rows
      const rows = q("SELECT id, sport, title, summary FROM agent_news").all() as any[];
      for (const r of rows) {
        const text = `${r.title} ${r.summary || ""}`.toLowerCase();
        let newSport = r.sport;
        const matches = (p: string) => new RegExp(`\\b(${p})\\b`, "i").test(text);

        if (matches("nba|wnba|nfl|lebron|celtics|76ers|arteta|arsenal|gyokeres|hansi flick|raphinha|de jong|barcelona|ajax|manchester city|maresca|ronaldo|premier league|la liga|serie a|bundesliga|champions league|uefa|chelsea|liverpool|real madrid|ebola|nwsl|congo|cdc") && !matches("india|indian|bcci|isl|aiff")) {
          newSport = "International";
        } else if (matches("cricket|t20|t20i|t20is|ipl|bcci|icc|test match|odi|odis|wicket|wickets|bowler|bowlers|bowling|batting|batter|batters|batsman|batsmen|mandhana|rohit|kohli|ashwin|jaiswal|shubman gill|bumrah|cricinfo|cricbuzz|wpl|ranji|morkel|gambhir|dravid|century|hong kong sixes|sixes|bhuvneshwar|fast bowling|bowling coach|delhi capitals|mumbai indians|csk|rcb|kkr|super kings|smriti|deepti sharma|deepti|niki prasad|vaibhav sooryavanshi|shreyas iyer|seamer|spinners?|crease|stumped|lbw|leg-spinner|off-spinner|all-rounder|bbl|big bash|daren sammy|scalps|with the ball|first t20i|cricketer|cricketers|test series|odi series|t20 series|ind vs zim|ind vs wi|ind vs aus|ind vs nz|chaminda vaas|duleep|one-day cup|fifty|ton|pacers?|ferguson|fast bowlers?|mega auction|ipl auction|patidar|australia a|australia-a|india a|india-a|rest of india|irani cup")) {
          newSport = "Cricket";
        } else if (matches("football|footballer|footballers|isl|indian super league|aiff|chhetri|bengaluru fc|mohun bagan|east bengal|fifa|soccer|striker|slk|super league kerala|forca kochi|thiruvananthapuram kombans|khalid jamil|jamil|kerala blasters")) {
          newSport = "Football";
        } else if (matches("badminton|bwf|sindhu|lakshya|satwik|chirag|shuttler|shuttlers|prannoy|srikanth|thomas cup|uber cup|denmark open|all england|an se-young|an se young|tanvi sharma|ayush shetty|jagsher")) {
          newSport = "Badminton";
        } else if (matches("hockey|fih|harmanpreet|kalinga|drag-flick|rourkela|penalty corner|hil|hockey india league")) {
          newSport = "Hockey";
        } else if (matches("boxing|boxer|boxers|lovlina|nikhat|wba|wbc|wbo|ibf|featherweight|welterweight|heavyweight|lightweight|pugilist|iba")) {
          newSport = "Boxing";
        } else if (matches("shoot|shooting|shooter|shooters|issf|pistol|rifle|manu bhaker|nrai|sarabjot|sift kaur|10m air")) {
          newSport = "Shooting";
        } else if (matches("wrestl|wrestling|wrestler|wrestlers|uww|sehrawat|phogat|akhara|grappler|dahiya|punia")) {
          newSport = "Wrestling";
        } else if (matches("weightlift|weightlifting|weightlifter|mirabai|snatch|clean and jerk|iwf")) {
          newSport = "Weightlifting";
        } else if (matches("para|paralympic|paralympics|antil|lekhara|para-shuttler|para asian|pci")) {
          newSport = "Para Sports";
        } else if (matches("archery|archer|archers|compound|recurve|sheetal devi|bommadevara|deepika kumari")) {
          newSport = "Archery";
        } else if (matches("table tennis|paddler|paddlers|sharath|manika")) {
          newSport = "Table Tennis";
        } else if (matches("squash|ghosal|chinappa")) {
          newSport = "Squash";
        } else if (matches("tennis|bopanna|atp|wta|grand slam|wimbledon|djokovic|alcaraz|sinner")) {
          newSport = "Tennis";
        } else if (matches("golf|golfer|aditi ashok|shubhankar|pga")) {
          newSport = "Golf";
        } else if (matches("swim|swimming|swimmer|nataraj|prakash|aquatics")) {
          newSport = "Swimming";
        } else if (matches("kabaddi|pkl|pro kabaddi|dabang delhi|puneri paltan|jaipur pink|u mumba")) {
          newSport = "Kabaddi";
        } else if (matches("athletics|javelin|steeplechase|relay|neeraj|sprint|sprinter|marathon|shot put|high jump|long jump|triple jump|race walk|track and field|diamond league|100m|200m|400m|800m|1500m|5000m|10000m|pole vault|decathlon|heptathlon")) {
          newSport = "Athletics";
        } else if (matches("cycling|cyclist|velodrome")) {
          newSport = "Cycling";
        } else if (matches("judo")) {
          newSport = "Judo";
        } else if (matches("rowing")) {
          newSport = "Rowing";
        } else if (matches("sailing")) {
          newSport = "Sailing";
        } else if (matches("wushu")) {
          newSport = "Wushu";
        } else if (matches("kurash")) {
          newSport = "Kurash";
        } else if (matches("sepaktakraw")) {
          newSport = "Sepaktakraw";
        } else if (matches("soft tennis")) {
          newSport = "Soft Tennis";
        } else if (matches("mixed martial|mma|ufc")) {
          newSport = "Mixed Martial Arts";
        } else {
          newSport = "General";
        }

        if (newSport !== r.sport) {
          q("UPDATE agent_news SET sport = ? WHERE id = ?").run(newSport, r.id);
        }
      }

      // 5. Exclude previews and non-results from results table; require outcome word or score
      const resultsRows = q("SELECT id, headline, score_text FROM results").all() as any[];
      for (const res of resultsRows) {
        const text = (res.headline || "").toLowerCase();
        const score = res.score_text;
        const isPreviewOrNonResult = /\b(predict(s|ion|ions|ed)?|preview(s|ed)?|lineups?|injur(y|ies)|ahead of|to lead|possib(le|ility)|probab(le|ility)|schedule|how to watch|where to watch|live stream(ing)?|squads?|pitch report|playing xi|expecting|child|pregnant)\b/i.test(text);
        const hasOutcomeWord = /\b(won|wins?|beat|beats|defeat(ed|s)?|clinch(ed|es)?|medals?|medall?ist|lost|loses?|loss|draw(s|n)?|drew|triumph(ed|s)?|crowned)\b/i.test(text);

        if (isPreviewOrNonResult || (!score && !hasOutcomeWord)) {
          q("DELETE FROM results WHERE id = ?").run(res.id);
        }
      }

      // Also update backup file live_news_archive.json
      const backupPath = path.resolve(DATA_DIR, "live_news_archive.json");
      const current = agentStorage.listNews(undefined, 100);
      fs.writeFileSync(backupPath, JSON.stringify(current, null, 2), "utf8");
    } catch (e: any) {
      console.warn("[storage] cleanupAndReclassify error:", e?.message);
    }
  },

  purgeSyntheticNews: () => {
    agentStorage.cleanupAndReclassify();
  },

  listScorecards: (): AgentScorecardItem[] => [],
  getScorecard: (_matchId: string): AgentScorecardItem | undefined => undefined,
  upsertScorecard: (_item: AgentScorecardItem) => false,
  purgeLiveRecords: () => {},

  logEvent: (event: string, details?: string) => {
    q("INSERT INTO agent_logs (event, details) VALUES (?, ?)").run(event, details || null);
  },

  stats: () => ({
    totalNews: (q("SELECT COUNT(*) n FROM agent_news").get() as { n: number })?.n || 0,
    totalResults: (q("SELECT COUNT(*) n FROM results").get() as { n: number })?.n || 0,
    newestArticleTime: (q("SELECT published_at FROM agent_news ORDER BY published_at DESC LIMIT 1").get() as any)?.published_at || null,
    newestResultTime: (q("SELECT published_at FROM results ORDER BY published_at DESC LIMIT 1").get() as any)?.published_at || null,
    lastLog: q("SELECT * FROM agent_logs ORDER BY id DESC LIMIT 1").get() as any,
  }),
};

export interface StoredMedalTable {
  games_id: string;
  games_name: string;
  source: string;
  source_url: string;
  fetched_at: string;
  is_live: number;
  india_rank: number | null;
  india_gold: number | null;
  india_silver: number | null;
  india_bronze: number | null;
  india_total: number | null;
  table_data: string; // JSON Array of MedalTableRow
  warnings: string | null;
  updated_at?: string;
}

export interface StoredCalendarEvent {
  id: string;
  name: string;
  short_name: string;
  start_date: string;
  end_date: string;
  location: string;
  venue: string | null;
  wikidata_id: string | null;
  wikipedia_title: string | null;
  source: string;
  source_url: string;
  fetched_at: string;
  featured: number;
  raw_data?: string | null;
  updated_at?: string;
}

export const medalTableStorage = {
  get: (gamesId: string): StoredMedalTable | undefined => {
    return q("SELECT * FROM medal_tables WHERE games_id = ?").get(gamesId) as StoredMedalTable | undefined;
  },
  list: (): StoredMedalTable[] => {
    return q("SELECT * FROM medal_tables ORDER BY is_live DESC, games_id ASC").all() as StoredMedalTable[];
  },
  upsert: (m: StoredMedalTable) => {
    q(`
      INSERT INTO medal_tables (
        games_id, games_name, source, source_url, fetched_at, is_live,
        india_rank, india_gold, india_silver, india_bronze, india_total,
        table_data, warnings, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(games_id) DO UPDATE SET
        games_name = excluded.games_name,
        source = excluded.source,
        source_url = excluded.source_url,
        fetched_at = excluded.fetched_at,
        is_live = excluded.is_live,
        india_rank = excluded.india_rank,
        india_gold = excluded.india_gold,
        india_silver = excluded.india_silver,
        india_bronze = excluded.india_bronze,
        india_total = excluded.india_total,
        table_data = excluded.table_data,
        warnings = excluded.warnings,
        updated_at = datetime('now')
    `).run(
      m.games_id, m.games_name, m.source, m.source_url, m.fetched_at, m.is_live ? 1 : 0,
      m.india_rank ?? null, m.india_gold ?? null, m.india_silver ?? null, m.india_bronze ?? null, m.india_total ?? null,
      m.table_data, m.warnings ?? null
    );
  },
};

export const eventCalendarStorage = {
  get: (id: string): StoredCalendarEvent | undefined => {
    return q("SELECT * FROM event_calendar WHERE id = ?").get(id) as StoredCalendarEvent | undefined;
  },
  list: (): StoredCalendarEvent[] => {
    return q("SELECT * FROM event_calendar ORDER BY start_date ASC").all() as StoredCalendarEvent[];
  },
  upsert: (e: StoredCalendarEvent) => {
    q(`
      INSERT INTO event_calendar (
        id, name, short_name, start_date, end_date, location, venue,
        wikidata_id, wikipedia_title, source, source_url, fetched_at, featured, raw_data, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        short_name = excluded.short_name,
        start_date = excluded.start_date,
        end_date = excluded.end_date,
        location = excluded.location,
        venue = excluded.venue,
        wikidata_id = excluded.wikidata_id,
        wikipedia_title = excluded.wikipedia_title,
        source = excluded.source,
        source_url = excluded.source_url,
        fetched_at = excluded.fetched_at,
        featured = excluded.featured,
        raw_data = excluded.raw_data,
        updated_at = datetime('now')
    `).run(
      e.id, e.name, e.short_name, e.start_date, e.end_date, e.location, e.venue || null,
      e.wikidata_id || null, e.wikipedia_title || null, e.source, e.source_url, e.fetched_at,
      e.featured ? 1 : 0, e.raw_data || null
    );
  },
};

/* ---------- Dynamic Telemetry Storage Objects ---------- */

export interface StoredAthlete {
  slug: string;
  name: string;
  sport: string;
  gender: string;
  tagline?: string | null;
  games: string;
  career_json: string;
  honours_json: string;
  is_team: number;
  featured: number;
  img_url?: string | null;
  bio?: string | null;
  medals_g: number;
  medals_s: number;
  medals_b: number;
  source: string;
  source_url: string;
  updated_at?: string;
}

export const athletesStorage = {
  get: (slug: string): StoredAthlete | undefined => {
    return q("SELECT * FROM athletes WHERE slug = ?").get(slug) as StoredAthlete | undefined;
  },
  list: (filter?: { sport?: string; gender?: string; featured?: boolean; search?: string; limit?: number; offset?: number }): { athletes: StoredAthlete[]; total: number } => {
    let sql = "SELECT * FROM athletes WHERE 1=1";
    let countSql = "SELECT COUNT(*) as count FROM athletes WHERE 1=1";
    const params: any[] = [];
    const countParams: any[] = [];

    if (filter?.sport) {
      sql += " AND LOWER(sport) = LOWER(?)";
      countSql += " AND LOWER(sport) = LOWER(?)";
      params.push(filter.sport);
      countParams.push(filter.sport);
    }
    if (filter?.gender) {
      sql += " AND LOWER(gender) = LOWER(?)";
      countSql += " AND LOWER(gender) = LOWER(?)";
      params.push(filter.gender);
      countParams.push(filter.gender);
    }
    if (filter?.featured !== undefined) {
      sql += " AND featured = ?";
      countSql += " AND featured = ?";
      params.push(filter.featured ? 1 : 0);
      countParams.push(filter.featured ? 1 : 0);
    }
    if (filter?.search) {
      const term = `%${filter.search.trim().toLowerCase()}%`;
      sql += " AND (LOWER(name) LIKE ? OR LOWER(sport) LIKE ? OR LOWER(tagline) LIKE ?)";
      countSql += " AND (LOWER(name) LIKE ? OR LOWER(sport) LIKE ? OR LOWER(tagline) LIKE ?)";
      params.push(term, term, term);
      countParams.push(term, term, term);
    }

    sql += " ORDER BY featured DESC, (medals_g * 100 + medals_s * 10 + medals_b) DESC, name ASC";
    const limit = Math.min(Math.max(filter?.limit || 100, 1), 200);
    const offset = Math.max(filter?.offset || 0, 0);
    sql += ` LIMIT ${limit} OFFSET ${offset}`;

    const totalRow = q(countSql).get(...countParams) as { count: number } | undefined;
    const athletes = q(sql).all(...params) as StoredAthlete[];
    return { athletes, total: totalRow?.count || athletes.length };
  },
  upsert: (a: StoredAthlete) => {
    q(`
      INSERT INTO athletes (
        slug, name, sport, gender, tagline, games, career_json, honours_json,
        is_team, featured, img_url, bio, medals_g, medals_s, medals_b, source, source_url, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(slug) DO UPDATE SET
        name = excluded.name,
        sport = excluded.sport,
        gender = excluded.gender,
        tagline = excluded.tagline,
        games = excluded.games,
        career_json = excluded.career_json,
        honours_json = excluded.honours_json,
        is_team = excluded.is_team,
        featured = excluded.featured,
        img_url = excluded.img_url,
        bio = excluded.bio,
        medals_g = excluded.medals_g,
        medals_s = excluded.medals_s,
        medals_b = excluded.medals_b,
        source = excluded.source,
        source_url = excluded.source_url,
        updated_at = datetime('now')
    `).run(
      a.slug, a.name, a.sport, a.gender || '', a.tagline || null, a.games,
      a.career_json, a.honours_json, a.is_team ? 1 : 0, a.featured ? 1 : 0,
      a.img_url || null, a.bio || null, a.medals_g || 0, a.medals_s || 0,
      a.medals_b || 0, a.source, a.source_url
    );
  },
  count: (): number => {
    const row = q("SELECT COUNT(*) as count FROM athletes").get() as { count: number } | undefined;
    return row?.count || 0;
  }
};

export interface StoredHallOfFame {
  id?: number;
  athlete_slug: string;
  name: string;
  sport: string;
  era: string;
  milestone: string;
  medals_text: string;
  img_url?: string | null;
  source: string;
  updated_at?: string;
}

export const hallOfFameStorage = {
  list: (): StoredHallOfFame[] => {
    return q("SELECT * FROM hall_of_fame ORDER BY id ASC").all() as StoredHallOfFame[];
  },
  upsert: (h: StoredHallOfFame) => {
    q(`
      INSERT INTO hall_of_fame (
        athlete_slug, name, sport, era, milestone, medals_text, img_url, source, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).run(
      h.athlete_slug, h.name, h.sport, h.era, h.milestone, h.medals_text, h.img_url || null, h.source
    );
  },
  clear: () => {
    q("DELETE FROM hall_of_fame").run();
  }
};

export interface StoredBroadcastItem {
  id: string;
  event_title: string;
  sport: string;
  tournament: string;
  channel: string;
  stream_app: string;
  stream_url?: string | null;
  start_time_ist: string;
  end_time_ist?: string | null;
  is_live: number;
  badge?: string | null;
  source: string;
  updated_at?: string;
}

export const broadcastStorage = {
  list: (isLiveOnly?: boolean): StoredBroadcastItem[] => {
    if (isLiveOnly) {
      return q("SELECT * FROM broadcast_schedule WHERE is_live = 1 ORDER BY start_time_ist ASC").all() as StoredBroadcastItem[];
    }
    return q("SELECT * FROM broadcast_schedule ORDER BY start_time_ist ASC").all() as StoredBroadcastItem[];
  },
  upsert: (b: StoredBroadcastItem) => {
    q(`
      INSERT INTO broadcast_schedule (
        id, event_title, sport, tournament, channel, stream_app, stream_url,
        start_time_ist, end_time_ist, is_live, badge, source, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(id) DO UPDATE SET
        event_title = excluded.event_title,
        sport = excluded.sport,
        tournament = excluded.tournament,
        channel = excluded.channel,
        stream_app = excluded.stream_app,
        stream_url = excluded.stream_url,
        start_time_ist = excluded.start_time_ist,
        end_time_ist = excluded.end_time_ist,
        is_live = excluded.is_live,
        badge = excluded.badge,
        source = excluded.source,
        updated_at = datetime('now')
    `).run(
      b.id, b.event_title, b.sport, b.tournament, b.channel, b.stream_app,
      b.stream_url || null, b.start_time_ist, b.end_time_ist || null,
      b.is_live ? 1 : 0, b.badge || null, b.source
    );
  }
};

export interface StoredFanQuiz {
  id?: number;
  sport: string;
  question: string;
  options_json: string;
  answer_index: number;
  explanation?: string | null;
  difficulty: string;
  category: string;
  created_at?: string;
}

export interface StoredFanPoll {
  id?: number;
  title: string;
  category: string;
  options_json: string;
  votes_json: string;
  closes_at?: string | null;
  status: string;
  created_at?: string;
}

export const fanInteractiveStorage = {
  getQuizRound: (count = 5): StoredFanQuiz[] => {
    return q("SELECT * FROM fan_quizzes ORDER BY RANDOM() LIMIT ?").all(count) as StoredFanQuiz[];
  },
  upsertQuiz: (qItem: StoredFanQuiz) => {
    q(`
      INSERT INTO fan_quizzes (sport, question, options_json, answer_index, explanation, difficulty, category, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).run(qItem.sport, qItem.question, qItem.options_json, qItem.answer_index, qItem.explanation || null, qItem.difficulty, qItem.category);
  },
  listPolls: (status = "active"): StoredFanPoll[] => {
    return q("SELECT * FROM fan_polls WHERE status = ? ORDER BY id DESC").all(status) as StoredFanPoll[];
  },
  getPoll: (id: number): StoredFanPoll | undefined => {
    return q("SELECT * FROM fan_polls WHERE id = ?").get(id) as StoredFanPoll | undefined;
  },
  votePoll: (id: number, optionIndex: number): boolean => {
    const poll = q("SELECT * FROM fan_polls WHERE id = ?").get(id) as StoredFanPoll | undefined;
    if (!poll) return false;
    let votes: Record<string, number> = {};
    try {
      votes = JSON.parse(poll.votes_json || "{}");
    } catch {}
    const key = String(optionIndex);
    votes[key] = (votes[key] || 0) + 1;
    q("UPDATE fan_polls SET votes_json = ? WHERE id = ?").run(JSON.stringify(votes), id);
    return true;
  },
  upsertPoll: (p: StoredFanPoll) => {
    q(`
      INSERT INTO fan_polls (title, category, options_json, votes_json, closes_at, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
    `).run(p.title, p.category, p.options_json, p.votes_json || "{}", p.closes_at || null, p.status || "active");
  }
};

export interface StoredParalympicTelemetry {
  id: string;
  games_name: string;
  year: number;
  host: string;
  dates: string;
  india_rank?: number | null;
  gold: number;
  silver: number;
  bronze: number;
  total: number;
  sports_count: number;
  top_athletes_json: string;
  table_json: string;
  source: string;
  source_url: string;
  updated_at?: string;
}

export const paralympicStorage = {
  get: (id: string): StoredParalympicTelemetry | undefined => {
    return q("SELECT * FROM paralympic_telemetry WHERE id = ?").get(id) as StoredParalympicTelemetry | undefined;
  },
  list: (): StoredParalympicTelemetry[] => {
    return q("SELECT * FROM paralympic_telemetry ORDER BY year DESC").all() as StoredParalympicTelemetry[];
  },
  upsert: (p: StoredParalympicTelemetry) => {
    q(`
      INSERT INTO paralympic_telemetry (
        id, games_name, year, host, dates, india_rank, gold, silver, bronze, total,
        sports_count, top_athletes_json, table_json, source, source_url, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(id) DO UPDATE SET
        games_name = excluded.games_name,
        year = excluded.year,
        host = excluded.host,
        dates = excluded.dates,
        india_rank = excluded.india_rank,
        gold = excluded.gold,
        silver = excluded.silver,
        bronze = excluded.bronze,
        total = excluded.total,
        sports_count = excluded.sports_count,
        top_athletes_json = excluded.top_athletes_json,
        table_json = excluded.table_json,
        source = excluded.source,
        source_url = excluded.source_url,
        updated_at = datetime('now')
    `).run(
      p.id, p.games_name, p.year, p.host, p.dates, p.india_rank || null,
      p.gold, p.silver, p.bronze, p.total, p.sports_count,
      p.top_athletes_json, p.table_json, p.source, p.source_url
    );
  }
};

export interface StoredMedalEdition {
  id: string;
  games_type: string;
  year: number;
  host: string;
  gold: number;
  silver: number;
  bronze: number;
  total: number;
  athletes_count?: number | null;
  rank?: string | null;
  note?: string | null;
  status: string;
  source: string;
  source_url: string;
  updated_at?: string;
}

export const medalEditionsStorage = {
  listByType: (gamesType: string): StoredMedalEdition[] => {
    return q("SELECT * FROM medal_editions WHERE games_type = ? ORDER BY year ASC").all(gamesType) as StoredMedalEdition[];
  },
  getAll: (): StoredMedalEdition[] => {
    return q("SELECT * FROM medal_editions ORDER BY year DESC").all() as StoredMedalEdition[];
  },
  upsert: (m: StoredMedalEdition) => {
    q(`
      INSERT INTO medal_editions (
        id, games_type, year, host, gold, silver, bronze, total,
        athletes_count, rank, note, status, source, source_url, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(id) DO UPDATE SET
        games_type = excluded.games_type,
        year = excluded.year,
        host = excluded.host,
        gold = excluded.gold,
        silver = excluded.silver,
        bronze = excluded.bronze,
        total = excluded.total,
        athletes_count = excluded.athletes_count,
        rank = excluded.rank,
        note = excluded.note,
        status = excluded.status,
        source = excluded.source,
        source_url = excluded.source_url,
        updated_at = datetime('now')
    `).run(
      m.id, m.games_type, m.year, m.host, m.gold, m.silver, m.bronze, m.total,
      m.athletes_count || null, m.rank || null, m.note || null, m.status,
      m.source, m.source_url
    );
  }
};


