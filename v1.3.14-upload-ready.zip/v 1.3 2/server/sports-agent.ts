import { agentStorage, type AgentNewsItem, type ResultItem } from "./storage";
import fs from "node:fs";
import path from "node:path";

export const LISTED_SPORTS = [
  "Cricket",
  "Football",
  "Kabaddi",
  "Hockey",
  "Athletics",
  "Badminton",
  "Shooting",
  "Archery",
  "Wrestling",
  "Boxing",
  "Weightlifting",
  "Para Sports",
  "Table Tennis",
  "Squash",
  "Tennis",
  "Golf",
  "Swimming",
  "Sailing",
  "Rowing",
  "Judo",
  "Mixed Martial Arts",
  "Kurash",
  "Wushu",
  "Sepaktakraw",
  "Soft Tennis",
  "Cycling",
] as const;

export type ListedSport = typeof LISTED_SPORTS[number];

export const SPORT_SEARCH_TERMS: Record<ListedSport, string> = {
  Cricket: "cricket",
  Football: "football OR ISL",
  Kabaddi: "kabaddi OR PKL",
  Hockey: "hockey",
  Athletics: "athletics OR javelin OR marathon OR sprint",
  Badminton: "badminton OR BWF",
  Shooting: "shooting OR pistol OR rifle OR ISSF",
  Archery: "archery OR recurve OR compound",
  Wrestling: "wrestling OR UWW",
  Boxing: "boxing",
  Weightlifting: "weightlifting",
  "Para Sports": "para sports OR paralympics",
  "Table Tennis": "'table tennis'",
  Squash: "squash",
  Tennis: "tennis OR ATP OR WTA",
  Golf: "golf",
  Swimming: "swimming",
  Sailing: "sailing",
  Rowing: "rowing",
  Judo: "judo",
  "Mixed Martial Arts": "MMA OR 'mixed martial arts'",
  Kurash: "kurash",
  Wushu: "wushu",
  Sepaktakraw: "sepaktakraw",
  "Soft Tennis": "'soft tennis'",
  Cycling: "cycling",
};

export interface FeedTrackerItem {
  url: string;
  name: string;
  lastStatus: number;
  itemCount: number;
  consecutiveFailures: number;
  isStale: boolean;
  lastFetchTime: string | null;
  error: string | null;
  state?: "CLOSED" | "OPEN" | "HALF_OPEN";
  nextProbeTime?: number;
}

export const feedStatusMap = new Map<string, FeedTrackerItem>();

export function getFeedStatusList(): FeedTrackerItem[] {
  return Array.from(feedStatusMap.values());
}

export interface FeedFetchResult {
  ok: boolean;
  itemBlocks: RegExpMatchArray[];
  stale?: boolean;
  error?: string | null;
}

export async function fetchFeedSafely(url: string, name: string, timeoutMs = 9000): Promise<FeedFetchResult> {
  let tracker = feedStatusMap.get(url);
  if (!tracker) {
    tracker = {
      url,
      name,
      lastStatus: 0,
      itemCount: 0,
      consecutiveFailures: 0,
      isStale: false,
      lastFetchTime: null,
      error: null,
      state: "CLOSED",
      nextProbeTime: 0,
    };
    feedStatusMap.set(url, tracker);
  }

  const now = Date.now();

  // Circuit breaker: if >= 3 failures, circuit is OPEN unless probe time arrived
  if (tracker.consecutiveFailures >= 3 && now < (tracker.nextProbeTime || 0)) {
    tracker.isStale = true;
    tracker.state = "OPEN";
    return { ok: false, itemBlocks: [], stale: true, error: tracker.error || "Circuit breaker OPEN" };
  }

  if (tracker.consecutiveFailures >= 3) {
    tracker.state = "HALF_OPEN";
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        Accept: "application/rss+xml, application/xml, text/xml, */*",
      },
      signal: controller.signal,
    });
    clearTimeout(timer);

    tracker.lastStatus = res.status;
    tracker.lastFetchTime = new Date().toISOString();

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }

    // 1. Check Content-Length cap (2MB)
    const cl = res.headers.get("content-length");
    if (cl && parseInt(cl, 10) > 2 * 1024 * 1024) {
      throw new Error("Feed payload exceeds 2 MB limit");
    }

    // 2. Reject HTML error pages
    const ct = res.headers.get("content-type") || "";
    if (ct.includes("text/html")) {
      throw new Error("Feed returned HTML page instead of RSS XML");
    }

    const text = await res.text();
    if (text.length > 2 * 1024 * 1024) {
      throw new Error("Feed payload exceeds 2 MB limit");
    }

    if (/^\s*<!doctype\s+html/i.test(text) || /^\s*<html/i.test(text)) {
      throw new Error("Feed returned HTML error page");
    }

    // 3. Reject empty channels
    const itemBlocks = [...text.matchAll(/<item>([\s\S]*?)<\/item>/gi)];
    if (itemBlocks.length === 0) {
      throw new Error("Feed returned empty channel (0 items)");
    }

    // Success: reset failures and close circuit
    tracker.itemCount = itemBlocks.length;
    tracker.consecutiveFailures = 0;
    tracker.isStale = false;
    tracker.state = "CLOSED";
    tracker.error = null;
    tracker.nextProbeTime = 0;
    feedStatusMap.set(url, tracker);

    return { ok: true, itemBlocks, stale: false };
  } catch (err: any) {
    clearTimeout(timer);
    tracker.consecutiveFailures++;
    tracker.error = err?.message || String(err);
    if (tracker.consecutiveFailures >= 3) {
      tracker.isStale = true;
      tracker.state = "OPEN";
      // Exponential backoff with jitter: 2^(fails - 3) * 60s up to 30 min + jitter
      const exp = Math.min(5, tracker.consecutiveFailures - 3);
      const backoffMs = Math.min(30 * 60 * 1000, 60 * 1000 * Math.pow(2, exp));
      const jitter = Math.floor(Math.random() * 5000);
      tracker.nextProbeTime = Date.now() + backoffMs + jitter;
    }
    feedStatusMap.set(url, tracker);
    return { ok: false, itemBlocks: [], stale: tracker.isStale, error: tracker.error };
  }
}

export function cleanText(s?: string): string {
  if (!s) return "";
  let text = s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1");
  // Decode entities BEFORE stripping tags, and repeat: an excerpt that
  // arrives as &lt;li&gt;... must not survive as literal markup text, which
  // is what happened when tags were stripped first and entities decoded after.
  for (let i = 0; i < 3; i++) {
    const decoded = text
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&#39;|&apos;/g, "'")
      .replace(/&nbsp;/g, " ")
      .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
      .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
    const stripped = decoded
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/<[^>]*$/, " ");
    if (stripped === text) { text = stripped; break; }
    text = stripped;
  }
  return text.replace(/\s+/g, " ").trim();
}

/** Normalised title key for deduplication: case, punctuation and filler words removed. */
export function normalizeKey(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\b(the|a|an)\b/g, " ").replace(/\s+/g, " ").trim();
}

/** India relevance: an Indian athlete, team, event, body, domestic competition or city. */
export function hasIndiaRelevance(text: string): boolean {
  return /\b(india|indians?|bcci|isl|pkl|aiff|sai|ttfi|bai|afi|nrai|wfi|pci|delhi|mumbai|bengaluru|kolkata|chennai|hyderabad|domestic|khelo india|ranji|duleep|santosh trophy|national championship|inter-state|harmanpreet|chhetri|neeraj|manu bhaker|satwik|chirag|lovlina|mirabai|sehrawat|sheetal devi|nataraj|shubhankar|nagal|bopanna|manika|sharath|lakshya|prannoy|srikanth|deepika kumari|nikhat|vinesh|antim|avinash sable)\b/i.test(text);
}

/** Off-topic gossip that has no place on an Indian-sports feed, even if a sport word appears in it. */
export function isOffTopicGossip(text: string): boolean {
  return /\b(wwe|wrestlemania|bigg boss|big boss|reality show|reality tv|streamer|twitch|influencer|weight loss|weight-loss|kaun banega|kbc contestant)\b/i.test(text);
}

/**
 * Resolve the sport a result actually belongs to, from its own text — never
 * from the search query that found it. Returns null to drop the item when it
 * is foreign, or when a "General" headline does not name the queried sport at
 * all (the old behaviour stored such items under the queried sport, which is
 * how cricket stories landed under Cycling and hockey under Archery).
 */
export function resolveResultSport(querySport: string, headline: string, body?: string | null): string | null {
  const classified = classifySport(headline, body);
  if ((LISTED_SPORTS as readonly string[]).includes(classified)) return classified;
  if (classified === "International") return null;
  const text = `${headline} ${body || ""}`.toLowerCase();
  if (text.includes(querySport.toLowerCase())) return querySport;
  if (querySport === "Para Sports" && /\bpara\b/.test(text)) return querySport;
  if (querySport === "Mixed Martial Arts" && /\bmma\b/.test(text)) return querySport;
  return null;
}

/**
 * Extracts a score or opponent ONLY if it literally appears in the headline or summary text.
 * Otherwise returns null.
 */
export function extractLiteralScore(text: string): string | null {
  if (!text) return null;

  // 1. Cricket wickets/runs victory margin: e.g. "beat India by 24 runs", "won by 6 wickets", "by 14 runs"
  const marginMatch = text.match(/\b(?:won|win|wins|beat|beats|defeats?)\s+(?:[A-Za-z\s]{1,25}\s+)?by\s+\d+\s+(?:wickets?|wkts?|runs?|goals?|points?|pts?)\b/i)
    || text.match(/\bby\s+\d+\s+(?:wickets?|wkts?|runs?|goals?|points?|pts?)\b/i);
  if (marginMatch) {
    return marginMatch[0].trim();
  }

  // 2. Cricket score with overs/wickets: e.g. "115/4", "245/6", "115 for 4"
  // Exclude ratings like "4/5 stars", "3/5 rating"
  const cricketScore = text.match(/\b\d{1,3}\/\d{1,2}(?:\s*\(\d+(?:\.\d+)?\s*(?:ov|overs)\))?\b/i)
    || text.match(/\b\d{1,3}\s+for\s+\d{1,2}\b/i);
  if (cricketScore) {
    const idx = text.indexOf(cricketScore[0]);
    const after = text.slice(idx + cricketScore[0].length, idx + cricketScore[0].length + 15);
    const before = text.slice(Math.max(0, idx - 15), idx);
    if (!/^\s*(?:stars?|ratings?|reviews?|pts?|points?)/i.test(after) && !/(?:rated|rating|give|gave)\s*$/i.test(before)) {
      return cricketScore[0].trim();
    }
  }

  // Multi-set strings (e.g. "21-19, 18-21, 21-18") must NOT parse as scores
  if (/\d+-\d+\s*,\s*\d+-\d+/.test(text)) {
    return null;
  }

  // 4. Single match scorelines e.g. "3-1", "4-2", "35-27"
  // Excludes 4-digit years (2026-27), seasons (26-27 season), ages (24-year-old), dates (18-24 October)
  const singleScoreMatch = text.match(/(?<!\d)(?:[1-9]\d?)\s*-\s*(?:[1-9]\d?|\d)(?!\d)/g);
  if (singleScoreMatch) {
    for (const m of singleScoreMatch) {
      const idx = text.indexOf(m);
      const after = text.slice(idx + m.length, idx + m.length + 15);
      const before = text.slice(Math.max(0, idx - 15), idx);
      if (/-(?:year|yr|month|day|old)/i.test(after) || /^\s*(?:year|yr|season|oct|nov|dec|jan|feb|mar|apr|may|jun|jul|aug|sep)/i.test(after)) continue;
      if (/(?:season|fy|year|u|under|age|aged)\s*$/i.test(before)) continue;
      const [left, right] = m.split("-").map(s => parseInt(s.trim(), 10));
      if (left >= 1900 || right >= 1900) continue;
      if (Math.abs(right - left) === 1 && left >= 20 && left <= 30 && /(?:isl|pkl|league|season|edition)/i.test(before + after)) continue;
      return m.trim();
    }
  }

  // 5. Distance / Athletics mark: e.g. "70.83m", "89.45 m"
  const distanceMatch = text.match(/\b\d{2}\.\d{2}\s*m(?:eters)?\b/i);
  if (distanceMatch) return distanceMatch[0].trim();

  // 6. Shooting / Points mark: e.g. "241.8 points", "149/150"
  const pointsMatch = text.match(/\b\d{2,3}(?:\.\d)?\s*(?:points|pts|\/\s*150)\b/i);
  if (pointsMatch) return pointsMatch[0].trim();

  return null;
}

/**
 * Formats a Date object to IST (Asia/Kolkata) date string: YYYY-MM-DD
 */
export function formatISTDate(d: Date): string {
  try {
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Kolkata",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(d);
  } catch {
    return d.toISOString().slice(0, 10);
  }
}

/**
 * Classifies sport based on headline and text.
 * Default is "General" (never "Athletics").
 * Non-India stories (e.g. Ebola, NWSL) tagged "International".
 */
export function classifySport(headline: string, body?: string | null): string {
  const full = `${headline} ${body || ""}`.toLowerCase();
  const matches = (p: string) => new RegExp(`\\b(${p})\\b`, "i").test(full);

  // Tag non-India / foreign stories (international leagues and clubs)
  if (matches("nba|wnba|nfl|lebron|celtics|76ers|arteta|arsenal|gyokeres|hansi flick|raphinha|de jong|barcelona|ajax|manchester city|maresca|ronaldo|premier league|la liga|serie a|bundesliga|champions league|uefa|chelsea|liverpool|real madrid|ebola|nwsl|congo|cdc") && !matches("india|indian|bcci|isl|aiff")) {
    return "International";
  }

  if (matches("cricket|t20|t20i|t20is|ipl|bcci|icc|test match|odi|odis|wicket|wickets|bowler|bowlers|bowling|batting|batter|batters|batsman|batsmen|mandhana|rohit|kohli|ashwin|jaiswal|shubman gill|bumrah|cricinfo|cricbuzz|wpl|ranji|morkel|gambhir|dravid|century|hong kong sixes|sixes|bhuvneshwar|fast bowling|bowling coach|delhi capitals|mumbai indians|csk|rcb|kkr|super kings|smriti|deepti sharma|deepti|niki prasad|vaibhav sooryavanshi|shreyas iyer|seamer|spinners?|crease|stumped|lbw|leg-spinner|off-spinner|all-rounder|bbl|big bash|daren sammy|scalps|with the ball|first t20i|cricketer|cricketers|test series|odi series|t20 series|ind vs zim|ind vs wi|ind vs aus|ind vs nz|chaminda vaas|duleep|one-day cup|fifty|ton|pacers?|ferguson|fast bowlers?|mega auction|ipl auction|patidar|australia a|australia-a|india a|india-a|rest of india|irani cup")) {
    return "Cricket";
  }
  if (matches("football|footballer|footballers|isl|indian super league|aiff|chhetri|bengaluru fc|mohun bagan|east bengal|fifa|soccer|striker|slk|super league kerala|forca kochi|thiruvananthapuram kombans|khalid jamil|jamil|kerala blasters")) {
    return "Football";
  }
  if (matches("badminton|bwf|sindhu|lakshya|satwik|chirag|shuttler|shuttlers|prannoy|srikanth|thomas cup|uber cup|denmark open|all england|an se-young|an se young|tanvi sharma|ayush shetty|jagsher")) {
    return "Badminton";
  }
  if (matches("hockey|fih|harmanpreet|kalinga|drag-flick|rourkela|penalty corner|hil|hockey india league")) {
    return "Hockey";
  }
  if (matches("boxing|boxer|boxers|lovlina|nikhat|wba|wbc|wbo|ibf|featherweight|welterweight|heavyweight|lightweight|pugilist|iba")) {
    return "Boxing";
  }
  if (matches("shoot|shooting|shooter|shooters|issf|pistol|rifle|manu bhaker|nrai|sarabjot|sift kaur|10m air")) {
    return "Shooting";
  }
  if (matches("wrestl|wrestling|wrestler|wrestlers|uww|sehrawat|phogat|akhara|grappler|dahiya|punia")) {
    return "Wrestling";
  }
  if (matches("weightlift|weightlifting|weightlifter|mirabai|snatch|clean and jerk|iwf")) {
    return "Weightlifting";
  }
  if (matches("para|paralympic|paralympics|antil|lekhara|para-shuttler|para asian|pci")) {
    return "Para Sports";
  }
  if (matches("archery|archer|archers|compound|recurve|sheetal devi|bommadevara|deepika kumari")) {
    return "Archery";
  }
  if (matches("table tennis|paddler|paddlers|sharath|manika")) {
    return "Table Tennis";
  }
  if (matches("squash|ghosal|chinappa")) {
    return "Squash";
  }
  if (matches("tennis|bopanna|atp|wta|grand slam|wimbledon|djokovic|alcaraz|sinner")) {
    return "Tennis";
  }
  if (matches("golf|golfer|aditi ashok|shubhankar|pga")) {
    return "Golf";
  }
  if (matches("swim|swimming|swimmer|nataraj|prakash|aquatics")) {
    return "Swimming";
  }
  if (matches("kabaddi|pkl|pro kabaddi|dabang delhi|puneri paltan|jaipur pink|u mumba")) {
    return "Kabaddi";
  }
  if (matches("athletics|javelin|steeplechase|relay|neeraj|sprint|sprinter|marathon|shot put|high jump|long jump|triple jump|race walk|track and field|diamond league|100m|200m|400m|800m|1500m|5000m|10000m|pole vault|decathlon|heptathlon")) {
    return "Athletics";
  }
  if (matches("cycling|cyclist|velodrome")) {
    return "Cycling";
  }
  if (matches("judo")) {
    return "Judo";
  }
  if (matches("rowing")) {
    return "Rowing";
  }
  if (matches("sailing")) {
    return "Sailing";
  }
  if (matches("wushu")) {
    return "Wushu";
  }
  if (matches("kurash")) {
    return "Kurash";
  }
  if (matches("sepaktakraw")) {
    return "Sepaktakraw";
  }
  if (matches("soft tennis")) {
    return "Soft Tennis";
  }
  if (matches("mixed martial|mma|ufc")) {
    return "Mixed Martial Arts";
  }

  // Strictest honest default: General
  return "General";
}

export class SportsAIAgent {
  private initialized = false;
  public lastNewsFetchTime: string | null = null;
  public lastResultsFetchTime: string | null = null;

  init() {
    if (this.initialized) return;
    this.initialized = true;

    // Run cleanups on startup: purge legacy scorecards, null fake fallbacks, reclassify existing rows
    agentStorage.cleanupAndReclassify();
    this.reclassifyStoredResults();
    agentStorage.purgeOldRecords();
    agentStorage.logEvent("agent_started", "Momentum Sports Agent started with clean news and daily results engine.");
  }

  /** Re-tag stored results from their own headlines, and drop ones that do
   *  not belong to any listed sport. Runs on startup via init(). */
  private reclassifyStoredResults() {
    try {
      const rows = agentStorage.listResults(undefined, undefined, 1000);
      for (const r of rows) {
        if (!r.id) continue;
        const resolved = resolveResultSport(r.sport, r.headline);
        if (!resolved) agentStorage.deleteResult(r.id);
        else if (resolved !== r.sport) agentStorage.updateResultSport(r.id, resolved);
      }
    } catch (e: any) {
      console.warn("[storage] reclassifyStoredResults error:", e?.message);
    }
  }

  /**
   * Fetches real news from RSS feeds.
   * Strips HTML, decodes entities, sets summary=null if absent, classifies accurately (default 'General').
   */
  async fetchLatestNews(sport?: string): Promise<{ count: number; items: AgentNewsItem[]; source: string }> {
    this.init();
    const fetchedItems: AgentNewsItem[] = [];

    const publisherFeeds = [
      { name: "Sportstar", url: "https://sportstar.thehindu.com/feeder/default.rss" },
      { name: "The Hindu", url: "https://www.thehindu.com/sport/feeder/default.rss" },
      { name: "NDTV Sports", url: "https://feeds.feedburner.com/ndtvsports-latest" },
      { name: "ESPNcricinfo", url: "https://www.espncricinfo.com/rss/content/story/feeds/0.xml" },
      { name: "Google News Sports", url: "https://news.google.com/rss/headlines/section/topic/SPORTS?hl=en-IN&gl=IN&ceid=IN:en" },
    ];

    for (const feed of publisherFeeds) {
      try {
        const feedResult = await fetchFeedSafely(feed.url, feed.name);
      if (!feedResult.ok || feedResult.itemBlocks.length === 0) {
        continue;
      }

      for (const block of feedResult.itemBlocks.slice(0, 25)) {
          const raw = block[1];
          const titleMatch = raw.match(/<title>([\s\S]*?)<\/title>/i);
          const linkMatch = raw.match(/<link>([\s\S]*?)<\/link>/i);
          const pubDateMatch = raw.match(/<pubDate>([\s\S]*?)<\/pubDate>/i);
          const descMatch = raw.match(/<description>([\s\S]*?)<\/description>/i);
          const sourceMatch = raw.match(/<source[^>]*>([\s\S]*?)<\/source>/i);
          const mediaMatch = raw.match(/<(?:media:content|enclosure)[^>]*url=["']([^"']+)["']/i);
          const imgInsideDesc = descMatch ? descMatch[1].match(/<img[^>]+src=["']([^"']+)["']/i) : null;

          const rawTitle = titleMatch ? cleanText(titleMatch[1]) : "";
          if (!rawTitle || rawTitle.length < 8) continue;

          // Extract publisher source name and headline
          let sourceName = sourceMatch ? cleanText(sourceMatch[1]) : "";
          let cleanTitle = rawTitle;
          if (rawTitle.includes(" - ")) {
            const parts = rawTitle.split(" - ");
            if (!sourceName && parts.length > 1) {
              sourceName = parts[parts.length - 1].trim();
            }
            cleanTitle = parts.slice(0, -1).join(" - ").trim();
          }
          if (!sourceName) {
            sourceName = feed.name;
          }

          // Extract clean real summary or null
          let rawDesc: string | null = descMatch ? cleanText(descMatch[1]) : null;
          if (rawDesc) {
            if (rawDesc.length < 25 || rawDesc.toLowerCase() === cleanTitle.toLowerCase() || rawDesc.includes("Tracked by Momentum India")) {
              rawDesc = null;
            } else if (rawDesc.length > 350) {
              rawDesc = rawDesc.slice(0, 347) + "...";
            }
          }

          // Extract direct publisher URL where available
          let cleanLink = linkMatch ? cleanText(linkMatch[1]) : null;

          const imageUrl = mediaMatch ? mediaMatch[1] : imgInsideDesc ? imgInsideDesc[1] : null;

          // Tag sport (default "General", non-India stories tagged "International")
          const matchedSport = classifySport(cleanTitle, rawDesc);
          // Publish gate: foreign leagues, off-topic gossip and stories with
          // no Indian athlete, team, event or body never reach the wire.
          // Any excerpt still containing markup after cleaning is dropped
          // to null rather than shown as raw HTML.
          if (matchedSport === "International") continue;
          if (isOffTopicGossip(`${cleanTitle} ${rawDesc || ""}`)) continue;
          if (!hasIndiaRelevance(`${cleanTitle} ${rawDesc || ""}`)) continue;
          if (/<[a-z][^>]*>/i.test(cleanTitle)) continue;
          if (rawDesc && /<[a-z][^>]*>/i.test(rawDesc)) rawDesc = null;

          let pubDate = new Date().toISOString();
          if (pubDateMatch && pubDateMatch[1]) {
            try {
              const d = new Date(cleanText(pubDateMatch[1]));
              if (!isNaN(d.getTime())) pubDate = d.toISOString();
            } catch {}
          }

          const item: AgentNewsItem = {
            sport: matchedSport,
            title: cleanTitle,
            summary: rawDesc,
            source: sourceName,
            url: cleanLink,
            image_url: imageUrl,
            published_at: pubDate,
            sentiment: "neutral",
            key_points: [],
          };

          agentStorage.addNews(item);
          fetchedItems.push(item);
        }
      } catch (err: any) {
        console.warn(`[Sports Wire] Sync error for ${feed.name}:`, err?.message || err);
        const st = feedStatusMap.get(feed.url) || {
          url: feed.url,
          name: feed.name,
          lastStatus: 0,
          itemCount: 0,
          consecutiveFailures: 0,
          isStale: false,
          lastFetchTime: null,
          error: null,
        };
        st.consecutiveFailures++;
        if (st.consecutiveFailures >= 3) st.isStale = true;
        st.error = err?.message || "Fetch timeout";
        feedStatusMap.set(feed.url, st);
      }
    }

    this.lastNewsFetchTime = new Date().toISOString();
    agentStorage.logEvent("real_news_ingested", `Ingested news from wires. Total stored news: ${agentStorage.stats().totalNews}`);

    return {
      count: fetchedItems.length,
      items: agentStorage.listNews(sport),
      source: "Real Live Sports Wire (Sportstar / The Hindu / NDTV Sports / ESPNcricinfo / Google News)",
    };
  }

  /**
   * Fetches real daily sports results across all 26 sports from news wires.
   * Extracts literal scores only if present, else null.
   * Stores into `results` table deduped by normalized title + URL.
   */
  async fetchLatestResults(): Promise<{ count: number; results: ResultItem[] }> {
    this.init();
    const fetchedResults: ResultItem[] = [];

    // Query each of the 26 sports
    for (const sport of LISTED_SPORTS) {
      const queryTerms = SPORT_SEARCH_TERMS[sport] || sport.toLowerCase();
      // Google News RSS query with time constraint when:1d
      const googleNewsUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(`${queryTerms} India (wins OR beat OR defeats OR bronze OR silver OR gold OR final OR result) when:1d`)}&hl=en-IN&gl=IN&ceid=IN:en`;
      const fallbackUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(`${queryTerms} India (wins OR beat OR defeats OR bronze OR silver OR gold OR final OR result) when:3d`)}&hl=en-IN&gl=IN&ceid=IN:en`;

      try {
        let feedResult = await fetchFeedSafely(googleNewsUrl, `Google News (${sport})`);
        if (!feedResult.ok || feedResult.itemBlocks.length === 0) {
          feedResult = await fetchFeedSafely(fallbackUrl, `Google News Fallback (${sport})`);
        }
        if (!feedResult.ok || feedResult.itemBlocks.length === 0) {
          continue;
        }

        const itemBlocks = feedResult.itemBlocks;

        for (const block of itemBlocks.slice(0, 15)) {
          const raw = block[1];
          const titleMatch = raw.match(/<title>([\s\S]*?)<\/title>/i);
          const linkMatch = raw.match(/<link>([\s\S]*?)<\/link>/i);
          const pubDateMatch = raw.match(/<pubDate>([\s\S]*?)<\/pubDate>/i);
          const descMatch = raw.match(/<description>([\s\S]*?)<\/description>/i);
          const sourceMatch = raw.match(/<source[^>]*>([\s\S]*?)<\/source>/i);

          const rawTitle = titleMatch ? cleanText(titleMatch[1]) : "";
          if (!rawTitle || rawTitle.length < 8) continue;

          let sourceName = sourceMatch ? cleanText(sourceMatch[1]) : "";
          let headline = rawTitle;
          if (rawTitle.includes(" - ")) {
            const parts = rawTitle.split(" - ");
            if (!sourceName && parts.length > 1) {
              sourceName = parts[parts.length - 1].trim();
            }
            headline = parts.slice(0, -1).join(" - ").trim();
          }

          const rawDesc = descMatch ? cleanText(descMatch[1]) : "";
          const link = linkMatch ? cleanText(linkMatch[1]) : "";
          if (!link) continue;

          // 1. Exclude false matches (felicitation ceremonies, political meetings, commercial shipping, match fixing)
          const full = `${headline} ${rawDesc}`.toLowerCase();
          const isFelicitationOrIrrelevant = /\b(felicitat(es?|ed|ing)|feted|lauds?|honours?|cheque|cash award|cash reward|reception in|awards rs|match-fixing|handed suspension|banned for|doping ban|navy|warship|cargo|vessel|freight|oil tanker|strait of hormuz|indian ocean sailing times|crews are|boating at|to interact with|interact with|meets asian games|rustication to|inspiring journey|recalls special moment)\b/i.test(full);
          if (isFelicitationOrIrrelevant) continue;

          // 2. Discipline specific check to prevent false matches
          if (sport === "Soft Tennis" && (!/\bsoft tennis\b/i.test(full) || /\b(kabaddi|hockey|badminton)\b/i.test(full))) continue;
          if (sport === "Kurash" && (!/\bkurash\b/i.test(full) || /\b(mma|mixed martial arts|ju-jitsu|judo)\b/i.test(full))) continue;
          if (sport === "Sailing" && (!/\b(regatta|yachting|sailing championship|yacht club)\b/i.test(full) || /\b(badminton|hockey|golf|cricket)\b/i.test(full))) continue;

          // 3. Exclude previews, predictions, lineups, injury reports, and non-results
          const isPreviewOrNonResult = /\b(predict(s|ion|ions|ed)?|preview(s|ed)?|lineups?|injur(y|ies)|ahead of|to lead|possib(le|ility)|probab(le|ility)|schedule|how to watch|where to watch|live stream(ing)?|squads?|pitch report|playing xi|expecting|child|pregnant)\b/i.test(full);
          if (isPreviewOrNonResult) continue;

          // 4. India relevance filter
          const hasIndia = /\b(india|indians?|bcci|isl|pkl|aiff|sai|ttfi|aitf|bai|afi|nrai|wfi|pci)\b/i.test(full)
            || /\b(harmanpreet|chhetri|neeraj|manu bhaker|satwik|chirag|lovlina|mirabai|sehrawat|sheetal devi|nataraj|shubhankar|nagal|senthilkumar|bopanna|bhambri|ramkumar|sania|manika|sharath|sathiyan|sreeja|ayhika|archana|divija paul|bhavina|lakshya|prannoy|srikanth|treesa|gayatri|tanvi sharma|ayush shetty|jagsher|deepika kumari|dhiraj|aditi swami|jyothi surekha|nikhat|vinesh|antim|avinash sable)\b/i.test(full)
            || /\b(national ranking|national championship|ranji|duleep|santosh trophy|khelo india|inter-state)\b/i.test(full);

          if (!hasIndia) continue;

          // 5. Require a real outcome word OR a literal score
          const scoreText = extractLiteralScore(headline) || extractLiteralScore(rawDesc);
          const hasOutcomeWord = /\b(won|wins?|beat|beats|defeat(ed|s)?|clinch(ed|es)?|medals?|medall?ist|lost|loses?|loss|draw(s|n)?|drew|triumph(ed|s)?|crowned)\b/i.test(full);

          if (!scoreText && !hasOutcomeWord) continue;

          let pubDateObj = new Date();
          if (pubDateMatch && pubDateMatch[1]) {
            const parsed = new Date(cleanText(pubDateMatch[1]));
            if (!isNaN(parsed.getTime())) pubDateObj = parsed;
          }

          const dateIst = formatISTDate(pubDateObj);

          // Relabel from the story's own text, or drop it: never trust the
          // search query that surfaced it as the sport label.
          const resolvedSport = resolveResultSport(sport, headline, rawDesc);
          if (!resolvedSport) continue;
          if (isOffTopicGossip(full)) continue;

          const resultItem = {
            sport: resolvedSport,
            date_ist: dateIst,
            headline,
            score_text: scoreText,
            source: sourceName || "Wire Desk",
            url: link,
            published_at: pubDateObj.toISOString(),
          };

          const rowId = agentStorage.addResult(resultItem);
          if (rowId > 0) {
            fetchedResults.push({ id: rowId, ...resultItem });
          }
        }
      } catch (err: any) {
        console.warn(`[Results] Error processing ${sport}:`, err?.message || err);
      }
    }

    this.lastResultsFetchTime = new Date().toISOString();
    agentStorage.logEvent("results_ingested", `Ingested daily sports results. Total stored results: ${agentStorage.stats().totalResults}`);

    return {
      count: fetchedResults.length,
      results: agentStorage.listResults(),
    };
  }

  async answerQuery(userPrompt: string): Promise<{ answer: string; relatedResults: ResultItem[]; relatedNews: AgentNewsItem[] }> {
    this.init();
    const clean = userPrompt.trim().toLowerCase();

    const detectedSport = LISTED_SPORTS.find((s) => clean.includes(s.toLowerCase()));
    const allResults = agentStorage.listResults(detectedSport, undefined, 10);
    const allNews = agentStorage.listNews(detectedSport, 10);

    const relatedResults = allResults
      .filter((r) => !detectedSport || r.sport.toLowerCase() === detectedSport.toLowerCase() || clean.includes(r.headline.toLowerCase()))
      .slice(0, 4);

    const relatedNews = allNews
      .filter((n) => !detectedSport || n.sport.toLowerCase() === detectedSport.toLowerCase() || clean.includes(n.title.toLowerCase()))
      .slice(0, 4);

    let reply = `### 🏆 Momentum India Wire Desk & Results\n\n`;
    if (relatedResults.length > 0) {
      reply += `**Results from the past day, via news wires:**\n\n`;
      for (const r of relatedResults) {
        reply += `- **[${r.sport}]** ${r.headline}\n`;
        if (r.score_text) reply += `  • Score / Mark: \`${r.score_text}\`\n`;
        reply += `  • Date: ${r.date_ist} IST · Source: ${r.source}\n`;
        reply += `  • [Read source](${r.url})\n\n`;
      }
    } else {
      reply += `No India results reported yet for this sport today.\n\n`;
    }

    if (relatedNews.length > 0) {
      reply += `**Latest Dispatches:**\n\n`;
      for (const n of relatedNews) {
        reply += `- **[${n.sport}]** ${n.title} (${n.source})\n`;
        if (n.summary) reply += `  ${n.summary}\n`;
        if (n.url) reply += `  [Read Full Article](${n.url})\n\n`;
      }
    }

    return { answer: reply, relatedResults, relatedNews };
  }
}

export const sportsAgent = new SportsAIAgent();
