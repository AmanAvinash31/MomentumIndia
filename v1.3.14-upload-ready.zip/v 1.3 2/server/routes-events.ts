import type { Express } from "express";
import { requireAdmin } from "./auth";
import { eventsStorage } from "./events-storage";
import { eventsSyncEngine } from "./events-sync";
import { publicCache } from "./cache";

export function registerEventsRoutes(app: Express) {
  /**
   * 100% Dynamic KPI Summary Cards
   */
  app.get("/api/events/summary", publicCache(5, 30), (_req, res) => {
    try {
      const kpis = eventsStorage.getKpis();
      res.json(kpis);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to load events KPIs", message: err?.message });
    }
  });

  /**
   * Filterable Directory List
   */
  app.get("/api/events", publicCache(5, 30), (req, res) => {
    try {
      const {
        category,
        sport,
        state,
        city,
        level,
        verification,
        status,
        search,
        startDate,
        endDate,
        month,
        limit,
        offset,
      } = req.query;

      const result = eventsStorage.list({
        category: category ? String(category) : undefined,
        sport: sport ? String(sport) : undefined,
        state: state ? String(state) : undefined,
        city: city ? String(city) : undefined,
        level: level ? String(level) : undefined,
        verification: verification ? String(verification) : undefined,
        status: status ? String(status) : undefined,
        search: search ? String(search) : undefined,
        startDate: startDate ? String(startDate) : undefined,
        endDate: endDate ? String(endDate) : undefined,
        month: month ? parseInt(String(month), 10) : undefined,
        limit: limit ? parseInt(String(limit), 10) : 500,
        offset: offset ? parseInt(String(offset), 10) : 0,
      });

      res.json({
        events: result.items,
        total: result.total,
        page: Math.floor((parseInt(String(offset || 0), 10)) / (parseInt(String(limit || 500), 10))) + 1,
        telemetryTimestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to list events", message: err?.message });
    }
  });

  /**
   * Map Markers Endpoint
   */
  app.get("/api/events/map", publicCache(10, 60), (req, res) => {
    try {
      const { category, sport, state, level, status, verification, month, search } = req.query;

      const markers = eventsStorage.getMapMarkers({
        category: category ? String(category) : undefined,
        sport: sport ? String(sport) : undefined,
        state: state ? String(state) : undefined,
        level: level ? String(level) : undefined,
        status: status ? String(status) : undefined,
        verification: verification ? String(verification) : undefined,
        month: month ? parseInt(String(month), 10) : undefined,
        search: search ? String(search) : undefined,
      });

      res.json({
        markers,
        count: markers.length,
        telemetryTimestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to load map markers", message: err?.message });
    }
  });

  /**
   * Calendar Multi-Day and Overlap Endpoint
   */
  app.get("/api/events/calendar", publicCache(5, 30), (req, res) => {
    try {
      const { category, sport, state, month, search } = req.query;

      const result = eventsStorage.list({
        category: category ? String(category) : undefined,
        sport: sport ? String(sport) : undefined,
        state: state ? String(state) : undefined,
        month: month ? parseInt(String(month), 10) : undefined,
        search: search ? String(search) : undefined,
        limit: 1000,
      });

      // Compute overlapping events by day
      const dateMap: Record<string, typeof result.items> = {};
      for (const ev of result.items) {
        let curr = new Date(ev.start_date);
        const end = new Date(ev.end_date);
        // Cap range to max 30 days to prevent infinite loops
        let dayCount = 0;
        while (curr <= end && dayCount < 30) {
          const dateStr = curr.toISOString().split("T")[0];
          if (!dateMap[dateStr]) dateMap[dateStr] = [];
          dateMap[dateStr].push(ev);
          curr.setDate(curr.getDate() + 1);
          dayCount++;
        }
      }

      // Identify conflicts (more than 1 event in same city or discipline on same day)
      const conflicts: Record<string, boolean> = {};
      for (const [dateStr, dayEvents] of Object.entries(dateMap)) {
        if (dayEvents.length > 1) {
          const cities = dayEvents.map(e => e.city);
          const hasCityOverlap = cities.some((c, i) => cities.indexOf(c) !== i);
          if (hasCityOverlap) conflicts[dateStr] = true;
        }
      }

      res.json({
        events: result.items,
        total: result.items.length,
        conflicts,
        telemetryTimestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to load calendar events", message: err?.message });
    }
  });

  /**
   * State-by-State 36 Units Breakdown & Completeness
   */
  app.get("/api/events/states", publicCache(10, 60), (_req, res) => {
    try {
      const states = eventsStorage.getStateSummaries();
      res.json({
        states,
        totalStatesCovered: states.filter(s => s.count > 0).length,
        telemetryTimestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to load state summaries", message: err?.message });
    }
  });

  /**
   * Analytics breakdown (Monthly, Sports, Levels)
   */
  app.get("/api/events/analytics", publicCache(10, 60), (_req, res) => {
    try {
      const monthly = eventsStorage.getMonthlyBreakdown();
      const kpis = eventsStorage.getKpis();

      res.json({
        monthly,
        kpis,
        telemetryTimestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to load analytics", message: err?.message });
    }
  });

  /**
   * CSV Data Export
   */
  app.get("/api/events/export/csv", (_req, res) => {
    try {
      const { items } = eventsStorage.list({ limit: 1000 });

      const headers = [
        "Event ID", "Event Name", "Official Name", "Sport", "Discipline",
        "Category", "Competition Level", "Start Date", "End Date", "Country",
        "State / UT", "City", "Venue", "Latitude", "Longitude",
        "Organizer", "Governing Federation", "Status", "Verification",
        "Registration URL", "Official URL"
      ];

      const csvRows = [headers.join(",")];

      for (const ev of items) {
        const row = [
          `"${ev.event_id}"`,
          `"${(ev.event_name || "").replace(/"/g, '""')}"`,
          `"${(ev.official_event_name || "").replace(/"/g, '""')}"`,
          `"${ev.sport}"`,
          `"${ev.discipline || ""}"`,
          `"${ev.sport_category}"`,
          `"${ev.competition_level}"`,
          `"${ev.start_date}"`,
          `"${ev.end_date}"`,
          `"${ev.country}"`,
          `"${ev.state_or_union_territory}"`,
          `"${ev.city}"`,
          `"${(ev.venue || "").replace(/"/g, '""')}"`,
          ev.latitude,
          ev.longitude,
          `"${(ev.organizer || "").replace(/"/g, '""')}"`,
          `"${(ev.governing_federation || "").replace(/"/g, '""')}"`,
          `"${ev.event_status}"`,
          `"${ev.verification_status}"`,
          `"${ev.registration_url || ""}"`,
          `"${ev.official_event_url || ""}"`,
        ];
        csvRows.push(row.join(","));
      }

      const csvContent = csvRows.join("\r\n");

      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", 'attachment; filename="India_Sports_Events_2026.csv"');
      res.send(csvContent);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to export CSV", message: err?.message });
    }
  });

  /**
   * iCalendar (.ics) Export
   */
  app.get("/api/events/export/ics", (_req, res) => {
    try {
      const { items } = eventsStorage.list({ limit: 1000 });

      let ics = "BEGIN:VCALENDAR\r\n";
      ics += "VERSION:2.0\r\n";
      ics += "PRODID:-//The Momentum India//India Sports Events 2026//EN\r\n";
      ics += "CALSCALE:GREGORIAN\r\n";
      ics += "METHOD:PUBLISH\r\n";
      ics += "X-WR-CALNAME:India Sports Events 2026\r\n";
      ics += "X-WR-TIMEZONE:Asia/Kolkata\r\n";

      for (const ev of items) {
        const startFormatted = ev.start_date.replace(/-/g, "");
        // ICS end dates for whole-day events are exclusive, so add 1 day
        const endDateObj = new Date(ev.end_date);
        endDateObj.setDate(endDateObj.getDate() + 1);
        const endFormatted = endDateObj.toISOString().split("T")[0].replace(/-/g, "");

        ics += "BEGIN:VEVENT\r\n";
        ics += `UID:${ev.event_id}@themomentum.in\r\n`;
        ics += `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, "").split(".")[0]}Z\r\n`;
        ics += `DTSTART;VALUE=DATE:${startFormatted}\r\n`;
        ics += `DTEND;VALUE=DATE:${endFormatted}\r\n`;
        ics += `SUMMARY:${ev.event_name} (${ev.sport})\r\n`;
        ics += `LOCATION:${ev.venue ? `${ev.venue}, ` : ""}${ev.city}, ${ev.state_or_union_territory}, India\r\n`;
        ics += `DESCRIPTION:${(ev.event_description || `${ev.event_name} - ${ev.competition_level} level in ${ev.sport}`).replace(/\n/g, "\\n")}\\n\\nLevel: ${ev.competition_level}\\nStatus: ${ev.event_status}\\nVerification: ${ev.verification_status}\r\n`;
        if (ev.official_event_url) {
          ics += `URL:${ev.official_event_url}\r\n`;
        }
        ics += `CATEGORIES:${ev.sport_category},${ev.sport}\r\n`;
        ics += `STATUS:${ev.event_status === "CANCELLED" ? "CANCELLED" : "CONFIRMED"}\r\n`;
        ics += "END:VEVENT\r\n";
      }

      ics += "END:VCALENDAR\r\n";

      res.setHeader("Content-Type", "text/calendar; charset=utf-8");
      res.setHeader("Content-Disposition", 'attachment; filename="India_Sports_Events_2026.ics"');
      res.send(ics);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to export ICS calendar", message: err?.message });
    }
  });

  /**
   * Single Event Details
   */
  app.get("/api/events/:id", publicCache(10, 60), (req, res) => {
    try {
      const eventId = String(req.params.id);
      const event = eventsStorage.getById(eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json(event);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to retrieve event", message: err?.message });
    }
  });

  /**
   * Manual Trigger Telemetry Refresh Endpoint
   */
  // Events sync was public with no throttle at all, and no client calls
  // it. It is now admin-only and throttled to once per 10 minutes.
  let lastEventsSyncAt = 0;
  app.post("/api/events/sync", requireAdmin, async (_req, res) => {
    const now = Date.now();
    if (now - lastEventsSyncAt < 10 * 60 * 1000) {
      return res.json({ success: false, rateLimited: true, message: "Sync already ran recently." });
    }
    lastEventsSyncAt = now;
    try {
      const result = await eventsSyncEngine.runFullSync();
      res.json({
        success: true,
        discovered: result.discovered,
        updated: result.updated,
        timestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to sync events", message: err?.message });
    }
  });

  /**
   * Audit log status
   */
  app.get("/api/events/sync/status", (_req, res) => {
    try {
      const logs = eventsStorage.getLatestSyncAudit();
      res.json({ logs });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to load sync audit", message: err?.message });
    }
  });
}
