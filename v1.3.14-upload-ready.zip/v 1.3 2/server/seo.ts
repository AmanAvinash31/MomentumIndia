import type { Express, Request } from "express";
import { seoFor, sitemapEntries, CRAWL_NAV, SITE_NAME, TAGLINE, type Seo } from "../client/src/lib/seo";
import { articlesStorage } from "./storage";

const esc = (s: string) => s.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

export const CANONICAL_ORIGIN = "https://themomentumindia.com";

/** Public origin, e.g. https://themomentumindia.com. Set SITE_URL in production. */
export function siteUrl(req?: Request) {
  const env = process.env.SITE_URL?.replace(/\/+$/, "");
  if (env) return env;
  if (!req) return CANONICAL_ORIGIN;
  const host = req.get("host");
  if (!host || host.includes("localhost") || host.includes("127.0.0.1") || host.includes("onrender.com")) {
    return CANONICAL_ORIGIN;
  }
  return `${req.protocol}://${host}`;
}

const ABS_KEYS = new Set(["url", "image", "logo", "mainEntityOfPage", "item"]);
function absolutise(v: unknown, origin: string, key = ""): unknown {
  if (typeof v === "string") return ABS_KEYS.has(key) && v.startsWith("/") ? origin + v : v;
  if (Array.isArray(v)) return v.map(x => absolutise(x, origin, key));
  if (v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, absolutise(x, origin, k)]));
  return v;
}

function headTags(s: Seo, origin: string) {
  const url = origin + (s.path === "/" ? "/" : s.path);
  const img = origin + s.image;
  const ld = [...(s.jsonld ?? [])];
  if (s.crumbs?.length) ld.push({ "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [["Home", "/"] as [string, string], ...s.crumbs, [s.h1, s.path] as [string, string]].map(([name, item], i) => ({ "@type": "ListItem", position: i + 1, name, item })) });
  return [
    `<title>${esc(s.title)}</title>`,
    `<meta name="title" content="${esc(s.title)}" />`,
    `<meta name="description" content="${esc(s.description)}" />`,
    s.keywords ? `<meta name="keywords" content="${esc(s.keywords)}" />` : "",
    `<meta name="robots" content="${s.noindex ? "noindex, follow" : "index, follow"}" />`,
    `<link rel="canonical" href="${esc(url)}" />`,
    `<meta property="og:type" content="${s.type === "article" ? "article" : s.type === "profile" ? "profile" : "website"}" />`,
    `<meta property="og:url" content="${esc(url)}" />`,
    `<meta property="og:site_name" content="${SITE_NAME}" />`,
    `<meta property="og:title" content="${esc(s.title)}" />`,
    `<meta property="og:description" content="${esc(s.description)}" />`,
    `<meta property="og:image" content="${esc(img)}" />`,
    `<meta property="og:locale" content="en_IN" />`,
    s.published ? `<meta property="article:published_time" content="${esc(s.published)}" />` : "",
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:url" content="${esc(url)}" />`,
    `<meta name="twitter:title" content="${esc(s.title)}" />`,
    `<meta name="twitter:description" content="${esc(s.description)}" />`,
    `<meta name="twitter:image" content="${esc(img)}" />`,
    ...ld.map(j => `<script type="application/ld+json">${JSON.stringify(absolutise(j, origin)).replace(/</g, "\\u003c")}</script>`),
  ].filter(Boolean).join("\n    ");
}

/** Plain HTML that crawlers and no-JS visitors can read. React replaces it on load. */
function shell(s: Seo) {
  const a = (l: string, h: string) => `<a href="${esc(h)}">${esc(l)}</a>`;
  return `<div class="seo-shell" style="max-width:860px;margin:0 auto;padding:24px 20px;font-family:system-ui,sans-serif;line-height:1.55;color:#e8e6e1;background:#070a14">
  <header><p><a href="/" style="color:#ff9933;font-weight:700;text-decoration:none">${SITE_NAME}</a> · ${esc(TAGLINE)}</p>
  <nav aria-label="Primary"><ul style="display:flex;flex-wrap:wrap;gap:6px 14px;list-style:none;padding:0">${CRAWL_NAV.map(([l, h]) => `<li>${a(l, h)}</li>`).join("")}</ul></nav></header>
  <main>${s.crumbs?.length ? `<nav aria-label="Breadcrumb"><p>${[["Home", "/"], ...s.crumbs].map(([l, h]) => a(l, h)).join(" › ")}</p></nav>` : ""}
  <h1>${esc(s.h1)}</h1>
  ${s.body.map(p => `<p>${esc(p)}</p>`).join("\n  ")}
  ${s.links?.length ? `<ul>${s.links.map(([l, h]) => `<li>${a(l, h)}</li>`).join("")}</ul>` : ""}
  <noscript><p>Turn on JavaScript for interactive medal tables, forms and charts.</p></noscript></main></div>`;
}

export function renderPage(template: string, pathname: string, req: Request) {
  const s = seoFor(pathname);
  const origin = siteUrl(req);
  let html = template
    .replace(/<title>[\s\S]*?<\/title>\s*/i, "")
    .replace(/<!--\s*(?:Primary Search Engine Tags|Open Graph \/ Social Preview|Twitter \/ X Card|Google Knowledge Graph Schema[^>]*)-->\s*/gi, "")
    .replace(/<meta\s+(?:name|property)="(?:title|description|keywords|robots|og:[^"]+|twitter:[^"]+)"[^>]*>\s*/gi, "")
    .replace(/<link\s+rel="canonical"[^>]*>\s*/gi, "")
    .replace(/<script\s+type="application\/ld\+json">[\s\S]*?<\/script>\s*/gi, "");
  html = html.replace(/<head>/i, `<head>\n    <base href="/" />\n    ${headTags(s, origin)}\n    <script>window.__MI_PATH__=1</script>`);
  html = html.replace(/<div id="root"><\/div>/, `<div id="root">${shell(s)}</div>`);
  return { html, status: s.status };
}

export function registerSeoRoutes(app: Express) {
  app.get("/robots.txt", (_req, res) => {
    res.type("text/plain").set("Cache-Control", "public, max-age=3600").send(
      `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\n\nSitemap: ${CANONICAL_ORIGIN}/sitemap.xml\n`);
  });
  app.get("/sitemap.xml", (_req, res) => {
    const o = CANONICAL_ORIGIN;
    const baseEntries = sitemapEntries();
    const existing = new Set(baseEntries.map(e => e.path));
    const entries = [...baseEntries];
    try {
      const dbArticles = articlesStorage.sitemap();
      for (const a of dbArticles) {
        const p = `/news/${a.slug}`;
        if (!existing.has(p)) {
          entries.push({ path: p, lastmod: a.updated_at ? a.updated_at.slice(0, 10) : new Date().toISOString().slice(0, 10), priority: 0.7 });
          existing.add(p);
        }
      }
    } catch {}
    const rows = entries.map(e => `  <url><loc>${esc(o + e.path)}</loc>${e.lastmod ? `<lastmod>${e.lastmod}</lastmod>` : ""}<priority>${e.priority.toFixed(1)}</priority></url>`).join("\n");
    res.type("application/xml").set("Cache-Control", "public, max-age=3600").send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${rows}\n</urlset>\n`);
  });
}
