import type { Express } from "express";
import {
  athletesStorage,
  hallOfFameStorage,
  broadcastStorage,
  fanInteractiveStorage,
  paralympicStorage,
  medalEditionsStorage,
  eventCalendarStorage,
} from "./storage";
import { getEventStatus, getNowIST, formatDateRangeIST } from "../shared/lifecycle";
import { publicCache } from "./cache";
import { z } from "zod";

export function registerDynamicRoutes(app: Express) {
  /**
   * Active and recent Games with dynamic IST lifecycle calculation
   */
  app.get("/api/games/active", publicCache(10, 30), (_req, res) => {
    try {
      const calendarEvents = eventCalendarStorage.list();
      const nowIST = getNowIST();

      const mapped = calendarEvents.map((ev) => {
        const lc = getEventStatus(ev.start_date, ev.end_date, nowIST);
        return {
          id: ev.id,
          name: ev.name,
          shortName: ev.short_name,
          startDate: ev.start_date,
          endDate: ev.end_date,
          dateRange: formatDateRangeIST(ev.start_date, ev.end_date),
          location: ev.location,
          venue: ev.venue,
          featured: ev.featured === 1,
          phase: lc.status, // "Live", "Upcoming", "Concluded" / "Ended"
          status: lc.status,
          isLive: lc.isLive,
          isUpcoming: lc.isUpcoming,
          isEnded: lc.isEnded,
          label: lc.label,
          daysToStart: lc.daysToStart,
          daysSinceEnd: lc.daysSinceEnd,
          source: ev.source,
          sourceUrl: ev.source_url,
          updatedAt: ev.updated_at,
        };
      });

      // Find currently live Games or latest concluded Games
      const liveGames = mapped.filter((g) => g.isLive);
      const upcomingGames = mapped.filter((g) => g.isUpcoming).sort((a, b) => a.startDate.localeCompare(b.startDate));
      const concludedGames = mapped.filter((g) => g.isEnded).sort((a, b) => b.endDate.localeCompare(a.endDate));

      res.json({
        live: liveGames,
        upcoming: upcomingGames,
        concluded: concludedGames,
        activeHub: liveGames[0] || concludedGames[0] || upcomingGames[0],
        telemetryTimestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve active games telemetry", error: err?.message, status: "offline" });
    }
  });

  /**
   * Dynamic schedule across multi-sport competitions
   */
  app.get("/api/schedule", publicCache(10, 30), (req, res) => {
    try {
      const calendarEvents = eventCalendarStorage.list();
      const nowIST = getNowIST();

      const events = calendarEvents.map((ev) => {
        const lc = getEventStatus(ev.start_date, ev.end_date, nowIST);
        return {
          id: ev.id,
          name: ev.name,
          shortName: ev.short_name,
          startDate: ev.start_date,
          endDate: ev.end_date,
          dateRange: formatDateRangeIST(ev.start_date, ev.end_date),
          location: ev.location,
          venue: ev.venue,
          status: lc.status,
          label: lc.label,
          daysToStart: lc.daysToStart,
          daysSinceEnd: lc.daysSinceEnd,
          featured: ev.featured === 1,
          source: ev.source,
          sourceUrl: ev.source_url,
          updatedAt: ev.updated_at,
        };
      });

      res.json({
        schedule: events,
        count: events.length,
        source: "Wikidata, Wikipedia & IOA Official Calendar",
        updatedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve schedule", error: err?.message, status: "offline" });
    }
  });

  /**
   * Dynamic Paralympic telemetry
   */
  app.get("/api/paralympics", publicCache(10, 30), (_req, res) => {
    try {
      const list = paralympicStorage.list();
      const active = list.find((p) => p.year === 2026) || list[0];

      let topAthletes = [];
      let table = [];
      try {
        if (active?.top_athletes_json) topAthletes = JSON.parse(active.top_athletes_json);
        if (active?.table_json) table = JSON.parse(active.table_json);
      } catch {}

      res.json({
        active: active ? {
          ...active,
          topAthletes,
          table,
        } : null,
        editions: list.map((p) => ({
          id: p.id,
          name: p.games_name,
          year: p.year,
          host: p.host,
          dates: p.dates,
          indiaRank: p.india_rank,
          gold: p.gold,
          silver: p.silver,
          bronze: p.bronze,
          total: p.total,
          source: p.source,
        })),
        telemetryTimestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve paralympics telemetry", error: err?.message, status: "offline" });
    }
  });

  /**
   * Dynamic Athlete Directory & Profiles
   */
  app.get("/api/athletes", publicCache(10, 30), (req, res) => {
    try {
      const sport = typeof req.query.sport === "string" ? req.query.sport : undefined;
      const gender = typeof req.query.gender === "string" ? req.query.gender : undefined;
      const search = typeof req.query.q === "string" ? req.query.q : undefined;
      const featured = req.query.featured === "true" ? true : undefined;
      const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 200);
      const offset = Math.max(Number(req.query.offset) || 0, 0);

      const result = athletesStorage.list({ sport, gender, search, featured, limit, offset });

      const parsedAthletes = result.athletes.map((a) => {
        let career = [];
        let honours = [];
        let games = [];
        try { career = JSON.parse(a.career_json); } catch {}
        try { honours = JSON.parse(a.honours_json); } catch {}
        try { games = JSON.parse(a.games); } catch {}

        return {
          slug: a.slug,
          name: a.name,
          sport: a.sport,
          gender: a.gender,
          tagline: a.tagline,
          games,
          career,
          honours,
          isTeam: a.is_team === 1,
          featured: a.featured === 1,
          img: a.img_url || "/img/crowd.webp",
          bio: a.bio,
          medals: {
            G: a.medals_g,
            S: a.medals_s,
            B: a.medals_b,
            total: a.medals_g + a.medals_s + a.medals_b,
          },
          source: a.source,
          sourceUrl: a.source_url,
          updatedAt: a.updated_at,
        };
      });

      res.json({
        athletes: parsedAthletes,
        total: result.total,
        limit,
        offset,
        source: "Momentum India Athlete Telemetry Database",
        updatedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve athletes", error: err?.message, status: "offline" });
    }
  });

  app.get("/api/athletes/:slug", publicCache(10, 30), (req, res) => {
    try {
      const slug = String(req.params.slug).toLowerCase();
      const a = athletesStorage.get(slug);
      if (!a) {
        return res.status(404).json({ message: "Athlete not found", status: "offline" });
      }

      let career = [];
      let honours = [];
      let games = [];
      try { career = JSON.parse(a.career_json); } catch {}
      try { honours = JSON.parse(a.honours_json); } catch {}
      try { games = JSON.parse(a.games); } catch {}

      res.json({
        athlete: {
          slug: a.slug,
          name: a.name,
          sport: a.sport,
          gender: a.gender,
          tagline: a.tagline,
          games,
          career,
          honours,
          isTeam: a.is_team === 1,
          featured: a.featured === 1,
          img: a.img_url || "/img/crowd.webp",
          bio: a.bio,
          medals: {
            G: a.medals_g,
            S: a.medals_s,
            B: a.medals_b,
            total: a.medals_g + a.medals_s + a.medals_b,
          },
          source: a.source,
          sourceUrl: a.source_url,
          updatedAt: a.updated_at,
        },
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve athlete profile", error: err?.message, status: "offline" });
    }
  });

  /**
   * Indian Sports Hall of Fame
   */
  app.get("/api/hall-of-fame", publicCache(10, 30), (_req, res) => {
    try {
      const legends = hallOfFameStorage.list();
      res.json({
        legends,
        source: "Indian Sports Archives & Ministry of Youth Affairs and Sports",
        updatedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve Hall of Fame", error: err?.message, status: "offline" });
    }
  });

  /**
   * Live Broadcaster Guides & Streaming Telemetry
   */
  app.get("/api/watch/schedule", publicCache(10, 30), (req, res) => {
    try {
      const liveOnly = req.query.live === "true";
      const rawBroadcasts = broadcastStorage.list(liveOnly);
      const broadcasts = rawBroadcasts.map((b) => ({
        ...b,
        streaming_platform: b.stream_app,
        official_link: b.stream_url,
        time_window_ist: b.start_time_ist + (b.end_time_ist ? ` – ${b.end_time_ist}` : ""),
        status: b.is_live ? "live" : "soon",
      }));
      res.json({
        broadcasts,
        source: "Official Broadcaster Schedules (Sony Sports, Star Sports, JioHotstar)",
        updatedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve broadcast schedule", error: err?.message, status: "offline" });
    }
  });

  app.get("/api/watch/channels", publicCache(60, 300), (_req, res) => {
    res.json({
      channels: [
        { name: "Sony Sports Ten 1 / 2 / 3", tournaments: "Indian Super League, Hockey India League", app: "SonyLIV & YouTube" },
        { name: "Star Sports 1 / 2 / Hindi", tournaments: "Pro Kabaddi League", app: "Disney+ Hotstar" },
        { name: "Sports18 / Colors Cineplex", tournaments: "Indian Cricket International", app: "JioCinema" },
        { name: "DD Sports (Prasar Bharati)", tournaments: "National Games, Khelo India, Para Sport", app: "Waves & YouTube" },
      ],
      updatedAt: new Date().toISOString(),
    });
  });

  /**
   * Dynamic Fan Zone: Quizzes & Polls
   */
  app.get("/api/fan/quizzes", publicCache(10, 30), (_req, res) => {
    try {
      const questions = fanInteractiveStorage.getQuizRound(5);
      const parsed = questions.map((q) => {
        let options: string[] = [];
        try { options = JSON.parse(q.options_json); } catch {}
        return {
          id: q.id,
          sport: q.sport,
          question: q.question,
          options,
          answerIndex: q.answer_index,
          explanation: q.explanation,
          category: q.category,
        };
      });

      res.json({
        round: parsed,
        source: "Momentum India Dynamic Sports Trivia Engine",
        updatedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve quiz round", error: err?.message, status: "offline" });
    }
  });

  app.get("/api/fan/polls", publicCache(10, 30), (_req, res) => {
    try {
      const polls = fanInteractiveStorage.listPolls("active");
      const parsed = polls.map((p) => {
        let options: string[] = [];
        let votes: Record<string, number> = {};
        try { options = JSON.parse(p.options_json); } catch {}
        try { votes = JSON.parse(p.votes_json); } catch {}
        return {
          id: p.id,
          title: p.title,
          category: p.category,
          options,
          votes,
          status: p.status,
        };
      });

      res.json({
        polls: parsed,
        source: "Momentum India Community Telemetry",
        updatedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve polls", error: err?.message, status: "offline" });
    }
  });

  app.post("/api/fan/polls/:id/vote", (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const optionIndex = parseInt(req.body?.optionIndex, 10);
      if (isNaN(id) || isNaN(optionIndex) || optionIndex < 0) {
        return res.status(400).json({ message: "Invalid poll vote selection" });
      }
      const ok = fanInteractiveStorage.votePoll(id, optionIndex);
      if (!ok) return res.status(404).json({ message: "Poll not found" });

      const poll = fanInteractiveStorage.getPoll(id);
      let votes = {};
      try { votes = JSON.parse(poll?.votes_json || "{}"); } catch {}
      res.json({ ok: true, votes });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to record vote", error: err?.message });
    }
  });

  /**
   * Dynamic Medal Database Overview & History
   */
  app.get("/api/medals/overview", publicCache(10, 30), (_req, res) => {
    try {
      const allEditions = medalEditionsStorage.getAll();

      const oly = allEditions.filter((e) => e.games_type === "olympics");
      const cwg = allEditions.filter((e) => e.games_type === "commonwealth");
      const asian = allEditions.filter((e) => e.games_type === "asian-games");

      const sumMedals = (list: typeof allEditions) =>
        list.reduce(
          (acc, e) => ({
            gold: acc.gold + e.gold,
            silver: acc.silver + e.silver,
            bronze: acc.bronze + e.bronze,
            total: acc.total + e.total,
          }),
          { gold: 0, silver: 0, bronze: 0, total: 0 }
        );

      const olySum = sumMedals(oly);
      const cwgSum = sumMedals(cwg);
      const asianSum = sumMedals(asian);
      const grandSum = sumMedals(allEditions);

      res.json({
        total_medals: grandSum.total,
        telemetry_source: "International Olympic Committee (IOC), OCA & CGF Official Archives",
        updated_at: new Date().toISOString(),
        overview: [
          { key: "oly", name: "Olympic Games", slug: "olympics", gold: olySum.gold, silver: olySum.silver, bronze: olySum.bronze, total: olySum.total, sub: "Since Paris 1900, all at the Summer Games" },
          { key: "asian", name: "Asian Games", slug: "asian-games", gold: asianSum.gold, silver: asianSum.silver, bronze: asianSum.bronze, total: asianSum.total, sub: "All-time since 1951, ranked 5th" },
          { key: "cwg", name: "Commonwealth Games", slug: "commonwealth", gold: cwgSum.gold, silver: cwgSum.silver, bronze: cwgSum.bronze, total: cwgSum.total, sub: "19 Games since 1934, fourth all-time" },
        ],
        totals: {
          olympics: olySum,
          commonwealth: cwgSum,
          asianGames: asianSum,
          grandTotal: grandSum,
        },
        counts: {
          olympicEditions: oly.length,
          cwgEditions: cwg.length,
          asianEditions: asian.length,
        },
        source: "International Olympic Committee (IOC), OCA & CGF Official Archives",
        updatedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve medals overview", error: err?.message, status: "offline" });
    }
  });

  app.get("/api/medals/history/:gamesType", publicCache(10, 30), (req, res) => {
    try {
      const raw = String(req.params.gamesType).toLowerCase();
      const type = raw === "asian" || raw === "asian-games" ? "asian-games" : raw === "oly" || raw === "olympics" ? "olympics" : raw === "cwg" || raw === "commonwealth" ? "commonwealth" : raw;
      const stored = medalEditionsStorage.listByType(type);

      const editions = stored.map(e => ({
        y: e.year,
        host: e.host,
        g: e.gold,
        s: e.silver,
        b: e.bronze,
        rank: e.rank ? (isNaN(+e.rank) ? e.rank : +e.rank) : undefined,
        ath: e.athletes_count ?? undefined,
        dnp: e.status === "dnp",
        upcoming: e.status === "upcoming",
        status: e.status,
      }));

      res.json({
        gamesType: type,
        editions,
        count: editions.length,
        source: "Official Games Archives (IOC / OCA / CGF)",
        telemetry_source: "Official Games Archives (IOC / OCA / CGF)",
        updatedAt: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve medals history", error: err?.message, status: "offline" });
    }
  });
}
