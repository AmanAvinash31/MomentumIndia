import type { Request, Response, NextFunction } from "express";
import { timingSafeEqual } from "node:crypto";
import { verifyManageToken } from "./manage-token";
import { sqlite } from "./storage";

export interface AdminActor {
  id: string | number;
  username: string;
  role: "admin" | "moderator" | "editor";
}

declare global {
  namespace Express {
    interface Request {
      adminActor?: AdminActor;
      manageEmail?: string;
    }
  }
}

// IP-based brute force protection with exponential backoff
interface FailRecord {
  attempts: number;
  lastAttempt: number;
  blockedUntil: number;
}
const adminFails = new Map<string, FailRecord>();

// Periodically clean up old fail records
setInterval(() => {
  const now = Date.now();
  for (const [ip, rec] of adminFails.entries()) {
    if (now - rec.lastAttempt > 60 * 60 * 1000) {
      adminFails.delete(ip);
    }
  }
}, 10 * 60 * 1000).unref();

export function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const token = process.env.ADMIN_TOKEN;
  const ip = req.ip ?? req.socket.remoteAddress ?? "?";
  const now = Date.now();

  const fail = adminFails.get(ip);
  if (fail && fail.blockedUntil > now) {
    const waitSec = Math.ceil((fail.blockedUntil - now) / 1000);
    res.setHeader("Retry-After", String(waitSec));
    res.status(429).json({
      message: `Too many wrong admin attempts. Locked out for ${waitSec} more seconds.`,
    });
    return;
  }

  const authHeader = String(req.get("authorization") ?? "");
  const given = authHeader.replace(/^Bearer\s+/i, "").trim();

  if (!given) {
    res.status(401).json({ message: "Admin authorization required." });
    return;
  }

  // 1. Fallback to ADMIN_TOKEN if configured
  let isAuthorized = false;
  let actorRole: "admin" | "moderator" | "editor" = "admin";
  let actorName = "env_admin";

  if (token && token.length >= 16) {
    const a = Buffer.from(given);
    const b = Buffer.from(token);
    if (a.length === b.length && timingSafeEqual(a, b)) {
      isAuthorized = true;
    }
  }

  // 2. Check named admin accounts in DB if not matched by ADMIN_TOKEN
  if (!isAuthorized) {
    try {
      const user = sqlite.prepare(
        "SELECT id, username, role FROM admin_users WHERE token = ? AND active = 1"
      ).get(given) as { id: number; username: string; role: "admin" | "moderator" | "editor" } | undefined;
      if (user) {
        isAuthorized = true;
        actorRole = user.role;
        actorName = user.username;
      }
    } catch {
      // Table might not exist yet during initial boot
    }
  }

  if (!isAuthorized) {
    const attempts = (fail ? fail.attempts : 0) + 1;
    // Exponential backoff: after 3 failures, wait 2^(attempts-3) seconds up to 15 minutes
    let backoffMs = 0;
    if (attempts >= 3) {
      backoffMs = Math.min(15 * 60 * 1000, Math.pow(2, attempts - 3) * 1000);
    }
    adminFails.set(ip, {
      attempts,
      lastAttempt: now,
      blockedUntil: now + backoffMs,
    });

    res.status(401).json({ message: "Wrong admin token" });
    return;
  }

  // Clear failure records on successful login
  adminFails.delete(ip);

  req.adminActor = {
    id: actorName,
    username: actorName,
    role: actorRole,
  };

  res.set("Cache-Control", "no-store");
  next();
}

/**
 * Middleware: require valid manage token for subscriber / follower routes
 */
export function requireManage(req: Request, res: Response, next: NextFunction): void {
  const emailParam = req.params.email || req.query.email || req.body?.email;
  if (!emailParam || typeof emailParam !== "string") {
    res.status(400).json({ message: "Email is required to manage subscriptions or alerts." });
    return;
  }

  const email = emailParam.trim().toLowerCase();
  const token = (req.get("x-manage-token") || req.query.t || req.body?.token) as string | undefined;

  if (!verifyManageToken(email, token)) {
    res.status(403).json({
      message: "Access forbidden. A valid manage token is required. Use the link sent to your email or manage from the device you used to subscribe.",
    });
    return;
  }

  req.manageEmail = email;
  next();
}
