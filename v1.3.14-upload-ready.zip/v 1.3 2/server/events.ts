import { EventEmitter } from "node:events";

export interface LiveEventPayload {
  type: "medals" | "fixtures" | "result" | "news" | "ping";
  data?: any;
  timestamp: string;
}

class LiveEventsEmitter extends EventEmitter {
  constructor() {
    super();
    // Allow up to 10,000 concurrent SSE clients without node warnings
    this.setMaxListeners(10000);
  }

  broadcast(type: LiveEventPayload["type"], data?: any) {
    const payload: LiveEventPayload = {
      type,
      data,
      timestamp: new Date().toISOString(),
    };
    this.emit("event", payload);
  }
}

export const liveEvents = new LiveEventsEmitter();
