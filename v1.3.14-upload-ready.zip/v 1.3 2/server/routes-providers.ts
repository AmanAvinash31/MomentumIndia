import type { Express } from "express";
import { providerManager } from "./providers/manager";
import { calendarProvider } from "./providers/calendar";
import { wikipediaMedalsProvider } from "./providers/wikipedia-medals";
import { theSportsDbProvider } from "./providers/thesportsdb";
import { gdeltProvider } from "./providers/gdelt";
import { officialLinksProvider } from "./providers/official-links";
import { publicCache } from "./cache";

export function registerProviderRoutes(app: Express) {
  // Calendar: all major games
  app.get("/api/calendar", publicCache(300, 900), (_req, res) => {
    try {
      const events = providerManager.getCalendarEvents();
      res.json({
        events,
        source: "Wikidata & Wikipedia (CC BY-SA)",
        source_url: "https://www.wikidata.org",
        updated_at: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch calendar", error: err?.message });
    }
  });

  // Calendar: next 6 upcoming/live events
  app.get("/api/calendar/coming-up", publicCache(300, 900), (req, res) => {
    try {
      const limit = Math.min(Math.max(Number(req.query.limit) || 6, 1), 20);
      const comingUp = providerManager.getComingUp(limit);
      res.json({
        events: comingUp,
        source: "Wikidata & Wikipedia (CC BY-SA)",
        source_url: "https://www.wikidata.org",
        updated_at: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch coming up events", error: err?.message });
    }
  });

  // Hero Games summary: auto-selects the latest Ended or currently Live major Games
  app.get("/api/hero/games", publicCache(120, 300), (_req, res) => {
    try {
      const hero = providerManager.getLatestGamesHeroSummary();
      res.json(hero);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to compute hero summary", error: err?.message });
    }
  });

  // Medal table for a specific games ID (e.g. asian-games-2026, asian-para-games-2026, etc.)
  app.get("/api/medals/:gamesId", publicCache(120, 300), async (req, res, next) => {
    const gamesId = String(req.params.gamesId).toLowerCase();
    if (gamesId === "overview" || gamesId === "history") {
      return next();
    }
    try {
      const table = providerManager.getMedalTable(gamesId);
      if (!table) {
        return res.status(404).json({
          message: `Medal table for '${gamesId}' not found. Available: asian-games-2026, asian-para-games-2026, paris-2024, tokyo-2020, hangzhou-2022`,
        });
      }
      res.json(table);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve medal table", error: err?.message });
    }
  });

  // Standings: Football (Indian Super League)
  app.get("/api/standings/football", publicCache(600, 1800), async (_req, res) => {
    try {
      const standings = await providerManager.getStandings();
      res.json(standings);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve football standings", error: err?.message });
    }
  });

  // Official verified links and announcements for PKL, HIL, BCCI
  app.get("/api/providers/official-links", publicCache(600, 1800), (_req, res) => {
    try {
      const links = officialLinksProvider.getAll();
      res.json({
        links,
        source: "Official League Portals (PKL, HIL, BCCI)",
        updated_at: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve official links", error: err?.message });
    }
  });

  // GDELT Headlines
  app.get("/api/providers/gdelt-headlines", publicCache(300, 600), (req, res) => {
    try {
      const query = typeof req.query.q === "string" ? req.query.q : "Asian Games India";
      const articles = gdeltProvider.getCachedArticles(query);
      res.json({
        articles,
        query,
        source: "GDELT DOC 2.0 (Open Data)",
        source_url: "https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/",
        updated_at: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to retrieve GDELT headlines", error: err?.message });
    }
  });

  // Public/Admin status of all providers
  app.get("/api/providers/status", (_req, res) => {
    res.json({
      providers: [
        {
          name: "Wikidata Entity API",
          feeds: "Event calendar dates (P580 start, P582 end)",
          schedule: "Daily at 04:00 IST",
          licence: "CC0 (Public Domain)",
          status: "Active",
          source_url: "https://www.wikidata.org",
        },
        {
          name: "Wikipedia MediaWiki API",
          feeds: "Medal tables (India + Top 10)",
          schedule: "Every 15 min (Live) / Every 6 hours (Ended)",
          licence: "CC BY-SA 4.0",
          status: "Active",
          source_url: "https://en.wikipedia.org",
        },
        {
          name: "TheSportsDB",
          feeds: "Indian Super League (ISL 4791) fixtures & standings",
          schedule: "Every 30 min on match days / 6 hours off-season",
          licence: "TheSportsDB Free API Terms",
          status: "Active",
          source_url: "https://www.thesportsdb.com",
        },
        {
          name: "GDELT DOC 2.0",
          feeds: "Global news headlines for major Indian sporting events",
          schedule: "Every 10 min",
          licence: "Open Data (GDELT Project)",
          status: "Active",
          source_url: "https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/",
        },
        {
          name: "Official Portals (PKL, HIL, BCCI)",
          feeds: "Verified official websites, schedule links, and dispatches",
          schedule: "Real-time verified links (no unauthorized scraping)",
          licence: "Official Fair Attribution",
          status: "Active",
          source_url: "https://www.prokabaddi.com",
        },
      ],
      timestamp: new Date().toISOString(),
    });
  });
}
