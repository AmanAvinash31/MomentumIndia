/**
 * Event Calendar Provider (Wikidata & Wikipedia API with local config fallback)
 * Fetches confirmed start (P580) and end (P582) dates from Wikidata entity claims.
 */

import { fetchJsonSafely } from "./safe-fetch";
import type { CalendarEvent, Provider } from "./types";
import { getEventStatus } from "../../shared/lifecycle";
import { eventCalendarStorage } from "../storage";

interface ConfiguredEvent {
  id: string;
  name: string;
  shortName: string;
  startDate: string;
  endDate: string;
  location: string;
  venue?: string;
  wikidataId?: string;
  wikipediaTitle?: string;
  featured: boolean;
}

export const CALENDAR_CONFIG: ConfiguredEvent[] = [
  {
    id: "asian-games-2026",
    name: "20th Asian Games (Aichi-Nagoya 2026)",
    shortName: "Asian Games 2026",
    startDate: "2026-09-19",
    endDate: "2026-10-04",
    location: "Aichi-Nagoya, Japan",
    venue: "Mizuho Athletics Stadium & Nippon Gaishi Hall",
    wikidataId: "Q1189473",
    wikipediaTitle: "2026_Asian_Games",
    featured: true,
  },
  {
    id: "asian-para-games-2026",
    name: "5th Asian Para Games (Aichi-Nagoya 2026)",
    shortName: "Asian Para Games 2026",
    startDate: "2026-10-18",
    endDate: "2026-10-24",
    location: "Aichi-Nagoya, Japan",
    venue: "Mizuho Athletics Stadium & Aichi Prefectural Gymnasium",
    wikidataId: "Q113540700",
    wikipediaTitle: "2026_Asian_Para_Games",
    featured: true,
  },
  {
    id: "glasgow-2026",
    name: "2026 Commonwealth Games (Glasgow)",
    shortName: "Glasgow 2026",
    startDate: "2026-07-23",
    endDate: "2026-08-02",
    location: "Glasgow, Scotland",
    venue: "Scotstoun Stadium & Tollcross International Swimming Centre",
    wikidataId: "Q21070693",
    wikipediaTitle: "2026_Commonwealth_Games",
    featured: true,
  },
  {
    id: "la-2028",
    name: "2028 Summer Olympics (Los Angeles)",
    shortName: "LA 2028",
    startDate: "2028-07-14",
    endDate: "2028-07-30",
    location: "Los Angeles, United States",
    venue: "LA Memorial Coliseum & SoFi Stadium",
    wikidataId: "Q2398850",
    wikipediaTitle: "2028_Summer_Olympics",
    featured: true,
  },
  {
    id: "la-2028-para",
    name: "2028 Summer Paralympics (Los Angeles)",
    shortName: "LA 2028 Paralympics",
    startDate: "2028-08-15",
    endDate: "2028-08-27",
    location: "Los Angeles, United States",
    venue: "LA Memorial Coliseum",
    wikidataId: "Q28790077",
    wikipediaTitle: "2028_Summer_Paralympics",
    featured: false,
  },
  {
    id: "ahmedabad-2030",
    name: "2030 Commonwealth Games (Ahmedabad Centenary)",
    shortName: "Ahmedabad 2030",
    startDate: "2030-10-05",
    endDate: "2030-10-17",
    location: "Ahmedabad, India",
    venue: "Sardar Patel Sports Enclave & Narendra Modi Stadium",
    wikipediaTitle: "2030_Commonwealth_Games",
    featured: true,
  },
  {
    id: "asian-games-2030",
    name: "21st Asian Games (Doha 2030)",
    shortName: "Doha 2030",
    startDate: "2030-11-01",
    endDate: "2030-11-15",
    location: "Doha, Qatar",
    venue: "Khalifa International Stadium & Aspire Zone",
    wikidataId: "Q29388836",
    wikipediaTitle: "2030_Asian_Games",
    featured: true,
  },
  {
    id: "brisbane-2032",
    name: "2032 Summer Olympics (Brisbane)",
    shortName: "Brisbane 2032",
    startDate: "2032-07-23",
    endDate: "2032-08-08",
    location: "Brisbane, Australia",
    venue: "The Gabba & Brisbane Arena",
    wikidataId: "Q30278160",
    wikipediaTitle: "2032_Summer_Olympics",
    featured: false,
  },
];

export class CalendarProvider implements Provider {
  id = "wikidata-calendar";
  name = "Wikidata / Wikipedia Public Event Calendar";

  isConfigured(): boolean {
    return true; // Public API, no key required
  }

  /**
   * Fetches start and end dates from Wikidata Entity Data API for a single QID.
   */
  async fetchFromWikidata(qid: string): Promise<{ start?: string; end?: string; raw?: any }> {
    try {
      const url = `https://www.wikidata.org/wiki/Special:EntityData/${qid}.json`;
      const res = await fetchJsonSafely<any>(url, { timeoutMs: 8000 });
      if (!res.ok || !res.data) {
        return {};
      }

      const entity = res.data?.entities?.[qid];
      if (!entity) return {};

      // Property P580: start time
      const p580 = entity.claims?.P580?.[0]?.mainsnak?.datavalue?.value?.time;
      // Property P582: end time
      const p582 = entity.claims?.P582?.[0]?.mainsnak?.datavalue?.value?.time;

      const cleanDate = (isoStr?: string): string | undefined => {
        if (!isoStr) return undefined;
        // Wikidata formats like "+2026-09-19T00:00:00Z"
        const match = isoStr.match(/([0-9]{4}-[0-9]{2}-[0-9]{2})/);
        return match ? match[1] : undefined;
      };

      return {
        start: cleanDate(p580),
        end: cleanDate(p582),
        raw: entity,
      };
    } catch (err: any) {
      console.warn(`[calendar] Wikidata fetch error for ${qid}:`, err?.message);
      return {};
    }
  }

  /**
   * Syncs all configured events against Wikidata, computes status in IST, and persists.
   */
  async syncAll(): Promise<CalendarEvent[]> {
    const fetchedAt = new Date().toISOString();
    const results: CalendarEvent[] = [];

    for (const cfg of CALENDAR_CONFIG) {
      let startDate = cfg.startDate;
      let endDate = cfg.endDate;
      let source = "Local Verified Calendar Config";
      let sourceUrl = cfg.wikipediaTitle
        ? `https://en.wikipedia.org/wiki/${encodeURIComponent(cfg.wikipediaTitle)}`
        : "https://www.wikidata.org";

      if (cfg.wikidataId) {
        const wd = await this.fetchFromWikidata(cfg.wikidataId);
        if (wd.start) {
          startDate = wd.start;
          source = `Wikidata (P580/P582 Entity ${cfg.wikidataId})`;
          sourceUrl = `https://www.wikidata.org/wiki/${cfg.wikidataId}`;
        }
        if (wd.end) {
          endDate = wd.end;
        }
      }

      const lifecycle = getEventStatus(startDate, endDate);

      const event: CalendarEvent = {
        id: cfg.id,
        name: cfg.name,
        shortName: cfg.shortName,
        startDate,
        endDate,
        location: cfg.location,
        venue: cfg.venue,
        wikidataId: cfg.wikidataId,
        wikipediaTitle: cfg.wikipediaTitle,
        source,
        sourceUrl,
        fetchedAt,
        featured: cfg.featured,
        status: lifecycle.status,
        daysToStart: lifecycle.daysToStart,
        daysSinceEnd: lifecycle.daysSinceEnd,
        label: lifecycle.label,
      };

      // Persist to SQLite
      eventCalendarStorage.upsert({
        id: event.id,
        name: event.name,
        short_name: event.shortName,
        start_date: event.startDate,
        end_date: event.endDate,
        location: event.location,
        venue: event.venue || null,
        wikidata_id: event.wikidataId || null,
        wikipedia_title: event.wikipediaTitle || null,
        source: event.source,
        source_url: event.sourceUrl,
        fetched_at: event.fetchedAt,
        featured: event.featured ? 1 : 0,
        raw_data: JSON.stringify(lifecycle),
      });

      results.push(event);
    }

    return results;
  }

  /**
   * Reads events from storage or falls back to initialized config.
   */
  getEvents(): CalendarEvent[] {
    const stored = eventCalendarStorage.list();
    if (!stored || stored.length === 0) {
      // Return immediate config-based events with current lifecycle
      const now = new Date().toISOString();
      return CALENDAR_CONFIG.map(cfg => {
        const lc = getEventStatus(cfg.startDate, cfg.endDate);
        return {
          id: cfg.id,
          name: cfg.name,
          shortName: cfg.shortName,
          startDate: cfg.startDate,
          endDate: cfg.endDate,
          location: cfg.location,
          venue: cfg.venue,
          wikidataId: cfg.wikidataId,
          wikipediaTitle: cfg.wikipediaTitle,
          source: "Local Verified Calendar Config",
          sourceUrl: cfg.wikipediaTitle
            ? `https://en.wikipedia.org/wiki/${encodeURIComponent(cfg.wikipediaTitle)}`
            : "https://www.wikidata.org",
          fetchedAt: now,
          featured: cfg.featured,
          status: lc.status,
          daysToStart: lc.daysToStart,
          daysSinceEnd: lc.daysSinceEnd,
          label: lc.label,
        };
      });
    }

    return stored.map(s => {
      const lc = getEventStatus(s.start_date, s.end_date);
      return {
        id: s.id,
        name: s.name,
        shortName: s.short_name,
        startDate: s.start_date,
        endDate: s.end_date,
        location: s.location,
        venue: s.venue || undefined,
        wikidataId: s.wikidata_id || undefined,
        wikipediaTitle: s.wikipedia_title || undefined,
        source: s.source,
        sourceUrl: s.source_url,
        fetchedAt: s.fetched_at,
        featured: s.featured === 1,
        status: lc.status,
        daysToStart: lc.daysToStart,
        daysSinceEnd: lc.daysSinceEnd,
        label: lc.label,
      };
    });
  }

  /**
   * Returns the next N upcoming events sorted by start date.
   */
  getComingUp(limit = 6): CalendarEvent[] {
    const events = this.getEvents();
    return events
      .filter(e => e.status === "Upcoming" || e.status === "Live")
      .sort((a, b) => a.startDate.localeCompare(b.startDate))
      .slice(0, limit);
  }
}

export const calendarProvider = new CalendarProvider();
