/**
 * Unified provider types and data contracts for Momentum India
 */

import type { EventStatus } from "../../shared/lifecycle";

export interface Provider {
  id: string;
  name: string;
  isConfigured(): boolean;
}

export interface CalendarEvent {
  id: string;
  name: string;
  shortName: string;
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  location: string;
  venue?: string;
  wikidataId?: string;
  wikipediaTitle?: string;
  source: string;
  sourceUrl: string;
  fetchedAt: string;
  featured: boolean;
  status: EventStatus;
  daysToStart: number;
  daysSinceEnd: number;
  label: string;
}

export interface MedalTableRow {
  rank: number;
  nation: string;
  code?: string;
  gold: number;
  silver: number;
  bronze: number;
  total: number;
}

export interface MedalTableData {
  gamesId: string;
  gamesName: string;
  source: string;
  sourceUrl: string;
  fetchedAt: string;
  isLive: boolean;
  indiaRank?: number;
  indiaMedals?: {
    gold: number;
    silver: number;
    bronze: number;
    total: number;
  };
  medalSportsCount?: number;
  table: MedalTableRow[];
  warnings?: string[];
}

export interface ProviderFixture {
  id: string;
  league: string;
  date: string;
  time?: string;
  home: string;
  away: string;
  venue?: string;
  homeScore?: number;
  awayScore?: number;
  status: "scheduled" | "live" | "final";
  source: string;
  sourceUrl: string;
  fetchedAt: string;
}

export interface ProviderStanding {
  rank: number;
  team: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  points: number;
  goalDiff?: number;
  form?: string;
}

export interface GDELTArticleItem {
  title: string;
  url: string;
  source: string;
  publishedAt: string;
  sport: string;
  summary?: string;
}
