/**
 * Official League Links & Verified Sources Provider
 * For leagues without open free APIs (Pro Kabaddi, Hockey India League, BCCI Cricket),
 * provides direct links to the official sites and aggregates publisher headlines without inventing fixtures.
 */

export interface OfficialLeagueInfo {
  id: string;
  name: string;
  sport: string;
  officialSite: string;
  governingBody: string;
  statusText: string;
  lastVerified: string;
  sourceNote: string;
}

export const OFFICIAL_LEAGUES: Record<string, OfficialLeagueInfo> = {
  pkl: {
    id: "pkl",
    name: "Pro Kabaddi League",
    sport: "Kabaddi",
    officialSite: "https://www.prokabaddi.com",
    governingBody: "Mashal Sports / Amateur Kabaddi Federation of India",
    statusText: "Official fixtures released exclusively on prokabaddi.com. Dabang Delhi won Season 12.",
    lastVerified: "2026-10-08",
    sourceNote: "Official Pro Kabaddi Site & Publisher RSS feeds",
  },
  hil: {
    id: "hil",
    name: "Hockey India League",
    sport: "Hockey",
    officialSite: "https://www.hockeyindia.org",
    governingBody: "Hockey India",
    statusText: "Season 3 scheduled for January 2027 in Bhubaneswar, Hyderabad and Delhi.",
    lastVerified: "2026-10-08",
    sourceNote: "Hockey India Official Communications",
  },
  bcci: {
    id: "bcci",
    name: "Indian Cricket International & Domestic Fixtures",
    sport: "Cricket",
    officialSite: "https://www.bcci.tv",
    governingBody: "Board of Control for Cricket in India",
    statusText: "Full men's and women's bilateral and ICC fixtures published on bcci.tv.",
    lastVerified: "2026-10-08",
    sourceNote: "BCCI Official Website",
  },
};

export function getOfficialLeague(leagueId: string): OfficialLeagueInfo | undefined {
  return OFFICIAL_LEAGUES[leagueId.toLowerCase()];
}

export const officialLinksProvider = {
  get: (leagueId: string): OfficialLeagueInfo | undefined => getOfficialLeague(leagueId),
  getAll: (): OfficialLeagueInfo[] => Object.values(OFFICIAL_LEAGUES),
};
