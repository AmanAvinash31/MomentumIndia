/**
 * Safe HTTP fetch utility with circuit breaker, timeout, and custom User-Agent.
 */

interface CircuitState {
  url: string;
  failures: number;
  lastFailureTime: number;
  state: "CLOSED" | "OPEN" | "HALF_OPEN";
  nextProbeTime: number;
}

const circuitMap = new Map<string, CircuitState>();

export const DEFAULT_USER_AGENT =
  process.env.WIKIPEDIA_USER_AGENT ||
  "MomentumIndia/1.0 (https://momentumindia.org; contact@momentumindia.org)";

export async function fetchWithCircuitBreaker(
  url: string,
  options: {
    timeoutMs?: number;
    headers?: Record<string, string>;
    maxFailures?: number;
    cooldownMs?: number;
  } = {}
): Promise<{ ok: boolean; status: number; text: string; error?: string; stale?: boolean }> {
  const {
    timeoutMs = 10000,
    headers = {},
    maxFailures = 3,
    cooldownMs = 60000,
  } = options;

  let state = circuitMap.get(url);
  if (!state) {
    state = { url, failures: 0, lastFailureTime: 0, state: "CLOSED", nextProbeTime: 0 };
    circuitMap.set(url, state);
  }

  const now = Date.now();
  if (state.state === "OPEN" && now < state.nextProbeTime) {
    return {
      ok: false,
      status: 503,
      text: "",
      error: `Circuit breaker OPEN for ${url}`,
      stale: true,
    };
  }

  if (state.state === "OPEN") {
    state.state = "HALF_OPEN";
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": DEFAULT_USER_AGENT,
        Accept: "application/json, text/plain, */*",
        ...headers,
      },
      signal: controller.signal,
    });
    clearTimeout(timer);

    if (!res.ok) {
      throw new Error(`HTTP ${res.status} ${res.statusText}`);
    }

    const text = await res.text();
    state.failures = 0;
    state.state = "CLOSED";
    return { ok: true, status: res.status, text };
  } catch (err: any) {
    clearTimeout(timer);
    state.failures++;
    state.lastFailureTime = now;
    if (state.failures >= maxFailures) {
      state.state = "OPEN";
      state.nextProbeTime = now + cooldownMs;
    }
    return {
      ok: false,
      status: 500,
      text: "",
      error: err?.message || "Fetch failed",
      stale: true,
    };
  }
}

export async function fetchJsonSafely<T>(
  url: string,
  options: { timeoutMs?: number; headers?: Record<string, string> } = {}
): Promise<{ ok: boolean; data?: T; error?: string; stale?: boolean }> {
  const result = await fetchWithCircuitBreaker(url, options);
  if (!result.ok || !result.text) {
    return { ok: false, error: result.error || "Empty response", stale: result.stale };
  }

  try {
    const parsed = JSON.parse(result.text) as T;
    return { ok: true, data: parsed };
  } catch (e: any) {
    return { ok: false, error: `Invalid JSON: ${e.message}`, stale: true };
  }
}
