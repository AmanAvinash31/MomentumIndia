/**
 * GDELT DOC 2.0 & Optional News APIs Provider
 * Free global event news monitoring for Indian sports milestones.
 */

import { fetchJsonSafely } from "./safe-fetch";
import type { GDELTArticleItem, Provider } from "./types";
import { q } from "../storage";

export class GDELTNewsProvider implements Provider {
  id = "gdelt-doc2";
  name = "GDELT DOC 2.0 Global News API";

  isConfigured(): boolean {
    return true; // Completely free, no API key required
  }

  /**
   * Fetches articles matching a query from GDELT DOC 2.0 API.
   */
  async searchArticles(query: string, sport: string): Promise<GDELTArticleItem[]> {
    const fetchedAt = new Date().toISOString();
    const encoded = encodeURIComponent(`"${query}" India sourcecountry:IN`);
    const url = `https://api.gdeltproject.org/api/v2/doc/doc?query=${encoded}&mode=artlist&format=json&maxrecords=15&timespan=14d`;

    const res = await fetchJsonSafely<{ articles?: any[] }>(url, { timeoutMs: 10000 });
    const items: GDELTArticleItem[] = [];

    if (res.ok && res.data?.articles && Array.isArray(res.data.articles)) {
      for (const a of res.data.articles) {
        if (!a.title || !a.url) continue;

        // Parse seendate YYYYMMDDTHHMMSSZ to ISO
        let pubDate = fetchedAt;
        if (a.seendate && a.seendate.length >= 8) {
          const yr = a.seendate.slice(0, 4);
          const mo = a.seendate.slice(4, 6);
          const da = a.seendate.slice(6, 8);
          pubDate = `${yr}-${mo}-${da}T12:00:00Z`;
        }

        const item: GDELTArticleItem = {
          title: a.title.trim(),
          url: a.url,
          source: a.domain ? `GDELT (${a.domain})` : "GDELT News",
          publishedAt: pubDate,
          sport,
          summary: a.title,
        };

        // Normalize and insert into `agent_news` table
        try {
          q(`
            INSERT INTO agent_news (
              sport, title, summary, source, url, image_url, published_at, sentiment, key_points, source_url, fetched_at, normalized_title
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'positive', '[]', ?, ?, ?)
            ON CONFLICT(id) DO NOTHING
          `).run(
            item.sport, item.title, item.summary || item.title, item.source, item.url, a.socialimage || null,
            item.publishedAt, item.url, fetchedAt, item.title.toLowerCase().trim()
          );
        } catch {}

        items.push(item);
      }
    }

    return items;
  }

  /**
   * Syncs event-specific headlines for major competitions.
   */
  async syncMajorEvents(): Promise<GDELTArticleItem[]> {
    const queries = [
      { q: "Asian Para Games", s: "Para Sports" },
      { q: "Asian Games", s: "General" },
      { q: "Indian Super League", s: "Football" },
      { q: "Khelo India", s: "Youth Sports" },
    ];

    const all: GDELTArticleItem[] = [];
    for (const item of queries) {
      const results = await this.searchArticles(item.q, item.s);
      all.push(...results);
    }
    return all;
  }

  /**
   * Retrieves cached news articles from SQLite.
   */
  getCachedArticles(query?: string): GDELTArticleItem[] {
    try {
      let rows: any[] = [];
      if (query && query.trim()) {
        const pattern = `%${query.trim()}%`;
        rows = q(`
          SELECT title, url, source, published_at, sport, summary
          FROM agent_news
          WHERE (title LIKE ? OR summary LIKE ? OR sport LIKE ?)
          ORDER BY published_at DESC
          LIMIT 20
        `).all(pattern, pattern, pattern) as any[];
      }
      if (!rows || rows.length === 0) {
        rows = q(`
          SELECT title, url, source, published_at, sport, summary
          FROM agent_news
          ORDER BY published_at DESC
          LIMIT 20
        `).all() as any[];
      }
      return rows.map((r) => ({
        title: r.title,
        url: r.url || "",
        source: r.source,
        publishedAt: r.published_at,
        sport: r.sport,
        summary: r.summary,
      }));
    } catch {
      return [];
    }
  }
}

export const gdeltProvider = new GDELTNewsProvider();
