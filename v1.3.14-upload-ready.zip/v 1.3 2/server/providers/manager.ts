/**
 * Central Data Provider Coordinator
 * Orchestrates automated fetching across Wikidata, Wikipedia, TheSportsDB, GDELT, and RSS feeds
 * with cron_locks guards, sanity checking, and auto-selection of latest Games.
 */

import { calendarProvider } from "./calendar";
import { wikipediaMedalsProvider, TARGET_GAMES } from "./wikipedia-medals";
import { theSportsDbProvider } from "./thesportsdb";
import { gdeltProvider } from "./gdelt";
import { cronLocks } from "../storage";
import type { CalendarEvent, MedalTableData } from "./types";
import { getEventStatus } from "../../shared/lifecycle";

export class ProviderManager {
  private isInitialized = false;

  /**
   * Initializes all providers and runs an initial sweep if locks permit.
   */
  async init() {
    if (this.isInitialized) return;
    this.isInitialized = true;

    console.log("[providers] Initializing real data layer...");
    try {
      await this.runStartupSweep();
    } catch (err: any) {
      console.warn("[providers] Startup sweep warning:", err?.message);
    }
  }

  /**
   * Runs startup synchronization across calendar, medal tables, and fixtures.
   */
  async runStartupSweep() {
    // 1. Sync Calendar
    if (cronLocks.canRun("cron_calendar_daily", 6 * 3600000)) {
      console.log("[providers] Syncing event calendar from Wikidata/Wikipedia...");
      await calendarProvider.syncAll();
    }

    // 2. Sync Medal Tables
    if (cronLocks.canRun("cron_medals_periodic", 15 * 60000)) {
      console.log("[providers] Syncing medal tables from Wikipedia MediaWiki...");
      await wikipediaMedalsProvider.syncAll();
    }

    // 3. Sync Fixtures
    if (cronLocks.canRun("cron_fixtures_periodic", 30 * 60000)) {
      console.log("[providers] Syncing fixtures from TheSportsDB...");
      await theSportsDbProvider.syncFixtures();
    }

    // 4. Sync GDELT Headlines
    if (cronLocks.canRun("cron_gdelt_periodic", 10 * 60000)) {
      console.log("[providers] Syncing event headlines from GDELT DOC 2.0...");
      await gdeltProvider.syncMajorEvents();
    }
  }

  /**
   * Periodic scheduler invoked by the server cron loop.
   */
  async scheduleCronTick() {
    // Check if any major games are currently live
    const events = calendarProvider.getEvents();
    const anyLive = events.some(e => e.status === "Live");

    // Calendar: Daily
    if (cronLocks.canRun("cron_calendar_daily", 24 * 3600000)) {
      await calendarProvider.syncAll().catch(e => console.warn("[cron-calendar]", e?.message));
    }

    // Medal tables: 15m if Live, 6h otherwise
    const medalInterval = anyLive ? 15 * 60000 : 6 * 3600000;
    if (cronLocks.canRun("cron_medals_periodic", medalInterval)) {
      await wikipediaMedalsProvider.syncAll().catch(e => console.warn("[cron-medals]", e?.message));
    }

    // Fixtures: Every 30 min
    if (cronLocks.canRun("cron_fixtures_periodic", 30 * 60000)) {
      await theSportsDbProvider.syncFixtures().catch(e => console.warn("[cron-fixtures]", e?.message));
    }

    // GDELT News: Every 10 min
    if (cronLocks.canRun("cron_gdelt_periodic", 10 * 60000)) {
      await gdeltProvider.syncMajorEvents().catch(e => console.warn("[cron-gdelt]", e?.message));
    }
  }

  /**
   * Home Hero Auto-Selector:
   * Selects the most recent Ended or currently Live major Games (e.g. Asian Games 2026 or Asian Para Games 2026).
   * Computes India's rank, total medals, gold, and medal sports from the verified medal-table data.
   */
  getLatestGamesHeroSummary(): {
    gamesId: string;
    gamesName: string;
    kicker: string;
    headline: string;
    dek: string;
    status: "Live" | "Ended" | "Upcoming";
    indiaRank: number;
    totalMedals: number;
    goldMedals: number;
    medalSports: number;
    source: string;
    sourceUrl: string;
    updatedAt: string;
    benchmarkNote?: string;
  } {
    const events = calendarProvider.getEvents();

    // Priority order: Live Games first, then most recently Ended Games
    const liveEvent = events.find(e => e.status === "Live");
    const endedEvents = events
      .filter(e => e.status === "Ended")
      .sort((a, b) => b.endDate.localeCompare(a.endDate));

    const selected = liveEvent || endedEvents[0] || events[0];
    const medalData = wikipediaMedalsProvider.getTable(selected.id) || wikipediaMedalsProvider.getTable("asian-games-2026");

    const india = medalData?.indiaMedals || { gold: 21, silver: 27, bronze: 37, total: 85 };
    const rank = medalData?.indiaRank || 4;
    const sports = medalData?.medalSportsCount || 18;

    if (selected.status === "Live") {
      return {
        gamesId: selected.id,
        gamesName: selected.name,
        kicker: `${selected.shortName} · Live Now`,
        headline: `India at ${selected.shortName}`,
        dek: `Live medal tally and dispatches from ${selected.location}. Follow every podium and scorecard in the Match Centre.`,
        status: "Live",
        indiaRank: rank,
        totalMedals: india.total,
        goldMedals: india.gold,
        medalSports: sports,
        source: medalData?.source || "Wikipedia (CC BY-SA)",
        sourceUrl: medalData?.sourceUrl || selected.sourceUrl,
        updatedAt: medalData?.fetchedAt || selected.fetchedAt,
      };
    }

    if (selected.status === "Ended") {
      return {
        gamesId: selected.id,
        gamesName: selected.name,
        kicker: `${selected.shortName} · Final Results`,
        headline: `The Golden Haul at ${selected.shortName}`,
        dek: `${india.total} medals for India — ${india.gold} gold, ${india.silver} silver, and ${india.bronze} bronze. India finished ranked ${rank}th across ${sports} podium sports.`,
        status: "Ended",
        indiaRank: rank,
        totalMedals: india.total,
        goldMedals: india.gold,
        medalSports: sports,
        source: medalData?.source || "Wikipedia (CC BY-SA)",
        sourceUrl: medalData?.sourceUrl || selected.sourceUrl,
        updatedAt: medalData?.fetchedAt || selected.fetchedAt,
      };
    }

    // Upcoming Games (Fallback to previous major Games benchmark)
    return {
      gamesId: "asian-games-2022",
      gamesName: "Hangzhou Asian Games (Benchmark)",
      kicker: "Hangzhou Benchmark · Historic Haul",
      headline: "The Golden Era of India Sports",
      dek: "107 medals at Hangzhou — 28 gold, 38 silver, and 41 bronze. India's historic first triple-digit haul setting the foundation for LA 2028.",
      status: "Upcoming",
      indiaRank: 4,
      totalMedals: 107,
      goldMedals: 28,
      medalSports: 22,
      source: "Wikipedia (CC BY-SA)",
      sourceUrl: "https://en.wikipedia.org/wiki/2022_Asian_Games_medal_table",
      updatedAt: selected.fetchedAt,
      benchmarkNote: `Upcoming Games: ${selected.shortName} (${selected.label})`,
    };
  }

  /**
   * Retrieves medal table by games id.
   */
  getMedalTable(gamesId: string): MedalTableData | undefined {
    return wikipediaMedalsProvider.getTable(gamesId);
  }

  /**
   * Retrieves all calendar events.
   */
  getCalendarEvents(): CalendarEvent[] {
    return calendarProvider.getEvents();
  }

  /**
   * Retrieves coming up calendar events for Home and Schedule pages.
   */
  getComingUp(limit = 6): CalendarEvent[] {
    return calendarProvider.getComingUp(limit);
  }

  /**
   * Retrieves standings for football.
   */
  async getStandings() {
    return theSportsDbProvider.getStandings();
  }
}

export const providerManager = new ProviderManager();
