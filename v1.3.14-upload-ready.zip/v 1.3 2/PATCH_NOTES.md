# Patch notes — v1.3.14 (on top of v1.3.13)

Base: v1.3.13-patched.zip. One change only: the site's GA4 Measurement ID
is now set in the code, at the owner's request.

## Google Analytics Measurement ID set

- `client/src/lib/analytics.ts`: the Measurement ID now defaults to
  `G-SZCX58T0Z4` (GA4 stream "Momentum India Website", created by the
  owner on 1 Nov 2026). A build-time `VITE_GA_MEASUREMENT_ID`, if set,
  still overrides it, so the ID can be rotated without another code
  change. A Measurement ID is a public identifier — it appears in the
  page source of any GA4 site — so embedding it here exposes no secret.
- `.env.example` and `DEPLOY.md` updated to match: the variable is now
  documented as an optional override, not a requirement.
- Unchanged: the consent gate. Analytics still only loads for visitors
  who accept cookies ("Accept All"); "Essential Only" or no choice still
  means no script and no page view. Nothing else from v1.3.13 changed:
  freshness stamp, image compression, WhatsApp share, Facilities
  pagination and the v1.3.11 homepage are all preserved.
- Deploy note: setting the ID in code is not the same as the live site
  tracking. The live site only starts sending data once this zip is
  deployed (fresh extract, `npm ci`, `npm run build`, restart) and a
  visitor accepts cookies. Verify in GA4 under Reports → Realtime.

## Verification

- Built with NO `VITE_GA_MEASUREMENT_ID` set: the client bundle now
  contains `googletagmanager`, `dataLayer` and `G-SZCX58T0Z4`, proving
  the default ID is active without any environment variable (in v1.3.13
  the same build optimised the gtag code away entirely). Server bundle
  built clean as before. Same sandbox caveat as v1.3.13: `npm ci` needed
  `--ignore-scripts` here (better-sqlite3 native build), server not
  booted end-to-end here; the one pre-existing tsc error in
  `server/routes.ts(139)` is untouched.

# Patch notes — v1.3.13 (on top of v1.3.12)

Base: v1.3.12-patched.zip (Facilities pagination preserved; homepage redesign
from v1.3.11 preserved). This patch covers the four items from the expert
review of 1 Nov 2026: Google Analytics, the freshness stamp, image
compression, and WhatsApp share. Logo, wordmark, tagline and menu titles are
unchanged. The user's data.db is carried over untouched.

## 1. Google Analytics 4 — wired, consent-gated, NOT yet active

- New `client/src/lib/analytics.ts` + an `<Analytics />` mount in
  `client/src/App.tsx`. It loads the GA4 gtag script and sends a page view
  on every route change (SPA-aware: `send_page_view: false` on config, then
  a manual `page_path` event per route, so hash-routing in dev and
  path-routing in production both report correctly).
- Activation needs BOTH of these, and nothing is tracked until both hold:
  (a) a build-time Measurement ID, `VITE_GA_MEASUREMENT_ID=G-XXXXXXXXXX`
  (see `.env.example` and the new DEPLOY.md variable — set it before
  `npm run build` and rebuild after changing it; it is a build-time
  variable, not a runtime one), and (b) the visitor accepting analytics in
  the existing cookie consent banner ("Accept All"). "Essential Only" or
  no choice yet = no script is loaded and no page view is sent. The module
  listens to the banner's existing `momentum_consent_change` event, so a
  visitor who accepts after the page loads starts tracking from the next
  page view without a reload.
- No Measurement ID was invented or supplied in this patch, so with the zip
  as delivered analytics is a complete no-op: the build optimises the gtag
  code away when no ID is set (verified — see Verification below). The
  user must supply their real GA4 Measurement ID and rebuild for any data
  to flow. Anonymised IPs (`anonymize_ip: true`) are set on every event.
- Still a separate, non-code step for the user: submit `/sitemap.xml` to
  Google Search Console and Bing Webmaster Tools, and add the Search
  Console verification if they want the query report. No verification meta
  tag was added here because no Search Console property was supplied.

## 2. Freshness stamp — can no longer go stale on deploy

- `client/src/data/index.ts`: `UPDATED` is no longer hardcoded. It now
  reads `VITE_BUILD_DATE`, falling back to "1 November 2026" only for local
  dev builds that bypass `script/build.ts`. Previously it was hardcoded to
  "17 October 2026", and that single date was used as the sitemap `lastmod`
  for every static page.
- `script/build.ts`: every production build now stamps `VITE_BUILD_DATE`
  with the build day (UTC, "1 November 2026" format), and the server
  (esbuild, CJS) bundle gets the same date via an esbuild `define` — this
  matters because the server bundle renders the sitemap, and CJS has no
  `import.meta.env`, so without the define the server sitemap would have
  kept falling back to the hardcoded date on every future deploy even
  while the client display updated. Verified with a test build dated
  "9 November 2026": both the client bundle and the server bundle carried
  the test date (see Verification).
- News articles already used their own dates in `sitemapEntries()` and
  still do; this change only fixes the static-page and athlete-page
  `lastmod` values that used the blanket date.
- `client/src/lib/seo.ts`: the Asian Para Games 2026 structured data now
  says `eventStatus: EventCompleted` instead of `EventScheduled` — the
  Games ended 24 October 2026. Start/end dates (18–24 Oct 2026) unchanged.

## 3. Image compression — the two largest photos, plus one orphan removed

- New WebP variants, generated from the originals at quality 82:
  `real-nagoya-stadium-800.webp` (70 KB, was 7.46 MB JPG) and
  `-1200.webp` (145 KB); `real-relay-action-800.webp` (69 KB, was
  8.14 MB JPG) and `-1200.webp` (120 KB). That is roughly a 98% saving on
  each file at desktop width.
- `client/src/components/site.tsx` (`Img` component): when no explicit
  `srcSet` is given, these two photos automatically serve the WebP
  variants with sizes "(max-width: 768px) 800px, 1200px". This covers
  every `Img` usage of them, including news article hero images.
  `client/src/pages/home.tsx`: the homepage Events FeatureCard (a raw
  `<img>`, not `Img`) now carries the Nagoya `srcSet` directly. The
  original JPGs are kept as `src` (fallback for older browsers) and remain
  the Open Graph images, so social previews are unchanged.
- Deleted: `client/public/img/real-sumit-antil.jpg` (7.47 MB). It had no
  reference anywhere in the code, content JSON, or data.db (the DB only
  contains the athlete slug "sumit-antil", not this image path), so
  removing it loses nothing on the site. It is still in the v1.3.12 zip
  if it is ever needed again. Net effect on the image folder: about
  7.5 MB removed outright, plus the two big photos now served at ~0.1 MB
  instead of ~8 MB on supporting browsers.
- Deliberately NOT changed: the other photos (e.g. Poovamma 2.2 MB,
  Neeraj LA28 1.5 MB, Glasgow Hampden 1.5 MB) were left alone to keep this
  patch focused on the worst offenders; they are candidates for a
  follow-up pass. No image content or crop changed — these are the same
  photos, recompressed and resized.

## 4. WhatsApp / X / Telegram share on news articles

- New reusable `client/src/components/share-buttons.tsx`: WhatsApp
  (`wa.me` with headline + URL prefilled), X (intent/tweet), Telegram
  (share/url), and Copy link (kept exactly as before, including its
  `button-copy-link` testid). No tracking parameters are added to shared
  URLs, and no data is sent to the site — the share happens in the
  visitor's own app.
- `client/src/pages/news.tsx` (`ArticlePage`): the old copy-only "Share
  story" button is replaced by this share row (next to the existing
  Report button). The old local `copy` handler and `copied` state were
  removed; the component owns copy state now.
- Deliberately partial: share buttons were added to news articles only,
  not to Match Centre result cards or medal pages. Match Centre cards link
  out to external source articles, so a share button there would share
  someone else's article, not a Momentum India page — that needs a
  decision on what the shared link should be before it is built. The
  `ShareButtons` component is ready to reuse on medal pages when that
  decision is made.

## Verification (this patch, unlike earlier ones, was build-verified)

- Fresh working copy from v1.3.12-patched.zip. `npm ci` in this sandbox
  needed `--ignore-scripts`: the `better-sqlite3` native module failed to
  compile here (node-gyp header download failure on Node 24.22.1 in this
  sandbox). The client + server bundles do not need the compiled module
  (it is an external in the server bundle), so `npm run build` then ran
  clean: Vite client build (~21 s) + esbuild server bundle (1.7 MB).
  On a normal deploy host, plain `npm ci` should compile it as before —
  this is a sandbox limitation, not a patch bug, and the server was
  therefore NOT booted end-to-end here. Deploy smoke checks (below) still
  apply.
- Bundle checks: with `VITE_GA_MEASUREMENT_ID=G-TEST123456` (a test ID,
  not a real account) the client bundle contained `googletagmanager`,
  `dataLayer` and the test ID; without any ID set, the gtag code is
  optimised away entirely. With `VITE_BUILD_DATE="9 November 2026"` both
  bundles carried the test date; the clean rebuild carries 1 November
  2026. `wa.me` share intents are present in the news page chunk, and
  `real-nagoya-stadium-1200.webp` is referenced by the homepage chunk.
- `npm run check` (tsc) reports exactly one error, pre-existing in the
  v1.3.12 base and untouched by this patch: `server/routes.ts(139,75)` —
  `fetched_at` does not exist on type `AgentNewsItem`. It does not block
  the Vite/esbuild build (which does not run tsc). Left open, not fixed
  here, to keep this patch to its four items.
- Deliberately left open (from the expert review, not in this patch):
  Google News sitemap, indexable `/facilities/<state>` and
  `/medals/<sport>` URLs, homepage links to Pathway/Sporting Nation/Clubs/
  Women/Para, home.tsx dead-code cleanup, CSP `unsafe-inline`, deterministic
  HMAC manage tokens with no email confirmation (SMTP TODO), Dockerfile
  Node 20 vs engines >= 22, and production `MANAGE_SECRET`/`ADMIN_TOKEN`
  setup (DEPLOY.md still lists only ADMIN_TOKEN for that pair — see the
  maintenance guide note). None of these were changed here.

## Deploy

Fresh extract, `npm ci`, `npm run build`, restart — and, to activate
analytics, set `VITE_GA_MEASUREMENT_ID` to your real GA4 Measurement ID
*before* `npm run build` (it is baked in at build time; changing it later
without rebuilding does nothing). Then smoke-check: (1) open a news
article and confirm WhatsApp/X/Telegram/Copy link buttons appear;
(2) on the homepage, confirm the Events card image loads (it should now
be a ~145 KB WebP on desktop, not the 7.5 MB JPG); (3) after accepting
cookies, confirm in GA4 Realtime that page views arrive — and confirm
nothing is sent with "Essential Only".

# Patch notes — v1.3.12 (on top of v1.3.11)

Base: v1.3.11-patched.zip (itself built from the re-uploaded v1.3.10 zip, so the
v1.3.11 homepage redesign is preserved — this patch does not revert it). Only
`client/src/pages/rise.tsx` and this file changed. Deploy as usual: fresh
extract, `npm ci`, `npm run build`, restart. Verified by code inspection and
brace/paren balance checks only; no npm build was run here.

## Facilities by state (/facilities) — pagination

- The SAI centres list and the Khelo India academies list on the Facilities
  page are now paginated at 12 per page each, using the site's existing
  `PaginationControl` (the same numbered 1, 2, 3… control used for News,
  Medals and the Sports directory in v1.3.7). Previously both lists rendered
  in full on one screen: 99 open SAI centres and 214 Khelo India
  academies with "All states" selected.
- Each list has its own page state, so paging the SAI list does not move the
  academies list and vice versa. The control shows "Showing a–b of N SAI
  centres / Khelo India academies" and hides itself when a filtered list has
  12 or fewer items (e.g. most single-state views).
- Pages reset to 1 whenever the state, sport, All/SAI/Khelo India toggle or
  search text changes, and the displayed page is clamped to the last page of
  the filtered list, so a filter can never land on an empty page.
- Unchanged: the "X results" count (still the filtered total), the state
  summary chips, the "Facilities by state" sidebar (top-15 ranking — clicking
  a state filters the paginated lists), the Contact/Directions actions, and
  the Map view, which still shows all SAI pins (Khelo India academies have no
  coordinates and were never on the map). No server or data change was
  needed; the lists are filtered client-side from the existing facilities
  data.

# Patch notes — v1.3 base, patched (v1.3.1)

Base: the uploaded `v 1.3` zip, used as-is as the starting point. None of the
v0.9.1 patches were in this base — all four issues below were still present
in v1.3 and were fixed here from scratch. The `.git` folder from the upload
was left out of the patched zip to keep it clean; the code itself is unchanged
apart from the items below.

## 1. Asian Games 2026 marked concluded at 21/27/37 everywhere

- `client/src/data/content.json`: `ASIAN_HISTORY` 2026 now 21 gold, 27 silver,
  37 bronze, rank "4th", note "Final results: India finished 4th with 85
  medals (21 gold, 27 silver, 37 bronze) at Aichi-Nagoya 2026." `upcoming`
  removed.
- `client/src/data/index.ts`: the fallback history mapping for 2026 now says
  the same final result / 4th, instead of "Scheduled…".
- Bundled `data.db`: `medal_editions` row `asian-2026` now 21/27/37, total 85,
  status `concluded`, rank 4. The stale `data.db-shm` / `data.db-wal` files
  were checkpointed into the database and removed.
- On a persistent production database, the same correction is applied on
  service restart, because `server/dynamic-sync.ts` `syncMedalEditions()`
  upserts edition history from `content.json` at startup — a production
  `data.db` does not need to be replaced by hand.
- Verified totals, static and database agreeing: Asian Games 864
  (204/266/394), Olympics 41 (10/10/21), Commonwealth 563 (202/190/171).

## 2. CountUp first-paint fix

- `client/src/components/site.tsx`: `CountUp` now renders the final total
  immediately and sets `aria-label` to the same final value. The count-up
  animation was deliberately removed for totals — it briefly showed a wrong
  intermediate value next to its gold/silver/bronze breakdown, and to screen
  readers. The now-unused framer-motion import was removed from `site.tsx`
  only (the package is still in `package.json` for any other use). The
  `duration` prop is kept as an optional, ignored prop so existing callers
  still type-check.

## 3. Athletes — 136 vs 6, and scope label

- `client/src/data/index.ts`: new `mergeAthletes()` helper. It starts from the
  static list, prefers the database record when a slug appears in both (so
  index cards match profile pages, which already prefer the database
  record), adds database-only athletes, and drops a static team entry only
  when a database team of the same sport has a name ending with it
  (database "Indian Men's Hockey Team" supersedes static "Men's hockey team").
- `client/src/pages/athletes.tsx`: uses `mergeAthletes()`, requests
  `/api/athletes?limit=200` (server default was 100), cache key aligned,
  scope note added.
- `client/src/pages/home.tsx`: carousel uses the same merged list; link text
  changed from "All {PEOPLE.length} athletes" to "Browse athletes" with no
  count claim; scope note added.
- Result: the index now shows 138 athletes = 136 static + 2 database-only
  para athletes (Sheetal Devi, Sumit Antil), with the duplicate men's hockey
  team merged. (136 is the static count in this base, same data as v0.9.)
- Scope note wording on both pages: "Medal counts are career medals shown in
  each athlete's timeline, not Olympic-only totals."

## 4. Match Centre slug renamed

- 16 public references to `"/agent"` in `client/src` renamed to
  `"/match-centre"`, including the route in `client/src/App.tsx`, navigation,
  search, site menus, `client/src/pages/live.tsx`, and SEO metadata in
  `client/src/lib/seo.ts`.
- `/agent` remains only as a legacy redirect: `LEGACY` in
  `client/src/lib/seo.ts` now includes `["/agent", "/match-centre"]`, and
  `App.tsx` already renders `LEGACY` as redirects, so old links/bookmarks
  keep working.
- Internal API paths `/api/agent/*` were deliberately NOT renamed.

## Not changed in this patch

- Feed tagging, HTML in excerpts, duplicates and off-topic gossip — feed-pipeline
  work, not part of these four items.
- Asian Para Games 2026 total of 111 — carried over as before, still not
  independently verified.
- This zip contains no `dist/` folder (the v1.3 upload had none either).
  Run the project's normal build (`npm run build`) before deploying, and
  restart the service so the startup sync applies the Asian Games correction
  to a persistent database.

## Post-build checks

Homepage Numbers section, Asian Games tab in Medal history,
`/medals/asian-games`, `/athletes` (result count and scope note), and
`/match-centre` with `/agent` redirecting to it.

---

# Patch notes — v1.3.2 (on top of v1.3.1)

This patch keeps every v1.3.1 fix and adds the two items left open there:
the Asian Para Games 2026 totals, and the feed pipeline.

## 5. Asian Para Games 2026 corrected: 114 medals (30/35/49), rank 4

The 111 (29/31/51, rank 5) in v1.3 was Hangzhou's figure, not Aichi-Nagoya's.
Verified final reporting, 24 Oct 2026 (Times of India, Sportstar, Latestly,
all agreeing): India finished 4th with 114 medals — 30 gold, 35 silver,
49 bronze. China 435 (207/117/111), Japan 186 (64/60/62), Uzbekistan 145
(45/49/51). Previous-best comparisons in those reports differ (108 revised
vs 111 initial for Hangzhou), so no Hangzhou comparison is asserted here.

Changed, so a restart cannot overwrite the correction (the startup sync
upserts these seeds unconditionally):
- `server/dynamic-sync.ts`: `asian-para-games-2026` seed now 30/35/49,
  total 114, rank 4, with the verified top-4 table (not the old generic rows).
- `server/providers/wikipedia-medals.ts`: benchmark for the Para Games now
  4th / 30/35/49/114, plus a `PARA_FINAL_TABLE` used as the fallback for
  that Games only, so a failed live-table fetch never shows generic Asian
  Games rows for Para.
- Bundled `data.db`: `paralympic_telemetry` row and the `medal_tables`
  row for `asian-para-games-2026` both updated to 30/35/49/114, rank 4.
  (The stored medal table was a second place the old 111 survived.)
- `client/src/pages/live.tsx`: Para hub fallbacks now 30/35/49/114, rank 4,
  fallback table is the verified top 4 only, and hard-coded copy fixed
  ("placing 4th overall", "4th in Asia, behind China, Japan, and
  Uzbekistan", "114 medals · Rank 4", wrap-up and top-performers copy).
- `client/src/pages/plus.tsx`: fallbacks now 114 / 30 gold.
- `client/src/lib/seo.ts`: Para hub description no longer claims the
  stale 121-strong squad; it now says final medal tally.

Not changed here: the generic other-nation fallback rows in the medal-table
provider for other Games, and the Asian Games 2026 top-10 other-nation rows
in `client/src/pages/games.tsx` — those were not verified to the same
standard and are left as they were, not presented as newly verified.

## 6. Feed pipeline: tagging, HTML, duplicates, off-topic

Root causes found in v1.3.1 (and confirmed in the bundled database):
- Results were labelled with the *search query* sport, not the story's own
  sport — hence cricket under Cycling, hockey under Archery.
- `cleanText` stripped tags before decoding entities, so excerpts arriving
  as `&lt;li&gt;` survived as literal markup; Google News descriptions
  truncated mid-tag left 108 stored summaries starting with raw `<a href…`
  or `<ol><li>` fragments.
- Deduplication was exact URL or exact lowercase title only, so the same
  story via Google News and via its publisher could appear twice.
- News ingest had no India-relevance or gossip gate, so foreign leagues
  (55 stored "International" rows) and off-topic items reached the wire.

Fixes:
- `server/sports-agent.ts`:
  - `cleanText` now decodes entities before stripping tags, loops, and
    drops a trailing truncated tag — encoded and cut-off markup no longer
    survives as text.
  - New `resolveResultSport()`: a result is stored under the sport its own
    headline/summary classifies to; if it classifies as International it is
    dropped; if it classifies as General it is kept only when the queried
    sport is actually named in the text. Otherwise it is dropped, not
    mislabelled.
  - News ingest now drops International items, off-topic gossip
    (WWE, Bigg Boss, streamers, weight-loss TV, etc.), and stories with no
    Indian athlete, team, event, body, domestic competition or city; an
    excerpt still containing markup after cleaning is stored as null.
  - Results ingest applies the same relabel-or-drop rule and gossip gate.
  - Startup now also re-tags stored results (`reclassifyStoredResults`),
    so old mislabelled rows are corrected or dropped on the next restart,
    not just new ingests.
- `server/storage.ts`:
  - `addNews` / `addResult` now dedupe on normalised title (case and
    punctuation removed) + published date / IST date, not URL alone, and
    store that normalised key.
  - `addNews` applies the markup gate (summary becomes null if nothing
    readable remains).
  - `cleanupAndReclassify` (runs on startup) now also strips markup from
    stored excerpts, deletes International and gossip news rows, and
    collapses duplicates by normalised title + date in both tables.
- Bundled `data.db` cleaned with the same rules, so the shipped database
  is already clean: news 547 → 487 rows (55 International, 5 gossip, plus
  markup repairs; duplicates in results collapsed), results 192 → 182
  rows, stored summaries containing markup 108 → 0, and the 5 Cycling
  rows that were demonstrably not cycling removed (the Para Games story
  among them relabelled to Para Sports, the rest dropped).
- `live_news_archive.json` regenerated from the cleaned news table, so
  the disk backup no longer carries the old markup / International rows.

What this does NOT do: it does not re-verify every individual story, and
it does not guarantee Google News will never return a loosely related
story — it guarantees such a story is relabelled from its own text or
dropped, rather than published under the queried sport. Stories that
classify as "General" but are India-relevant are still shown as General,
not forced into a sport they do not name.

---

# Patch notes — v1.3.3 (on top of v1.3.2)

Theme realignment: the homepage and the menu bar now tell one story, in
order — celebrate the past and get motivated, participate in the present,
prepare for the future. No page, route or link destination was removed;
only ordering, grouping and headings moved.

## 7. Homepage, reordered into three parts

- `client/src/pages/home.tsx`:
  - New `ThemeStrip` directly under the hero: three cards that are also
    the map of the page — "01 Celebrate the past", "02 Participate in the
    present", "03 Prepare for the future" — linking to `#past`, `#present`
    and `#future`.
  - New `ThemeHeading` anchors before each part, so a reader can jump
    straight to the part they came for instead of scrolling a long,
    unordered page.
  - New order (was: Hero, strip, Command Centre, LiveStrip, Numbers, Hubs,
    History, Athletes, Upcoming, Nation/Rise/Plus, Analysis/Hall):
    - Part 1, Celebrate the past: Numbers, HistoryTeaser, Athletes,
      AnalysisAndHall (Hall of Fame lives here).
    - Part 2, Participate in the present: FrontPageCommandCenter
      (Daily Ledger & Match Centre), LiveStrip, Hubs.
    - Part 3, Prepare for the future: Upcoming, NationBand, RiseBand,
      PlusBand.
  - Section kickers retitled to the theme: Numbers and HistoryTeaser now
    "Celebrate the past · …", Athletes now "Celebrate the past · Athletes"
    with the dek "The medallists whose stories motivate the next
    generation.", Hubs now "Participate in the present · Major hubs",
    Upcoming now "Prepare for the future · Coming up".
  - The hero itself is unchanged (it is data-driven: the latest Games),
    and the quick-link strip under the hero is unchanged, so the most-used
    present links are still at the very top.

## 8. Menu bar, realigned to the same three themes

- `client/src/components/site.tsx` (desktop menu) and
  `client/src/components/mobile-nav.tsx` (mobile "More" accordions):
  - Top-level menus are now Celebrate | Participate | News | Prepare
    (labels in `client/src/lib/prefs.tsx`; menu keys are now
    `past` / `present` / `future`, so data-testids become
    `nav-past`, `nav-present`, `nav-future` — update any external test
    that clicks the old `nav-games` / `nav-athletes` / `nav-explore`).
  - Celebrate groups: Medal history (overview, Olympics, Asian Games,
    Commonwealth Games), Legends & moments (Hall of Fame, Golden moments,
    Where champions began, India's Medallists), Records & comparison
    (Nations comparison).
  - Participate groups: Follow live (Match Centre, Events 2026, Leagues,
    Schedule, Where to watch), 2026 Games (Asian Para Games, Asian Games,
    Glasgow), Join in (Fan Zone, My Momentum, Sports Directory, State
    leaderboards).
  - Prepare groups: Next Games (Road to LA 2028, Ahmedabad 2030),
    Start & grow (Pathway, Sporting Nation, Clubs and coaches, Facilities,
    Para sport hub, Women in sport), About & standards (About, FAQ).
  - The footer columns in `site.tsx` use the same three headings, so the
    bottom of the page does not contradict the top.
  - Verified: every link in the new menus matches an existing route in
    `App.tsx`; no destination was added or removed (the old "Sports Desk
    Q&A" duplicate link to Match Centre was the only item dropped, as it
    duplicated Match Centre itself).

## Post-build checks

Homepage in order — hero, three pillar cards, Past (Numbers, History,
Athletes, Hall), Present (Command Centre, LiveStrip, Hubs), Future
(Upcoming, Nation, Rise, Plus) — and each pillar card jumps to its part;
desktop menu shows Celebrate / Participate / News / Prepare with the
groups above, and the mobile "More" panel shows the same three accordions.

---

# Patch notes — v1.3.4 (on top of v1.3.3)

Patches every item from the v1.3.3 review, in the order it was listed.
Where a full fix was not safely possible without breaking a working flow,
the note says exactly what was done instead — see "Deliberately partial"
at the end.

## 9. Light mode and dark mode

- `client/src/lib/prefs.tsx`, `client/src/components/theme-toggle.tsx`:
  Theme is now a real three-way choice — Light, Dark, System — cycling on
  one button. "System" follows the OS and live-updates when the OS theme
  changes. The resolved theme (not the preference) is what existing code
  reads, so maps and other theme-dependent components keep working. The
  button label now states the current choice, e.g. "Theme: System (dark)".
- `client/src/pages/home.tsx`: ThemeStrip pillar cards, Hubs list, History
  chart card, Upcoming cards and the Today ticker now use
  `var(--surface)` / `var(--surface-2)` / `var(--surface-hover)` instead of
  hardcoded dark panels, so they read correctly in light mode (in dark
  mode those variables are the same colours as before).
- `client/src/components/command-center.tsx`: all four pillars and their
  chips/cards converted to theme surfaces and `var(--text)` /
  `var(--text-muted)`, fixing the dark-pillar-with-dark-text case.
- `client/src/pages/events.tsx` and `client/src/components/events/*`:
  the Events page was a fully dark page that ignored the theme choice
  entirely. Its root, hero, KPI cards, filters, calendar, directory, map
  and modal now use theme variables. Events chart axes now use
  `var(--border)` instead of a hardcoded grey.
- Intentionally dark sections (hero, Numbers ledger inside the dark
  Numbers band, athlete cards, dark pills with light text) were left
  alone — they are readable in both modes because their text colours are
  explicit.

## 10. Security

- `server/routes.ts`: `POST /api/subscribe` and `POST /api/follow` no
  longer return the management token — or the full follows list — for an
  email address that already has a record. The token is only issued to
  the browser that created the record, so a stranger who knows someone's
  email can no longer use a fresh POST to take over that account or read
  its WhatsApp number. Existing owners keep the token from their
  original signup. Client code in `action-buttons.tsx` and `plus.tsx`
  now guards against the missing `follows`/`manage_token` fields.
- Per-email rate limit (5 creates/hour) on subscribe/follow, and a
  per-IP limit (60/hour) on `/api/vitals`, which was previously exempt
  from the API rate limiter.
- Honeypot: a hidden `website` field on the newsletter form, rejected
  server-side on subscribe/follow (bots that fill every field are turned
  away as if they succeeded).
- `server/routes-events.ts`: `POST /api/events/sync` was public with no
  throttle and no client calls it. It is now admin-only and throttled to
  once per 10 minutes.
- `server/routes-agent.ts`: agent fetch triggers keep their public
  refresh button (the Match Centre uses it), but now also have a per-IP
  60-second throttle on top of the global one, and the `sport` parameter
  is validated against the listed sports.
- `server/index.ts`: CSP drops `'unsafe-eval'`, adds `object-src 'none'`
  and `base-uri 'self'`. `'unsafe-inline'` remains for styles/scripts
  until inline code is refactored out — see "Deliberately partial".
- `client/src/components/events/events-map.tsx`: event names, venues,
  cities, states, sports, verification status and competition levels are
  HTML-escaped before reaching the Leaflet popup's `innerHTML`, closing
  a stored-XSS path via a crafted event name.

## 11. Information and stats

- New `GET /api/site-status` (`server/routes.ts`): one canonical "last
  updated" stamp, taken from the latest successful feed ingest
  (agent_logs / newest news item). The ticker and footer in
  `client/src/components/site.tsx` now read it, falling back to the old
  hardcoded date only if the endpoint is unreachable. Medal history
  itself is archival and is described as such, not as "updated today".
- Broadcast data: ISL now reads "Sports18 1 HD · JioHotstar" in the
  Command Centre, and the live-page fallback is "JioHotstar / SonyLIV"
  (was "JioCinema / SonyLIV / Hotstar").
- The dated Asian Para Games preview article in `content.json` now opens
  with an editor's note giving the final result (4th, 114 medals,
  30/35/49) and pointing to the Para Games hub, instead of silently
  repeating the pre-Games 121-athlete / 111-medal figures.
- `server/providers/wikipedia-medals.ts`: the generic fallback warning
  now says plainly that India's total is verified but other nations'
  splits are provisional; the Medals page download section carries the
  same note.

## 12. UI, layout and graphics

- Hero image: new responsive variants `hero-javelin-800.webp` (20 KB)
  and `hero-javelin-1200.webp` (33 KB) alongside the 1600 px original,
  wired via `srcSet`/`sizes` on the hero `<img>`; the shared `Img`
  component in `site.tsx` now accepts `srcSet`/`sizes` props for other
  images to use later.
- Homepage length: Nation/Rise/Plus were not collapsed into tabs (that
  would have hidden whole pages behind a new interaction). Instead the
  Future part now has a jump list — What's next / Sporting nation /
  Road to LA 2028 / Para & women — and each band has an anchor id, so
  the long page is navigable in one tap.
- Mobile "More" sheet: four pinned links (Match Centre, News, Medals,
  Schedule) now sit above the long directories.
- About page (`pages/explore.tsx`): the Hindi/Gujarati claim is corrected
  — the site is currently published in English, with Hindi/Gujarati
  planned but not switched on — and a corrections note replaces the
  missing contact email claim: use the Report button or the Standards
  tab correction form.

## 13. Features, accessibility and personalisation

- Report an error: new `ReportButton` in `action-buttons.tsx`, wired to
  the existing `/api/corrections` endpoint and the existing admin
  Corrections table (which is the review queue: status open/resolved,
  visible in `/admin`). It appears on every live wire card and on every
  article page, next to Share story. Reports land as open corrections
  for an editor to resolve — there is no separate feed-moderation UI;
  the corrections table is the queue.
- PWA: new `client/public/manifest.webmanifest` and `sw.js`, linked in
  `client/index.html` and registered in `main.tsx`. The worker caches
  only the shell and static assets (images, fonts, built assets); API
  and admin requests are never cached, so live scores and moderation
  can never be served stale. This makes the site installable; it is not
  a full offline app — schedule and medal pages still need a connection
  for fresh data.
- Accessibility: a visible `:focus-visible` outline rule was already
  present in `index.css` and was verified, not added. The mega-menu,
  chart tooltips and skeleton live-regions were not rebuilt in this
  patch (see below).
- Personalisation shortcut: every Games hub card on the homepage now
  has a Follow button (Games follow), so a reader can follow a Games
  from the hub list instead of only from inside its page.

## Deliberately partial (do not claim these as done)

- Management tokens are still deterministic HMACs of the email, and
  there is still no email confirmation — the SMTP TODO in `routes.ts`
  remains. What changed is that existing accounts can no longer be
  hijacked via a fresh POST. A fully email-verified management flow
  needs a mailer configured first.
- CSP still allows `'unsafe-inline'`; removing it needs inline scripts
  and styles refactored out, which is a separate pass.
- The language switcher is still a stub (`LangSwitch` returns null);
  the About page now says so honestly instead of claiming live editions.
- Chart tooltips are theme-aware in the main charts, but keyboard
  navigation of charts and the mega-menu hover/keyboard audit were not
  rebuilt here.
- This patch was verified by code inspection and balance checks only
  (see below) — run `npm run build` and watch for TypeScript errors
  before deploying, especially around the new theme types and the
  FollowButton-in-Hubs markup.

## 5. Events 2026 Intelligence — graphical upgrade + research pass (v1.3.5)

Research findings first, because they change what the page says:
- The directory listed only 65 events and was missing the four biggest
  2026 stories for Indian sport: the ICC Men's T20 World Cup (co-hosted
  by India), the Glasgow Commonwealth Games, the Aichi-Nagoya Asian
  Games and the Asian Para Games. All four are now in the seed
  (`server/events-seed.ts`) and the bundled DB, with verified dates and
  India's results where verified:
  - T20 World Cup: 7 Feb – 8 Mar 2026, India/Sri Lanka, final at
    Ahmedabad; India beat New Zealand by 96 runs (first back-to-back
    titles, third title overall).
  - Glasgow 2026: 23 Jul – 2 Aug 2026, compact 11-day, 10-sport Games.
  - Asian Games: 19 Sep – 4 Oct 2026, India 4th with 85 (21/27/37).
  - Asian Para Games: 18 – 24 Oct 2026, India 4th with a record 114
    (30/35/49).
- One entry was wrong and has been removed: "38th National Games of
  India 2026" in Dehradun, 28 Jan – 14 Feb 2026. The 38th National
  Games were held in Uttarakhand on those dates in 2025, not 2026
  (PIB closing-ceremony release). It is deleted from the seed and from
  the bundled DB, and `server/events-sync.ts` now deletes that event
  id on startup (`eventsStorage.remove()` in `events-storage.ts`), so
  persistent production databases are cleaned too — the seed upsert
  alone cannot delete a row. The 39th edition's host/dates were left
  out: sources conflicted (Meghalaya vs Chhattisgarh), so no date was
  invented.
- Total is now 68 events (65 − 1 + 4). `getKpis()` now counts states
  and cities only for country = India, so the three overseas Games do
  not inflate the "36 States & UTs" KPI; Indian coverage is still
  exactly 36.

Graphical changes (`client/src/pages/events.tsx`,
`client/src/components/events/events-map.tsx`):
- New "2026 at a glance" section between the hero and the filters:
  flagship cards for the four majors above (click opens the event
  modal, with India's result in the description), a "Next up" line
  pointing at the next event still to come, and a clickable month
  density strip (Jan–Dec bars sized by event count) that jumps to
  that month in the calendar (`#events-calendar` anchor added).
- Map tiles now follow the resolved theme: light-grey canvas in
  light mode, dark-grey in dark mode. Previously the dark tiles were
  used in both modes, which washed the map out in light mode.
- No routes, filters or existing sections were removed. As with
  v1.3.4, no npm build was run here (no installed dependencies in
  this workspace) — run `npm run build` before deploying, and watch
  the new glance section in `events.tsx`.

## 6. Standard menu labels (v1.3.6)

The v1.3.3 theme labels were vague as navigation. The top-level menu
now uses standard, descriptive labels, with the same order and the
same links inside each menu — nothing moved and no destination
changed:
- Celebrate → Medals & History (medal history, legends & moments,
  nations comparison)
- Participate → Live & Games (follow live, 2026 Games, join in)
- News → News (unchanged)
- Prepare → Future & Pathways (next Games, start & grow, about)
Applied in desktop (`lib/prefs.tsx` EXTRA_EN, `components/site.tsx`
footer columns), mobile accordions (`components/mobile-nav.tsx`),
and comments. Internal menu keys (past/present/future) and
data-testids (nav-past etc.) are unchanged, so no test or link
breaks. The homepage's own section headings still use the
Celebrate/Participate/Prepare theme language — that was left alone
deliberately, as this change was scoped to the menu; renaming the
homepage pillars is a separate decision.
As with v1.3.4/5, no npm build was run here — run `npm run build`
before deploying.

## 7. Numbered pagination on every main list (v1.3.7)

Rule applied: no main list stops at one screen of items. Every list
below now shows numbered pages (1, 2, 3…) via the shared
`PaginationControl`, with the page resetting when the filter changes:
- News / Live Sports Wire (`pages/news.tsx`): was one fetched batch
  (60 items) rendered as a single long grid, with the rest of the
  487 stored stories unreachable. Now 12 per page, fetch raised to
  the API maximum of 100, and a "Load older wire stories" button
  pulls further batches through the API's existing `nextCursor`
  (id-based), appending them so the page count grows instead of
  stopping. Archive Reports mode: the remaining stories paginate at
  12 per page under the featured story.
- Match Centre (`pages/agent.tsx`): results tab was every fetched
  result on one long page; news tab the same. Now results paginate
  at 20 per page (fetch raised to the 200 maximum) and news at 12
  per page (fetch raised to 100), each with its own "Load older"
  cursor button. Pages reset when sport or date changes.
- Medals — sport breakdown (`components/charts.tsx` SportBars):
  was top 10 sports plus a "Show all" toggle. Now numbered pages
  of 10 sports, so every sport is reachable on page 1, 2, 3…
- Sports directory (`pages/explore.tsx` Sports): was the whole
  directory on one page. Now 12 per page, resetting on Games filter.
- Already paginated, so unchanged: Athletes index (20 per page),
  Medallist Explorer on the Medals page (20 per page), and the
  Events 2026 directory (8/16/25 per page). Homepage teasers,
  profile "similar athletes", calendar day cells and search
  suggestions are previews, not lists, and were deliberately left
  as short previews with a link to the full paginated list.
No server change was needed: the news/results APIs already
returned `nextCursor`; the clients simply never used it.
As with v1.3.4–6, no npm build was run here — run `npm run build`
before deploying, and watch the new page controls in `news.tsx`
and `agent.tsx`.

## 8. Menu, logo and name restored to the starting zip (v1.3.8)

Standing rule set by the user: do not change the logo, the name, or
the menu titles from the starting zip (v1.3). Applied by restoring
the menu blocks verbatim from that zip:
- Desktop menu back to Games | Athletes | News | Explore
  (`lib/prefs.tsx` EXTRA_EN and `components/site.tsx` NAV), with
  the starting zip's groups: Live & Leagues, Major Games,
  Medallists & Stories, Sports & Standings, Medal History &
  Legends, Next Gen & Grassroots, Community & About.
- Mobile accordions back to Athletes & Stories, Grassroots &
  Next Gen, Community & About (`components/mobile-nav.tsx`).
- Footer columns back to Games, Medal History, Grassroots &
  Stars, Explore & About.
- Logo and name were never changed by any patch and are untouched
  here: the same Logo component, "Momentum India" wordmark and
  "Celebrating the rise of a sporting nation" tagline as the
  starting zip.
Two deliberate exceptions, neither a title: the restored desktop
menu's old "/agent" links point to "/match-centre" (the v1.3.1
route rename), and its "Sports Desk Q&A" item is kept as in the
starting zip (it points to Match Centre, as it did to /agent).
This also reverts the v1.3.3 theme grouping and the v1.3.6
standard labels; internal menu keys and data-testids go back to
nav-games / nav-athletes / nav-explore, so any test written
against the v1.3.3–v1.3.6 keys needs updating back. Everything
else from v1.3.1–v1.3.7 (medals, feed, events, pagination, theme,
security) is unchanged. As before, no npm build was run here —
run `npm run build` before deploying.

## 9. Homepage timeline — classy, motivational treatment (v1.3.9)

Ported from the approved demo restyle into the real homepage
(`client/src/pages/home.tsx` only):
- The flat three pillar cards (`ThemeStrip`) are replaced by a
  vertical `JourneyTimeline`: a gold-to-green thread down the left
  rail with nodes for Then / Now / Next, large uppercase titles
  (CELEBRATE / PARTICIPATE / PREPARE) that still jump to the
  #past / #present / #future sections, and italic mottos:
  "Honour the ones who proved it could be done",
  "History is being written this week — be there for it",
  "The next podium is built in today's training halls."
- Each stage carries its own visual: a tricolour-ribbon medal for
  Celebrate, a live pulse with "Live now" for Participate, and a
  large green calendar-day countdown for Prepare — days to the
  LA 2028 opening ceremony (14 July 2028), computed in calendar
  days, so it reads 622 on 31 Oct 2026, matching the demo.
- Pill links under each stage go to existing routes only
  (medals, athletes, Hall of Fame, Match Centre, Asian Games hub,
  Road to LA 2028, Events 2026, Pathway); the Command Centre pill
  jumps to #present, as the Command Centre is a homepage section.
- Closing creed line under the timeline, as in the demo:
  "Behind every medal is a morning nobody filmed."
- Deliberately unchanged, per the standing rule: logo, name,
  tagline, and the Games | Athletes | News | Explore menu
  (site.tsx / mobile-nav.tsx untouched in this patch). The
  homepage's own section headings still use the Celebrate /
  Participate / Prepare theme language, as before. No new font
  was added: titles use the site's existing display type with
  gold/green accents, so nothing depends on an external font
  fetch. As before, no npm build was run here — run
  `npm run build` before deploying, and check the timeline on
  the homepage at phone width first.

## 10. Timeline 404 + Explore menu columns (v1.3.10)

Applied on top of the user's own v1.3-clean copy (which already
contains v1.3.9). Two fixes, two files only
(`client/src/pages/home.tsx`, `client/src/components/site.tsx`):

1. Celebrate / Participate / Prepare gave a 404 page. Root cause:
   in dev the app routes on the URL hash (`Router hook=
   useHashLocation` in `client/src/App.tsx` — path routing only
   when `window.__MI_PATH__` is set). A plain `<a href="#past">`
   therefore set the route to "/past", which has no page, so the
   catch-all NotFound page rendered. The same bug was present in
   the v1.3.3 pillar cards and in the Future-sections pills.
   Fix: a `jumpTo(id)` helper in home.tsx scrolls to the section
   with `scrollIntoView` instead of navigating. The three
   timeline titles, the Command Centre pill and the four
   Future-sections pills are now buttons calling `jumpTo`.
   This works in both hash mode (dev) and path mode
   (production). The Future-section targets also gained
   `scroll-mt-24` so they no longer land under the sticky header.
2. Explore menu wrapped as 2 rows x 2 columns. Root cause: the
   dropdown grid in `NavDropdown` gave 3 columns only to the
   (old) "past" menu; every other menu, including Explore with
   its 3 groups (Medal History & Legends, Next Gen & Grassroots,
   Community & About), was forced into 2 columns, so the third
   group wrapped onto a second row. Fix: the grid now uses 3
   columns whenever the menu has 3 or more groups
   (`groups.length >= 3`), and 2 columns otherwise — Games and
   Athletes (2 groups each) are unchanged. Explore's groups hold
   5, 6 and 5 items, all within the existing 6-per-group cap, so
   nothing is hidden by the change; on desktop all three columns
   now sit in a single row.
- Unchanged by this patch, per the standing rule: logo, name,
  tagline, and the Games | Athletes | News | Explore menu titles
  and links. The user's bundled data.db is carried over untouched;
  only the transient data.db-shm / data.db-wal files were left
  out of the zip. As before, no npm build was run here — run
  `npm run build` (after `npm ci` in a fresh folder) and check:
  timeline titles scroll instead of 404ing, and the Explore
  dropdown shows 3 columns in 1 row on desktop.

## 11. Homepage redesigned — modern, uncluttered (v1.3.11)

The homepage was 11 stacked sections with three repeated theme
headings, a ticker strip, a timeline and three more bands — that
was the mess. Rebuilt in `client/src/pages/home.tsx` only, on the
pattern of a world-class sports homepage (one hero, proof, a few
big visual cards, live results, athletes):

- Hero: unchanged — the full-bleed javelin photo, cover story
  and glass results band were already the strongest part.
- New `HomeStats`: one clean strip — Olympic 41, Asian Games
  864, Commonwealth 563 (all computed from the existing edition
  data, not hardcoded) and Asian Para Games 2026, 114 (India
  4th, 30/35/49, the verified final result).
- New `FeatureCards`: three large image cards — Medal History
  (/medals), Events 2026 (/events: 68 events, 36 States & UTs,
  the four 2026 majors) and Facilities (/facilities: SAI centres
  and Khelo academies by state). No invented facility counts.
- Then the existing LiveStrip and the Athletes spotlight, and
  nothing else.
- No longer rendered on the homepage: the JourneyTimeline, the
  PostHeroStrip ticker/chips, the three ThemeHeadings, the
  Numbers ledger, HistoryTeaser, AnalysisAndHall, the FrontPage
  Command Centre, Hubs, Upcoming and the Nation / Rise / Plus
  bands. Nothing was deleted from the site: every one of those
  sections still exists as a full page behind the Games |
  Athletes | News | Explore menu (their components are still in
  home.tsx, just not rendered on the homepage). The timeline
  anchors (#past / #present / #future) go with the timeline;
  the Explore menu's 3-column layout from v1.3.10 is untouched.
- Unchanged, per the standing rule: logo, name, tagline and all
  menu titles and links. The user's bundled data.db is carried
  over untouched. As before, no npm build was run here — run
  `npm ci` then `npm run build` in a fresh folder and check the
  homepage top-to-bottom on phone and desktop: hero, stats,
  three cards, live strip, athletes.
